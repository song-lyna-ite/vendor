
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);

var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// .netlify/functions-internal/server/chunks/_/error-500.mjs
var error_500_exports = {};
__export(error_500_exports, {
  template: () => template
});
var _messages, template;
var init_error_500 = __esm({
  ".netlify/functions-internal/server/chunks/_/error-500.mjs"() {
    "use strict";
    _messages = { "appName": "Nuxt", "version": "", "statusCode": 500, "statusMessage": "Server error", "description": "This page is temporarily unavailable." };
    template = (messages) => {
      messages = { ..._messages, ...messages };
      return '<!DOCTYPE html><html lang="en"><head><title>' + messages.statusCode + " - " + messages.statusMessage + " | " + messages.appName + `</title><meta charset="utf-8"><meta content="width=device-width,initial-scale=1.0,minimum-scale=1.0" name="viewport"><style>.spotlight{background:linear-gradient(45deg,#00dc82,#36e4da 50%,#0047e1);filter:blur(20vh)}*,:after,:before{border-color:var(--un-default-border-color,#e5e7eb);border-style:solid;border-width:0;box-sizing:border-box}:after,:before{--un-content:""}html{line-height:1.5;-webkit-text-size-adjust:100%;font-family:ui-sans-serif,system-ui,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol,Noto Color Emoji;font-feature-settings:normal;font-variation-settings:normal;-moz-tab-size:4;tab-size:4;-webkit-tap-highlight-color:transparent}body{line-height:inherit;margin:0}h1{font-size:inherit;font-weight:inherit}h1,p{margin:0}*,:after,:before{--un-rotate:0;--un-rotate-x:0;--un-rotate-y:0;--un-rotate-z:0;--un-scale-x:1;--un-scale-y:1;--un-scale-z:1;--un-skew-x:0;--un-skew-y:0;--un-translate-x:0;--un-translate-y:0;--un-translate-z:0;--un-pan-x: ;--un-pan-y: ;--un-pinch-zoom: ;--un-scroll-snap-strictness:proximity;--un-ordinal: ;--un-slashed-zero: ;--un-numeric-figure: ;--un-numeric-spacing: ;--un-numeric-fraction: ;--un-border-spacing-x:0;--un-border-spacing-y:0;--un-ring-offset-shadow:0 0 transparent;--un-ring-shadow:0 0 transparent;--un-shadow-inset: ;--un-shadow:0 0 transparent;--un-ring-inset: ;--un-ring-offset-width:0px;--un-ring-offset-color:#fff;--un-ring-width:0px;--un-ring-color:rgba(147,197,253,.5);--un-blur: ;--un-brightness: ;--un-contrast: ;--un-drop-shadow: ;--un-grayscale: ;--un-hue-rotate: ;--un-invert: ;--un-saturate: ;--un-sepia: ;--un-backdrop-blur: ;--un-backdrop-brightness: ;--un-backdrop-contrast: ;--un-backdrop-grayscale: ;--un-backdrop-hue-rotate: ;--un-backdrop-invert: ;--un-backdrop-opacity: ;--un-backdrop-saturate: ;--un-backdrop-sepia: }.fixed{position:fixed}.-bottom-1\\/2{bottom:-50%}.left-0{left:0}.right-0{right:0}.grid{display:grid}.mb-16{margin-bottom:4rem}.mb-8{margin-bottom:2rem}.h-1\\/2{height:50%}.max-w-520px{max-width:520px}.min-h-screen{min-height:100vh}.place-content-center{place-content:center}.overflow-hidden{overflow:hidden}.bg-white{--un-bg-opacity:1;background-color:rgb(255 255 255/var(--un-bg-opacity))}.px-8{padding-left:2rem;padding-right:2rem}.text-center{text-align:center}.text-8xl{font-size:6rem;line-height:1}.text-xl{font-size:1.25rem;line-height:1.75rem}.text-black{--un-text-opacity:1;color:rgb(0 0 0/var(--un-text-opacity))}.font-light{font-weight:300}.font-medium{font-weight:500}.leading-tight{line-height:1.25}.font-sans{font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol,Noto Color Emoji}.antialiased{-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}@media (prefers-color-scheme:dark){.dark\\:bg-black{--un-bg-opacity:1;background-color:rgb(0 0 0/var(--un-bg-opacity))}.dark\\:text-white{--un-text-opacity:1;color:rgb(255 255 255/var(--un-text-opacity))}}@media (min-width:640px){.sm\\:px-0{padding-left:0;padding-right:0}.sm\\:text-4xl{font-size:2.25rem;line-height:2.5rem}}</style><script>!function(){const e=document.createElement("link").relList;if(!(e&&e.supports&&e.supports("modulepreload"))){for(const e of document.querySelectorAll('link[rel="modulepreload"]'))r(e);new MutationObserver((e=>{for(const o of e)if("childList"===o.type)for(const e of o.addedNodes)"LINK"===e.tagName&&"modulepreload"===e.rel&&r(e)})).observe(document,{childList:!0,subtree:!0})}function r(e){if(e.ep)return;e.ep=!0;const r=function(e){const r={};return e.integrity&&(r.integrity=e.integrity),e.referrerPolicy&&(r.referrerPolicy=e.referrerPolicy),"use-credentials"===e.crossOrigin?r.credentials="include":"anonymous"===e.crossOrigin?r.credentials="omit":r.credentials="same-origin",r}(e);fetch(e.href,r)}}();</script></head><body class="antialiased bg-white dark:bg-black dark:text-white font-sans grid min-h-screen overflow-hidden place-content-center text-black"><div class="-bottom-1/2 fixed h-1/2 left-0 right-0 spotlight"></div><div class="max-w-520px text-center"><h1 class="font-medium mb-8 sm:text-10xl text-8xl">` + messages.statusCode + '</h1><p class="font-light leading-tight mb-16 px-8 sm:px-0 sm:text-4xl text-xl">' + messages.description + "</p></div></body></html>";
    };
  }
});

// .netlify/functions-internal/server/chunks/virtual/global-sources.mjs
var global_sources_exports = {};
__export(global_sources_exports, {
  sources: () => sources
});
var sources;
var init_global_sources = __esm({
  ".netlify/functions-internal/server/chunks/virtual/global-sources.mjs"() {
    "use strict";
    sources = [
      {
        "context": {
          "name": "sitemap:urls",
          "description": "Set with the `sitemap.urls` config."
        },
        "urls": [],
        "sourceType": "user"
      },
      {
        "context": {
          "name": "nuxt:pages",
          "description": "Generated from your static page files.",
          "tips": [
            "Can be disabled with `{ excludeAppSources: ['nuxt:pages'] }`."
          ]
        },
        "urls": [
          {
            "loc": "/dashboard"
          },
          {
            "loc": "/error"
          },
          {
            "loc": "/"
          },
          {
            "loc": "/map"
          },
          {
            "loc": "/profile"
          }
        ],
        "sourceType": "app"
      }
    ];
  }
});

// .netlify/functions-internal/server/chunks/virtual/child-sources.mjs
var child_sources_exports = {};
__export(child_sources_exports, {
  sources: () => sources2
});
var sources2;
var init_child_sources = __esm({
  ".netlify/functions-internal/server/chunks/virtual/child-sources.mjs"() {
    "use strict";
    sources2 = {};
  }
});

// .netlify/functions-internal/server/chunks/build/client.manifest.mjs
var client_manifest_exports = {};
__export(client_manifest_exports, {
  default: () => client_manifest
});
var client_manifest;
var init_client_manifest = __esm({
  ".netlify/functions-internal/server/chunks/build/client.manifest.mjs"() {
    "use strict";
    client_manifest = {
      "_BpZdOYyO.js": {
        "resourceType": "script",
        "module": true,
        "prefetch": true,
        "preload": true,
        "file": "BpZdOYyO.js",
        "name": "index",
        "imports": [
          "node_modules/nuxt/dist/app/entry.js",
          "_CeNKJV1O.js"
        ]
      },
      "_CeNKJV1O.js": {
        "resourceType": "script",
        "module": true,
        "prefetch": true,
        "preload": true,
        "file": "CeNKJV1O.js",
        "name": "vue.8fc199ce",
        "imports": [
          "node_modules/nuxt/dist/app/entry.js"
        ]
      },
      "_gF8IN1Dv.js": {
        "resourceType": "script",
        "module": true,
        "prefetch": true,
        "preload": true,
        "file": "gF8IN1Dv.js",
        "name": "composables",
        "imports": [
          "node_modules/nuxt/dist/app/entry.js"
        ]
      },
      "_jPs5lTbA.js": {
        "resourceType": "script",
        "module": true,
        "prefetch": true,
        "preload": true,
        "file": "jPs5lTbA.js",
        "name": "cookie",
        "imports": [
          "node_modules/nuxt/dist/app/entry.js"
        ]
      },
      "layouts/default.vue": {
        "resourceType": "script",
        "module": true,
        "prefetch": true,
        "preload": true,
        "file": "BrlESLTs.js",
        "name": "default",
        "src": "layouts/default.vue",
        "isDynamicEntry": true,
        "imports": [
          "node_modules/nuxt/dist/app/entry.js",
          "_jPs5lTbA.js"
        ],
        "dynamicImports": [
          "services/AuthService.js",
          "services/BaseService.js",
          "services/UserService.js",
          "transformers/AuthTransformer.js",
          "transformers/UserTransformer.js"
        ],
        "css": [
          "default.694jUuxS.css"
        ]
      },
      "default.694jUuxS.css": {
        "file": "default.694jUuxS.css",
        "resourceType": "style",
        "prefetch": true,
        "preload": true
      },
      "middleware/authenticate.js": {
        "resourceType": "script",
        "module": true,
        "prefetch": true,
        "preload": true,
        "file": "CoTAcTfK.js",
        "name": "authenticate",
        "src": "middleware/authenticate.js",
        "isDynamicEntry": true,
        "imports": [
          "node_modules/nuxt/dist/app/entry.js",
          "_jPs5lTbA.js"
        ]
      },
      "middleware/redirectIfAuthenticated.js": {
        "resourceType": "script",
        "module": true,
        "prefetch": true,
        "preload": true,
        "file": "ChydRkG5.js",
        "name": "redirectIfAuthenticated",
        "src": "middleware/redirectIfAuthenticated.js",
        "isDynamicEntry": true,
        "imports": [
          "node_modules/nuxt/dist/app/entry.js",
          "_jPs5lTbA.js"
        ]
      },
      "node_modules/@fortawesome/fontawesome-free/webfonts/fa-brands-400.ttf": {
        "resourceType": "font",
        "mimeType": "font/ttf",
        "file": "fa-brands-400.Dur5g48u.ttf",
        "src": "node_modules/@fortawesome/fontawesome-free/webfonts/fa-brands-400.ttf"
      },
      "node_modules/@fortawesome/fontawesome-free/webfonts/fa-brands-400.woff2": {
        "resourceType": "font",
        "mimeType": "font/woff2",
        "file": "fa-brands-400.O7nZalfM.woff2",
        "src": "node_modules/@fortawesome/fontawesome-free/webfonts/fa-brands-400.woff2"
      },
      "node_modules/@fortawesome/fontawesome-free/webfonts/fa-regular-400.ttf": {
        "resourceType": "font",
        "mimeType": "font/ttf",
        "file": "fa-regular-400.Bf3rG5Nx.ttf",
        "src": "node_modules/@fortawesome/fontawesome-free/webfonts/fa-regular-400.ttf"
      },
      "node_modules/@fortawesome/fontawesome-free/webfonts/fa-regular-400.woff2": {
        "resourceType": "font",
        "mimeType": "font/woff2",
        "file": "fa-regular-400.DgEfZSYE.woff2",
        "src": "node_modules/@fortawesome/fontawesome-free/webfonts/fa-regular-400.woff2"
      },
      "node_modules/@fortawesome/fontawesome-free/webfonts/fa-solid-900.ttf": {
        "resourceType": "font",
        "mimeType": "font/ttf",
        "file": "fa-solid-900.BV3CbEM2.ttf",
        "src": "node_modules/@fortawesome/fontawesome-free/webfonts/fa-solid-900.ttf"
      },
      "node_modules/@fortawesome/fontawesome-free/webfonts/fa-solid-900.woff2": {
        "resourceType": "font",
        "mimeType": "font/woff2",
        "file": "fa-solid-900.DOQJEhcS.woff2",
        "src": "node_modules/@fortawesome/fontawesome-free/webfonts/fa-solid-900.woff2"
      },
      "node_modules/@fortawesome/fontawesome-free/webfonts/fa-v4compatibility.ttf": {
        "resourceType": "font",
        "mimeType": "font/ttf",
        "file": "fa-v4compatibility.B9MWI-E6.ttf",
        "src": "node_modules/@fortawesome/fontawesome-free/webfonts/fa-v4compatibility.ttf"
      },
      "node_modules/@fortawesome/fontawesome-free/webfonts/fa-v4compatibility.woff2": {
        "resourceType": "font",
        "mimeType": "font/woff2",
        "file": "fa-v4compatibility.BX8XWJtE.woff2",
        "src": "node_modules/@fortawesome/fontawesome-free/webfonts/fa-v4compatibility.woff2"
      },
      "node_modules/nuxt/dist/app/components/error-404.vue": {
        "resourceType": "script",
        "module": true,
        "prefetch": true,
        "preload": true,
        "file": "CX73cbTB.js",
        "name": "error-404",
        "src": "node_modules/nuxt/dist/app/components/error-404.vue",
        "isDynamicEntry": true,
        "imports": [
          "node_modules/nuxt/dist/app/entry.js",
          "_CeNKJV1O.js"
        ],
        "css": []
      },
      "error-404.CoZKRZXM.css": {
        "file": "error-404.CoZKRZXM.css",
        "resourceType": "style",
        "prefetch": true,
        "preload": true
      },
      "node_modules/nuxt/dist/app/components/error-500.vue": {
        "resourceType": "script",
        "module": true,
        "prefetch": true,
        "preload": true,
        "file": "HmM5I0HV.js",
        "name": "error-500",
        "src": "node_modules/nuxt/dist/app/components/error-500.vue",
        "isDynamicEntry": true,
        "imports": [
          "node_modules/nuxt/dist/app/entry.js",
          "_CeNKJV1O.js"
        ],
        "css": []
      },
      "error-500.D6506J9O.css": {
        "file": "error-500.D6506J9O.css",
        "resourceType": "style",
        "prefetch": true,
        "preload": true
      },
      "node_modules/nuxt/dist/app/entry.js": {
        "resourceType": "script",
        "module": true,
        "prefetch": true,
        "preload": true,
        "file": "BmrEEJaX.js",
        "name": "entry",
        "src": "node_modules/nuxt/dist/app/entry.js",
        "isEntry": true,
        "dynamicImports": [
          "middleware/authenticate.js",
          "middleware/redirectIfAuthenticated.js",
          "layouts/default.vue",
          "node_modules/nuxt/dist/app/components/error-404.vue",
          "node_modules/nuxt/dist/app/components/error-500.vue"
        ],
        "_globalCSS": true
      },
      "pages/dashboard/index.vue": {
        "resourceType": "script",
        "module": true,
        "prefetch": true,
        "preload": true,
        "file": "KoQR2iJu.js",
        "name": "index",
        "src": "pages/dashboard/index.vue",
        "isDynamicEntry": true,
        "imports": [
          "node_modules/nuxt/dist/app/entry.js",
          "_BpZdOYyO.js",
          "_CeNKJV1O.js"
        ]
      },
      "pages/error.vue": {
        "resourceType": "script",
        "module": true,
        "prefetch": true,
        "preload": true,
        "file": "DdW0X8km.js",
        "name": "error",
        "src": "pages/error.vue",
        "isDynamicEntry": true,
        "imports": [
          "node_modules/nuxt/dist/app/entry.js"
        ]
      },
      "pages/index.vue": {
        "resourceType": "script",
        "module": true,
        "prefetch": true,
        "preload": true,
        "file": "ByOI7bdS.js",
        "name": "index",
        "src": "pages/index.vue",
        "isDynamicEntry": true,
        "imports": [
          "node_modules/nuxt/dist/app/entry.js",
          "_BpZdOYyO.js",
          "_CeNKJV1O.js"
        ],
        "css": []
      },
      "index.CmVDYuI5.css": {
        "file": "index.CmVDYuI5.css",
        "resourceType": "style",
        "prefetch": true,
        "preload": true
      },
      "pages/map/index.vue": {
        "resourceType": "script",
        "module": true,
        "prefetch": true,
        "preload": true,
        "file": "Cqbh0txe.js",
        "name": "index",
        "src": "pages/map/index.vue",
        "isDynamicEntry": true,
        "imports": [
          "node_modules/nuxt/dist/app/entry.js",
          "_BpZdOYyO.js",
          "_CeNKJV1O.js"
        ]
      },
      "pages/profile/index.vue": {
        "resourceType": "script",
        "module": true,
        "prefetch": true,
        "preload": true,
        "file": "BhndYuRX.js",
        "name": "index",
        "src": "pages/profile/index.vue",
        "isDynamicEntry": true,
        "imports": [
          "node_modules/nuxt/dist/app/entry.js",
          "_BpZdOYyO.js",
          "_CeNKJV1O.js"
        ]
      },
      "services/AuthService.js": {
        "resourceType": "script",
        "module": true,
        "prefetch": true,
        "preload": true,
        "file": "DpF042FE.js",
        "name": "AuthService",
        "src": "services/AuthService.js",
        "isDynamicEntry": true,
        "imports": [
          "services/BaseService.js",
          "node_modules/nuxt/dist/app/entry.js",
          "_jPs5lTbA.js"
        ]
      },
      "services/BaseService.js": {
        "resourceType": "script",
        "module": true,
        "prefetch": true,
        "preload": true,
        "file": "Da4lTb-Y.js",
        "name": "BaseService",
        "src": "services/BaseService.js",
        "isDynamicEntry": true,
        "imports": [
          "node_modules/nuxt/dist/app/entry.js",
          "_jPs5lTbA.js"
        ]
      },
      "services/UserService.js": {
        "resourceType": "script",
        "module": true,
        "prefetch": true,
        "preload": true,
        "file": "D1Jcs3OJ.js",
        "name": "UserService",
        "src": "services/UserService.js",
        "isDynamicEntry": true,
        "imports": [
          "services/BaseService.js",
          "node_modules/nuxt/dist/app/entry.js",
          "_jPs5lTbA.js"
        ]
      },
      "transformers/AuthTransformer.js": {
        "resourceType": "script",
        "module": true,
        "prefetch": true,
        "preload": true,
        "file": "DsNd0CGt.js",
        "name": "AuthTransformer",
        "src": "transformers/AuthTransformer.js",
        "isDynamicEntry": true,
        "imports": [
          "_gF8IN1Dv.js",
          "node_modules/nuxt/dist/app/entry.js"
        ]
      },
      "transformers/UserTransformer.js": {
        "resourceType": "script",
        "module": true,
        "prefetch": true,
        "preload": true,
        "file": "DRV8WCHV.js",
        "name": "UserTransformer",
        "src": "transformers/UserTransformer.js",
        "isDynamicEntry": true,
        "imports": [
          "_gF8IN1Dv.js",
          "node_modules/nuxt/dist/app/entry.js"
        ]
      }
    };
  }
});

// .netlify/functions-internal/server/chunks/build/index--DdJWkO-.mjs
import { composableNames, unpackMeta } from "@unhead/shared";
import { ref, watchEffect, watch, getCurrentInstance } from "vue";
function useHead(input, options = {}) {
  const head = options.head || injectHead();
  if (head) {
    if (!head.ssr)
      return clientUseHead(head, input, options);
    return head.push(input, options);
  }
}
function clientUseHead(head, input, options = {}) {
  const deactivated = ref(false);
  const resolvedInput = ref({});
  watchEffect(() => {
    resolvedInput.value = deactivated.value ? {} : resolveUnrefHeadInput(input);
  });
  const entry2 = head.push(resolvedInput.value, options);
  watch(resolvedInput, (e) => {
    entry2.patch(e);
  });
  getCurrentInstance();
  return entry2;
}
function useSeoMeta(input, options) {
  const { title, titleTemplate, ...meta } = input;
  return useHead({
    title,
    titleTemplate,
    // @ts-expect-error runtime type
    _flatMeta: meta
  }, {
    ...options,
    transform(t) {
      const meta2 = unpackMeta({ ...t._flatMeta });
      delete t._flatMeta;
      return {
        // @ts-expect-error runtime type
        ...t,
        meta: meta2
      };
    }
  });
}
var coreComposableNames;
var init_index_DdJWkO = __esm({
  ".netlify/functions-internal/server/chunks/build/index--DdJWkO-.mjs"() {
    "use strict";
    init_server();
    coreComposableNames = [
      "injectHead"
    ];
    ({
      "@unhead/vue": [...coreComposableNames, ...composableNames]
    });
  }
});

// .netlify/functions-internal/server/chunks/build/index-D704dL8k.mjs
var index_D704dL8k_exports = {};
__export(index_D704dL8k_exports, {
  default: () => _sfc_main
});
import { ssrRenderAttrs } from "vue/server-renderer";
import { useI18n } from "vue-i18n";
import { useSSRContext } from "vue";
import "@unhead/shared";
import "consola/core";
import "unhead";
import "vue-router";
import "dayjs";
import "dayjs/plugin/updateLocale.js";
import "dayjs/plugin/utc.js";
var _sfc_main, _sfc_setup;
var init_index_D704dL8k = __esm({
  ".netlify/functions-internal/server/chunks/build/index-D704dL8k.mjs"() {
    "use strict";
    init_index_DdJWkO();
    init_server();
    init_nitro();
    _sfc_main = {
      __name: "index",
      __ssrInlineRender: true,
      setup(__props) {
        const { t } = useI18n();
        useSeoMeta({
          titleTemplate: (title) => {
            return `${title} | ${t("page.dashboard")}`;
          }
        });
        return (_ctx, _push, _parent, _attrs) => {
          _push(`<div${ssrRenderAttrs(_attrs)}>Dashboard</div>`);
        };
      }
    };
    _sfc_setup = _sfc_main.setup;
    _sfc_main.setup = (props, ctx) => {
      const ssrContext = useSSRContext();
      (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/dashboard/index.vue");
      return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
    };
  }
});

// .netlify/functions-internal/server/chunks/build/error-CiqhZn6d.mjs
var error_CiqhZn6d_exports = {};
__export(error_CiqhZn6d_exports, {
  default: () => error
});
import { ssrRenderAttrs as ssrRenderAttrs2 } from "vue/server-renderer";
import { useSSRContext as useSSRContext2 } from "vue";
import "consola/core";
import "unhead";
import "@unhead/shared";
import "vue-router";
import "dayjs";
import "dayjs/plugin/updateLocale.js";
import "dayjs/plugin/utc.js";
import "vue-i18n";
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs2(_attrs)}><p>Error</p></div>`);
}
var _sfc_main2, _sfc_setup2, error;
var init_error_CiqhZn6d = __esm({
  ".netlify/functions-internal/server/chunks/build/error-CiqhZn6d.mjs"() {
    "use strict";
    init_server();
    init_nitro();
    _sfc_main2 = {};
    _sfc_setup2 = _sfc_main2.setup;
    _sfc_main2.setup = (props, ctx) => {
      const ssrContext = useSSRContext2();
      (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/error.vue");
      return _sfc_setup2 ? _sfc_setup2(props, ctx) : void 0;
    };
    error = /* @__PURE__ */ _export_sfc(_sfc_main2, [["ssrRender", _sfc_ssrRender]]);
  }
});

// .netlify/functions-internal/server/chunks/build/index-fCrtNcwr.mjs
var index_fCrtNcwr_exports = {};
__export(index_fCrtNcwr_exports, {
  default: () => index
});
import { ssrRenderAttrs as ssrRenderAttrs3, ssrRenderComponent, ssrRenderList, ssrInterpolate, ssrRenderClass } from "vue/server-renderer";
import { defineComponent, computed, openBlock, createElementBlock, mergeProps, unref, renderSlot, ref as ref2, watch as watch2, createBlock, resolveDynamicComponent, withCtx, Fragment, normalizeClass, createCommentVNode, provide, reactive, toRef, withModifiers, Transition, withDirectives, createElementVNode, createVNode, vShow, normalizeStyle, renderList, toDisplayString, shallowReactive, warn, useSSRContext as useSSRContext3, inject, getCurrentInstance as getCurrentInstance2, useSlots, Text, shallowRef, createTextVNode, isRef, isVNode } from "vue";
import { fromPairs, throttle, get } from "lodash-unified";
import { isString, isObject, hasOwn, NOOP, isFunction, isArray } from "@vue/shared";
import { TinyColor } from "@ctrl/tinycolor";
import "consola/core";
import "unhead";
import "@unhead/shared";
import "vue-router";
import "dayjs";
import "dayjs/plugin/updateLocale.js";
import "dayjs/plugin/utc.js";
import "vue-i18n";
function addUnit(value, defaultUnit = "px") {
  if (!value)
    return "";
  if (isNumber(value) || isStringNumber(value)) {
    return `${value}${defaultUnit}`;
  } else if (isString(value)) {
    return value;
  }
}
function useGlobalConfig(key, defaultValue = void 0) {
  const config3 = getCurrentInstance2() ? inject(configProviderContextKey, globalConfig) : globalConfig;
  if (key) {
    return computed(() => {
      var _a, _b;
      return (_b = (_a = config3.value) == null ? void 0 : _a[key]) != null ? _b : defaultValue;
    });
  } else {
    return config3;
  }
}
function darken(color, amount = 20) {
  return color.mix("#141414", amount).toString();
}
function useButtonCustomStyle(props) {
  const _disabled = useFormDisabled();
  const ns = useNamespace("button");
  return computed(() => {
    let styles2 = {};
    let buttonColor = props.color;
    if (buttonColor) {
      const match = buttonColor.match(/var\((.*?)\)/);
      if (match) {
        buttonColor = (void 0).getComputedStyle((void 0).document.documentElement).getPropertyValue(match[1]);
      }
      const color = new TinyColor(buttonColor);
      const activeBgColor = props.dark ? color.tint(20).toString() : darken(color, 20);
      if (props.plain) {
        styles2 = ns.cssVarBlock({
          "bg-color": props.dark ? darken(color, 90) : color.tint(90).toString(),
          "text-color": buttonColor,
          "border-color": props.dark ? darken(color, 50) : color.tint(50).toString(),
          "hover-text-color": `var(${ns.cssVarName("color-white")})`,
          "hover-bg-color": buttonColor,
          "hover-border-color": buttonColor,
          "active-bg-color": activeBgColor,
          "active-text-color": `var(${ns.cssVarName("color-white")})`,
          "active-border-color": activeBgColor
        });
        if (_disabled.value) {
          styles2[ns.cssVarBlockName("disabled-bg-color")] = props.dark ? darken(color, 90) : color.tint(90).toString();
          styles2[ns.cssVarBlockName("disabled-text-color")] = props.dark ? darken(color, 50) : color.tint(50).toString();
          styles2[ns.cssVarBlockName("disabled-border-color")] = props.dark ? darken(color, 80) : color.tint(80).toString();
        }
      } else {
        const hoverBgColor = props.dark ? darken(color, 30) : color.tint(30).toString();
        const textColor = color.isDark() ? `var(${ns.cssVarName("color-white")})` : `var(${ns.cssVarName("color-black")})`;
        styles2 = ns.cssVarBlock({
          "bg-color": buttonColor,
          "text-color": textColor,
          "border-color": buttonColor,
          "hover-bg-color": hoverBgColor,
          "hover-text-color": textColor,
          "hover-border-color": hoverBgColor,
          "active-bg-color": activeBgColor,
          "active-border-color": activeBgColor
        });
        if (_disabled.value) {
          const disabledButtonColor = props.dark ? darken(color, 50) : color.tint(50).toString();
          styles2[ns.cssVarBlockName("disabled-bg-color")] = disabledButtonColor;
          styles2[ns.cssVarBlockName("disabled-text-color")] = props.dark ? "rgba(255, 255, 255, 0.5)" : `var(${ns.cssVarName("color-white")})`;
          styles2[ns.cssVarBlockName("disabled-border-color")] = disabledButtonColor;
        }
      }
    }
    return styles2;
  });
}
function closeAll(type) {
  for (const instance6 of instances) {
    if (!type || type === instance6.props.type) {
      instance6.handler.close();
    }
  }
}
var isUndefined, isBoolean, isNumber, isElement, isStringNumber, keysOf, arrow_left_vue_vue_type_script_setup_true_lang_default, arrow_left_default, arrow_right_vue_vue_type_script_setup_true_lang_default, arrow_right_default, loading_vue_vue_type_script_setup_true_lang_default, loading_default, epPropKey, definePropType, isEpProp, buildProp, buildProps, iconPropType, withInstall, withInstallFunction, withNoopInstall, componentSizes, flattedChildren, mutable, defaultNamespace, statePrefix, _bem, namespaceContextKey, useGetDerivedNamespace, useNamespace, _sfc_main$7, _sfc_setup$2, Square, _sfc_main$6, _sfc_setup$1, useDeprecated, English, buildTranslator, translate, buildLocaleContext, localeContextKey, useLocale, useProp, getOrderedChildren, useOrderedChildren, useSizeProp, SIZE_INJECTION_KEY, useGlobalSize, emptyValuesContextKey, useEmptyValuesProps, iconProps, _export_sfc2, __default__$4, _sfc_main$5, Icon, ElIcon, formContextKey, formItemContextKey, useFormSize, useFormDisabled, useFormItem, configProviderContextKey, globalConfig, provideGlobalConfig, mergeConfig, configProviderProps, messageConfig, buttonGroupContextKey, useButton, buttonTypes, buttonNativeTypes, buttonProps, buttonEmits, __default__$3, _sfc_main$4, Button, buttonGroupProps, __default__$2, _sfc_main$3, ButtonGroup, ElButton, carouselProps, carouselEmits, carouselContextKey, CAROUSEL_ITEM_NAME, THROTTLE_TIME, useCarousel, COMPONENT_NAME, __default__$1, _sfc_main$2, Carousel, carouselItemProps, useCarouselItem, __default__, _sfc_main$1, CarouselItem, ElCarousel, ElCarouselItem, messageTypes, messageDefaults, instances, normalizeOptions, message, ElMessage, _sfc_main3, _sfc_setup3, index;
var init_index_fCrtNcwr = __esm({
  ".netlify/functions-internal/server/chunks/build/index-fCrtNcwr.mjs"() {
    "use strict";
    init_server();
    init_index_DdJWkO();
    init_nitro();
    isUndefined = (val) => val === void 0;
    isBoolean = (val) => typeof val === "boolean";
    isNumber = (val) => typeof val === "number";
    isElement = (e) => {
      if (typeof Element === "undefined")
        return false;
      return e instanceof Element;
    };
    isStringNumber = (val) => {
      if (!isString(val)) {
        return false;
      }
      return !Number.isNaN(Number(val));
    };
    keysOf = (arr) => Object.keys(arr);
    arrow_left_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
      name: "ArrowLeft",
      __name: "arrow-left",
      setup(__props) {
        return (_ctx, _cache) => (openBlock(), createElementBlock("svg", {
          xmlns: "http://www.w3.org/2000/svg",
          viewBox: "0 0 1024 1024"
        }, [
          createElementVNode("path", {
            fill: "currentColor",
            d: "M609.408 149.376 277.76 489.6a32 32 0 0 0 0 44.672l331.648 340.352a29.12 29.12 0 0 0 41.728 0 30.592 30.592 0 0 0 0-42.752L339.264 511.936l311.872-319.872a30.592 30.592 0 0 0 0-42.688 29.12 29.12 0 0 0-41.728 0z"
          })
        ]));
      }
    });
    arrow_left_default = arrow_left_vue_vue_type_script_setup_true_lang_default;
    arrow_right_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
      name: "ArrowRight",
      __name: "arrow-right",
      setup(__props) {
        return (_ctx, _cache) => (openBlock(), createElementBlock("svg", {
          xmlns: "http://www.w3.org/2000/svg",
          viewBox: "0 0 1024 1024"
        }, [
          createElementVNode("path", {
            fill: "currentColor",
            d: "M340.864 149.312a30.592 30.592 0 0 0 0 42.752L652.736 512 340.864 831.872a30.592 30.592 0 0 0 0 42.752 29.12 29.12 0 0 0 41.728 0L714.24 534.336a32 32 0 0 0 0-44.672L382.592 149.376a29.12 29.12 0 0 0-41.728 0z"
          })
        ]));
      }
    });
    arrow_right_default = arrow_right_vue_vue_type_script_setup_true_lang_default;
    loading_vue_vue_type_script_setup_true_lang_default = /* @__PURE__ */ defineComponent({
      name: "Loading",
      __name: "loading",
      setup(__props) {
        return (_ctx, _cache) => (openBlock(), createElementBlock("svg", {
          xmlns: "http://www.w3.org/2000/svg",
          viewBox: "0 0 1024 1024"
        }, [
          createElementVNode("path", {
            fill: "currentColor",
            d: "M512 64a32 32 0 0 1 32 32v192a32 32 0 0 1-64 0V96a32 32 0 0 1 32-32m0 640a32 32 0 0 1 32 32v192a32 32 0 1 1-64 0V736a32 32 0 0 1 32-32m448-192a32 32 0 0 1-32 32H736a32 32 0 1 1 0-64h192a32 32 0 0 1 32 32m-640 0a32 32 0 0 1-32 32H96a32 32 0 0 1 0-64h192a32 32 0 0 1 32 32M195.2 195.2a32 32 0 0 1 45.248 0L376.32 331.008a32 32 0 0 1-45.248 45.248L195.2 240.448a32 32 0 0 1 0-45.248zm452.544 452.544a32 32 0 0 1 45.248 0L828.8 783.552a32 32 0 0 1-45.248 45.248L647.744 692.992a32 32 0 0 1 0-45.248zM828.8 195.264a32 32 0 0 1 0 45.184L692.992 376.32a32 32 0 0 1-45.248-45.248l135.808-135.808a32 32 0 0 1 45.248 0m-452.544 452.48a32 32 0 0 1 0 45.248L240.448 828.8a32 32 0 0 1-45.248-45.248l135.808-135.808a32 32 0 0 1 45.248 0z"
          })
        ]));
      }
    });
    loading_default = loading_vue_vue_type_script_setup_true_lang_default;
    epPropKey = "__epPropKey";
    definePropType = (val) => val;
    isEpProp = (val) => isObject(val) && !!val[epPropKey];
    buildProp = (prop, key) => {
      if (!isObject(prop) || isEpProp(prop))
        return prop;
      const { values, required, default: defaultValue, type, validator } = prop;
      const _validator = values || validator ? (val) => {
        let valid = false;
        let allowedValues = [];
        if (values) {
          allowedValues = Array.from(values);
          if (hasOwn(prop, "default")) {
            allowedValues.push(defaultValue);
          }
          valid || (valid = allowedValues.includes(val));
        }
        if (validator)
          valid || (valid = validator(val));
        if (!valid && allowedValues.length > 0) {
          const allowValuesText = [...new Set(allowedValues)].map((value) => JSON.stringify(value)).join(", ");
          warn(`Invalid prop: validation failed${key ? ` for prop "${key}"` : ""}. Expected one of [${allowValuesText}], got value ${JSON.stringify(val)}.`);
        }
        return valid;
      } : void 0;
      const epProp = {
        type,
        required: !!required,
        validator: _validator,
        [epPropKey]: true
      };
      if (hasOwn(prop, "default"))
        epProp.default = defaultValue;
      return epProp;
    };
    buildProps = (props) => fromPairs(Object.entries(props).map(([key, option]) => [
      key,
      buildProp(option, key)
    ]));
    iconPropType = definePropType([
      String,
      Object,
      Function
    ]);
    withInstall = (main, extra) => {
      main.install = (app) => {
        for (const comp of [main, ...Object.values(extra != null ? extra : {})]) {
          app.component(comp.name, comp);
        }
      };
      if (extra) {
        for (const [key, comp] of Object.entries(extra)) {
          main[key] = comp;
        }
      }
      return main;
    };
    withInstallFunction = (fn, name) => {
      fn.install = (app) => {
        fn._context = app._context;
        app.config.globalProperties[name] = fn;
      };
      return fn;
    };
    withNoopInstall = (component) => {
      component.install = NOOP;
      return component;
    };
    componentSizes = ["", "default", "small", "large"];
    flattedChildren = (children) => {
      const vNodes = isArray(children) ? children : [children];
      const result = [];
      vNodes.forEach((child) => {
        var _a;
        if (isArray(child)) {
          result.push(...flattedChildren(child));
        } else if (isVNode(child) && isArray(child.children)) {
          result.push(...flattedChildren(child.children));
        } else {
          result.push(child);
          if (isVNode(child) && ((_a = child.component) == null ? void 0 : _a.subTree)) {
            result.push(...flattedChildren(child.component.subTree));
          }
        }
      });
      return result;
    };
    mutable = (val) => val;
    defaultNamespace = "el";
    statePrefix = "is-";
    _bem = (namespace, block, blockSuffix, element, modifier) => {
      let cls = `${namespace}-${block}`;
      if (blockSuffix) {
        cls += `-${blockSuffix}`;
      }
      if (element) {
        cls += `__${element}`;
      }
      if (modifier) {
        cls += `--${modifier}`;
      }
      return cls;
    };
    namespaceContextKey = Symbol("namespaceContextKey");
    useGetDerivedNamespace = (namespaceOverrides) => {
      const derivedNamespace = getCurrentInstance2() ? inject(namespaceContextKey, ref2(defaultNamespace)) : ref2(defaultNamespace);
      const namespace = computed(() => {
        return unref(derivedNamespace) || defaultNamespace;
      });
      return namespace;
    };
    useNamespace = (block, namespaceOverrides) => {
      const namespace = useGetDerivedNamespace();
      const b = (blockSuffix = "") => _bem(namespace.value, block, blockSuffix, "", "");
      const e = (element) => element ? _bem(namespace.value, block, "", element, "") : "";
      const m = (modifier) => modifier ? _bem(namespace.value, block, "", "", modifier) : "";
      const be = (blockSuffix, element) => blockSuffix && element ? _bem(namespace.value, block, blockSuffix, element, "") : "";
      const em = (element, modifier) => element && modifier ? _bem(namespace.value, block, "", element, modifier) : "";
      const bm = (blockSuffix, modifier) => blockSuffix && modifier ? _bem(namespace.value, block, blockSuffix, "", modifier) : "";
      const bem = (blockSuffix, element, modifier) => blockSuffix && element && modifier ? _bem(namespace.value, block, blockSuffix, element, modifier) : "";
      const is = (name, ...args) => {
        const state = args.length >= 1 ? args[0] : true;
        return name && state ? `${statePrefix}${name}` : "";
      };
      const cssVar = (object) => {
        const styles2 = {};
        for (const key in object) {
          if (object[key]) {
            styles2[`--${namespace.value}-${key}`] = object[key];
          }
        }
        return styles2;
      };
      const cssVarBlock = (object) => {
        const styles2 = {};
        for (const key in object) {
          if (object[key]) {
            styles2[`--${namespace.value}-${block}-${key}`] = object[key];
          }
        }
        return styles2;
      };
      const cssVarName = (name) => `--${namespace.value}-${name}`;
      const cssVarBlockName = (name) => `--${namespace.value}-${block}-${name}`;
      return {
        namespace,
        b,
        e,
        m,
        be,
        em,
        bm,
        bem,
        is,
        cssVar,
        cssVarName,
        cssVarBlock,
        cssVarBlockName
      };
    };
    _sfc_main$7 = {
      __name: "Square",
      __ssrInlineRender: true,
      props: {
        width: {
          type: Number,
          default: 100
        },
        height: {
          type: Number,
          default: 60
        }
      },
      setup(__props) {
        const props = __props;
        const logo = computed(() => {
          return "/logo/site/square.png";
        });
        const getWidth = computed(() => {
          return props.width;
        });
        const getHeight = computed(() => {
          return props.height;
        });
        return (_ctx, _push, _parent, _attrs) => {
          _push(`<img${ssrRenderAttrs3(mergeProps({
            src: unref(logo),
            width: unref(getWidth),
            height: unref(getHeight),
            class: "d-inline-block align-top img-thumbnail logo-img"
          }, _attrs))} data-v-c893ce81>`);
        };
      }
    };
    _sfc_setup$2 = _sfc_main$7.setup;
    _sfc_main$7.setup = (props, ctx) => {
      const ssrContext = useSSRContext3();
      (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Site/Logo/Square.vue");
      return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
    };
    Square = /* @__PURE__ */ _export_sfc(_sfc_main$7, [["__scopeId", "data-v-c893ce81"]]);
    _sfc_main$6 = {
      __name: "Title",
      __ssrInlineRender: true,
      setup(__props) {
        const siteTitle = ref2([
          { text: "I", isActive: false },
          { text: "T", isActive: true },
          { text: "E | ", isActive: false },
          { text: "R", isActive: true },
          { text: "U", isActive: false },
          { text: "P", isActive: true },
          { text: "P | ", isActive: false },
          { text: "P", isActive: true },
          { text: "latform", isActive: false }
        ]);
        return (_ctx, _push, _parent, _attrs) => {
          _push(`<!--[--><div><!--[-->`);
          ssrRenderList(siteTitle.value, (site, index22) => {
            _push(`<span class="${ssrRenderClass({ "active-text": site.isActive })}">${ssrInterpolate(site.text)}</span>`);
          });
          _push(`<!--]--></div>`);
          _push(ssrRenderComponent(Square, {
            width: "100",
            height: "60"
          }, null, _parent));
          _push(`<!--]-->`);
        };
      }
    };
    _sfc_setup$1 = _sfc_main$6.setup;
    _sfc_main$6.setup = (props, ctx) => {
      const ssrContext = useSSRContext3();
      (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Site/Title.vue");
      return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
    };
    useDeprecated = ({ from, replacement, scope, version: version3, ref: ref22, type = "API" }, condition) => {
      watch2(() => unref(condition), (val) => {
      }, {
        immediate: true
      });
    };
    English = {
      name: "en",
      el: {
        breadcrumb: {
          label: "Breadcrumb"
        },
        colorpicker: {
          confirm: "OK",
          clear: "Clear",
          defaultLabel: "color picker",
          description: "current color is {color}. press enter to select a new color.",
          alphaLabel: "pick alpha value"
        },
        datepicker: {
          now: "Now",
          today: "Today",
          cancel: "Cancel",
          clear: "Clear",
          confirm: "OK",
          dateTablePrompt: "Use the arrow keys and enter to select the day of the month",
          monthTablePrompt: "Use the arrow keys and enter to select the month",
          yearTablePrompt: "Use the arrow keys and enter to select the year",
          selectedDate: "Selected date",
          selectDate: "Select date",
          selectTime: "Select time",
          startDate: "Start Date",
          startTime: "Start Time",
          endDate: "End Date",
          endTime: "End Time",
          prevYear: "Previous Year",
          nextYear: "Next Year",
          prevMonth: "Previous Month",
          nextMonth: "Next Month",
          year: "",
          month1: "January",
          month2: "February",
          month3: "March",
          month4: "April",
          month5: "May",
          month6: "June",
          month7: "July",
          month8: "August",
          month9: "September",
          month10: "October",
          month11: "November",
          month12: "December",
          week: "week",
          weeks: {
            sun: "Sun",
            mon: "Mon",
            tue: "Tue",
            wed: "Wed",
            thu: "Thu",
            fri: "Fri",
            sat: "Sat"
          },
          weeksFull: {
            sun: "Sunday",
            mon: "Monday",
            tue: "Tuesday",
            wed: "Wednesday",
            thu: "Thursday",
            fri: "Friday",
            sat: "Saturday"
          },
          months: {
            jan: "Jan",
            feb: "Feb",
            mar: "Mar",
            apr: "Apr",
            may: "May",
            jun: "Jun",
            jul: "Jul",
            aug: "Aug",
            sep: "Sep",
            oct: "Oct",
            nov: "Nov",
            dec: "Dec"
          }
        },
        inputNumber: {
          decrease: "decrease number",
          increase: "increase number"
        },
        select: {
          loading: "Loading",
          noMatch: "No matching data",
          noData: "No data",
          placeholder: "Select"
        },
        mention: {
          loading: "Loading"
        },
        dropdown: {
          toggleDropdown: "Toggle Dropdown"
        },
        cascader: {
          noMatch: "No matching data",
          loading: "Loading",
          placeholder: "Select",
          noData: "No data"
        },
        pagination: {
          goto: "Go to",
          pagesize: "/page",
          total: "Total {total}",
          pageClassifier: "",
          page: "Page",
          prev: "Go to previous page",
          next: "Go to next page",
          currentPage: "page {pager}",
          prevPages: "Previous {pager} pages",
          nextPages: "Next {pager} pages",
          deprecationWarning: "Deprecated usages detected, please refer to the el-pagination documentation for more details"
        },
        dialog: {
          close: "Close this dialog"
        },
        drawer: {
          close: "Close this dialog"
        },
        messagebox: {
          title: "Message",
          confirm: "OK",
          cancel: "Cancel",
          error: "Illegal input",
          close: "Close this dialog"
        },
        upload: {
          deleteTip: "press delete to remove",
          delete: "Delete",
          preview: "Preview",
          continue: "Continue"
        },
        slider: {
          defaultLabel: "slider between {min} and {max}",
          defaultRangeStartLabel: "pick start value",
          defaultRangeEndLabel: "pick end value"
        },
        table: {
          emptyText: "No Data",
          confirmFilter: "Confirm",
          resetFilter: "Reset",
          clearFilter: "All",
          sumText: "Sum"
        },
        tour: {
          next: "Next",
          previous: "Previous",
          finish: "Finish"
        },
        tree: {
          emptyText: "No Data"
        },
        transfer: {
          noMatch: "No matching data",
          noData: "No data",
          titles: ["List 1", "List 2"],
          filterPlaceholder: "Enter keyword",
          noCheckedFormat: "{total} items",
          hasCheckedFormat: "{checked}/{total} checked"
        },
        image: {
          error: "FAILED"
        },
        pageHeader: {
          title: "Back"
        },
        popconfirm: {
          confirmButtonText: "Yes",
          cancelButtonText: "No"
        },
        carousel: {
          leftArrow: "Carousel arrow left",
          rightArrow: "Carousel arrow right",
          indicator: "Carousel switch to index {index}"
        }
      }
    };
    buildTranslator = (locale) => (path, option) => translate(path, option, unref(locale));
    translate = (path, option, locale) => get(locale, path, path).replace(/\{(\w+)\}/g, (_, key) => {
      var _a;
      return `${(_a = option == null ? void 0 : option[key]) != null ? _a : `{${key}}`}`;
    });
    buildLocaleContext = (locale) => {
      const lang = computed(() => unref(locale).name);
      const localeRef = isRef(locale) ? locale : ref2(locale);
      return {
        lang,
        locale: localeRef,
        t: buildTranslator(locale)
      };
    };
    localeContextKey = Symbol("localeContextKey");
    useLocale = (localeOverrides) => {
      const locale = inject(localeContextKey, ref2());
      return buildLocaleContext(computed(() => locale.value || English));
    };
    useProp = (name) => {
      const vm = getCurrentInstance2();
      return computed(() => {
        var _a, _b;
        return (_b = (_a = vm == null ? void 0 : vm.proxy) == null ? void 0 : _a.$props) == null ? void 0 : _b[name];
      });
    };
    getOrderedChildren = (vm, childComponentName, children) => {
      const nodes = flattedChildren(vm.subTree).filter((n) => {
        var _a;
        return isVNode(n) && ((_a = n.type) == null ? void 0 : _a.name) === childComponentName && !!n.component;
      });
      const uids = nodes.map((n) => n.component.uid);
      return uids.map((uid) => children[uid]).filter((p) => !!p);
    };
    useOrderedChildren = (vm, childComponentName) => {
      const children = {};
      const orderedChildren = shallowRef([]);
      const addChild = (child) => {
        children[child.uid] = child;
        orderedChildren.value = getOrderedChildren(vm, childComponentName, children);
      };
      const removeChild = (uid) => {
        delete children[uid];
        orderedChildren.value = orderedChildren.value.filter((children2) => children2.uid !== uid);
      };
      return {
        children: orderedChildren,
        addChild,
        removeChild
      };
    };
    useSizeProp = buildProp({
      type: String,
      values: componentSizes,
      required: false
    });
    SIZE_INJECTION_KEY = Symbol("size");
    useGlobalSize = () => {
      const injectedSize = inject(SIZE_INJECTION_KEY, {});
      return computed(() => {
        return unref(injectedSize.size) || "";
      });
    };
    emptyValuesContextKey = Symbol("emptyValuesContextKey");
    useEmptyValuesProps = buildProps({
      emptyValues: Array,
      valueOnClear: {
        type: [String, Number, Boolean, Function],
        default: void 0,
        validator: (val) => isFunction(val) ? !val() : !val
      }
    });
    iconProps = buildProps({
      size: {
        type: definePropType([Number, String])
      },
      color: {
        type: String
      }
    });
    _export_sfc2 = (sfc, props) => {
      const target = sfc.__vccOpts || sfc;
      for (const [key, val] of props) {
        target[key] = val;
      }
      return target;
    };
    __default__$4 = defineComponent({
      name: "ElIcon",
      inheritAttrs: false
    });
    _sfc_main$5 = /* @__PURE__ */ defineComponent({
      ...__default__$4,
      props: iconProps,
      setup(__props) {
        const props = __props;
        const ns = useNamespace("icon");
        const style = computed(() => {
          const { size, color } = props;
          if (!size && !color)
            return {};
          return {
            fontSize: isUndefined(size) ? void 0 : addUnit(size),
            "--color": color
          };
        });
        return (_ctx, _cache) => {
          return openBlock(), createElementBlock("i", mergeProps({
            class: unref(ns).b(),
            style: unref(style)
          }, _ctx.$attrs), [
            renderSlot(_ctx.$slots, "default")
          ], 16);
        };
      }
    });
    Icon = /* @__PURE__ */ _export_sfc2(_sfc_main$5, [["__file", "icon.vue"]]);
    ElIcon = withInstall(Icon);
    formContextKey = Symbol("formContextKey");
    formItemContextKey = Symbol("formItemContextKey");
    useFormSize = (fallback, ignore = {}) => {
      const emptyRef = ref2(void 0);
      const size = ignore.prop ? emptyRef : useProp("size");
      const globalConfig2 = ignore.global ? emptyRef : useGlobalSize();
      const form = ignore.form ? { size: void 0 } : inject(formContextKey, void 0);
      const formItem = ignore.formItem ? { size: void 0 } : inject(formItemContextKey, void 0);
      return computed(() => size.value || unref(fallback) || (formItem == null ? void 0 : formItem.size) || (form == null ? void 0 : form.size) || globalConfig2.value || "");
    };
    useFormDisabled = (fallback) => {
      const disabled = useProp("disabled");
      const form = inject(formContextKey, void 0);
      return computed(() => disabled.value || unref(fallback) || (form == null ? void 0 : form.disabled) || false);
    };
    useFormItem = () => {
      const form = inject(formContextKey, void 0);
      const formItem = inject(formItemContextKey, void 0);
      return {
        form,
        formItem
      };
    };
    configProviderContextKey = Symbol();
    globalConfig = ref2();
    provideGlobalConfig = (config3, app, global2 = false) => {
      var _a;
      const inSetup = !!getCurrentInstance2();
      const oldConfig = inSetup ? useGlobalConfig() : void 0;
      const provideFn = (_a = void 0) != null ? _a : inSetup ? provide : void 0;
      if (!provideFn) {
        return;
      }
      const context = computed(() => {
        const cfg = unref(config3);
        if (!(oldConfig == null ? void 0 : oldConfig.value))
          return cfg;
        return mergeConfig(oldConfig.value, cfg);
      });
      provideFn(configProviderContextKey, context);
      provideFn(localeContextKey, computed(() => context.value.locale));
      provideFn(namespaceContextKey, computed(() => context.value.namespace));
      provideFn(zIndexContextKey, computed(() => context.value.zIndex));
      provideFn(SIZE_INJECTION_KEY, {
        size: computed(() => context.value.size || "")
      });
      provideFn(emptyValuesContextKey, computed(() => ({
        emptyValues: context.value.emptyValues,
        valueOnClear: context.value.valueOnClear
      })));
      if (global2 || !globalConfig.value) {
        globalConfig.value = context.value;
      }
      return context;
    };
    mergeConfig = (a, b) => {
      const keys = [.../* @__PURE__ */ new Set([...keysOf(a), ...keysOf(b)])];
      const obj = {};
      for (const key of keys) {
        obj[key] = b[key] !== void 0 ? b[key] : a[key];
      }
      return obj;
    };
    configProviderProps = buildProps({
      a11y: {
        type: Boolean,
        default: true
      },
      locale: {
        type: definePropType(Object)
      },
      size: useSizeProp,
      button: {
        type: definePropType(Object)
      },
      experimentalFeatures: {
        type: definePropType(Object)
      },
      keyboardNavigation: {
        type: Boolean,
        default: true
      },
      message: {
        type: definePropType(Object)
      },
      zIndex: Number,
      namespace: {
        type: String,
        default: "el"
      },
      ...useEmptyValuesProps
    });
    messageConfig = {};
    defineComponent({
      name: "ElConfigProvider",
      props: configProviderProps,
      setup(props, { slots }) {
        watch2(() => props.message, (val) => {
          Object.assign(messageConfig, val != null ? val : {});
        }, { immediate: true, deep: true });
        const config3 = provideGlobalConfig(props);
        return () => renderSlot(slots, "default", { config: config3 == null ? void 0 : config3.value });
      }
    });
    buttonGroupContextKey = Symbol("buttonGroupContextKey");
    useButton = (props, emit) => {
      useDeprecated({
        from: "type.text",
        replacement: "link",
        version: "3.0.0",
        scope: "props",
        ref: "https://element-plus.org/en-US/component/button.html#button-attributes"
      }, computed(() => props.type === "text"));
      const buttonGroupContext = inject(buttonGroupContextKey, void 0);
      const globalConfig2 = useGlobalConfig("button");
      const { form } = useFormItem();
      const _size = useFormSize(computed(() => buttonGroupContext == null ? void 0 : buttonGroupContext.size));
      const _disabled = useFormDisabled();
      const _ref = ref2();
      const slots = useSlots();
      const _type = computed(() => props.type || (buttonGroupContext == null ? void 0 : buttonGroupContext.type) || "");
      const autoInsertSpace = computed(() => {
        var _a, _b, _c;
        return (_c = (_b = props.autoInsertSpace) != null ? _b : (_a = globalConfig2.value) == null ? void 0 : _a.autoInsertSpace) != null ? _c : false;
      });
      const _props = computed(() => {
        if (props.tag === "button") {
          return {
            ariaDisabled: _disabled.value || props.loading,
            disabled: _disabled.value || props.loading,
            autofocus: props.autofocus,
            type: props.nativeType
          };
        }
        return {};
      });
      const shouldAddSpace = computed(() => {
        var _a;
        const defaultSlot = (_a = slots.default) == null ? void 0 : _a.call(slots);
        if (autoInsertSpace.value && (defaultSlot == null ? void 0 : defaultSlot.length) === 1) {
          const slot = defaultSlot[0];
          if ((slot == null ? void 0 : slot.type) === Text) {
            const text = slot.children;
            return new RegExp("^\\p{Unified_Ideograph}{2}$", "u").test(text.trim());
          }
        }
        return false;
      });
      const handleClick = (evt) => {
        if (_disabled.value || props.loading) {
          evt.stopPropagation();
          return;
        }
        if (props.nativeType === "reset") {
          form == null ? void 0 : form.resetFields();
        }
        emit("click", evt);
      };
      return {
        _disabled,
        _size,
        _type,
        _ref,
        _props,
        shouldAddSpace,
        handleClick
      };
    };
    buttonTypes = [
      "default",
      "primary",
      "success",
      "warning",
      "info",
      "danger",
      "text",
      ""
    ];
    buttonNativeTypes = ["button", "submit", "reset"];
    buttonProps = buildProps({
      size: useSizeProp,
      disabled: Boolean,
      type: {
        type: String,
        values: buttonTypes,
        default: ""
      },
      icon: {
        type: iconPropType
      },
      nativeType: {
        type: String,
        values: buttonNativeTypes,
        default: "button"
      },
      loading: Boolean,
      loadingIcon: {
        type: iconPropType,
        default: () => loading_default
      },
      plain: Boolean,
      text: Boolean,
      link: Boolean,
      bg: Boolean,
      autofocus: Boolean,
      round: Boolean,
      circle: Boolean,
      color: String,
      dark: Boolean,
      autoInsertSpace: {
        type: Boolean,
        default: void 0
      },
      tag: {
        type: definePropType([String, Object]),
        default: "button"
      }
    });
    buttonEmits = {
      click: (evt) => evt instanceof MouseEvent
    };
    __default__$3 = defineComponent({
      name: "ElButton"
    });
    _sfc_main$4 = /* @__PURE__ */ defineComponent({
      ...__default__$3,
      props: buttonProps,
      emits: buttonEmits,
      setup(__props, { expose, emit }) {
        const props = __props;
        const buttonStyle = useButtonCustomStyle(props);
        const ns = useNamespace("button");
        const { _ref, _size, _type, _disabled, _props, shouldAddSpace, handleClick } = useButton(props, emit);
        const buttonKls = computed(() => [
          ns.b(),
          ns.m(_type.value),
          ns.m(_size.value),
          ns.is("disabled", _disabled.value),
          ns.is("loading", props.loading),
          ns.is("plain", props.plain),
          ns.is("round", props.round),
          ns.is("circle", props.circle),
          ns.is("text", props.text),
          ns.is("link", props.link),
          ns.is("has-bg", props.bg)
        ]);
        expose({
          ref: _ref,
          size: _size,
          type: _type,
          disabled: _disabled,
          shouldAddSpace
        });
        return (_ctx, _cache) => {
          return openBlock(), createBlock(resolveDynamicComponent(_ctx.tag), mergeProps({
            ref_key: "_ref",
            ref: _ref
          }, unref(_props), {
            class: unref(buttonKls),
            style: unref(buttonStyle),
            onClick: unref(handleClick)
          }), {
            default: withCtx(() => [
              _ctx.loading ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
                _ctx.$slots.loading ? renderSlot(_ctx.$slots, "loading", { key: 0 }) : (openBlock(), createBlock(unref(ElIcon), {
                  key: 1,
                  class: normalizeClass(unref(ns).is("loading"))
                }, {
                  default: withCtx(() => [
                    (openBlock(), createBlock(resolveDynamicComponent(_ctx.loadingIcon)))
                  ]),
                  _: 1
                }, 8, ["class"]))
              ], 64)) : _ctx.icon || _ctx.$slots.icon ? (openBlock(), createBlock(unref(ElIcon), { key: 1 }, {
                default: withCtx(() => [
                  _ctx.icon ? (openBlock(), createBlock(resolveDynamicComponent(_ctx.icon), { key: 0 })) : renderSlot(_ctx.$slots, "icon", { key: 1 })
                ]),
                _: 3
              })) : createCommentVNode("v-if", true),
              _ctx.$slots.default ? (openBlock(), createElementBlock("span", {
                key: 2,
                class: normalizeClass({ [unref(ns).em("text", "expand")]: unref(shouldAddSpace) })
              }, [
                renderSlot(_ctx.$slots, "default")
              ], 2)) : createCommentVNode("v-if", true)
            ]),
            _: 3
          }, 16, ["class", "style", "onClick"]);
        };
      }
    });
    Button = /* @__PURE__ */ _export_sfc2(_sfc_main$4, [["__file", "button.vue"]]);
    buttonGroupProps = {
      size: buttonProps.size,
      type: buttonProps.type
    };
    __default__$2 = defineComponent({
      name: "ElButtonGroup"
    });
    _sfc_main$3 = /* @__PURE__ */ defineComponent({
      ...__default__$2,
      props: buttonGroupProps,
      setup(__props) {
        const props = __props;
        provide(buttonGroupContextKey, reactive({
          size: toRef(props, "size"),
          type: toRef(props, "type")
        }));
        const ns = useNamespace("button");
        return (_ctx, _cache) => {
          return openBlock(), createElementBlock("div", {
            class: normalizeClass(unref(ns).b("group"))
          }, [
            renderSlot(_ctx.$slots, "default")
          ], 2);
        };
      }
    });
    ButtonGroup = /* @__PURE__ */ _export_sfc2(_sfc_main$3, [["__file", "button-group.vue"]]);
    ElButton = withInstall(Button, {
      ButtonGroup
    });
    withNoopInstall(ButtonGroup);
    carouselProps = buildProps({
      initialIndex: {
        type: Number,
        default: 0
      },
      height: {
        type: String,
        default: ""
      },
      trigger: {
        type: String,
        values: ["hover", "click"],
        default: "hover"
      },
      autoplay: {
        type: Boolean,
        default: true
      },
      interval: {
        type: Number,
        default: 3e3
      },
      indicatorPosition: {
        type: String,
        values: ["", "none", "outside"],
        default: ""
      },
      arrow: {
        type: String,
        values: ["always", "hover", "never"],
        default: "hover"
      },
      type: {
        type: String,
        values: ["", "card"],
        default: ""
      },
      cardScale: {
        type: Number,
        default: 0.83
      },
      loop: {
        type: Boolean,
        default: true
      },
      direction: {
        type: String,
        values: ["horizontal", "vertical"],
        default: "horizontal"
      },
      pauseOnHover: {
        type: Boolean,
        default: true
      },
      motionBlur: Boolean
    });
    carouselEmits = {
      change: (current, prev) => [current, prev].every(isNumber)
    };
    carouselContextKey = Symbol("carouselContextKey");
    CAROUSEL_ITEM_NAME = "ElCarouselItem";
    THROTTLE_TIME = 300;
    useCarousel = (props, emit, componentName) => {
      const {
        children: items,
        addChild: addItem,
        removeChild: removeItem
      } = useOrderedChildren(getCurrentInstance2(), CAROUSEL_ITEM_NAME);
      const slots = useSlots();
      const activeIndex = ref2(-1);
      const timer = ref2(null);
      const hover = ref2(false);
      const root = ref2();
      const containerHeight = ref2(0);
      const isItemsTwoLength = ref2(true);
      const isFirstCall = ref2(true);
      const isTransitioning = ref2(false);
      const arrowDisplay = computed(() => props.arrow !== "never" && !unref(isVertical));
      const hasLabel = computed(() => {
        return items.value.some((item) => item.props.label.toString().length > 0);
      });
      const isCardType = computed(() => props.type === "card");
      const isVertical = computed(() => props.direction === "vertical");
      const containerStyle = computed(() => {
        if (props.height !== "auto") {
          return {
            height: props.height
          };
        }
        return {
          height: `${containerHeight.value}px`,
          overflow: "hidden"
        };
      });
      const throttledArrowClick = throttle((index22) => {
        setActiveItem(index22);
      }, THROTTLE_TIME, { trailing: true });
      const throttledIndicatorHover = throttle((index22) => {
        handleIndicatorHover(index22);
      }, THROTTLE_TIME);
      const isTwoLengthShow = (index22) => {
        if (!isItemsTwoLength.value)
          return true;
        return activeIndex.value <= 1 ? index22 <= 1 : index22 > 1;
      };
      function pauseTimer() {
        if (timer.value) {
          clearInterval(timer.value);
          timer.value = null;
        }
      }
      function startTimer() {
        if (props.interval <= 0 || !props.autoplay || timer.value)
          return;
        timer.value = setInterval(() => playSlides(), props.interval);
      }
      const playSlides = () => {
        if (!isFirstCall.value) {
          isTransitioning.value = true;
        }
        isFirstCall.value = false;
        if (activeIndex.value < items.value.length - 1) {
          activeIndex.value = activeIndex.value + 1;
        } else if (props.loop) {
          activeIndex.value = 0;
        } else {
          isTransitioning.value = false;
        }
      };
      function setActiveItem(index22) {
        if (!isFirstCall.value) {
          isTransitioning.value = true;
        }
        isFirstCall.value = false;
        if (isString(index22)) {
          const filteredItems = items.value.filter((item) => item.props.name === index22);
          if (filteredItems.length > 0) {
            index22 = items.value.indexOf(filteredItems[0]);
          }
        }
        index22 = Number(index22);
        if (Number.isNaN(index22) || index22 !== Math.floor(index22)) {
          return;
        }
        const itemCount = items.value.length;
        const oldIndex = activeIndex.value;
        if (index22 < 0) {
          activeIndex.value = props.loop ? itemCount - 1 : 0;
        } else if (index22 >= itemCount) {
          activeIndex.value = props.loop ? 0 : itemCount - 1;
        } else {
          activeIndex.value = index22;
        }
        if (oldIndex === activeIndex.value) {
          resetItemPosition(oldIndex);
        }
        resetTimer();
      }
      function resetItemPosition(oldIndex) {
        items.value.forEach((item, index22) => {
          item.translateItem(index22, activeIndex.value, oldIndex);
        });
      }
      function itemInStage(item, index22) {
        var _a, _b, _c, _d;
        const _items = unref(items);
        const itemCount = _items.length;
        if (itemCount === 0 || !item.states.inStage)
          return false;
        const nextItemIndex = index22 + 1;
        const prevItemIndex = index22 - 1;
        const lastItemIndex = itemCount - 1;
        const isLastItemActive = _items[lastItemIndex].states.active;
        const isFirstItemActive = _items[0].states.active;
        const isNextItemActive = (_b = (_a = _items[nextItemIndex]) == null ? void 0 : _a.states) == null ? void 0 : _b.active;
        const isPrevItemActive = (_d = (_c = _items[prevItemIndex]) == null ? void 0 : _c.states) == null ? void 0 : _d.active;
        if (index22 === lastItemIndex && isFirstItemActive || isNextItemActive) {
          return "left";
        } else if (index22 === 0 && isLastItemActive || isPrevItemActive) {
          return "right";
        }
        return false;
      }
      function handleMouseEnter() {
        hover.value = true;
        if (props.pauseOnHover) {
          pauseTimer();
        }
      }
      function handleMouseLeave() {
        hover.value = false;
        startTimer();
      }
      function handleTransitionEnd() {
        isTransitioning.value = false;
      }
      function handleButtonEnter(arrow) {
        if (unref(isVertical))
          return;
        items.value.forEach((item, index22) => {
          if (arrow === itemInStage(item, index22)) {
            item.states.hover = true;
          }
        });
      }
      function handleButtonLeave() {
        if (unref(isVertical))
          return;
        items.value.forEach((item) => {
          item.states.hover = false;
        });
      }
      function handleIndicatorClick(index22) {
        if (index22 !== activeIndex.value) {
          if (!isFirstCall.value) {
            isTransitioning.value = true;
          }
        }
        activeIndex.value = index22;
      }
      function handleIndicatorHover(index22) {
        if (props.trigger === "hover" && index22 !== activeIndex.value) {
          activeIndex.value = index22;
          if (!isFirstCall.value) {
            isTransitioning.value = true;
          }
        }
      }
      function prev() {
        setActiveItem(activeIndex.value - 1);
      }
      function next() {
        setActiveItem(activeIndex.value + 1);
      }
      function resetTimer() {
        pauseTimer();
        if (!props.pauseOnHover)
          startTimer();
      }
      function setContainerHeight(height) {
        if (props.height !== "auto")
          return;
        containerHeight.value = height;
      }
      function PlaceholderItem() {
        var _a;
        const defaultSlots = (_a = slots.default) == null ? void 0 : _a.call(slots);
        if (!defaultSlots)
          return null;
        const flatSlots = flattedChildren(defaultSlots);
        const normalizeSlots = flatSlots.filter((slot) => {
          return isVNode(slot) && slot.type.name === CAROUSEL_ITEM_NAME;
        });
        if ((normalizeSlots == null ? void 0 : normalizeSlots.length) === 2 && props.loop && !isCardType.value) {
          isItemsTwoLength.value = true;
          return normalizeSlots;
        }
        isItemsTwoLength.value = false;
        return null;
      }
      watch2(() => activeIndex.value, (current, prev2) => {
        resetItemPosition(prev2);
        if (isItemsTwoLength.value) {
          current = current % 2;
          prev2 = prev2 % 2;
        }
        if (prev2 > -1) {
          emit("change", current, prev2);
        }
      });
      watch2(() => props.autoplay, (autoplay) => {
        autoplay ? startTimer() : pauseTimer();
      });
      watch2(() => props.loop, () => {
        setActiveItem(activeIndex.value);
      });
      watch2(() => props.interval, () => {
        resetTimer();
      });
      shallowRef();
      provide(carouselContextKey, {
        root,
        isCardType,
        isVertical,
        items,
        loop: props.loop,
        cardScale: props.cardScale,
        addItem,
        removeItem,
        setActiveItem,
        setContainerHeight
      });
      return {
        root,
        activeIndex,
        arrowDisplay,
        hasLabel,
        hover,
        isCardType,
        isTransitioning,
        items,
        isVertical,
        containerStyle,
        isItemsTwoLength,
        handleButtonEnter,
        handleTransitionEnd,
        handleButtonLeave,
        handleIndicatorClick,
        handleMouseEnter,
        handleMouseLeave,
        setActiveItem,
        prev,
        next,
        PlaceholderItem,
        isTwoLengthShow,
        throttledArrowClick,
        throttledIndicatorHover
      };
    };
    COMPONENT_NAME = "ElCarousel";
    __default__$1 = defineComponent({
      name: COMPONENT_NAME
    });
    _sfc_main$2 = /* @__PURE__ */ defineComponent({
      ...__default__$1,
      props: carouselProps,
      emits: carouselEmits,
      setup(__props, { expose, emit }) {
        const props = __props;
        const {
          root,
          activeIndex,
          arrowDisplay,
          hasLabel,
          hover,
          isCardType,
          items,
          isVertical,
          containerStyle,
          handleButtonEnter,
          handleButtonLeave,
          isTransitioning,
          handleIndicatorClick,
          handleMouseEnter,
          handleMouseLeave,
          handleTransitionEnd,
          setActiveItem,
          prev,
          next,
          PlaceholderItem,
          isTwoLengthShow,
          throttledArrowClick,
          throttledIndicatorHover
        } = useCarousel(props, emit);
        const ns = useNamespace("carousel");
        const { t } = useLocale();
        const carouselClasses = computed(() => {
          const classes = [ns.b(), ns.m(props.direction)];
          if (unref(isCardType)) {
            classes.push(ns.m("card"));
          }
          return classes;
        });
        const carouselContainer = computed(() => {
          const classes = [ns.e("container")];
          if (props.motionBlur && unref(isTransitioning) && items.value.length > 1) {
            classes.push(unref(isVertical) ? `${ns.namespace.value}-transitioning-vertical` : `${ns.namespace.value}-transitioning`);
          }
          return classes;
        });
        const indicatorsClasses = computed(() => {
          const classes = [ns.e("indicators"), ns.em("indicators", props.direction)];
          if (unref(hasLabel)) {
            classes.push(ns.em("indicators", "labels"));
          }
          if (props.indicatorPosition === "outside") {
            classes.push(ns.em("indicators", "outside"));
          }
          if (unref(isVertical)) {
            classes.push(ns.em("indicators", "right"));
          }
          return classes;
        });
        expose({
          activeIndex,
          setActiveItem,
          prev,
          next
        });
        return (_ctx, _cache) => {
          return openBlock(), createElementBlock("div", {
            ref_key: "root",
            ref: root,
            class: normalizeClass(unref(carouselClasses)),
            onMouseenter: withModifiers(unref(handleMouseEnter), ["stop"]),
            onMouseleave: withModifiers(unref(handleMouseLeave), ["stop"])
          }, [
            unref(arrowDisplay) ? (openBlock(), createBlock(Transition, {
              key: 0,
              name: "carousel-arrow-left",
              persisted: ""
            }, {
              default: withCtx(() => [
                withDirectives(createElementVNode("button", {
                  type: "button",
                  class: normalizeClass([unref(ns).e("arrow"), unref(ns).em("arrow", "left")]),
                  "aria-label": unref(t)("el.carousel.leftArrow"),
                  onMouseenter: ($event) => unref(handleButtonEnter)("left"),
                  onMouseleave: unref(handleButtonLeave),
                  onClick: withModifiers(($event) => unref(throttledArrowClick)(unref(activeIndex) - 1), ["stop"])
                }, [
                  createVNode(unref(ElIcon), null, {
                    default: withCtx(() => [
                      createVNode(unref(arrow_left_default))
                    ]),
                    _: 1
                  })
                ], 42, ["aria-label", "onMouseenter", "onMouseleave", "onClick"]), [
                  [
                    vShow,
                    (_ctx.arrow === "always" || unref(hover)) && (props.loop || unref(activeIndex) > 0)
                  ]
                ])
              ]),
              _: 1
            })) : createCommentVNode("v-if", true),
            unref(arrowDisplay) ? (openBlock(), createBlock(Transition, {
              key: 1,
              name: "carousel-arrow-right",
              persisted: ""
            }, {
              default: withCtx(() => [
                withDirectives(createElementVNode("button", {
                  type: "button",
                  class: normalizeClass([unref(ns).e("arrow"), unref(ns).em("arrow", "right")]),
                  "aria-label": unref(t)("el.carousel.rightArrow"),
                  onMouseenter: ($event) => unref(handleButtonEnter)("right"),
                  onMouseleave: unref(handleButtonLeave),
                  onClick: withModifiers(($event) => unref(throttledArrowClick)(unref(activeIndex) + 1), ["stop"])
                }, [
                  createVNode(unref(ElIcon), null, {
                    default: withCtx(() => [
                      createVNode(unref(arrow_right_default))
                    ]),
                    _: 1
                  })
                ], 42, ["aria-label", "onMouseenter", "onMouseleave", "onClick"]), [
                  [
                    vShow,
                    (_ctx.arrow === "always" || unref(hover)) && (props.loop || unref(activeIndex) < unref(items).length - 1)
                  ]
                ])
              ]),
              _: 1
            })) : createCommentVNode("v-if", true),
            createElementVNode("div", {
              class: normalizeClass(unref(carouselContainer)),
              style: normalizeStyle(unref(containerStyle)),
              onTransitionend: unref(handleTransitionEnd)
            }, [
              createVNode(unref(PlaceholderItem)),
              renderSlot(_ctx.$slots, "default")
            ], 46, ["onTransitionend"]),
            _ctx.indicatorPosition !== "none" ? (openBlock(), createElementBlock("ul", {
              key: 2,
              class: normalizeClass(unref(indicatorsClasses))
            }, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(unref(items), (item, index22) => {
                return withDirectives((openBlock(), createElementBlock("li", {
                  key: index22,
                  class: normalizeClass([
                    unref(ns).e("indicator"),
                    unref(ns).em("indicator", _ctx.direction),
                    unref(ns).is("active", index22 === unref(activeIndex))
                  ]),
                  onMouseenter: ($event) => unref(throttledIndicatorHover)(index22),
                  onClick: withModifiers(($event) => unref(handleIndicatorClick)(index22), ["stop"])
                }, [
                  createElementVNode("button", {
                    class: normalizeClass(unref(ns).e("button")),
                    "aria-label": unref(t)("el.carousel.indicator", { index: index22 + 1 })
                  }, [
                    unref(hasLabel) ? (openBlock(), createElementBlock("span", { key: 0 }, toDisplayString(item.props.label), 1)) : createCommentVNode("v-if", true)
                  ], 10, ["aria-label"])
                ], 42, ["onMouseenter", "onClick"])), [
                  [vShow, unref(isTwoLengthShow)(index22)]
                ]);
              }), 128))
            ], 2)) : createCommentVNode("v-if", true),
            props.motionBlur ? (openBlock(), createElementBlock("svg", {
              key: 3,
              xmlns: "http://www.w3.org/2000/svg",
              version: "1.1",
              style: { "display": "none" }
            }, [
              createElementVNode("defs", null, [
                createElementVNode("filter", { id: "elCarouselHorizontal" }, [
                  createElementVNode("feGaussianBlur", {
                    in: "SourceGraphic",
                    stdDeviation: "12,0"
                  })
                ]),
                createElementVNode("filter", { id: "elCarouselVertical" }, [
                  createElementVNode("feGaussianBlur", {
                    in: "SourceGraphic",
                    stdDeviation: "0,10"
                  })
                ])
              ])
            ])) : createCommentVNode("v-if", true)
          ], 42, ["onMouseenter", "onMouseleave"]);
        };
      }
    });
    Carousel = /* @__PURE__ */ _export_sfc2(_sfc_main$2, [["__file", "carousel.vue"]]);
    carouselItemProps = buildProps({
      name: { type: String, default: "" },
      label: {
        type: [String, Number],
        default: ""
      }
    });
    useCarouselItem = (props) => {
      const carouselContext = inject(carouselContextKey);
      const instance6 = getCurrentInstance2();
      const carouselItemRef = ref2();
      const hover = ref2(false);
      const translate2 = ref2(0);
      const scale = ref2(1);
      const active = ref2(false);
      const ready = ref2(false);
      const inStage = ref2(false);
      const animating = ref2(false);
      const { isCardType, isVertical, cardScale } = carouselContext;
      function handleItemClick() {
        if (carouselContext && unref(isCardType)) {
          const index22 = carouselContext.items.value.findIndex(({ uid }) => uid === instance6.uid);
          carouselContext.setActiveItem(index22);
        }
      }
      return {
        carouselItemRef,
        active,
        animating,
        hover,
        inStage,
        isVertical,
        translate: translate2,
        isCardType,
        scale,
        ready,
        handleItemClick
      };
    };
    __default__ = defineComponent({
      name: CAROUSEL_ITEM_NAME
    });
    _sfc_main$1 = /* @__PURE__ */ defineComponent({
      ...__default__,
      props: carouselItemProps,
      setup(__props) {
        const ns = useNamespace("carousel");
        const {
          carouselItemRef,
          active,
          animating,
          hover,
          inStage,
          isVertical,
          translate: translate2,
          isCardType,
          scale,
          ready,
          handleItemClick
        } = useCarouselItem();
        const itemKls = computed(() => [
          ns.e("item"),
          ns.is("active", active.value),
          ns.is("in-stage", inStage.value),
          ns.is("hover", hover.value),
          ns.is("animating", animating.value),
          {
            [ns.em("item", "card")]: isCardType.value,
            [ns.em("item", "card-vertical")]: isCardType.value && isVertical.value
          }
        ]);
        const itemStyle = computed(() => {
          const translateType = `translate${unref(isVertical) ? "Y" : "X"}`;
          const _translate = `${translateType}(${unref(translate2)}px)`;
          const _scale = `scale(${unref(scale)})`;
          const transform = [_translate, _scale].join(" ");
          return {
            transform
          };
        });
        return (_ctx, _cache) => {
          return withDirectives((openBlock(), createElementBlock("div", {
            ref_key: "carouselItemRef",
            ref: carouselItemRef,
            class: normalizeClass(unref(itemKls)),
            style: normalizeStyle(unref(itemStyle)),
            onClick: unref(handleItemClick)
          }, [
            unref(isCardType) ? withDirectives((openBlock(), createElementBlock("div", {
              key: 0,
              class: normalizeClass(unref(ns).e("mask"))
            }, null, 2)), [
              [vShow, !unref(active)]
            ]) : createCommentVNode("v-if", true),
            renderSlot(_ctx.$slots, "default")
          ], 14, ["onClick"])), [
            [vShow, unref(ready)]
          ]);
        };
      }
    });
    CarouselItem = /* @__PURE__ */ _export_sfc2(_sfc_main$1, [["__file", "carousel-item.vue"]]);
    ElCarousel = withInstall(Carousel, {
      CarouselItem
    });
    ElCarouselItem = withNoopInstall(CarouselItem);
    messageTypes = ["success", "info", "warning", "error"];
    messageDefaults = mutable({
      customClass: "",
      center: false,
      dangerouslyUseHTMLString: false,
      duration: 3e3,
      icon: void 0,
      id: "",
      message: "",
      onClose: void 0,
      showClose: false,
      type: "info",
      plain: false,
      offset: 16,
      zIndex: 0,
      grouping: false,
      repeatNum: 1,
      appendTo: void 0
    });
    buildProps({
      customClass: {
        type: String,
        default: messageDefaults.customClass
      },
      center: {
        type: Boolean,
        default: messageDefaults.center
      },
      dangerouslyUseHTMLString: {
        type: Boolean,
        default: messageDefaults.dangerouslyUseHTMLString
      },
      duration: {
        type: Number,
        default: messageDefaults.duration
      },
      icon: {
        type: iconPropType,
        default: messageDefaults.icon
      },
      id: {
        type: String,
        default: messageDefaults.id
      },
      message: {
        type: definePropType([
          String,
          Object,
          Function
        ]),
        default: messageDefaults.message
      },
      onClose: {
        type: definePropType(Function),
        default: messageDefaults.onClose
      },
      showClose: {
        type: Boolean,
        default: messageDefaults.showClose
      },
      type: {
        type: String,
        values: messageTypes,
        default: messageDefaults.type
      },
      plain: {
        type: Boolean,
        default: messageDefaults.plain
      },
      offset: {
        type: Number,
        default: messageDefaults.offset
      },
      zIndex: {
        type: Number,
        default: messageDefaults.zIndex
      },
      grouping: {
        type: Boolean,
        default: messageDefaults.grouping
      },
      repeatNum: {
        type: Number,
        default: messageDefaults.repeatNum
      }
    });
    instances = shallowReactive([]);
    normalizeOptions = (params) => {
      const options = !params || isString(params) || isVNode(params) || isFunction(params) ? { message: params } : params;
      const normalized = {
        ...messageDefaults,
        ...options
      };
      if (!normalized.appendTo) {
        normalized.appendTo = (void 0).body;
      } else if (isString(normalized.appendTo)) {
        let appendTo = (void 0).querySelector(normalized.appendTo);
        if (!isElement(appendTo)) {
          appendTo = (void 0).body;
        }
        normalized.appendTo = appendTo;
      }
      if (isBoolean(messageConfig.grouping) && !normalized.grouping) {
        normalized.grouping = messageConfig.grouping;
      }
      if (isNumber(messageConfig.duration) && normalized.duration === 3e3) {
        normalized.duration = messageConfig.duration;
      }
      if (isNumber(messageConfig.offset) && normalized.offset === 16) {
        normalized.offset = messageConfig.offset;
      }
      if (isBoolean(messageConfig.showClose) && !normalized.showClose) {
        normalized.showClose = messageConfig.showClose;
      }
      return normalized;
    };
    message = (options = {}, context) => {
      return { close: () => void 0 };
    };
    messageTypes.forEach((type) => {
      message[type] = (options = {}, appContext) => {
        const normalized = normalizeOptions(options);
        return message({ ...normalized, type });
      };
    });
    message.closeAll = closeAll;
    message._context = null;
    ElMessage = withInstallFunction(message, "$message");
    _sfc_main3 = {
      __name: "index",
      __ssrInlineRender: true,
      setup(__props) {
        useSeoMeta({ title: "ITE | Home" });
        return (_ctx, _push, _parent, _attrs) => {
          const _component_site_title = _sfc_main$6;
          const _component_el_button = ElButton;
          const _component_el_carousel = ElCarousel;
          const _component_el_carousel_item = ElCarouselItem;
          _push(`<div${ssrRenderAttrs3(mergeProps({ class: "container-fluid home-content" }, _attrs))} data-v-fe77d168><button data-v-fe77d168>Go to Dashboard</button>`);
          _push(ssrRenderComponent(_component_site_title, null, null, _parent));
          _push(ssrRenderComponent(_component_el_button, {
            type: "primary",
            onClick: ($event) => unref(ElMessage)("hello")
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`Button`);
              } else {
                return [
                  createTextVNode("Button")
                ];
              }
            }),
            _: 1
          }, _parent));
          _push(ssrRenderComponent(_component_el_carousel, {
            interval: 4e3,
            type: "card",
            height: "200px"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<!--[-->`);
                ssrRenderList(6, (item) => {
                  _push2(ssrRenderComponent(_component_el_carousel_item, { key: item }, {
                    default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                      if (_push3) {
                        _push3(`<h3 text="2xl" justify="center" data-v-fe77d168${_scopeId2}>${ssrInterpolate(item)}</h3>`);
                      } else {
                        return [
                          createVNode("h3", {
                            text: "2xl",
                            justify: "center"
                          }, toDisplayString(item), 1)
                        ];
                      }
                    }),
                    _: 2
                  }, _parent2, _scopeId));
                });
                _push2(`<!--]-->`);
              } else {
                return [
                  (openBlock(), createBlock(Fragment, null, renderList(6, (item) => {
                    return createVNode(_component_el_carousel_item, { key: item }, {
                      default: withCtx(() => [
                        createVNode("h3", {
                          text: "2xl",
                          justify: "center"
                        }, toDisplayString(item), 1)
                      ]),
                      _: 2
                    }, 1024);
                  }), 64))
                ];
              }
            }),
            _: 1
          }, _parent));
          _push(`</div>`);
        };
      }
    };
    _sfc_setup3 = _sfc_main3.setup;
    _sfc_main3.setup = (props, ctx) => {
      const ssrContext = useSSRContext3();
      (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
      return _sfc_setup3 ? _sfc_setup3(props, ctx) : void 0;
    };
    index = /* @__PURE__ */ _export_sfc(_sfc_main3, [["__scopeId", "data-v-fe77d168"]]);
  }
});

// .netlify/functions-internal/server/chunks/build/index-CyAywMu6.mjs
var index_CyAywMu6_exports = {};
__export(index_CyAywMu6_exports, {
  default: () => _sfc_main4
});
import { ssrRenderAttrs as ssrRenderAttrs4 } from "vue/server-renderer";
import { useI18n as useI18n2 } from "vue-i18n";
import { useSSRContext as useSSRContext4 } from "vue";
import "@unhead/shared";
import "consola/core";
import "unhead";
import "vue-router";
import "dayjs";
import "dayjs/plugin/updateLocale.js";
import "dayjs/plugin/utc.js";
var _sfc_main4, _sfc_setup4;
var init_index_CyAywMu6 = __esm({
  ".netlify/functions-internal/server/chunks/build/index-CyAywMu6.mjs"() {
    "use strict";
    init_index_DdJWkO();
    init_server();
    init_nitro();
    _sfc_main4 = {
      __name: "index",
      __ssrInlineRender: true,
      setup(__props) {
        const { t } = useI18n2();
        useSeoMeta({
          titleTemplate: (title) => {
            return `${title} | ${t("page.map")}`;
          }
        });
        return (_ctx, _push, _parent, _attrs) => {
          _push(`<div${ssrRenderAttrs4(_attrs)}>Map</div>`);
        };
      }
    };
    _sfc_setup4 = _sfc_main4.setup;
    _sfc_main4.setup = (props, ctx) => {
      const ssrContext = useSSRContext4();
      (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/map/index.vue");
      return _sfc_setup4 ? _sfc_setup4(props, ctx) : void 0;
    };
  }
});

// .netlify/functions-internal/server/chunks/build/index-BupDkBmr.mjs
var index_BupDkBmr_exports = {};
__export(index_BupDkBmr_exports, {
  default: () => _sfc_main5
});
import { ssrRenderAttrs as ssrRenderAttrs5 } from "vue/server-renderer";
import { useI18n as useI18n3 } from "vue-i18n";
import { useSSRContext as useSSRContext5 } from "vue";
import "@unhead/shared";
import "consola/core";
import "unhead";
import "vue-router";
import "dayjs";
import "dayjs/plugin/updateLocale.js";
import "dayjs/plugin/utc.js";
var _sfc_main5, _sfc_setup5;
var init_index_BupDkBmr = __esm({
  ".netlify/functions-internal/server/chunks/build/index-BupDkBmr.mjs"() {
    "use strict";
    init_index_DdJWkO();
    init_server();
    init_nitro();
    _sfc_main5 = {
      __name: "index",
      __ssrInlineRender: true,
      setup(__props) {
        const { t } = useI18n3();
        useSeoMeta({
          titleTemplate: (title) => {
            return `${title} | ${t("page.profile")}`;
          }
        });
        return (_ctx, _push, _parent, _attrs) => {
          _push(`<div${ssrRenderAttrs5(_attrs)}>adwdsdw</div>`);
        };
      }
    };
    _sfc_setup5 = _sfc_main5.setup;
    _sfc_main5.setup = (props, ctx) => {
      const ssrContext = useSSRContext5();
      (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/profile/index.vue");
      return _sfc_setup5 ? _sfc_setup5(props, ctx) : void 0;
    };
  }
});

// .netlify/functions-internal/server/chunks/build/cookie-DaDFWqWH.mjs
import { ref as ref3 } from "vue";
function useCookie(name, _opts) {
  var _a2, _b;
  var _a;
  const opts = { ...CookieDefaults, ..._opts };
  (_a2 = opts.filter) != null ? _a2 : opts.filter = (key) => key === name;
  const cookies = readRawCookies(opts) || {};
  let delay;
  if (opts.maxAge !== void 0) {
    delay = opts.maxAge * 1e3;
  } else if (opts.expires) {
    delay = opts.expires.getTime() - Date.now();
  }
  const hasExpired = delay !== void 0 && delay <= 0;
  const cookieValue = klona(hasExpired ? void 0 : (_b = cookies[name]) != null ? _b : (_a = opts.default) == null ? void 0 : _a.call(opts));
  const cookie = ref3(cookieValue);
  {
    const nuxtApp = useNuxtApp();
    const writeFinalCookieValue = () => {
      if (opts.readonly || isEqual(cookie.value, cookies[name])) {
        return;
      }
      nuxtApp._cookies || (nuxtApp._cookies = {});
      if (name in nuxtApp._cookies) {
        if (isEqual(cookie.value, nuxtApp._cookies[name])) {
          return;
        }
      }
      nuxtApp._cookies[name] = cookie.value;
      writeServerCookie(useRequestEvent(nuxtApp), name, cookie.value, opts);
    };
    const unhook = nuxtApp.hooks.hookOnce("app:rendered", writeFinalCookieValue);
    nuxtApp.hooks.hookOnce("app:error", () => {
      unhook();
      return writeFinalCookieValue();
    });
  }
  return cookie;
}
function readRawCookies(opts = {}) {
  {
    return parse(getRequestHeader(useRequestEvent(), "cookie") || "", opts);
  }
}
function writeServerCookie(event, name, value, opts = {}) {
  if (event) {
    if (value !== null && value !== void 0) {
      return setCookie(event, name, value, opts);
    }
    if (getCookie(event, name) !== void 0) {
      return deleteCookie(event, name, opts);
    }
  }
}
var CookieDefaults;
var init_cookie_DaDFWqWH = __esm({
  ".netlify/functions-internal/server/chunks/build/cookie-DaDFWqWH.mjs"() {
    "use strict";
    init_nitro();
    init_server();
    CookieDefaults = {
      path: "/",
      watch: true,
      decode: (val) => destr(decodeURIComponent(val)),
      encode: (val) => encodeURIComponent(typeof val === "string" ? val : JSON.stringify(val))
    };
  }
});

// .netlify/functions-internal/server/chunks/build/authenticate-CY38wZJr.mjs
var authenticate_CY38wZJr_exports = {};
__export(authenticate_CY38wZJr_exports, {
  default: () => authenticate
});
import "vue";
import "consola/core";
import "unhead";
import "@unhead/shared";
import "vue-router";
import "dayjs";
import "dayjs/plugin/updateLocale.js";
import "dayjs/plugin/utc.js";
import "vue-i18n";
import "vue/server-renderer";
var authenticate;
var init_authenticate_CY38wZJr = __esm({
  ".netlify/functions-internal/server/chunks/build/authenticate-CY38wZJr.mjs"() {
    "use strict";
    init_server();
    init_cookie_DaDFWqWH();
    init_nitro();
    authenticate = defineNuxtRouteMiddleware(() => {
      const { value: token } = useCookie("token");
      if (!token) {
        return navigateTo("/");
      }
    });
  }
});

// .netlify/functions-internal/server/chunks/build/redirectIfAuthenticated-CftVgjT9.mjs
var redirectIfAuthenticated_CftVgjT9_exports = {};
__export(redirectIfAuthenticated_CftVgjT9_exports, {
  default: () => redirectIfAuthenticated
});
import "vue";
import "consola/core";
import "unhead";
import "@unhead/shared";
import "vue-router";
import "dayjs";
import "dayjs/plugin/updateLocale.js";
import "dayjs/plugin/utc.js";
import "vue-i18n";
import "vue/server-renderer";
var redirectIfAuthenticated;
var init_redirectIfAuthenticated_CftVgjT9 = __esm({
  ".netlify/functions-internal/server/chunks/build/redirectIfAuthenticated-CftVgjT9.mjs"() {
    "use strict";
    init_server();
    init_cookie_DaDFWqWH();
    init_nitro();
    redirectIfAuthenticated = defineNuxtRouteMiddleware(() => {
      const { value: token } = useCookie("token");
      if (token) {
        return navigateTo("/dashboard");
      }
    });
  }
});

// .netlify/functions-internal/server/chunks/build/BaseService-DD57qP2C.mjs
var BaseService_DD57qP2C_exports = {};
__export(BaseService_DD57qP2C_exports, {
  default: () => BaseService
});
import { computed as computed2, toValue, reactive as reactive2, ref as ref4, shallowRef as shallowRef2, toRef as toRef2, getCurrentInstance as getCurrentInstance3, onServerPrefetch, unref as unref2 } from "vue";
import swal from "sweetalert2";
import "unhead";
import "@unhead/shared";
import "vue-router";
import "dayjs";
import "dayjs/plugin/updateLocale.js";
import "dayjs/plugin/utc.js";
import "vue-i18n";
import "vue/server-renderer";
import "consola/core";
function useAsyncData(...args) {
  var _a2, _b2, _c, _d, _e, _f, _g, _h;
  var _b;
  const autoKey = typeof args[args.length - 1] === "string" ? args.pop() : void 0;
  if (typeof args[0] !== "string") {
    args.unshift(autoKey);
  }
  let [key, _handler, options = {}] = args;
  if (typeof key !== "string") {
    throw new TypeError("[nuxt] [asyncData] key must be a string.");
  }
  if (typeof _handler !== "function") {
    throw new TypeError("[nuxt] [asyncData] handler must be a function.");
  }
  const nuxtApp = useNuxtApp();
  const handler2 = _handler;
  const getDefault = () => asyncDataDefaults.value;
  const getDefaultCachedData = () => nuxtApp.isHydrating ? nuxtApp.payload.data[key] : nuxtApp.static.data[key];
  options.server = (_a2 = options.server) != null ? _a2 : true;
  options.default = (_b2 = options.default) != null ? _b2 : getDefault;
  options.getCachedData = (_c = options.getCachedData) != null ? _c : getDefaultCachedData;
  options.lazy = (_d = options.lazy) != null ? _d : false;
  options.immediate = (_e = options.immediate) != null ? _e : true;
  options.deep = (_f = options.deep) != null ? _f : asyncDataDefaults.deep;
  options.dedupe = (_g = options.dedupe) != null ? _g : "cancel";
  const initialCachedData = options.getCachedData(key, nuxtApp);
  const hasCachedData = initialCachedData != null;
  if (!nuxtApp._asyncData[key] || !options.immediate) {
    (_h = (_b = nuxtApp.payload._errors)[key]) != null ? _h : _b[key] = asyncDataDefaults.errorValue;
    const _ref = options.deep ? ref4 : shallowRef2;
    nuxtApp._asyncData[key] = {
      data: _ref(hasCachedData ? initialCachedData : options.default()),
      pending: ref4(!hasCachedData),
      error: toRef2(nuxtApp.payload._errors, key),
      status: ref4("idle"),
      _default: options.default
    };
  }
  const asyncData = { ...nuxtApp._asyncData[key] };
  delete asyncData._default;
  asyncData.refresh = asyncData.execute = (opts = {}) => {
    var _a3;
    if (nuxtApp._asyncDataPromises[key]) {
      if (isDefer((_a3 = opts.dedupe) != null ? _a3 : options.dedupe)) {
        return nuxtApp._asyncDataPromises[key];
      }
      nuxtApp._asyncDataPromises[key].cancelled = true;
    }
    if (opts._initial || nuxtApp.isHydrating && opts._initial !== false) {
      const cachedData = opts._initial ? initialCachedData : options.getCachedData(key, nuxtApp);
      if (cachedData != null) {
        return Promise.resolve(cachedData);
      }
    }
    asyncData.pending.value = true;
    asyncData.status.value = "pending";
    const promise = new Promise(
      (resolve2, reject) => {
        try {
          resolve2(handler2(nuxtApp));
        } catch (err) {
          reject(err);
        }
      }
    ).then(async (_result) => {
      if (promise.cancelled) {
        return nuxtApp._asyncDataPromises[key];
      }
      let result = _result;
      if (options.transform) {
        result = await options.transform(_result);
      }
      if (options.pick) {
        result = pick(result, options.pick);
      }
      nuxtApp.payload.data[key] = result;
      asyncData.data.value = result;
      asyncData.error.value = asyncDataDefaults.errorValue;
      asyncData.status.value = "success";
    }).catch((error2) => {
      if (promise.cancelled) {
        return nuxtApp._asyncDataPromises[key];
      }
      asyncData.error.value = createError(error2);
      asyncData.data.value = unref2(options.default());
      asyncData.status.value = "error";
    }).finally(() => {
      if (promise.cancelled) {
        return;
      }
      asyncData.pending.value = false;
      delete nuxtApp._asyncDataPromises[key];
    });
    nuxtApp._asyncDataPromises[key] = promise;
    return nuxtApp._asyncDataPromises[key];
  };
  asyncData.clear = () => clearNuxtDataByKey(nuxtApp, key);
  const initialFetch = () => asyncData.refresh({ _initial: true });
  const fetchOnServer = options.server !== false && nuxtApp.payload.serverRendered;
  if (fetchOnServer && options.immediate) {
    const promise = initialFetch();
    if (getCurrentInstance3()) {
      onServerPrefetch(() => promise);
    } else {
      nuxtApp.hook("app:created", async () => {
        await promise;
      });
    }
  }
  const asyncDataPromise = Promise.resolve(nuxtApp._asyncDataPromises[key]).then(() => asyncData);
  Object.assign(asyncDataPromise, asyncData);
  return asyncDataPromise;
}
function clearNuxtDataByKey(nuxtApp, key) {
  if (key in nuxtApp.payload.data) {
    nuxtApp.payload.data[key] = void 0;
  }
  if (key in nuxtApp.payload._errors) {
    nuxtApp.payload._errors[key] = asyncDataDefaults.errorValue;
  }
  if (nuxtApp._asyncData[key]) {
    nuxtApp._asyncData[key].data.value = void 0;
    nuxtApp._asyncData[key].error.value = asyncDataDefaults.errorValue;
    nuxtApp._asyncData[key].pending.value = false;
    nuxtApp._asyncData[key].status.value = "idle";
  }
  if (key in nuxtApp._asyncDataPromises) {
    if (nuxtApp._asyncDataPromises[key]) {
      nuxtApp._asyncDataPromises[key].cancelled = true;
    }
    nuxtApp._asyncDataPromises[key] = void 0;
  }
}
function pick(obj, keys) {
  const newObj = {};
  for (const key of keys) {
    newObj[key] = obj[key];
  }
  return newObj;
}
function useFetch(request, arg1, arg2) {
  const [opts = {}, autoKey] = typeof arg1 === "string" ? [{}, arg1] : [arg1, arg2];
  const _request = computed2(() => toValue(request));
  const _key = opts.key || hash([autoKey, typeof _request.value === "string" ? _request.value : "", ...generateOptionSegments(opts)]);
  if (!_key || typeof _key !== "string") {
    throw new TypeError("[nuxt] [useFetch] key must be a string: " + _key);
  }
  if (!request) {
    throw new Error("[nuxt] [useFetch] request is missing.");
  }
  const key = _key === autoKey ? "$f" + _key : _key;
  if (!opts.baseURL && typeof _request.value === "string" && (_request.value[0] === "/" && _request.value[1] === "/")) {
    throw new Error('[nuxt] [useFetch] the request URL must not start with "//".');
  }
  const {
    server,
    lazy,
    default: defaultFn,
    transform,
    pick: pick2,
    watch: watch5,
    immediate,
    getCachedData,
    deep,
    dedupe,
    ...fetchOptions
  } = opts;
  const _fetchOptions = reactive2({
    ...fetchDefaults,
    ...fetchOptions,
    cache: typeof opts.cache === "boolean" ? void 0 : opts.cache
  });
  const _asyncDataOptions = {
    server,
    lazy,
    default: defaultFn,
    transform,
    pick: pick2,
    immediate,
    getCachedData,
    deep,
    dedupe,
    watch: watch5 === false ? [] : [_fetchOptions, _request, ...watch5 || []]
  };
  let controller;
  const asyncData = useAsyncData(key, () => {
    var _a;
    (_a = controller == null ? void 0 : controller.abort) == null ? void 0 : _a.call(controller, new DOMException("Request aborted as another request to the same endpoint was initiated.", "AbortError"));
    controller = typeof AbortController !== "undefined" ? new AbortController() : {};
    const timeoutLength = toValue(opts.timeout);
    let timeoutId;
    if (timeoutLength) {
      timeoutId = setTimeout(() => controller.abort(new DOMException("Request aborted due to timeout.", "AbortError")), timeoutLength);
      controller.signal.onabort = () => clearTimeout(timeoutId);
    }
    let _$fetch = opts.$fetch || globalThis.$fetch;
    if (!opts.$fetch) {
      const isLocalFetch = typeof _request.value === "string" && _request.value[0] === "/" && (!toValue(opts.baseURL) || toValue(opts.baseURL)[0] === "/");
      if (isLocalFetch) {
        _$fetch = useRequestFetch();
      }
    }
    return _$fetch(_request.value, { signal: controller.signal, ..._fetchOptions }).finally(() => {
      clearTimeout(timeoutId);
    });
  }, _asyncDataOptions);
  return asyncData;
}
function generateOptionSegments(opts) {
  var _a;
  const segments = [
    ((_a = toValue(opts.method)) == null ? void 0 : _a.toUpperCase()) || "GET",
    toValue(opts.baseURL)
  ];
  for (const _obj of [opts.params || opts.query]) {
    const obj = toValue(_obj);
    if (!obj) {
      continue;
    }
    const unwrapped = {};
    for (const [key, value] of Object.entries(obj)) {
      unwrapped[toValue(key)] = toValue(value);
    }
    segments.push(unwrapped);
  }
  return segments;
}
var isDefer, useAuthPopupStore, isFunction2, useSwal, useHttp, instance, BaseService;
var init_BaseService_DD57qP2C = __esm({
  ".netlify/functions-internal/server/chunks/build/BaseService-DD57qP2C.mjs"() {
    "use strict";
    init_server();
    init_cookie_DaDFWqWH();
    init_nitro();
    isDefer = (dedupe) => dedupe === "defer" || dedupe === false;
    useAuthPopupStore = defineStore("auth-popup", () => {
      const isShowLoginPopup = ref4(false);
      const showLoginPopup = () => {
        isShowLoginPopup.value = true;
      };
      const hideLoginPopup = () => {
        isShowLoginPopup.value = false;
      };
      return { isShowLoginPopup, showLoginPopup, hideLoginPopup };
    });
    isFunction2 = (func) => {
      if (func && typeof func === "function") {
        return true;
      }
      return false;
    };
    useSwal = () => {
      const showSwal = (title = "", titleText = "", type = "info", confirm = () => {
      }, reject = () => {
      }, options = {}) => {
        swal.fire({
          title,
          text: titleText,
          icon: type,
          allowOutsideClick: () => !swal.isLoading(),
          ...options
        }).then((result) => {
          if (result.isConfirmed) {
            swal.close();
            if (isFunction2(confirm)) {
              confirm();
            }
          } else {
            swal.close();
            if (isFunction2(reject)) {
              reject();
            }
          }
        });
      };
      const success = (title, message2, options = {}) => {
        showSwal(title, message2, "success", options);
      };
      const info = (title, message2, options = {}) => {
        showSwal(title, message2, "info", options);
      };
      const error2 = (title, message2, options = {}) => {
        showSwal(title, message2, "error", options);
      };
      const warning = (title, message2, confirm = () => {
      }, reject = () => {
      }, options = {}) => {
        showSwal(title, message2, "warning", confirm, reject, options);
      };
      const question = (title, message2, confirm = () => {
      }, reject = () => {
      }, options = {}) => {
        showSwal(title, message2, "question", confirm, reject, options);
      };
      return {
        success,
        info,
        error: error2,
        warning,
        question
      };
    };
    useHttp = (url, options) => {
      const config3 = useRuntimeConfig();
      const baseURL2 = config3.public.serverApiUrl + "/" + config3.public.apiVersion;
      const cookie = useCookie("token");
      const token = cookie.value;
      const { showLoginPopup } = useAuthPopupStore();
      options = {
        ...options,
        headers: {
          Authorization: `Bearer ${token}`,
          accept: "application/json",
          "Content-Type": "application/json",
          "X-SSDAP-Locale": "en"
        },
        async onResponseError({ request, response, options: options2 }) {
          var _a;
          if (response.status === 401) {
            cookie.value = null;
            await showLoginPopup();
          } else if (response.status !== 422) {
            if (await ((_a = response == null ? void 0 : response._data) == null ? void 0 : _a.message)) {
              const swal2 = await useSwal();
              await swal2.error("", response._data.message);
            }
          }
        }
      };
      return useFetch(url, { baseURL: baseURL2, ...options }, "$H54fdbas9U");
    };
    instance = null;
    BaseService = class _BaseService {
      constructor(prefix) {
        this._prefix = prefix;
      }
      static getInstance() {
        if (!instance) {
          instance = new _BaseService();
        }
        return instance;
      }
      _get(path, params = null) {
        let payload2 = {};
        if (params) {
          payload2 = { body: params };
        }
        return useHttp(path, { method: "GET", ...payload2 });
      }
      _post(path, params = null) {
        let payload2 = {};
        if (params) {
          payload2 = { body: params };
        }
        return useHttp(path, { method: "POST", ...payload2 });
      }
      _put(path, params = null) {
        let payload2 = {};
        if (params) {
          payload2 = { body: params };
        }
        return useHttp(path, { method: "PUT", ...payload2 });
      }
      _delete(path, params = null) {
        return useHttp(path, { method: "DELETE", ...payload });
      }
    };
  }
});

// .netlify/functions-internal/server/chunks/build/AuthService-CQwCZy8K.mjs
var AuthService_CQwCZy8K_exports = {};
__export(AuthService_CQwCZy8K_exports, {
  default: () => AuthService
});
import "vue";
import "consola/core";
import "unhead";
import "@unhead/shared";
import "vue-router";
import "dayjs";
import "dayjs/plugin/updateLocale.js";
import "dayjs/plugin/utc.js";
import "vue-i18n";
import "vue/server-renderer";
import "sweetalert2";
var instance2, AuthService;
var init_AuthService_CQwCZy8K = __esm({
  ".netlify/functions-internal/server/chunks/build/AuthService-CQwCZy8K.mjs"() {
    "use strict";
    init_BaseService_DD57qP2C();
    init_server();
    init_nitro();
    init_cookie_DaDFWqWH();
    instance2 = null;
    AuthService = class _AuthService extends BaseService {
      constructor() {
        super("auth");
      }
      static getInstance() {
        if (!instance2) {
          instance2 = new _AuthService();
        }
        return instance2;
      }
      async login(req) {
        return await this._post(`${this._prefix}/login`, req);
      }
      async register(req) {
        return await this._post(`${this._prefix}/register`, req);
      }
      async sendOTPCode(req) {
        return await this._post(`${this._prefix}/send-otp-code`, req);
      }
      async verifyOTPCode(req) {
        return await this._post(`${this._prefix}/verify-otp-code`, req);
      }
      async resetPassword(req) {
        return await this._post(`${this._prefix}/reset-password`, req);
      }
      async logout(req) {
        return await this._post(`${this._prefix}/logout`, req);
      }
    };
  }
});

// .netlify/functions-internal/server/chunks/build/UserService-B_vqosOi.mjs
var UserService_B_vqosOi_exports = {};
__export(UserService_B_vqosOi_exports, {
  default: () => UserService
});
import "vue";
import "consola/core";
import "unhead";
import "@unhead/shared";
import "vue-router";
import "dayjs";
import "dayjs/plugin/updateLocale.js";
import "dayjs/plugin/utc.js";
import "vue-i18n";
import "vue/server-renderer";
import "sweetalert2";
var instance3, UserService;
var init_UserService_B_vqosOi = __esm({
  ".netlify/functions-internal/server/chunks/build/UserService-B_vqosOi.mjs"() {
    "use strict";
    init_BaseService_DD57qP2C();
    init_server();
    init_nitro();
    init_cookie_DaDFWqWH();
    instance3 = null;
    UserService = class _UserService extends BaseService {
      constructor() {
        super("user");
      }
      static getInstance() {
        if (!instance3) {
          instance3 = new _UserService();
        }
        return instance3;
      }
      async getMe() {
        return await this._get(`${this._prefix}/me`);
      }
      async updateProfile(req) {
        return await this._post(`${this._prefix}/update-profile`, req);
      }
      async updatePassword(req) {
        return await this._post(`${this._prefix}/update-password`, req);
      }
      async disabledTwoFactorAuthentication(req) {
        return await this._post(`${this._prefix}/disable-two-factor`, req);
      }
      async confirmTwoFactorInfo(req) {
        return await this._post(`${this._prefix}/confirm-two-factor-info`, req);
      }
    };
  }
});

// .netlify/functions-internal/server/chunks/build/composables-OxtQ7pZ5.mjs
var useDayjs;
var init_composables_OxtQ7pZ5 = __esm({
  ".netlify/functions-internal/server/chunks/build/composables-OxtQ7pZ5.mjs"() {
    "use strict";
    init_server();
    useDayjs = () => {
      const { $dayjs } = useNuxtApp();
      return $dayjs;
    };
  }
});

// .netlify/functions-internal/server/chunks/build/AuthTransformer-jmxhrGaK.mjs
var AuthTransformer_jmxhrGaK_exports = {};
__export(AuthTransformer_jmxhrGaK_exports, {
  default: () => AuthTransformer
});
import "vue";
import "consola/core";
import "unhead";
import "@unhead/shared";
import "vue-router";
import "dayjs";
import "dayjs/plugin/updateLocale.js";
import "dayjs/plugin/utc.js";
import "vue-i18n";
import "vue/server-renderer";
var instance4, AuthTransformer;
var init_AuthTransformer_jmxhrGaK = __esm({
  ".netlify/functions-internal/server/chunks/build/AuthTransformer-jmxhrGaK.mjs"() {
    "use strict";
    init_composables_OxtQ7pZ5();
    init_server();
    init_nitro();
    instance4 = null;
    AuthTransformer = class _AuthTransformer {
      static getInstance() {
        if (!instance4) {
          instance4 = new _AuthTransformer();
        }
        return instance4;
      }
      fetch(res) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s, _t;
        if (!res) {
          return {};
        }
        const dayjs2 = useDayjs();
        return {
          token_type: res == null ? void 0 : res.token_type,
          access_token: res == null ? void 0 : res.access_token,
          token_expires_at: res == null ? void 0 : res.token_expires_at,
          user: {
            id: (_a = res == null ? void 0 : res.user) == null ? void 0 : _a.id,
            first_name: (_b = res == null ? void 0 : res.user) == null ? void 0 : _b.first_name,
            last_name: (_c = res == null ? void 0 : res.user) == null ? void 0 : _c.last_name,
            full_name: ((_d = res == null ? void 0 : res.user) == null ? void 0 : _d.first_name) + " " + ((_e = res == null ? void 0 : res.user) == null ? void 0 : _e.last_name),
            gender: (_f = res == null ? void 0 : res.user) == null ? void 0 : _f.gender,
            username: (_g = res == null ? void 0 : res.user) == null ? void 0 : _g.username,
            phone_number: (_h = res == null ? void 0 : res.user) == null ? void 0 : _h.phone_number,
            email: (_i = res == null ? void 0 : res.user) == null ? void 0 : _i.email,
            position: (_j = res == null ? void 0 : res.user) == null ? void 0 : _j.position,
            government_institution: (_k = res == null ? void 0 : res.user) == null ? void 0 : _k.government_institution,
            avatar: (_l = res == null ? void 0 : res.user) == null ? void 0 : _l.avatar,
            user_type: (_m = res == null ? void 0 : res.user) == null ? void 0 : _m.user_type,
            is_active: (_n = res == null ? void 0 : res.user) == null ? void 0 : _n.is_active,
            status: (_o = res == null ? void 0 : res.user) == null ? void 0 : _o.status,
            is_enable_two_factor_authentication: (_p = res == null ? void 0 : res.user) == null ? void 0 : _p.is_enable_two_factor_authentication,
            two_factor_authentication_type: (_q = res == null ? void 0 : res.user) == null ? void 0 : _q.two_factor_authentication_type,
            is_email_verified: (_r = res == null ? void 0 : res.user) == null ? void 0 : _r.is_email_verified,
            created_at: ((_s = res == null ? void 0 : res.user) == null ? void 0 : _s.created_at) ? dayjs2(res.user.created_at).format("YYYY/MM/DD hh:mm A") : "",
            updated_at: ((_t = res == null ? void 0 : res.user) == null ? void 0 : _t.updated_at) ? dayjs2(res.user.updated_at).format("YYYY/MM/DD hh:mm A") : ""
          }
        };
      }
      loginReq(req) {
        if (!req) {
          return {};
        }
        return {
          username: req == null ? void 0 : req.username,
          password: req == null ? void 0 : req.password
        };
      }
      registerReq(req) {
        if (!req) {
          return {};
        }
        return {
          first_name: req == null ? void 0 : req.first_name,
          last_name: req == null ? void 0 : req.last_name,
          gender: req == null ? void 0 : req.gender,
          username: req == null ? void 0 : req.username,
          phone_number: req == null ? void 0 : req.phone_number,
          email: req == null ? void 0 : req.email,
          password: req == null ? void 0 : req.password,
          password_confirmation: req == null ? void 0 : req.password_confirmation,
          user_type: req == null ? void 0 : req.user_type,
          position: req == null ? void 0 : req.position,
          government_institution: req == null ? void 0 : req.government_institution
        };
      }
      verifyOTPCodeReq(req) {
        if (!req) {
          return {};
        }
        return {
          action_type: req == null ? void 0 : req.action_type,
          provided_value: req == null ? void 0 : req.provided_value,
          verify_code: req.verify_code,
          two_factor_method: req == null ? void 0 : req.two_factor_method,
          two_factor_info: req == null ? void 0 : req.two_factor_info
        };
      }
    };
  }
});

// .netlify/functions-internal/server/chunks/build/UserTransformer-D3tPglEV.mjs
var UserTransformer_D3tPglEV_exports = {};
__export(UserTransformer_D3tPglEV_exports, {
  default: () => UserTransformer
});
import "vue";
import "consola/core";
import "unhead";
import "@unhead/shared";
import "vue-router";
import "dayjs";
import "dayjs/plugin/updateLocale.js";
import "dayjs/plugin/utc.js";
import "vue-i18n";
import "vue/server-renderer";
var instance5, UserTransformer;
var init_UserTransformer_D3tPglEV = __esm({
  ".netlify/functions-internal/server/chunks/build/UserTransformer-D3tPglEV.mjs"() {
    "use strict";
    init_composables_OxtQ7pZ5();
    init_server();
    init_nitro();
    instance5 = null;
    UserTransformer = class _UserTransformer {
      static getInstance() {
        if (!instance5) {
          instance5 = new _UserTransformer();
        }
        return instance5;
      }
      fetch(res) {
        if (!res) {
          return {};
        }
        const dayjs2 = useDayjs();
        return {
          id: res == null ? void 0 : res.id,
          first_name: res == null ? void 0 : res.first_name,
          last_name: res == null ? void 0 : res.last_name,
          full_name: (res == null ? void 0 : res.first_name) + " " + (res == null ? void 0 : res.last_name),
          gender: res == null ? void 0 : res.gender,
          username: res == null ? void 0 : res.username,
          phone_number: res == null ? void 0 : res.phone_number,
          email: res == null ? void 0 : res.email,
          position: res == null ? void 0 : res.position,
          government_institution: res == null ? void 0 : res.government_institution,
          avatar: res == null ? void 0 : res.avatar,
          user_type: res == null ? void 0 : res.user_type,
          is_active: res == null ? void 0 : res.is_active,
          status: res == null ? void 0 : res.status,
          is_enable_two_factor_authentication: res == null ? void 0 : res.is_enable_two_factor_authentication,
          two_factor_authentication_type: res == null ? void 0 : res.two_factor_authentication_type,
          is_email_verified: res == null ? void 0 : res.is_email_verified,
          created_at: (res == null ? void 0 : res.created_at) ? dayjs2(res.created_at).format("YYYY/MM/DD hh:mm A") : "",
          updated_at: (res == null ? void 0 : res.updated_at) ? dayjs2(res.updated_at).format("YYYY/MM/DD hh:mm A") : ""
        };
      }
      updateProfileReq(req) {
        if (!req) {
          return {};
        }
        return {
          last_name: req == null ? void 0 : req.last_name,
          first_name: req == null ? void 0 : req.first_name,
          gender: req == null ? void 0 : req.gender,
          government_institution: req == null ? void 0 : req.government_institution,
          avatar: req == null ? void 0 : req.avatar
        };
      }
      updatePasswordReq(req) {
        if (!req) {
          return {};
        }
        return {
          current_password: req == null ? void 0 : req.current_password,
          new_password: req == null ? void 0 : req.new_password,
          password_confirmation: req == null ? void 0 : req.password_confirmation
        };
      }
    };
  }
});

// .netlify/functions-internal/server/chunks/build/default-BRlDANaF.mjs
var default_BRlDANaF_exports = {};
__export(default_BRlDANaF_exports, {
  default: () => _sfc_main6
});
import { withAsyncContext, useSSRContext as useSSRContext6, computed as computed3, ref as ref5, unref as unref3, resolveComponent, mergeProps as mergeProps2, withCtx as withCtx2, createVNode as createVNode2 } from "vue";
import { ssrRenderAttrs as ssrRenderAttrs6, ssrRenderComponent as ssrRenderComponent2, ssrRenderSlot, ssrRenderTeleport, ssrRenderClass as ssrRenderClass2 } from "vue/server-renderer";
import { useI18n as useI18n4 } from "vue-i18n";
import "consola/core";
import "unhead";
import "@unhead/shared";
import "vue-router";
import "dayjs";
import "dayjs/plugin/updateLocale.js";
import "dayjs/plugin/utc.js";
var __variableDynamicImportRuntimeHelper, useService, useTransformer, useAuthenticate, useAuthStore, useLoadingStore, useLoading, _sfc_main$22, _sfc_setup$22, __nuxt_component_0, _sfc_main$12, _sfc_setup$12, __nuxt_component_1, _sfc_main6, _sfc_setup6;
var init_default_BRlDANaF = __esm({
  ".netlify/functions-internal/server/chunks/build/default-BRlDANaF.mjs"() {
    "use strict";
    init_server();
    init_cookie_DaDFWqWH();
    init_nitro();
    __variableDynamicImportRuntimeHelper = (glob, path, segs) => {
      const v = glob[path];
      if (v) {
        return typeof v === "function" ? v() : Promise.resolve(v);
      }
      return new Promise((_, reject) => {
        (typeof queueMicrotask === "function" ? queueMicrotask : setTimeout)(
          reject.bind(
            null,
            new Error(
              "Unknown variable dynamic import: " + path + (path.split("/").length !== segs ? ". Note that variables only represent file names one level deep." : "")
            )
          )
        );
      });
    };
    useService = async (service) => {
      try {
        const callbackFunction = (module, callback) => {
          if (callback && typeof callback === "function") {
            return callback(module.default.getInstance());
          }
          return module.default.getInstance();
        };
        const serviceModule = (callback) => {
          return __variableDynamicImportRuntimeHelper(/* @__PURE__ */ Object.assign({ "../services/AuthService.js": () => Promise.resolve().then(() => (init_AuthService_CQwCZy8K(), AuthService_CQwCZy8K_exports)), "../services/BaseService.js": () => Promise.resolve().then(() => (init_BaseService_DD57qP2C(), BaseService_DD57qP2C_exports)), "../services/UserService.js": () => Promise.resolve().then(() => (init_UserService_B_vqosOi(), UserService_B_vqosOi_exports)) }), `../services/${service}Service.js`, 3).then((module) => {
            return callbackFunction(module, callback);
          });
        };
        return serviceModule;
      } catch (error2) {
        return {};
      }
    };
    useTransformer = async (transformer) => {
      try {
        const callbackFunction = (module, callback) => {
          if (callback && typeof callback === "function") {
            return callback(module.default.getInstance());
          }
          return module.default.getInstance();
        };
        const transformerModule = (callback) => {
          return __variableDynamicImportRuntimeHelper(/* @__PURE__ */ Object.assign({ "../transformers/AuthTransformer.js": () => Promise.resolve().then(() => (init_AuthTransformer_jmxhrGaK(), AuthTransformer_jmxhrGaK_exports)), "../transformers/UserTransformer.js": () => Promise.resolve().then(() => (init_UserTransformer_D3tPglEV(), UserTransformer_D3tPglEV_exports)) }), `../transformers/${transformer}Transformer.js`, 3).then(
            (module) => {
              return callbackFunction(module, callback);
            }
          );
        };
        if (!transformerModule) {
          return {};
        }
        return transformerModule;
      } catch (error2) {
        return {};
      }
    };
    useAuthenticate = () => {
      const cookie = useCookie("token", { maxAge: 20160 * 60 });
      const setAccessToken = (accessToken) => {
        cookie.value = accessToken;
      };
      const isLoggedIn = computed3(() => cookie.value != null);
      return { setAccessToken, isLoggedIn };
    };
    useAuthStore = defineStore("auth", () => {
      const user = ref5({});
      const getMe = async () => {
        var _a;
        const [service, transformer] = await Promise.all([
          useService("User"),
          useTransformer("User")
        ]);
        const { data, error: error2 } = await service((module) => module.getMe());
        if (((_a = error2.value) == null ? void 0 : _a.statusCode) === 401) {
          const { setAccessToken } = useAuthenticate();
          setAccessToken(null);
        }
        const res = await transformer((module) => module.fetch(data.value));
        if (res) {
          user.value = res;
        }
      };
      const setUser = (value) => {
        user.value = value;
      };
      return { user, getMe, setUser };
    });
    useLoadingStore = defineStore("loading", () => {
      const isLoading = ref5(false);
      const showLoading = () => {
        isLoading.value = true;
      };
      const hideLoading = () => {
        isLoading.value = false;
      };
      return { isLoading, showLoading, hideLoading };
    });
    useLoading = () => {
      const loadingStore = useLoadingStore();
      const { isLoading } = storeToRefs(loadingStore);
      const { showLoading, hideLoading } = loadingStore;
      return { isLoading, showLoading, hideLoading };
    };
    _sfc_main$22 = {
      __name: "index",
      __ssrInlineRender: true,
      setup(__props) {
        const { isLoading } = useLoading();
        return (_ctx, _push, _parent, _attrs) => {
          ssrRenderTeleport(_push, (_push2) => {
            _push2(`<div class="${ssrRenderClass2([{ "d-none": !unref3(isLoading) }, "position-fixed top-0 start-0 end-0 bottom-0 d-flex align-items-center justify-content-center page-loading"])}" data-v-ff1b7767><div class="overlay" data-v-ff1b7767></div><div class="spinner-border" data-v-ff1b7767></div></div>`);
          }, "body", false, _parent);
        };
      }
    };
    _sfc_setup$22 = _sfc_main$22.setup;
    _sfc_main$22.setup = (props, ctx) => {
      const ssrContext = useSSRContext6();
      (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Loading/index.vue");
      return _sfc_setup$22 ? _sfc_setup$22(props, ctx) : void 0;
    };
    __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$22, [["__scopeId", "data-v-ff1b7767"]]);
    _sfc_main$12 = {
      __name: "index",
      __ssrInlineRender: true,
      setup(__props) {
        const authStore = useAuthStore();
        storeToRefs(authStore);
        useLoading();
        useI18n4();
        return (_ctx, _push, _parent, _attrs) => {
          const _component_router_link = resolveComponent("router-link");
          _push(`<header${ssrRenderAttrs6(mergeProps2({ class: "top-header bg-primary text-white" }, _attrs))} data-v-c1972f50><div class="container" data-v-c1972f50><div class="d-flex justify-content-between align-items-center" data-v-c1972f50><div class="d-flex align-items-center" data-v-c1972f50>`);
          _push(ssrRenderComponent2(_component_router_link, {
            to: "/map",
            class: "text-white"
          }, {
            default: withCtx2((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<h1 class="h4 mb-0 ms text-white" data-v-c1972f50${_scopeId}>Home</h1>`);
              } else {
                return [
                  createVNode2("h1", { class: "h4 mb-0 ms text-white" }, "Home")
                ];
              }
            }),
            _: 1
          }, _parent));
          _push(`</div></div></div></header>`);
        };
      }
    };
    _sfc_setup$12 = _sfc_main$12.setup;
    _sfc_main$12.setup = (props, ctx) => {
      const ssrContext = useSSRContext6();
      (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Page/Header/index.vue");
      return _sfc_setup$12 ? _sfc_setup$12(props, ctx) : void 0;
    };
    __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$12, [["__scopeId", "data-v-c1972f50"]]);
    _sfc_main6 = {
      __name: "default",
      __ssrInlineRender: true,
      async setup(__props) {
        let __temp, __restore;
        const { isLoggedIn } = useAuthenticate();
        if (isLoggedIn.value) {
          [__temp, __restore] = withAsyncContext(() => useAuthStore().getMe()), await __temp, __restore();
        }
        return (_ctx, _push, _parent, _attrs) => {
          const _component_Loading = __nuxt_component_0;
          const _component_PageHeader = __nuxt_component_1;
          _push(`<div${ssrRenderAttrs6(_attrs)}>`);
          _push(ssrRenderComponent2(_component_Loading, null, null, _parent));
          _push(ssrRenderComponent2(_component_PageHeader, null, null, _parent));
          _push(`<main>`);
          ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
          _push(`</main></div>`);
        };
      }
    };
    _sfc_setup6 = _sfc_main6.setup;
    _sfc_main6.setup = (props, ctx) => {
      const ssrContext = useSSRContext6();
      (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/default.vue");
      return _sfc_setup6 ? _sfc_setup6(props, ctx) : void 0;
    };
  }
});

// .netlify/functions-internal/server/chunks/build/error-404-BzVqw6J6.mjs
var error_404_BzVqw6J6_exports = {};
__export(error_404_BzVqw6J6_exports, {
  default: () => error404
});
import { mergeProps as mergeProps3, withCtx as withCtx3, createTextVNode as createTextVNode2, toDisplayString as toDisplayString2, useSSRContext as useSSRContext7, defineComponent as defineComponent2, ref as ref6, h, resolveComponent as resolveComponent2, computed as computed4 } from "vue";
import { ssrRenderAttrs as ssrRenderAttrs7, ssrInterpolate as ssrInterpolate2, ssrRenderComponent as ssrRenderComponent3 } from "vue/server-renderer";
import "consola/core";
import "unhead";
import "@unhead/shared";
import "vue-router";
import "dayjs";
import "dayjs/plugin/updateLocale.js";
import "dayjs/plugin/utc.js";
import "vue-i18n";
async function preloadRouteComponents(to, router = useRouter()) {
  {
    return;
  }
}
// @__NO_SIDE_EFFECTS__
function defineNuxtLink(options) {
  const componentName = options.componentName || "NuxtLink";
  function resolveTrailingSlashBehavior(to, resolve2) {
    if (!to || options.trailingSlash !== "append" && options.trailingSlash !== "remove") {
      return to;
    }
    if (typeof to === "string") {
      return applyTrailingSlashBehavior(to, options.trailingSlash);
    }
    const path = "path" in to && to.path !== void 0 ? to.path : resolve2(to).path;
    const resolvedPath = {
      ...to,
      name: void 0,
      // named routes would otherwise always override trailing slash behavior
      path: applyTrailingSlashBehavior(path, options.trailingSlash)
    };
    return resolvedPath;
  }
  function useNuxtLink(props) {
    var _a, _b, _c;
    const router = useRouter();
    const config3 = useRuntimeConfig();
    const hasTarget = computed4(() => !!props.target && props.target !== "_self");
    const isAbsoluteUrl = computed4(() => {
      const path = props.to || props.href || "";
      return typeof path === "string" && hasProtocol(path, { acceptRelative: true });
    });
    const builtinRouterLink = resolveComponent2("RouterLink");
    const useBuiltinLink = builtinRouterLink && typeof builtinRouterLink !== "string" ? builtinRouterLink.useLink : void 0;
    const isExternal = computed4(() => {
      if (props.external) {
        return true;
      }
      const path = props.to || props.href || "";
      if (typeof path === "object") {
        return false;
      }
      return path === "" || isAbsoluteUrl.value;
    });
    const to = computed4(() => {
      const path = props.to || props.href || "";
      if (isExternal.value) {
        return path;
      }
      return resolveTrailingSlashBehavior(path, router.resolve);
    });
    const link = isExternal.value ? void 0 : useBuiltinLink == null ? void 0 : useBuiltinLink({ ...props, to });
    const href = computed4(() => {
      var _a3;
      var _a2;
      if (!to.value || isAbsoluteUrl.value) {
        return to.value;
      }
      if (isExternal.value) {
        const path = typeof to.value === "object" && "path" in to.value ? resolveRouteObject(to.value) : to.value;
        const href2 = typeof path === "object" ? router.resolve(path).href : path;
        return resolveTrailingSlashBehavior(
          href2,
          router.resolve
          /* will not be called */
        );
      }
      if (typeof to.value === "object") {
        return (_a3 = (_a2 = router.resolve(to.value)) == null ? void 0 : _a2.href) != null ? _a3 : null;
      }
      return resolveTrailingSlashBehavior(
        joinURL(config3.app.baseURL, to.value),
        router.resolve
        /* will not be called */
      );
    });
    return {
      to,
      hasTarget,
      isAbsoluteUrl,
      isExternal,
      //
      href,
      isActive: (_a = link == null ? void 0 : link.isActive) != null ? _a : computed4(() => to.value === router.currentRoute.value.path),
      isExactActive: (_b = link == null ? void 0 : link.isExactActive) != null ? _b : computed4(() => to.value === router.currentRoute.value.path),
      route: (_c = link == null ? void 0 : link.route) != null ? _c : computed4(() => router.resolve(to.value)),
      async navigate() {
        await navigateTo(href.value, { replace: props.replace, external: isExternal.value || hasTarget.value });
      }
    };
  }
  return defineComponent2({
    name: componentName,
    props: {
      // Routing
      to: {
        type: [String, Object],
        default: void 0,
        required: false
      },
      href: {
        type: [String, Object],
        default: void 0,
        required: false
      },
      // Attributes
      target: {
        type: String,
        default: void 0,
        required: false
      },
      rel: {
        type: String,
        default: void 0,
        required: false
      },
      noRel: {
        type: Boolean,
        default: void 0,
        required: false
      },
      // Prefetching
      prefetch: {
        type: Boolean,
        default: void 0,
        required: false
      },
      prefetchOn: {
        type: [String, Object],
        default: void 0,
        required: false
      },
      noPrefetch: {
        type: Boolean,
        default: void 0,
        required: false
      },
      // Styling
      activeClass: {
        type: String,
        default: void 0,
        required: false
      },
      exactActiveClass: {
        type: String,
        default: void 0,
        required: false
      },
      prefetchedClass: {
        type: String,
        default: void 0,
        required: false
      },
      // Vue Router's `<RouterLink>` additional props
      replace: {
        type: Boolean,
        default: void 0,
        required: false
      },
      ariaCurrentValue: {
        type: String,
        default: void 0,
        required: false
      },
      // Edge cases handling
      external: {
        type: Boolean,
        default: void 0,
        required: false
      },
      // Slot API
      custom: {
        type: Boolean,
        default: void 0,
        required: false
      }
    },
    useLink: useNuxtLink,
    setup(props, { slots }) {
      const router = useRouter();
      const { to, href, navigate, isExternal, hasTarget, isAbsoluteUrl } = useNuxtLink(props);
      const prefetched = ref6(false);
      const el = void 0;
      const elRef = void 0;
      function shouldPrefetch(mode) {
        var _a2, _b2;
        var _a, _b;
        return !prefetched.value && (typeof props.prefetchOn === "string" ? props.prefetchOn === mode : (_a2 = (_a = props.prefetchOn) == null ? void 0 : _a[mode]) != null ? _a2 : (_b = options.prefetchOn) == null ? void 0 : _b[mode]) && ((_b2 = props.prefetch) != null ? _b2 : options.prefetch) !== false && props.noPrefetch !== true && props.target !== "_blank" && !isSlowConnection();
      }
      async function prefetch(nuxtApp = useNuxtApp()) {
        if (prefetched.value) {
          return;
        }
        prefetched.value = true;
        const path = typeof to.value === "string" ? to.value : isExternal.value ? resolveRouteObject(to.value) : router.resolve(to.value).fullPath;
        const normalizedPath = isExternal.value ? new URL(path, (void 0).location.href).href : path;
        await Promise.all([
          nuxtApp.hooks.callHook("link:prefetch", normalizedPath).catch(() => {
          }),
          !isExternal.value && !hasTarget.value && preloadRouteComponents(to.value, router).catch(() => {
          })
        ]);
      }
      return () => {
        var _a;
        if (!isExternal.value && !hasTarget.value) {
          const routerLinkProps = {
            ref: elRef,
            to: to.value,
            activeClass: props.activeClass || options.activeClass,
            exactActiveClass: props.exactActiveClass || options.exactActiveClass,
            replace: props.replace,
            ariaCurrentValue: props.ariaCurrentValue,
            custom: props.custom
          };
          if (!props.custom) {
            if (shouldPrefetch("interaction")) {
              routerLinkProps.onPointerenter = prefetch.bind(null, void 0);
              routerLinkProps.onFocus = prefetch.bind(null, void 0);
            }
            if (prefetched.value) {
              routerLinkProps.class = props.prefetchedClass || options.prefetchedClass;
            }
            routerLinkProps.rel = props.rel || void 0;
          }
          return h(
            resolveComponent2("RouterLink"),
            routerLinkProps,
            slots.default
          );
        }
        const target = props.target || null;
        const rel = firstNonUndefined(
          // converts `""` to `null` to prevent the attribute from being added as empty (`rel=""`)
          props.noRel ? "" : props.rel,
          options.externalRelAttribute,
          /*
          * A fallback rel of `noopener noreferrer` is applied for external links or links that open in a new tab.
          * This solves a reverse tabnapping security flaw in browsers pre-2021 as well as improving privacy.
          */
          isAbsoluteUrl.value || hasTarget.value ? "noopener noreferrer" : ""
        ) || null;
        if (props.custom) {
          if (!slots.default) {
            return null;
          }
          return slots.default({
            href: href.value,
            navigate,
            prefetch,
            get route() {
              if (!href.value) {
                return void 0;
              }
              const url = new URL(href.value, "http://localhost");
              return {
                path: url.pathname,
                fullPath: url.pathname,
                get query() {
                  return parseQuery(url.search);
                },
                hash: url.hash,
                params: {},
                name: void 0,
                matched: [],
                redirectedFrom: void 0,
                meta: {},
                href: href.value
              };
            },
            rel,
            target,
            isExternal: isExternal.value || hasTarget.value,
            isActive: false,
            isExactActive: false
          });
        }
        return h("a", { ref: el, href: href.value || null, rel, target }, (_a = slots.default) == null ? void 0 : _a.call(slots));
      };
    }
  });
}
function applyTrailingSlashBehavior(to, trailingSlash) {
  const normalizeFn = trailingSlash === "append" ? withTrailingSlash : withoutTrailingSlash;
  const hasProtocolDifferentFromHttp = hasProtocol(to) && !to.startsWith("http");
  if (hasProtocolDifferentFromHttp) {
    return to;
  }
  return normalizeFn(to, true);
}
function isSlowConnection() {
  {
    return;
  }
}
var firstNonUndefined, __nuxt_component_02, _sfc_main7, _sfc_setup7, error404;
var init_error_404_BzVqw6J6 = __esm({
  ".netlify/functions-internal/server/chunks/build/error-404-BzVqw6J6.mjs"() {
    "use strict";
    init_nitro();
    init_server();
    init_index_DdJWkO();
    firstNonUndefined = (...args) => args.find((arg) => arg !== void 0);
    __nuxt_component_02 = /* @__PURE__ */ defineNuxtLink(nuxtLinkDefaults);
    _sfc_main7 = {
      __name: "error-404",
      __ssrInlineRender: true,
      props: {
        appName: {
          type: String,
          default: "Nuxt"
        },
        version: {
          type: String,
          default: ""
        },
        statusCode: {
          type: Number,
          default: 404
        },
        statusMessage: {
          type: String,
          default: "Not Found"
        },
        description: {
          type: String,
          default: "Sorry, the page you are looking for could not be found."
        },
        backHome: {
          type: String,
          default: "Go back home"
        }
      },
      setup(__props) {
        const props = __props;
        useHead({
          title: `${props.statusCode} - ${props.statusMessage} | ${props.appName}`,
          script: [
            {
              children: `!function(){const e=document.createElement("link").relList;if(!(e&&e.supports&&e.supports("modulepreload"))){for(const e of document.querySelectorAll('link[rel="modulepreload"]'))r(e);new MutationObserver((e=>{for(const o of e)if("childList"===o.type)for(const e of o.addedNodes)"LINK"===e.tagName&&"modulepreload"===e.rel&&r(e)})).observe(document,{childList:!0,subtree:!0})}function r(e){if(e.ep)return;e.ep=!0;const r=function(e){const r={};return e.integrity&&(r.integrity=e.integrity),e.referrerPolicy&&(r.referrerPolicy=e.referrerPolicy),"use-credentials"===e.crossOrigin?r.credentials="include":"anonymous"===e.crossOrigin?r.credentials="omit":r.credentials="same-origin",r}(e);fetch(e.href,r)}}();`
            }
          ],
          style: [
            {
              children: `*,:after,:before{border-color:var(--un-default-border-color,#e5e7eb);border-style:solid;border-width:0;box-sizing:border-box}:after,:before{--un-content:""}html{line-height:1.5;-webkit-text-size-adjust:100%;font-family:ui-sans-serif,system-ui,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol,Noto Color Emoji;font-feature-settings:normal;font-variation-settings:normal;-moz-tab-size:4;tab-size:4;-webkit-tap-highlight-color:transparent}body{line-height:inherit;margin:0}h1{font-size:inherit;font-weight:inherit}a{color:inherit;text-decoration:inherit}h1,p{margin:0}*,:after,:before{--un-rotate:0;--un-rotate-x:0;--un-rotate-y:0;--un-rotate-z:0;--un-scale-x:1;--un-scale-y:1;--un-scale-z:1;--un-skew-x:0;--un-skew-y:0;--un-translate-x:0;--un-translate-y:0;--un-translate-z:0;--un-pan-x: ;--un-pan-y: ;--un-pinch-zoom: ;--un-scroll-snap-strictness:proximity;--un-ordinal: ;--un-slashed-zero: ;--un-numeric-figure: ;--un-numeric-spacing: ;--un-numeric-fraction: ;--un-border-spacing-x:0;--un-border-spacing-y:0;--un-ring-offset-shadow:0 0 transparent;--un-ring-shadow:0 0 transparent;--un-shadow-inset: ;--un-shadow:0 0 transparent;--un-ring-inset: ;--un-ring-offset-width:0px;--un-ring-offset-color:#fff;--un-ring-width:0px;--un-ring-color:rgba(147,197,253,.5);--un-blur: ;--un-brightness: ;--un-contrast: ;--un-drop-shadow: ;--un-grayscale: ;--un-hue-rotate: ;--un-invert: ;--un-saturate: ;--un-sepia: ;--un-backdrop-blur: ;--un-backdrop-brightness: ;--un-backdrop-contrast: ;--un-backdrop-grayscale: ;--un-backdrop-hue-rotate: ;--un-backdrop-invert: ;--un-backdrop-opacity: ;--un-backdrop-saturate: ;--un-backdrop-sepia: }`
            }
          ]
        });
        return (_ctx, _push, _parent, _attrs) => {
          const _component_NuxtLink = __nuxt_component_02;
          _push(`<div${ssrRenderAttrs7(mergeProps3({ class: "antialiased bg-white dark:bg-black dark:text-white font-sans grid min-h-screen overflow-hidden place-content-center text-black" }, _attrs))} data-v-00b6b518><div class="fixed left-0 right-0 spotlight z-10" data-v-00b6b518></div><div class="max-w-520px text-center z-20" data-v-00b6b518><h1 class="font-medium mb-8 sm:text-10xl text-8xl" data-v-00b6b518>${ssrInterpolate2(__props.statusCode)}</h1><p class="font-light leading-tight mb-16 px-8 sm:px-0 sm:text-4xl text-xl" data-v-00b6b518>${ssrInterpolate2(__props.description)}</p><div class="flex items-center justify-center w-full" data-v-00b6b518>`);
          _push(ssrRenderComponent3(_component_NuxtLink, {
            to: "/",
            class: "cursor-pointer gradient-border px-4 py-2 sm:px-6 sm:py-3 sm:text-xl text-md"
          }, {
            default: withCtx3((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`${ssrInterpolate2(__props.backHome)}`);
              } else {
                return [
                  createTextVNode2(toDisplayString2(__props.backHome), 1)
                ];
              }
            }),
            _: 1
          }, _parent));
          _push(`</div></div></div>`);
        };
      }
    };
    _sfc_setup7 = _sfc_main7.setup;
    _sfc_main7.setup = (props, ctx) => {
      const ssrContext = useSSRContext7();
      (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("node_modules/nuxt/dist/app/components/error-404.vue");
      return _sfc_setup7 ? _sfc_setup7(props, ctx) : void 0;
    };
    error404 = /* @__PURE__ */ _export_sfc(_sfc_main7, [["__scopeId", "data-v-00b6b518"]]);
  }
});

// .netlify/functions-internal/server/chunks/build/error-500-BPon51zX.mjs
var error_500_BPon51zX_exports = {};
__export(error_500_BPon51zX_exports, {
  default: () => error500
});
import { mergeProps as mergeProps4, useSSRContext as useSSRContext8 } from "vue";
import { ssrRenderAttrs as ssrRenderAttrs8, ssrInterpolate as ssrInterpolate3 } from "vue/server-renderer";
import "consola/core";
import "unhead";
import "@unhead/shared";
import "vue-router";
import "dayjs";
import "dayjs/plugin/updateLocale.js";
import "dayjs/plugin/utc.js";
import "vue-i18n";
var _sfc_main8, _sfc_setup8, error500;
var init_error_500_BPon51zX = __esm({
  ".netlify/functions-internal/server/chunks/build/error-500-BPon51zX.mjs"() {
    "use strict";
    init_server();
    init_index_DdJWkO();
    init_nitro();
    _sfc_main8 = {
      __name: "error-500",
      __ssrInlineRender: true,
      props: {
        appName: {
          type: String,
          default: "Nuxt"
        },
        version: {
          type: String,
          default: ""
        },
        statusCode: {
          type: Number,
          default: 500
        },
        statusMessage: {
          type: String,
          default: "Server error"
        },
        description: {
          type: String,
          default: "This page is temporarily unavailable."
        }
      },
      setup(__props) {
        const props = __props;
        useHead({
          title: `${props.statusCode} - ${props.statusMessage} | ${props.appName}`,
          script: [
            {
              children: `!function(){const e=document.createElement("link").relList;if(!(e&&e.supports&&e.supports("modulepreload"))){for(const e of document.querySelectorAll('link[rel="modulepreload"]'))r(e);new MutationObserver((e=>{for(const o of e)if("childList"===o.type)for(const e of o.addedNodes)"LINK"===e.tagName&&"modulepreload"===e.rel&&r(e)})).observe(document,{childList:!0,subtree:!0})}function r(e){if(e.ep)return;e.ep=!0;const r=function(e){const r={};return e.integrity&&(r.integrity=e.integrity),e.referrerPolicy&&(r.referrerPolicy=e.referrerPolicy),"use-credentials"===e.crossOrigin?r.credentials="include":"anonymous"===e.crossOrigin?r.credentials="omit":r.credentials="same-origin",r}(e);fetch(e.href,r)}}();`
            }
          ],
          style: [
            {
              children: `*,:after,:before{border-color:var(--un-default-border-color,#e5e7eb);border-style:solid;border-width:0;box-sizing:border-box}:after,:before{--un-content:""}html{line-height:1.5;-webkit-text-size-adjust:100%;font-family:ui-sans-serif,system-ui,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol,Noto Color Emoji;font-feature-settings:normal;font-variation-settings:normal;-moz-tab-size:4;tab-size:4;-webkit-tap-highlight-color:transparent}body{line-height:inherit;margin:0}h1{font-size:inherit;font-weight:inherit}h1,p{margin:0}*,:after,:before{--un-rotate:0;--un-rotate-x:0;--un-rotate-y:0;--un-rotate-z:0;--un-scale-x:1;--un-scale-y:1;--un-scale-z:1;--un-skew-x:0;--un-skew-y:0;--un-translate-x:0;--un-translate-y:0;--un-translate-z:0;--un-pan-x: ;--un-pan-y: ;--un-pinch-zoom: ;--un-scroll-snap-strictness:proximity;--un-ordinal: ;--un-slashed-zero: ;--un-numeric-figure: ;--un-numeric-spacing: ;--un-numeric-fraction: ;--un-border-spacing-x:0;--un-border-spacing-y:0;--un-ring-offset-shadow:0 0 transparent;--un-ring-shadow:0 0 transparent;--un-shadow-inset: ;--un-shadow:0 0 transparent;--un-ring-inset: ;--un-ring-offset-width:0px;--un-ring-offset-color:#fff;--un-ring-width:0px;--un-ring-color:rgba(147,197,253,.5);--un-blur: ;--un-brightness: ;--un-contrast: ;--un-drop-shadow: ;--un-grayscale: ;--un-hue-rotate: ;--un-invert: ;--un-saturate: ;--un-sepia: ;--un-backdrop-blur: ;--un-backdrop-brightness: ;--un-backdrop-contrast: ;--un-backdrop-grayscale: ;--un-backdrop-hue-rotate: ;--un-backdrop-invert: ;--un-backdrop-opacity: ;--un-backdrop-saturate: ;--un-backdrop-sepia: }`
            }
          ]
        });
        return (_ctx, _push, _parent, _attrs) => {
          _push(`<div${ssrRenderAttrs8(mergeProps4({ class: "antialiased bg-white dark:bg-black dark:text-white font-sans grid min-h-screen overflow-hidden place-content-center text-black" }, _attrs))} data-v-f7ad9679><div class="-bottom-1/2 fixed h-1/2 left-0 right-0 spotlight" data-v-f7ad9679></div><div class="max-w-520px text-center" data-v-f7ad9679><h1 class="font-medium mb-8 sm:text-10xl text-8xl" data-v-f7ad9679>${ssrInterpolate3(__props.statusCode)}</h1><p class="font-light leading-tight mb-16 px-8 sm:px-0 sm:text-4xl text-xl" data-v-f7ad9679>${ssrInterpolate3(__props.description)}</p></div></div>`);
        };
      }
    };
    _sfc_setup8 = _sfc_main8.setup;
    _sfc_main8.setup = (props, ctx) => {
      const ssrContext = useSSRContext8();
      (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("node_modules/nuxt/dist/app/components/error-500.vue");
      return _sfc_setup8 ? _sfc_setup8(props, ctx) : void 0;
    };
    error500 = /* @__PURE__ */ _export_sfc(_sfc_main8, [["__scopeId", "data-v-f7ad9679"]]);
  }
});

// .netlify/functions-internal/server/chunks/build/server.mjs
var server_exports = {};
__export(server_exports, {
  _: () => _export_sfc,
  a: () => navigateTo,
  b: () => useNuxtApp,
  c: () => useRuntimeConfig,
  d: () => resolveUnrefHeadInput,
  default: () => entry$1,
  e: () => defineNuxtRouteMiddleware,
  f: () => defineStore,
  g: () => useRequestEvent,
  h: () => asyncDataDefaults,
  i: () => injectHead,
  j: () => createError,
  k: () => fetchDefaults,
  l: () => useRequestFetch,
  n: () => nuxtLinkDefaults,
  r: () => resolveRouteObject,
  s: () => storeToRefs,
  u: () => useRouter,
  z: () => zIndexContextKey
});
import { version, unref as unref4, inject as inject2, toRaw, isRef as isRef2, isReactive, toRef as toRef3, ref as ref7, defineComponent as defineComponent3, h as h2, computed as computed5, provide as provide2, shallowReactive as shallowReactive2, watch as watch3, Suspense, nextTick, Fragment as Fragment2, Transition as Transition2, hasInjectionContext, getCurrentInstance as getCurrentInstance4, mergeProps as mergeProps5, useSSRContext as useSSRContext9, createApp, effectScope, reactive as reactive3, getCurrentScope, onErrorCaptured, onServerPrefetch as onServerPrefetch2, createVNode as createVNode3, resolveDynamicComponent as resolveDynamicComponent2, onScopeDispose, defineAsyncComponent, shallowRef as shallowRef3, isReadonly, toRefs, markRaw, withCtx as withCtx4, isShallow } from "vue";
import { getActiveHead, CapoPlugin } from "unhead";
import { defineHeadPlugin } from "@unhead/shared";
import { useRoute as useRoute$1, RouterView, createMemoryHistory, createRouter, START_LOCATION } from "vue-router";
import dayjs from "dayjs";
import updateLocale from "dayjs/plugin/updateLocale.js";
import utc from "dayjs/plugin/utc.js";
import { createI18n } from "vue-i18n";
import { ssrRenderSuspense, ssrRenderComponent as ssrRenderComponent4, ssrRenderVNode } from "vue/server-renderer";
import "consola/core";
function getNuxtAppCtx(id = appId) {
  return getContext(id, {
    asyncContext: false
  });
}
function createNuxtApp(options) {
  var _a;
  let hydratingCount = 0;
  const nuxtApp = {
    _id: options.id || appId || "nuxt-app",
    _scope: effectScope(),
    provide: void 0,
    globalName: "nuxt",
    versions: {
      get nuxt() {
        return "3.14.159";
      },
      get vue() {
        return nuxtApp.vueApp.version;
      }
    },
    payload: shallowReactive2({
      ...((_a = options.ssrContext) == null ? void 0 : _a.payload) || {},
      data: shallowReactive2({}),
      state: reactive3({}),
      once: /* @__PURE__ */ new Set(),
      _errors: shallowReactive2({})
    }),
    static: {
      data: {}
    },
    runWithContext(fn) {
      if (nuxtApp._scope.active && !getCurrentScope()) {
        return nuxtApp._scope.run(() => callWithNuxt(nuxtApp, fn));
      }
      return callWithNuxt(nuxtApp, fn);
    },
    isHydrating: false,
    deferHydration() {
      if (!nuxtApp.isHydrating) {
        return () => {
        };
      }
      hydratingCount++;
      let called = false;
      return () => {
        if (called) {
          return;
        }
        called = true;
        hydratingCount--;
        if (hydratingCount === 0) {
          nuxtApp.isHydrating = false;
          return nuxtApp.callHook("app:suspense:resolve");
        }
      };
    },
    _asyncDataPromises: {},
    _asyncData: shallowReactive2({}),
    _payloadRevivers: {},
    ...options
  };
  {
    nuxtApp.payload.serverRendered = true;
  }
  if (nuxtApp.ssrContext) {
    nuxtApp.payload.path = nuxtApp.ssrContext.url;
    nuxtApp.ssrContext.nuxt = nuxtApp;
    nuxtApp.ssrContext.payload = nuxtApp.payload;
    nuxtApp.ssrContext.config = {
      public: nuxtApp.ssrContext.runtimeConfig.public,
      app: nuxtApp.ssrContext.runtimeConfig.app
    };
  }
  nuxtApp.hooks = createHooks();
  nuxtApp.hook = nuxtApp.hooks.hook;
  {
    const contextCaller = async function(hooks, args) {
      for (const hook of hooks) {
        await nuxtApp.runWithContext(() => hook(...args));
      }
    };
    nuxtApp.hooks.callHook = (name, ...args) => nuxtApp.hooks.callHookWith(contextCaller, name, ...args);
  }
  nuxtApp.callHook = nuxtApp.hooks.callHook;
  nuxtApp.provide = (name, value) => {
    const $name = "$" + name;
    defineGetter(nuxtApp, $name, value);
    defineGetter(nuxtApp.vueApp.config.globalProperties, $name, value);
  };
  defineGetter(nuxtApp.vueApp, "$nuxt", nuxtApp);
  defineGetter(nuxtApp.vueApp.config.globalProperties, "$nuxt", nuxtApp);
  const runtimeConfig = options.ssrContext.runtimeConfig;
  nuxtApp.provide("config", runtimeConfig);
  return nuxtApp;
}
function registerPluginHooks(nuxtApp, plugin2) {
  if (plugin2.hooks) {
    nuxtApp.hooks.addHooks(plugin2.hooks);
  }
}
async function applyPlugin(nuxtApp, plugin2) {
  if (typeof plugin2 === "function") {
    const { provide: provide22 } = await nuxtApp.runWithContext(() => plugin2(nuxtApp)) || {};
    if (provide22 && typeof provide22 === "object") {
      for (const key in provide22) {
        nuxtApp.provide(key, provide22[key]);
      }
    }
  }
}
async function applyPlugins(nuxtApp, plugins22) {
  var _a, _b, _c, _d;
  const resolvedPlugins = [];
  const unresolvedPlugins = [];
  const parallels = [];
  const errors = [];
  let promiseDepth = 0;
  async function executePlugin(plugin2) {
    var _a2;
    const unresolvedPluginsForThisPlugin = ((_a2 = plugin2.dependsOn) == null ? void 0 : _a2.filter((name) => plugins22.some((p) => p._name === name) && !resolvedPlugins.includes(name))) ?? [];
    if (unresolvedPluginsForThisPlugin.length > 0) {
      unresolvedPlugins.push([new Set(unresolvedPluginsForThisPlugin), plugin2]);
    } else {
      const promise = applyPlugin(nuxtApp, plugin2).then(async () => {
        if (plugin2._name) {
          resolvedPlugins.push(plugin2._name);
          await Promise.all(unresolvedPlugins.map(async ([dependsOn, unexecutedPlugin]) => {
            if (dependsOn.has(plugin2._name)) {
              dependsOn.delete(plugin2._name);
              if (dependsOn.size === 0) {
                promiseDepth++;
                await executePlugin(unexecutedPlugin);
              }
            }
          }));
        }
      });
      if (plugin2.parallel) {
        parallels.push(promise.catch((e) => errors.push(e)));
      } else {
        await promise;
      }
    }
  }
  for (const plugin2 of plugins22) {
    if (((_a = nuxtApp.ssrContext) == null ? void 0 : _a.islandContext) && ((_b = plugin2.env) == null ? void 0 : _b.islands) === false) {
      continue;
    }
    registerPluginHooks(nuxtApp, plugin2);
  }
  for (const plugin2 of plugins22) {
    if (((_c = nuxtApp.ssrContext) == null ? void 0 : _c.islandContext) && ((_d = plugin2.env) == null ? void 0 : _d.islands) === false) {
      continue;
    }
    await executePlugin(plugin2);
  }
  await Promise.all(parallels);
  if (promiseDepth) {
    for (let i2 = 0; i2 < promiseDepth; i2++) {
      await Promise.all(parallels);
    }
  }
  if (errors.length) {
    throw errors[0];
  }
}
// @__NO_SIDE_EFFECTS__
function defineNuxtPlugin(plugin2) {
  if (typeof plugin2 === "function") {
    return plugin2;
  }
  const _name = plugin2._name || plugin2.name;
  delete plugin2.name;
  return Object.assign(plugin2.setup || (() => {
  }), plugin2, { [NuxtPluginIndicator]: true, _name });
}
function callWithNuxt(nuxt, setup, args) {
  const fn = () => setup();
  const nuxtAppCtx = getNuxtAppCtx(nuxt._id);
  {
    return nuxt.vueApp.runWithContext(() => nuxtAppCtx.callAsync(nuxt, fn));
  }
}
function tryUseNuxtApp(id) {
  var _a;
  let nuxtAppInstance;
  if (hasInjectionContext()) {
    nuxtAppInstance = (_a = getCurrentInstance4()) == null ? void 0 : _a.appContext.app.$nuxt;
  }
  nuxtAppInstance = nuxtAppInstance || getNuxtAppCtx(id).tryUse();
  return nuxtAppInstance || null;
}
function useNuxtApp(id) {
  const nuxtAppInstance = tryUseNuxtApp(id);
  if (!nuxtAppInstance) {
    {
      throw new Error("[nuxt] instance unavailable");
    }
  }
  return nuxtAppInstance;
}
// @__NO_SIDE_EFFECTS__
function useRuntimeConfig(_event) {
  return useNuxtApp().$config;
}
function defineGetter(obj, key, val) {
  Object.defineProperty(obj, key, { get: () => val });
}
// @__NO_SIDE_EFFECTS__
function defineNuxtRouteMiddleware(middleware) {
  return middleware;
}
function resolveRouteObject(to) {
  return withQuery(to.path || "", to.query || {}) + (to.hash || "");
}
function encodeURL(location2, isExternalHost = false) {
  const url = new URL(location2, "http://localhost");
  if (!isExternalHost) {
    return url.pathname + url.search + url.hash;
  }
  if (location2.startsWith("//")) {
    return url.toString().replace(url.protocol, "");
  }
  return url.toString();
}
function resolveUnref(r) {
  return typeof r === "function" ? r() : unref4(r);
}
function resolveUnrefHeadInput(ref22) {
  if (ref22 instanceof Promise || ref22 instanceof Date || ref22 instanceof RegExp)
    return ref22;
  const root = resolveUnref(ref22);
  if (!ref22 || !root)
    return root;
  if (Array.isArray(root))
    return root.map((r) => resolveUnrefHeadInput(r));
  if (typeof root === "object") {
    const resolved = {};
    for (const k in root) {
      if (!Object.prototype.hasOwnProperty.call(root, k)) {
        continue;
      }
      if (k === "titleTemplate" || k[0] === "o" && k[1] === "n") {
        resolved[k] = unref4(root[k]);
        continue;
      }
      resolved[k] = resolveUnrefHeadInput(root[k]);
    }
    return resolved;
  }
  return root;
}
function setHeadInjectionHandler(handler2) {
  _global[globalKey$1] = handler2;
}
function injectHead() {
  if (globalKey$1 in _global) {
    return _global[globalKey$1]();
  }
  const head = inject2(headSymbol);
  if (!head && false)
    console.warn("Unhead is missing Vue context, falling back to shared context. This may have unexpected results.");
  return head || getActiveHead();
}
function createContext(opts = {}) {
  let currentInstance;
  let isSingleton = false;
  const checkConflict = (instance6) => {
    if (currentInstance && currentInstance !== instance6) {
      throw new Error("Context conflict");
    }
  };
  let als;
  if (opts.asyncContext) {
    const _AsyncLocalStorage = opts.AsyncLocalStorage || globalThis.AsyncLocalStorage;
    if (_AsyncLocalStorage) {
      als = new _AsyncLocalStorage();
    } else {
      console.warn("[unctx] `AsyncLocalStorage` is not provided.");
    }
  }
  const _getCurrentInstance = () => {
    if (als && currentInstance === void 0) {
      const instance6 = als.getStore();
      if (instance6 !== void 0) {
        return instance6;
      }
    }
    return currentInstance;
  };
  return {
    use: () => {
      const _instance = _getCurrentInstance();
      if (_instance === void 0) {
        throw new Error("Context is not available");
      }
      return _instance;
    },
    tryUse: () => {
      return _getCurrentInstance();
    },
    set: (instance6, replace) => {
      if (!replace) {
        checkConflict(instance6);
      }
      currentInstance = instance6;
      isSingleton = true;
    },
    unset: () => {
      currentInstance = void 0;
      isSingleton = false;
    },
    call: (instance6, callback) => {
      checkConflict(instance6);
      currentInstance = instance6;
      try {
        return als ? als.run(instance6, callback) : callback();
      } finally {
        if (!isSingleton) {
          currentInstance = void 0;
        }
      }
    },
    async callAsync(instance6, callback) {
      currentInstance = instance6;
      const onRestore = () => {
        currentInstance = instance6;
      };
      const onLeave = () => currentInstance === instance6 ? onRestore : void 0;
      asyncHandlers.add(onLeave);
      try {
        const r = als ? als.run(instance6, callback) : callback();
        if (!isSingleton) {
          currentInstance = void 0;
        }
        return await r;
      } finally {
        asyncHandlers.delete(onLeave);
      }
    }
  };
}
function createNamespace(defaultOpts = {}) {
  const contexts = {};
  return {
    get(key, opts = {}) {
      if (!contexts[key]) {
        contexts[key] = createContext({ ...defaultOpts, ...opts });
      }
      contexts[key];
      return contexts[key];
    }
  };
}
function executeAsync(function_) {
  const restores = [];
  for (const leaveHandler of asyncHandlers) {
    const restore2 = leaveHandler();
    if (restore2) {
      restores.push(restore2);
    }
  }
  const restore = () => {
    for (const restore2 of restores) {
      restore2();
    }
  };
  let awaitable = function_();
  if (awaitable && typeof awaitable === "object" && "catch" in awaitable) {
    awaitable = awaitable.catch((error2) => {
      restore();
      throw error2;
    });
  }
  return [awaitable, restore];
}
function toArray(value) {
  return Array.isArray(value) ? value : [value];
}
async function getRouteRules(url) {
  {
    const _routeRulesMatcher2 = toRouteMatcher(
      createRouter$1({ routes: (/* @__PURE__ */ useRuntimeConfig()).nitro.routeRules })
    );
    return defu({}, ..._routeRulesMatcher2.matchAll(url).reverse());
  }
}
function generateRouteKey(route) {
  const source = (route == null ? void 0 : route.meta.key) ?? route.path.replace(ROUTE_KEY_PARENTHESES_RE, "$1").replace(ROUTE_KEY_SYMBOLS_RE, "$1").replace(ROUTE_KEY_NORMAL_RE, (r) => {
    var _a;
    return ((_a = route.params[r.slice(1)]) == null ? void 0 : _a.toString()) || "";
  });
  return typeof source === "function" ? source(route) : source;
}
function isChangingPage(to, from) {
  if (to === from || from === START_LOCATION) {
    return false;
  }
  if (generateRouteKey(to) !== generateRouteKey(from)) {
    return true;
  }
  const areComponentsSame = to.matched.every(
    (comp, index3) => {
      var _a, _b;
      return comp.components && comp.components.default === ((_b = (_a = from.matched[index3]) == null ? void 0 : _a.components) == null ? void 0 : _b.default);
    }
  );
  if (areComponentsSame) {
    return false;
  }
  return true;
}
function _getHashElementScrollMarginTop(selector) {
  try {
    const elem = (void 0).querySelector(selector);
    if (elem) {
      return (Number.parseFloat(getComputedStyle(elem).scrollMarginTop) || 0) + (Number.parseFloat(getComputedStyle((void 0).documentElement).scrollPaddingTop) || 0);
    }
  } catch {
  }
  return 0;
}
function useState(...args) {
  const autoKey = typeof args[args.length - 1] === "string" ? args.pop() : void 0;
  if (typeof args[0] !== "string") {
    args.unshift(autoKey);
  }
  const [_key, init] = args;
  if (!_key || typeof _key !== "string") {
    throw new TypeError("[nuxt] [useState] key must be a string: " + _key);
  }
  if (init !== void 0 && typeof init !== "function") {
    throw new Error("[nuxt] [useState] init must be a function: " + init);
  }
  const key = useStateKeyPrefix + _key;
  const nuxtApp = useNuxtApp();
  const state = toRef3(nuxtApp.payload.state, key);
  if (state.value === void 0 && init) {
    const initialValue = init();
    if (isRef2(initialValue)) {
      nuxtApp.payload.state[key] = initialValue;
      return initialValue;
    }
    state.value = initialValue;
  }
  return state;
}
function useRequestEvent(nuxtApp = useNuxtApp()) {
  var _a;
  return (_a = nuxtApp.ssrContext) == null ? void 0 : _a.event;
}
function useRequestFetch() {
  var _a;
  return ((_a = useRequestEvent()) == null ? void 0 : _a.$fetch) || globalThis.$fetch;
}
function definePayloadReducer(name, reduce) {
  {
    useNuxtApp().ssrContext._payloadReducers[name] = reduce;
  }
}
function isPlainObject(o) {
  return o && typeof o === "object" && Object.prototype.toString.call(o) === "[object Object]" && typeof o.toJSON !== "function";
}
function createPinia() {
  const scope = effectScope(true);
  const state = scope.run(() => ref7({}));
  let _p = [];
  let toBeInstalled = [];
  const pinia = markRaw({
    install(app) {
      setActivePinia(pinia);
      {
        pinia._a = app;
        app.provide(piniaSymbol, pinia);
        app.config.globalProperties.$pinia = pinia;
        toBeInstalled.forEach((plugin2) => _p.push(plugin2));
        toBeInstalled = [];
      }
    },
    use(plugin2) {
      if (!this._a && !isVue2) {
        toBeInstalled.push(plugin2);
      } else {
        _p.push(plugin2);
      }
      return this;
    },
    _p,
    // it's actually undefined here
    // @ts-expect-error
    _a: null,
    _e: scope,
    _s: /* @__PURE__ */ new Map(),
    state
  });
  return pinia;
}
function addSubscription(subscriptions, callback, detached, onCleanup = noop) {
  subscriptions.push(callback);
  const removeSubscription = () => {
    const idx = subscriptions.indexOf(callback);
    if (idx > -1) {
      subscriptions.splice(idx, 1);
      onCleanup();
    }
  };
  if (!detached && getCurrentScope()) {
    onScopeDispose(removeSubscription);
  }
  return removeSubscription;
}
function triggerSubscriptions(subscriptions, ...args) {
  subscriptions.slice().forEach((callback) => {
    callback(...args);
  });
}
function mergeReactiveObjects(target, patchToApply) {
  if (target instanceof Map && patchToApply instanceof Map) {
    patchToApply.forEach((value, key) => target.set(key, value));
  } else if (target instanceof Set && patchToApply instanceof Set) {
    patchToApply.forEach(target.add, target);
  }
  for (const key in patchToApply) {
    if (!patchToApply.hasOwnProperty(key))
      continue;
    const subPatch = patchToApply[key];
    const targetValue = target[key];
    if (isPlainObject(targetValue) && isPlainObject(subPatch) && target.hasOwnProperty(key) && !isRef2(subPatch) && !isReactive(subPatch)) {
      target[key] = mergeReactiveObjects(targetValue, subPatch);
    } else {
      target[key] = subPatch;
    }
  }
  return target;
}
function shouldHydrate(obj) {
  return !isPlainObject(obj) || !obj.hasOwnProperty(skipHydrateSymbol);
}
function isComputed(o) {
  return !!(isRef2(o) && o.effect);
}
function createOptionsStore(id, options, pinia, hot) {
  const { state, actions, getters } = options;
  const initialState = pinia.state.value[id];
  let store;
  function setup() {
    if (!initialState && true) {
      {
        pinia.state.value[id] = state ? state() : {};
      }
    }
    const localState = toRefs(pinia.state.value[id]);
    return assign(localState, actions, Object.keys(getters || {}).reduce((computedGetters, name) => {
      computedGetters[name] = markRaw(computed5(() => {
        setActivePinia(pinia);
        const store2 = pinia._s.get(id);
        return getters[name].call(store2, store2);
      }));
      return computedGetters;
    }, {}));
  }
  store = createSetupStore(id, setup, options, pinia, hot, true);
  return store;
}
function createSetupStore($id, setup, options = {}, pinia, hot, isOptionsStore) {
  let scope;
  const optionsForPlugin = assign({ actions: {} }, options);
  const $subscribeOptions = { deep: true };
  let isListening;
  let isSyncListening;
  let subscriptions = [];
  let actionSubscriptions = [];
  let debuggerEvents;
  const initialState = pinia.state.value[$id];
  if (!isOptionsStore && !initialState && true) {
    {
      pinia.state.value[$id] = {};
    }
  }
  ref7({});
  let activeListener;
  function $patch(partialStateOrMutator) {
    let subscriptionMutation;
    isListening = isSyncListening = false;
    if (typeof partialStateOrMutator === "function") {
      partialStateOrMutator(pinia.state.value[$id]);
      subscriptionMutation = {
        type: MutationType.patchFunction,
        storeId: $id,
        events: debuggerEvents
      };
    } else {
      mergeReactiveObjects(pinia.state.value[$id], partialStateOrMutator);
      subscriptionMutation = {
        type: MutationType.patchObject,
        payload: partialStateOrMutator,
        storeId: $id,
        events: debuggerEvents
      };
    }
    const myListenerId = activeListener = Symbol();
    nextTick().then(() => {
      if (activeListener === myListenerId) {
        isListening = true;
      }
    });
    isSyncListening = true;
    triggerSubscriptions(subscriptions, subscriptionMutation, pinia.state.value[$id]);
  }
  const $reset = isOptionsStore ? function $reset2() {
    const { state } = options;
    const newState = state ? state() : {};
    this.$patch(($state) => {
      assign($state, newState);
    });
  } : (
    /* istanbul ignore next */
    noop
  );
  function $dispose() {
    scope.stop();
    subscriptions = [];
    actionSubscriptions = [];
    pinia._s.delete($id);
  }
  const action = (fn, name = "") => {
    if (ACTION_MARKER in fn) {
      fn[ACTION_NAME] = name;
      return fn;
    }
    const wrappedAction = function() {
      setActivePinia(pinia);
      const args = Array.from(arguments);
      const afterCallbackList = [];
      const onErrorCallbackList = [];
      function after(callback) {
        afterCallbackList.push(callback);
      }
      function onError(callback) {
        onErrorCallbackList.push(callback);
      }
      triggerSubscriptions(actionSubscriptions, {
        args,
        name: wrappedAction[ACTION_NAME],
        store,
        after,
        onError
      });
      let ret;
      try {
        ret = fn.apply(this && this.$id === $id ? this : store, args);
      } catch (error2) {
        triggerSubscriptions(onErrorCallbackList, error2);
        throw error2;
      }
      if (ret instanceof Promise) {
        return ret.then((value) => {
          triggerSubscriptions(afterCallbackList, value);
          return value;
        }).catch((error2) => {
          triggerSubscriptions(onErrorCallbackList, error2);
          return Promise.reject(error2);
        });
      }
      triggerSubscriptions(afterCallbackList, ret);
      return ret;
    };
    wrappedAction[ACTION_MARKER] = true;
    wrappedAction[ACTION_NAME] = name;
    return wrappedAction;
  };
  const partialStore = {
    _p: pinia,
    // _s: scope,
    $id,
    $onAction: addSubscription.bind(null, actionSubscriptions),
    $patch,
    $reset,
    $subscribe(callback, options2 = {}) {
      const removeSubscription = addSubscription(subscriptions, callback, options2.detached, () => stopWatcher());
      const stopWatcher = scope.run(() => watch3(() => pinia.state.value[$id], (state) => {
        if (options2.flush === "sync" ? isSyncListening : isListening) {
          callback({
            storeId: $id,
            type: MutationType.direct,
            events: debuggerEvents
          }, state);
        }
      }, assign({}, $subscribeOptions, options2)));
      return removeSubscription;
    },
    $dispose
  };
  const store = reactive3(partialStore);
  pinia._s.set($id, store);
  const runWithContext = pinia._a && pinia._a.runWithContext || fallbackRunWithContext;
  const setupStore = runWithContext(() => pinia._e.run(() => (scope = effectScope()).run(() => setup({ action }))));
  for (const key in setupStore) {
    const prop = setupStore[key];
    if (isRef2(prop) && !isComputed(prop) || isReactive(prop)) {
      if (!isOptionsStore) {
        if (initialState && shouldHydrate(prop)) {
          if (isRef2(prop)) {
            prop.value = initialState[key];
          } else {
            mergeReactiveObjects(prop, initialState[key]);
          }
        }
        {
          pinia.state.value[$id][key] = prop;
        }
      }
    } else if (typeof prop === "function") {
      const actionValue = action(prop, key);
      {
        setupStore[key] = actionValue;
      }
      optionsForPlugin.actions[key] = prop;
    } else
      ;
  }
  {
    assign(store, setupStore);
    assign(toRaw(store), setupStore);
  }
  Object.defineProperty(store, "$state", {
    get: () => pinia.state.value[$id],
    set: (state) => {
      $patch(($state) => {
        assign($state, state);
      });
    }
  });
  pinia._p.forEach((extender) => {
    {
      assign(store, scope.run(() => extender({
        store,
        app: pinia._a,
        pinia,
        options: optionsForPlugin
      })));
    }
  });
  if (initialState && isOptionsStore && options.hydrate) {
    options.hydrate(store.$state, initialState);
  }
  isListening = true;
  isSyncListening = true;
  return store;
}
// @__NO_SIDE_EFFECTS__
function defineStore(idOrOptions, setup, setupOptions) {
  let id;
  let options;
  const isSetupStore = typeof setup === "function";
  if (typeof idOrOptions === "string") {
    id = idOrOptions;
    options = isSetupStore ? setupOptions : setup;
  } else {
    options = idOrOptions;
    id = idOrOptions.id;
  }
  function useStore(pinia, hot) {
    const hasContext = hasInjectionContext();
    pinia = // in test mode, ignore the argument provided as we can always retrieve a
    // pinia instance with getActivePinia()
    pinia || (hasContext ? inject2(piniaSymbol, null) : null);
    if (pinia)
      setActivePinia(pinia);
    pinia = activePinia;
    if (!pinia._s.has(id)) {
      if (isSetupStore) {
        createSetupStore(id, setup, options, pinia);
      } else {
        createOptionsStore(id, options, pinia);
      }
    }
    const store = pinia._s.get(id);
    return store;
  }
  useStore.$id = id;
  return useStore;
}
function storeToRefs(store) {
  {
    const rawStore = toRaw(store);
    const refs = {};
    for (const key in rawStore) {
      const value = rawStore[key];
      if (isRef2(value) || isReactive(value)) {
        refs[key] = // ---
        toRef3(store, key);
      }
    }
    return refs;
  }
}
function renderTeleports(teleports) {
  const body = Object.entries(teleports).reduce((all, [key, value]) => {
    if (key.startsWith("#el-popper-container-") || [].includes(key)) {
      return `${all}<div id="${key.slice(1)}">${value}</div>`;
    }
    return all;
  }, teleports.body || "");
  return { ...teleports, body };
}
function _mergeTransitionProps(routeProps) {
  const _props = routeProps.map((prop) => ({
    ...prop,
    onAfterLeave: prop.onAfterLeave ? toArray(prop.onAfterLeave) : void 0
  }));
  return defu(..._props);
}
function hasChildrenRoutes(fork, newRoute, Component) {
  if (!fork) {
    return false;
  }
  const index3 = newRoute.matched.findIndex((m) => {
    var _a;
    return ((_a = m.components) == null ? void 0 : _a.default) === (Component == null ? void 0 : Component.type);
  });
  return index3 < newRoute.matched.length - 1;
}
function _sfc_ssrRender2(_ctx, _push, _parent, _attrs) {
  const _component_NuxtLayout = __nuxt_component_03;
  const _component_NuxtPage = __nuxt_component_12;
  _push(ssrRenderComponent4(_component_NuxtLayout, _attrs, {
    default: withCtx4((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(ssrRenderComponent4(_component_NuxtPage, null, null, _parent2, _scopeId));
      } else {
        return [
          createVNode3(_component_NuxtPage)
        ];
      }
    }),
    _: 1
  }, _parent));
}
var appLayoutTransition, appPageTransition, appKeepalive, nuxtLinkDefaults, asyncDataDefaults, fetchDefaults, appId, NuxtPluginIndicator, LayoutMetaSymbol, PageRouteSymbol, useRouter, useRoute, isProcessingMiddleware, URL_QUOTE_RE, navigateTo, NUXT_ERROR_SIGNATURE, useError, showError, isNuxtError, createError, headSymbol, _global, globalKey$1, unhead_KgADcZ0jPj, _globalThis, globalKey, asyncHandlersKey, asyncHandlers, ROUTE_KEY_PARENTHESES_RE$1, ROUTE_KEY_SYMBOLS_RE$1, ROUTE_KEY_NORMAL_RE$1, interpolatePath, generateRouteKey$1, wrapInKeepAlive, __nuxt_page_meta, _routes, _wrapIf, ROUTE_KEY_PARENTHESES_RE, ROUTE_KEY_SYMBOLS_RE, ROUTE_KEY_NORMAL_RE, routerOptions0, configRouterOptions, routerOptions, validate, manifest_45route_45rule, globalMiddleware, namedMiddleware, plugin$1, useStateKeyPrefix, _0_siteConfig_MwZUzHrRNP, reducers, revive_payload_server_eJ33V7gbc6, isVue2, activePinia, setActivePinia, piniaSymbol, MutationType, noop, fallbackRunWithContext, ACTION_MARKER, ACTION_NAME, skipHydrateSymbol, assign, plugin, components_plugin_KR1HBZs4kY, element_plus_teleports_plugin_h4Dmekbj62, ID_INJECTION_KEY, ZINDEX_INJECTION_KEY, zIndexContextKey, element_plus_injection_plugin_1RNPi6ogby, plugin_8SbxDRbG6Y, general, page, auth, home, profile, en, i18n_sVHQBgnb3t, DEFAULT_CONFIG, currentConfig, setConfig, configure, vee_validate_K3WwmJMPDb, plugins, layouts, LayoutLoader, __nuxt_component_03, LayoutProvider, RouteProvider, __nuxt_component_12, _export_sfc, _sfc_main$23, _sfc_setup$23, AppComponent, _sfc_main$13, _sfc_setup$13, _sfc_main9, _sfc_setup9, entry, entry$1;
var init_server = __esm({
  ".netlify/functions-internal/server/chunks/build/server.mjs"() {
    "use strict";
    init_nitro();
    if (!globalThis.$fetch) {
      globalThis.$fetch = $fetch.create({
        baseURL: baseURL()
      });
    }
    appLayoutTransition = false;
    appPageTransition = false;
    appKeepalive = false;
    nuxtLinkDefaults = { "componentName": "NuxtLink", "prefetch": true, "prefetchOn": { "visibility": true } };
    asyncDataDefaults = { "value": null, "errorValue": null, "deep": true };
    fetchDefaults = {};
    appId = "nuxt-app";
    NuxtPluginIndicator = "__nuxt_plugin";
    LayoutMetaSymbol = Symbol("layout-meta");
    PageRouteSymbol = Symbol("route");
    useRouter = () => {
      var _a;
      return (_a = useNuxtApp()) == null ? void 0 : _a.$router;
    };
    useRoute = () => {
      if (hasInjectionContext()) {
        return inject2(PageRouteSymbol, useNuxtApp()._route);
      }
      return useNuxtApp()._route;
    };
    isProcessingMiddleware = () => {
      try {
        if (useNuxtApp()._processingMiddleware) {
          return true;
        }
      } catch {
        return false;
      }
      return false;
    };
    URL_QUOTE_RE = /"/g;
    navigateTo = (to, options) => {
      if (!to) {
        to = "/";
      }
      const toPath = typeof to === "string" ? to : "path" in to ? resolveRouteObject(to) : useRouter().resolve(to).href;
      const isExternalHost = hasProtocol(toPath, { acceptRelative: true });
      const isExternal = (options == null ? void 0 : options.external) || isExternalHost;
      if (isExternal) {
        if (!(options == null ? void 0 : options.external)) {
          throw new Error("Navigating to an external URL is not allowed by default. Use `navigateTo(url, { external: true })`.");
        }
        const { protocol } = new URL(toPath, "http://localhost");
        if (protocol && isScriptProtocol(protocol)) {
          throw new Error(`Cannot navigate to a URL with '${protocol}' protocol.`);
        }
      }
      const inMiddleware = isProcessingMiddleware();
      const router = useRouter();
      const nuxtApp = useNuxtApp();
      {
        if (nuxtApp.ssrContext) {
          const fullPath = typeof to === "string" || isExternal ? toPath : router.resolve(to).fullPath || "/";
          const location2 = isExternal ? toPath : joinURL((/* @__PURE__ */ useRuntimeConfig()).app.baseURL, fullPath);
          const redirect = async function(response) {
            await nuxtApp.callHook("app:redirected");
            const encodedLoc = location2.replace(URL_QUOTE_RE, "%22");
            const encodedHeader = encodeURL(location2, isExternalHost);
            nuxtApp.ssrContext._renderResponse = {
              statusCode: sanitizeStatusCode((options == null ? void 0 : options.redirectCode) || 302, 302),
              body: `<!DOCTYPE html><html><head><meta http-equiv="refresh" content="0; url=${encodedLoc}"></head></html>`,
              headers: { location: encodedHeader }
            };
            return response;
          };
          if (!isExternal && inMiddleware) {
            router.afterEach((final) => final.fullPath === fullPath ? redirect(false) : void 0);
            return to;
          }
          return redirect(!inMiddleware ? void 0 : (
            /* abort route navigation */
            false
          ));
        }
      }
      if (isExternal) {
        nuxtApp._scope.stop();
        if (options == null ? void 0 : options.replace) {
          (void 0).replace(toPath);
        } else {
          (void 0).href = toPath;
        }
        if (inMiddleware) {
          if (!nuxtApp.isHydrating) {
            return false;
          }
          return new Promise(() => {
          });
        }
        return Promise.resolve();
      }
      return (options == null ? void 0 : options.replace) ? router.replace(to) : router.push(to);
    };
    NUXT_ERROR_SIGNATURE = "__nuxt_error";
    useError = () => toRef3(useNuxtApp().payload, "error");
    showError = (error2) => {
      const nuxtError = createError(error2);
      try {
        const nuxtApp = useNuxtApp();
        const error22 = useError();
        if (false)
          ;
        error22.value = error22.value || nuxtError;
      } catch {
        throw nuxtError;
      }
      return nuxtError;
    };
    isNuxtError = (error2) => !!error2 && typeof error2 === "object" && NUXT_ERROR_SIGNATURE in error2;
    createError = (error2) => {
      const nuxtError = createError$1(error2);
      Object.defineProperty(nuxtError, NUXT_ERROR_SIGNATURE, {
        value: true,
        configurable: false,
        writable: false
      });
      return nuxtError;
    };
    version[0] === "3";
    defineHeadPlugin({
      hooks: {
        "entries:resolve": (ctx) => {
          for (const entry2 of ctx.entries)
            entry2.resolvedInput = resolveUnrefHeadInput(entry2.input);
        }
      }
    });
    headSymbol = "usehead";
    _global = typeof globalThis !== "undefined" ? globalThis : typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : {};
    globalKey$1 = "__unhead_injection_handler__";
    [CapoPlugin({ track: true })];
    unhead_KgADcZ0jPj = /* @__PURE__ */ defineNuxtPlugin({
      name: "nuxt:head",
      enforce: "pre",
      setup(nuxtApp) {
        const head = nuxtApp.ssrContext.head;
        setHeadInjectionHandler(
          // need a fresh instance of the nuxt app to avoid parallel requests interfering with each other
          () => useNuxtApp().vueApp._context.provides.usehead
        );
        nuxtApp.vueApp.use(head);
      }
    });
    _globalThis = typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof global !== "undefined" ? global : {};
    globalKey = "__unctx__";
    _globalThis[globalKey] || (_globalThis[globalKey] = createNamespace());
    asyncHandlersKey = "__unctx_async_handlers__";
    asyncHandlers = _globalThis[asyncHandlersKey] || (_globalThis[asyncHandlersKey] = /* @__PURE__ */ new Set());
    ROUTE_KEY_PARENTHESES_RE$1 = /(:\w+)\([^)]+\)/g;
    ROUTE_KEY_SYMBOLS_RE$1 = /(:\w+)[?+*]/g;
    ROUTE_KEY_NORMAL_RE$1 = /:\w+/g;
    interpolatePath = (route, match) => {
      return match.path.replace(ROUTE_KEY_PARENTHESES_RE$1, "$1").replace(ROUTE_KEY_SYMBOLS_RE$1, "$1").replace(ROUTE_KEY_NORMAL_RE$1, (r) => {
        var _a;
        return ((_a = route.params[r.slice(1)]) == null ? void 0 : _a.toString()) || "";
      });
    };
    generateRouteKey$1 = (routeProps, override) => {
      const matchedRoute = routeProps.route.matched.find((m) => {
        var _a;
        return ((_a = m.components) == null ? void 0 : _a.default) === routeProps.Component.type;
      });
      const source = override ?? (matchedRoute == null ? void 0 : matchedRoute.meta.key) ?? (matchedRoute && interpolatePath(routeProps.route, matchedRoute));
      return typeof source === "function" ? source(routeProps.route) : source;
    };
    wrapInKeepAlive = (props, children) => {
      return { default: () => children };
    };
    __nuxt_page_meta = { middleware: "authenticate" };
    _routes = [
      {
        name: "dashboard",
        path: "/dashboard",
        component: () => Promise.resolve().then(() => (init_index_D704dL8k(), index_D704dL8k_exports))
      },
      {
        name: "error",
        path: "/error",
        component: () => Promise.resolve().then(() => (init_error_CiqhZn6d(), error_CiqhZn6d_exports))
      },
      {
        name: "index",
        path: "/",
        component: () => Promise.resolve().then(() => (init_index_fCrtNcwr(), index_fCrtNcwr_exports))
      },
      {
        name: "map",
        path: "/map",
        component: () => Promise.resolve().then(() => (init_index_CyAywMu6(), index_CyAywMu6_exports))
      },
      {
        name: "profile",
        path: "/profile",
        meta: __nuxt_page_meta || {},
        component: () => Promise.resolve().then(() => (init_index_BupDkBmr(), index_BupDkBmr_exports))
      }
    ];
    _wrapIf = (component, props, slots) => {
      props = props === true ? {} : props;
      return { default: () => {
        var _a;
        return props ? h2(component, props, slots) : (_a = slots.default) == null ? void 0 : _a.call(slots);
      } };
    };
    ROUTE_KEY_PARENTHESES_RE = /(:\w+)\([^)]+\)/g;
    ROUTE_KEY_SYMBOLS_RE = /(:\w+)[?+*]/g;
    ROUTE_KEY_NORMAL_RE = /:\w+/g;
    routerOptions0 = {
      scrollBehavior(to, from, savedPosition) {
        var _a;
        const nuxtApp = useNuxtApp();
        const behavior = ((_a = useRouter().options) == null ? void 0 : _a.scrollBehaviorType) ?? "auto";
        let position = savedPosition || void 0;
        const routeAllowsScrollToTop = typeof to.meta.scrollToTop === "function" ? to.meta.scrollToTop(to, from) : to.meta.scrollToTop;
        if (!position && from && to && routeAllowsScrollToTop !== false && isChangingPage(to, from)) {
          position = { left: 0, top: 0 };
        }
        if (to.path === from.path) {
          if (from.hash && !to.hash) {
            return { left: 0, top: 0 };
          }
          if (to.hash) {
            return { el: to.hash, top: _getHashElementScrollMarginTop(to.hash), behavior };
          }
          return false;
        }
        const hasTransition = (route) => !!(route.meta.pageTransition ?? appPageTransition);
        const hookToWait = hasTransition(from) && hasTransition(to) ? "page:transition:finish" : "page:finish";
        return new Promise((resolve2) => {
          nuxtApp.hooks.hookOnce(hookToWait, async () => {
            await new Promise((resolve22) => setTimeout(resolve22, 0));
            if (to.hash) {
              position = { el: to.hash, top: _getHashElementScrollMarginTop(to.hash), behavior };
            }
            resolve2(position);
          });
        });
      }
    };
    configRouterOptions = {
      hashMode: false,
      scrollBehaviorType: "auto"
    };
    routerOptions = {
      ...configRouterOptions,
      ...routerOptions0
    };
    validate = /* @__PURE__ */ defineNuxtRouteMiddleware(async (to) => {
      var _a;
      let __temp, __restore;
      if (!((_a = to.meta) == null ? void 0 : _a.validate)) {
        return;
      }
      const nuxtApp = useNuxtApp();
      const router = useRouter();
      const result = ([__temp, __restore] = executeAsync(() => Promise.resolve(to.meta.validate(to))), __temp = await __temp, __restore(), __temp);
      if (result === true) {
        return;
      }
      const error2 = createError({
        statusCode: result && result.statusCode || 404,
        statusMessage: result && result.statusMessage || `Page Not Found: ${to.fullPath}`,
        data: {
          path: to.fullPath
        }
      });
      const unsub = router.beforeResolve((final) => {
        unsub();
        if (final === to) {
          const unsub2 = router.afterEach(async () => {
            unsub2();
            await nuxtApp.runWithContext(() => showError(error2));
          });
          return false;
        }
      });
    });
    manifest_45route_45rule = /* @__PURE__ */ defineNuxtRouteMiddleware(async (to) => {
      {
        return;
      }
    });
    globalMiddleware = [
      validate,
      manifest_45route_45rule
    ];
    namedMiddleware = {
      authenticate: () => Promise.resolve().then(() => (init_authenticate_CY38wZJr(), authenticate_CY38wZJr_exports)),
      "redirect-if-authenticated": () => Promise.resolve().then(() => (init_redirectIfAuthenticated_CftVgjT9(), redirectIfAuthenticated_CftVgjT9_exports))
    };
    plugin$1 = /* @__PURE__ */ defineNuxtPlugin({
      name: "nuxt:router",
      enforce: "pre",
      async setup(nuxtApp) {
        var _a, _b, _c;
        let __temp, __restore;
        let routerBase = (/* @__PURE__ */ useRuntimeConfig()).app.baseURL;
        if (routerOptions.hashMode && !routerBase.includes("#")) {
          routerBase += "#";
        }
        const history = ((_a = routerOptions.history) == null ? void 0 : _a.call(routerOptions, routerBase)) ?? createMemoryHistory(routerBase);
        const routes = routerOptions.routes ? ([__temp, __restore] = executeAsync(() => routerOptions.routes(_routes)), __temp = await __temp, __restore(), __temp) ?? _routes : _routes;
        let startPosition;
        const router = createRouter({
          ...routerOptions,
          scrollBehavior: (to, from, savedPosition) => {
            if (from === START_LOCATION) {
              startPosition = savedPosition;
              return;
            }
            if (routerOptions.scrollBehavior) {
              router.options.scrollBehavior = routerOptions.scrollBehavior;
              if ("scrollRestoration" in (void 0).history) {
                const unsub = router.beforeEach(() => {
                  unsub();
                  (void 0).history.scrollRestoration = "manual";
                });
              }
              return routerOptions.scrollBehavior(to, START_LOCATION, startPosition || savedPosition);
            }
          },
          history,
          routes
        });
        nuxtApp.vueApp.use(router);
        const previousRoute = shallowRef3(router.currentRoute.value);
        router.afterEach((_to, from) => {
          previousRoute.value = from;
        });
        Object.defineProperty(nuxtApp.vueApp.config.globalProperties, "previousRoute", {
          get: () => previousRoute.value
        });
        const initialURL = nuxtApp.ssrContext.url;
        const _route = shallowRef3(router.currentRoute.value);
        const syncCurrentRoute = () => {
          _route.value = router.currentRoute.value;
        };
        nuxtApp.hook("page:finish", syncCurrentRoute);
        router.afterEach((to, from) => {
          var _a2, _b2, _c2, _d;
          if (((_b2 = (_a2 = to.matched[0]) == null ? void 0 : _a2.components) == null ? void 0 : _b2.default) === ((_d = (_c2 = from.matched[0]) == null ? void 0 : _c2.components) == null ? void 0 : _d.default)) {
            syncCurrentRoute();
          }
        });
        const route = {};
        for (const key in _route.value) {
          Object.defineProperty(route, key, {
            get: () => _route.value[key],
            enumerable: true
          });
        }
        nuxtApp._route = shallowReactive2(route);
        nuxtApp._middleware = nuxtApp._middleware || {
          global: [],
          named: {}
        };
        useError();
        if (!((_b = nuxtApp.ssrContext) == null ? void 0 : _b.islandContext)) {
          router.afterEach(async (to, _from, failure) => {
            delete nuxtApp._processingMiddleware;
            if (failure) {
              await nuxtApp.callHook("page:loading:end");
            }
            if ((failure == null ? void 0 : failure.type) === 4) {
              return;
            }
            if (to.redirectedFrom && to.fullPath !== initialURL) {
              await nuxtApp.runWithContext(() => navigateTo(to.fullPath || "/"));
            }
          });
        }
        try {
          if (true) {
            ;
            [__temp, __restore] = executeAsync(() => router.push(initialURL)), await __temp, __restore();
            ;
          }
          ;
          [__temp, __restore] = executeAsync(() => router.isReady()), await __temp, __restore();
          ;
        } catch (error2) {
          [__temp, __restore] = executeAsync(() => nuxtApp.runWithContext(() => showError(error2))), await __temp, __restore();
        }
        const resolvedInitialRoute = router.currentRoute.value;
        syncCurrentRoute();
        if ((_c = nuxtApp.ssrContext) == null ? void 0 : _c.islandContext) {
          return { provide: { router } };
        }
        const initialLayout = nuxtApp.payload.state._layout;
        router.beforeEach(async (to, from) => {
          var _a2, _b2;
          await nuxtApp.callHook("page:loading:start");
          to.meta = reactive3(to.meta);
          if (nuxtApp.isHydrating && initialLayout && !isReadonly(to.meta.layout)) {
            to.meta.layout = initialLayout;
          }
          nuxtApp._processingMiddleware = true;
          if (!((_a2 = nuxtApp.ssrContext) == null ? void 0 : _a2.islandContext)) {
            const middlewareEntries = /* @__PURE__ */ new Set([...globalMiddleware, ...nuxtApp._middleware.global]);
            for (const component of to.matched) {
              const componentMiddleware = component.meta.middleware;
              if (!componentMiddleware) {
                continue;
              }
              for (const entry2 of toArray(componentMiddleware)) {
                middlewareEntries.add(entry2);
              }
            }
            {
              const routeRules = await nuxtApp.runWithContext(() => getRouteRules(to.path));
              if (routeRules.appMiddleware) {
                for (const key in routeRules.appMiddleware) {
                  if (routeRules.appMiddleware[key]) {
                    middlewareEntries.add(key);
                  } else {
                    middlewareEntries.delete(key);
                  }
                }
              }
            }
            for (const entry2 of middlewareEntries) {
              const middleware = typeof entry2 === "string" ? nuxtApp._middleware.named[entry2] || await ((_b2 = namedMiddleware[entry2]) == null ? void 0 : _b2.call(namedMiddleware).then((r) => r.default || r)) : entry2;
              if (!middleware) {
                throw new Error(`Unknown route middleware: '${entry2}'.`);
              }
              const result = await nuxtApp.runWithContext(() => middleware(to, from));
              {
                if (result === false || result instanceof Error) {
                  const error2 = result || createError$1({
                    statusCode: 404,
                    statusMessage: `Page Not Found: ${initialURL}`
                  });
                  await nuxtApp.runWithContext(() => showError(error2));
                  return false;
                }
              }
              if (result === true) {
                continue;
              }
              if (result || result === false) {
                return result;
              }
            }
          }
        });
        router.onError(async () => {
          delete nuxtApp._processingMiddleware;
          await nuxtApp.callHook("page:loading:end");
        });
        router.afterEach(async (to, _from) => {
          if (to.matched.length === 0) {
            await nuxtApp.runWithContext(() => showError(createError$1({
              statusCode: 404,
              fatal: false,
              statusMessage: `Page not found: ${to.fullPath}`,
              data: {
                path: to.fullPath
              }
            })));
          }
        });
        nuxtApp.hooks.hookOnce("app:created", async () => {
          try {
            if ("name" in resolvedInitialRoute) {
              resolvedInitialRoute.name = void 0;
            }
            await router.replace({
              ...resolvedInitialRoute,
              force: true
            });
            router.options.scrollBehavior = routerOptions.scrollBehavior;
          } catch (error2) {
            await nuxtApp.runWithContext(() => showError(error2));
          }
        });
        return { provide: { router } };
      }
    });
    useStateKeyPrefix = "$s";
    _0_siteConfig_MwZUzHrRNP = /* @__PURE__ */ defineNuxtPlugin({
      name: "nuxt-site-config:init",
      enforce: "pre",
      async setup(nuxtApp) {
        var _a;
        const state = useState("site-config");
        {
          const context = (_a = useRequestEvent()) == null ? void 0 : _a.context;
          nuxtApp.hooks.hook("app:rendered", () => {
            state.value = context == null ? void 0 : context.siteConfig.get({
              debug: (/* @__PURE__ */ useRuntimeConfig())["nuxt-site-config"].debug,
              resolveRefs: true
            });
          });
        }
        let stack = {};
        return {
          provide: {
            nuxtSiteConfig: stack
          }
        };
      }
    });
    reducers = [
      ["NuxtError", (data) => isNuxtError(data) && data.toJSON()],
      ["EmptyShallowRef", (data) => isRef2(data) && isShallow(data) && !data.value && (typeof data.value === "bigint" ? "0n" : JSON.stringify(data.value) || "_")],
      ["EmptyRef", (data) => isRef2(data) && !data.value && (typeof data.value === "bigint" ? "0n" : JSON.stringify(data.value) || "_")],
      ["ShallowRef", (data) => isRef2(data) && isShallow(data) && data.value],
      ["ShallowReactive", (data) => isReactive(data) && isShallow(data) && toRaw(data)],
      ["Ref", (data) => isRef2(data) && data.value],
      ["Reactive", (data) => isReactive(data) && toRaw(data)]
    ];
    revive_payload_server_eJ33V7gbc6 = /* @__PURE__ */ defineNuxtPlugin({
      name: "nuxt:revive-payload:server",
      setup() {
        for (const [reducer, fn] of reducers) {
          definePayloadReducer(reducer, fn);
        }
      }
    });
    isVue2 = false;
    setActivePinia = (pinia) => activePinia = pinia;
    piniaSymbol = /* istanbul ignore next */
    Symbol();
    (function(MutationType2) {
      MutationType2["direct"] = "direct";
      MutationType2["patchObject"] = "patch object";
      MutationType2["patchFunction"] = "patch function";
    })(MutationType || (MutationType = {}));
    noop = () => {
    };
    fallbackRunWithContext = (fn) => fn();
    ACTION_MARKER = Symbol();
    ACTION_NAME = Symbol();
    skipHydrateSymbol = /* istanbul ignore next */
    Symbol();
    ({ assign } = Object);
    plugin = /* @__PURE__ */ defineNuxtPlugin({
      name: "pinia",
      setup(nuxtApp) {
        const pinia = createPinia();
        nuxtApp.vueApp.use(pinia);
        setActivePinia(pinia);
        {
          nuxtApp.payload.pinia = pinia.state.value;
        }
        return {
          provide: {
            pinia
          }
        };
      }
    });
    components_plugin_KR1HBZs4kY = /* @__PURE__ */ defineNuxtPlugin({
      name: "nuxt:global-components"
    });
    element_plus_teleports_plugin_h4Dmekbj62 = /* @__PURE__ */ defineNuxtPlugin((nuxtApp) => {
      nuxtApp.hook("app:rendered", (ctx) => {
        var _a;
        if ((_a = ctx.ssrContext) == null ? void 0 : _a.teleports) {
          ctx.ssrContext.teleports = renderTeleports(ctx.ssrContext.teleports);
        }
      });
    });
    ID_INJECTION_KEY = Symbol("elIdInjection");
    ref7(0);
    ZINDEX_INJECTION_KEY = Symbol("elZIndexContextKey");
    zIndexContextKey = Symbol("zIndexContextKey");
    element_plus_injection_plugin_1RNPi6ogby = /* @__PURE__ */ defineNuxtPlugin((nuxtApp) => {
      nuxtApp.vueApp.provide(ID_INJECTION_KEY, { "prefix": 1024, "current": 0 }).provide(ZINDEX_INJECTION_KEY, { "current": 0 });
    });
    dayjs.extend(updateLocale);
    dayjs.extend(utc);
    plugin_8SbxDRbG6Y = /* @__PURE__ */ defineNuxtPlugin(async (nuxtApp) => nuxtApp.provide("dayjs", dayjs));
    general = {
      no_data: "No data.",
      okay: "Okay",
      yes: "Yes",
      cancel: "Cancel",
      no: "No",
      close: "Close",
      logout_confirmation: "Are you sure want to logout?",
      yes_logout: "Yes, Logout",
      delete: "Delete",
      update: "Update",
      save: "Save",
      add: "Add",
      edit: "Edit",
      change: "Change",
      submit: "Submit"
    };
    page = {
      map: "Map",
      dashboard: "Dashboard",
      data_list: "Data List",
      profile: "Profile"
    };
    auth = {
      login: "Login",
      signup: "Signup",
      profile: "Profile",
      logout: "Logout",
      forgot_your_password: "Forgot password?",
      username: "Username",
      username_validate: "Invalid username. Start with lowercase letter or phone number. Only use lowercase letters, underscores, and numbers. No spaces or special characters allowed.",
      password: "Password",
      password_confirmation: "Confirm Password",
      current_password: "Current Password",
      new_password: "New Password",
      new_password_confirmation: "Confirm New Password",
      password_confirmation_not_match: "Confirm Password not match",
      new_password_confirmation_not_match: "Confirm New Password not match",
      confirm: "Confirm",
      first_name: "First Name",
      last_name: "Last Name",
      gender: "Gender",
      male: "Male",
      female: "Female",
      other_gender: "I do not answer",
      phone_number: "Phone Number",
      phone_number_invalid: "Please enter a valid phone number starting with 0",
      email: "email",
      email_address: "E-Mail Address",
      email_address_invalid: "E-Mail Address must be a valid email",
      register_as: "Register as",
      user_type: "User Type",
      owner: "Owner",
      public_user: "Public User",
      position: "Position",
      government_institution: "Government Institution",
      reset_password: "Reset Password",
      update_password: "Update Password",
      change_password: "Change Password",
      forgot_password: "Forgot Password",
      forgot_password_description: "Please enter your registered email address we will get back to you with the reset password link and confirmation OTP thanks",
      phone_or_email: "Email Address",
      phone_or_email_invalid: "Please enter a email address.",
      resend: "Resend",
      verify_and_continue: "Verify & Continue",
      otp_verification: "OTP Verification",
      otp_code: "OTP Code",
      otp_verification_description: 'We have send the OTP code to your registered email address. Please fill in the code and click in the "Verify & Continue" Button.',
      new_otp_code_sent_success: "The new OTP code was sent to your registered email address.",
      register_success: "Register Successfully"
    };
    home = {
      total_visitor: "Total Visitors"
    };
    profile = {
      name: "Name",
      first_name: "First Name",
      last_name: "Last Name",
      username: "Username",
      username_validate: "Invalid username. Start with lowercase letter or phone number. Only use lowercase letters, underscores, and numbers. No spaces or special characters allowed.",
      gender: "Gender",
      male: "Male",
      female: "Female",
      other_gender: "I do not answer",
      phone_number: "Phone Number",
      phone_number_invalid: "Please enter a valid phone number starting with 0",
      email_address: "Email Address",
      email_address_invalid: "Email Address must be a valid email",
      position: "Position",
      government_institution: "Government Institution",
      registration_date: "Registration Date",
      latest_update_date: "Latest Update Date",
      edit_profile: "Edit Profile",
      update_profile: "Update Profile",
      update_user_profile: "Update User Profile",
      change_password: "Change Password",
      enable: "Enable",
      two_factor_auth: "Two-factor authentication",
      two_factor_auth_description: "Two-factor authentication adds an additional layer of security to your account by requiring more than a password to login.",
      prefer_two_fa_method: "Preferred 2FA method",
      prefer_two_fa_method_description: "Set your preferred method to use for two-factor authentication when signing into SSDaP.",
      sms: "SMS/Text message",
      email: "Email",
      choose_one_method: "Choose one method",
      disable_two_factor_confirmation: "Are you sure want to turn off two factor authentication?",
      confirm: "Confirm",
      save_two_factor_confirmation: "Are you sure want to use this info?",
      same_email_two_factor: "This email is the same like your current email. Please use another email!",
      success_disabled_two_factor_message: "Your two factor authentication has been disabled.",
      success_confirm_two_factor_message: "Your two factor authentication info has been confirmed."
    };
    en = {
      general,
      page,
      auth,
      home,
      profile
    };
    i18n_sVHQBgnb3t = /* @__PURE__ */ defineNuxtPlugin(({ vueApp }) => {
      const i18n = createI18n({
        legacy: false,
        globalInjection: true,
        locale: "en",
        fallbackLocale: "en",
        messages: { en }
      });
      vueApp.use(i18n);
    });
    DEFAULT_CONFIG = {
      generateMessage: ({ field }) => `${field} is not valid.`,
      bails: true,
      validateOnBlur: true,
      validateOnChange: true,
      validateOnInput: false,
      validateOnModelUpdate: true
    };
    currentConfig = Object.assign({}, DEFAULT_CONFIG);
    setConfig = (newConf) => {
      currentConfig = Object.assign(Object.assign({}, currentConfig), newConf);
    };
    configure = setConfig;
    vee_validate_K3WwmJMPDb = /* @__PURE__ */ defineNuxtPlugin(() => {
      configure({
        validateOnBlur: true,
        validateOnChange: true,
        validateOnInput: true
      });
    });
    plugins = [
      unhead_KgADcZ0jPj,
      plugin$1,
      _0_siteConfig_MwZUzHrRNP,
      revive_payload_server_eJ33V7gbc6,
      plugin,
      components_plugin_KR1HBZs4kY,
      element_plus_teleports_plugin_h4Dmekbj62,
      element_plus_injection_plugin_1RNPi6ogby,
      plugin_8SbxDRbG6Y,
      i18n_sVHQBgnb3t,
      vee_validate_K3WwmJMPDb
    ];
    layouts = {
      default: () => Promise.resolve().then(() => (init_default_BRlDANaF(), default_BRlDANaF_exports))
    };
    LayoutLoader = defineComponent3({
      name: "LayoutLoader",
      inheritAttrs: false,
      props: {
        name: String,
        layoutProps: Object
      },
      async setup(props, context) {
        const LayoutComponent = await layouts[props.name]().then((r) => r.default || r);
        return () => h2(LayoutComponent, props.layoutProps, context.slots);
      }
    });
    __nuxt_component_03 = defineComponent3({
      name: "NuxtLayout",
      inheritAttrs: false,
      props: {
        name: {
          type: [String, Boolean, Object],
          default: null
        },
        fallback: {
          type: [String, Object],
          default: null
        }
      },
      setup(props, context) {
        const nuxtApp = useNuxtApp();
        const injectedRoute = inject2(PageRouteSymbol);
        const route = injectedRoute === useRoute() ? useRoute$1() : injectedRoute;
        const layout = computed5(() => {
          let layout2 = unref4(props.name) ?? route.meta.layout ?? "default";
          if (layout2 && !(layout2 in layouts)) {
            if (props.fallback) {
              layout2 = unref4(props.fallback);
            }
          }
          return layout2;
        });
        const layoutRef = ref7();
        context.expose({ layoutRef });
        const done = nuxtApp.deferHydration();
        return () => {
          const hasLayout = layout.value && layout.value in layouts;
          const transitionProps = route.meta.layoutTransition ?? appLayoutTransition;
          return _wrapIf(Transition2, hasLayout && transitionProps, {
            default: () => h2(Suspense, { suspensible: true, onResolve: () => {
              nextTick(done);
            } }, {
              default: () => h2(
                LayoutProvider,
                {
                  layoutProps: mergeProps5(context.attrs, { ref: layoutRef }),
                  key: layout.value || void 0,
                  name: layout.value,
                  shouldProvide: !props.name,
                  hasTransition: !!transitionProps
                },
                context.slots
              )
            })
          }).default();
        };
      }
    });
    LayoutProvider = defineComponent3({
      name: "NuxtLayoutProvider",
      inheritAttrs: false,
      props: {
        name: {
          type: [String, Boolean]
        },
        layoutProps: {
          type: Object
        },
        hasTransition: {
          type: Boolean
        },
        shouldProvide: {
          type: Boolean
        }
      },
      setup(props, context) {
        const name = props.name;
        if (props.shouldProvide) {
          provide2(LayoutMetaSymbol, {
            isCurrent: (route) => name === (route.meta.layout ?? "default")
          });
        }
        return () => {
          var _a, _b;
          if (!name || typeof name === "string" && !(name in layouts)) {
            return (_b = (_a = context.slots).default) == null ? void 0 : _b.call(_a);
          }
          return h2(
            LayoutLoader,
            { key: name, layoutProps: props.layoutProps, name },
            context.slots
          );
        };
      }
    });
    RouteProvider = defineComponent3({
      props: {
        vnode: {
          type: Object,
          required: true
        },
        route: {
          type: Object,
          required: true
        },
        vnodeRef: Object,
        renderKey: String,
        trackRootNodes: Boolean
      },
      setup(props) {
        const previousKey = props.renderKey;
        const previousRoute = props.route;
        const route = {};
        for (const key in props.route) {
          Object.defineProperty(route, key, {
            get: () => previousKey === props.renderKey ? props.route[key] : previousRoute[key],
            enumerable: true
          });
        }
        provide2(PageRouteSymbol, shallowReactive2(route));
        return () => {
          return h2(props.vnode, { ref: props.vnodeRef });
        };
      }
    });
    __nuxt_component_12 = defineComponent3({
      name: "NuxtPage",
      inheritAttrs: false,
      props: {
        name: {
          type: String
        },
        transition: {
          type: [Boolean, Object],
          default: void 0
        },
        keepalive: {
          type: [Boolean, Object],
          default: void 0
        },
        route: {
          type: Object
        },
        pageKey: {
          type: [Function, String],
          default: null
        }
      },
      setup(props, { attrs, slots, expose }) {
        const nuxtApp = useNuxtApp();
        const pageRef = ref7();
        const forkRoute = inject2(PageRouteSymbol, null);
        let previousPageKey;
        expose({ pageRef });
        inject2(LayoutMetaSymbol, null);
        let vnode;
        const done = nuxtApp.deferHydration();
        if (props.pageKey) {
          watch3(() => props.pageKey, (next, prev) => {
            if (next !== prev) {
              nuxtApp.callHook("page:loading:start");
            }
          });
        }
        return () => {
          return h2(RouterView, { name: props.name, route: props.route, ...attrs }, {
            default: (routeProps) => {
              if (!routeProps.Component) {
                done();
                return;
              }
              const key = generateRouteKey$1(routeProps, props.pageKey);
              if (!nuxtApp.isHydrating && !hasChildrenRoutes(forkRoute, routeProps.route, routeProps.Component) && previousPageKey === key) {
                nuxtApp.callHook("page:loading:end");
              }
              previousPageKey = key;
              const hasTransition = !!(props.transition ?? routeProps.route.meta.pageTransition ?? appPageTransition);
              const transitionProps = hasTransition && _mergeTransitionProps([
                props.transition,
                routeProps.route.meta.pageTransition,
                appPageTransition,
                { onAfterLeave: () => {
                  nuxtApp.callHook("page:transition:finish", routeProps.Component);
                } }
              ].filter(Boolean));
              const keepaliveConfig = props.keepalive ?? routeProps.route.meta.keepalive ?? appKeepalive;
              vnode = _wrapIf(
                Transition2,
                hasTransition && transitionProps,
                wrapInKeepAlive(
                  keepaliveConfig,
                  h2(Suspense, {
                    suspensible: true,
                    onPending: () => nuxtApp.callHook("page:start", routeProps.Component),
                    onResolve: () => {
                      nextTick(() => nuxtApp.callHook("page:finish", routeProps.Component).then(() => nuxtApp.callHook("page:loading:end")).finally(done));
                    }
                  }, {
                    default: () => {
                      const providerVNode = h2(RouteProvider, {
                        key: key || void 0,
                        vnode: slots.default ? h2(Fragment2, void 0, slots.default(routeProps)) : routeProps.Component,
                        route: routeProps.route,
                        renderKey: key || void 0,
                        trackRootNodes: hasTransition,
                        vnodeRef: pageRef
                      });
                      return providerVNode;
                    }
                  })
                )
              ).default();
              return vnode;
            }
          });
        };
      }
    });
    _export_sfc = (sfc, props) => {
      const target = sfc.__vccOpts || sfc;
      for (const [key, val] of props) {
        target[key] = val;
      }
      return target;
    };
    _sfc_main$23 = {};
    _sfc_setup$23 = _sfc_main$23.setup;
    _sfc_main$23.setup = (props, ctx) => {
      const ssrContext = useSSRContext9();
      (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("node_modules/nuxt/dist/pages/runtime/app.vue");
      return _sfc_setup$23 ? _sfc_setup$23(props, ctx) : void 0;
    };
    AppComponent = /* @__PURE__ */ _export_sfc(_sfc_main$23, [["ssrRender", _sfc_ssrRender2]]);
    _sfc_main$13 = {
      __name: "nuxt-error-page",
      __ssrInlineRender: true,
      props: {
        error: Object
      },
      setup(__props) {
        const props = __props;
        const _error = props.error;
        _error.stack ? _error.stack.split("\n").splice(1).map((line) => {
          const text = line.replace("webpack:/", "").replace(".vue", ".js").trim();
          return {
            text,
            internal: line.includes("node_modules") && !line.includes(".cache") || line.includes("internal") || line.includes("new Promise")
          };
        }).map((i2) => `<span class="stack${i2.internal ? " internal" : ""}">${i2.text}</span>`).join("\n") : "";
        const statusCode = Number(_error.statusCode || 500);
        const is404 = statusCode === 404;
        const statusMessage = _error.statusMessage ?? (is404 ? "Page Not Found" : "Internal Server Error");
        const description = _error.message || _error.toString();
        const stack = void 0;
        const _Error404 = defineAsyncComponent(() => Promise.resolve().then(() => (init_error_404_BzVqw6J6(), error_404_BzVqw6J6_exports)));
        const _Error = defineAsyncComponent(() => Promise.resolve().then(() => (init_error_500_BPon51zX(), error_500_BPon51zX_exports)));
        const ErrorTemplate = is404 ? _Error404 : _Error;
        return (_ctx, _push, _parent, _attrs) => {
          _push(ssrRenderComponent4(unref4(ErrorTemplate), mergeProps5({ statusCode: unref4(statusCode), statusMessage: unref4(statusMessage), description: unref4(description), stack: unref4(stack) }, _attrs), null, _parent));
        };
      }
    };
    _sfc_setup$13 = _sfc_main$13.setup;
    _sfc_main$13.setup = (props, ctx) => {
      const ssrContext = useSSRContext9();
      (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("node_modules/nuxt/dist/app/components/nuxt-error-page.vue");
      return _sfc_setup$13 ? _sfc_setup$13(props, ctx) : void 0;
    };
    _sfc_main9 = {
      __name: "nuxt-root",
      __ssrInlineRender: true,
      setup(__props) {
        const IslandRenderer = () => null;
        const nuxtApp = useNuxtApp();
        nuxtApp.deferHydration();
        nuxtApp.ssrContext.url;
        const SingleRenderer = false;
        provide2(PageRouteSymbol, useRoute());
        nuxtApp.hooks.callHookWith((hooks) => hooks.map((hook) => hook()), "vue:setup");
        const error2 = useError();
        const abortRender = error2.value && !nuxtApp.ssrContext.error;
        onErrorCaptured((err, target, info) => {
          nuxtApp.hooks.callHook("vue:error", err, target, info).catch((hookError) => console.error("[nuxt] Error in `vue:error` hook", hookError));
          {
            const p = nuxtApp.runWithContext(() => showError(err));
            onServerPrefetch2(() => p);
            return false;
          }
        });
        const islandContext = nuxtApp.ssrContext.islandContext;
        return (_ctx, _push, _parent, _attrs) => {
          ssrRenderSuspense(_push, {
            default: () => {
              if (unref4(abortRender)) {
                _push(`<div></div>`);
              } else if (unref4(error2)) {
                _push(ssrRenderComponent4(unref4(_sfc_main$13), { error: unref4(error2) }, null, _parent));
              } else if (unref4(islandContext)) {
                _push(ssrRenderComponent4(unref4(IslandRenderer), { context: unref4(islandContext) }, null, _parent));
              } else if (unref4(SingleRenderer)) {
                ssrRenderVNode(_push, createVNode3(resolveDynamicComponent2(unref4(SingleRenderer)), null, null), _parent);
              } else {
                _push(ssrRenderComponent4(unref4(AppComponent), null, null, _parent));
              }
            },
            _: 1
          });
        };
      }
    };
    _sfc_setup9 = _sfc_main9.setup;
    _sfc_main9.setup = (props, ctx) => {
      const ssrContext = useSSRContext9();
      (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("node_modules/nuxt/dist/app/components/nuxt-root.vue");
      return _sfc_setup9 ? _sfc_setup9(props, ctx) : void 0;
    };
    {
      entry = async function createNuxtAppServer(ssrContext) {
        const vueApp = createApp(_sfc_main9);
        const nuxt = createNuxtApp({ vueApp, ssrContext });
        try {
          await applyPlugins(nuxt, plugins);
          await nuxt.hooks.callHook("app:created", vueApp);
        } catch (error2) {
          await nuxt.hooks.callHook("app:error", error2);
          nuxt.payload.error = nuxt.payload.error || createError(error2);
        }
        if (ssrContext == null ? void 0 : ssrContext._renderResponse) {
          throw new Error("skipping render");
        }
        return vueApp;
      };
    }
    entry$1 = (ssrContext) => entry(ssrContext);
  }
});

// .netlify/functions-internal/server/chunks/build/entry-styles.B5NIiaim.mjs
var entry_styles_B5NIiaim_exports = {};
__export(entry_styles_B5NIiaim_exports, {
  default: () => entryStyles_B5NIiaim
});
import "vue";
import "consola/core";
var index2, entryStyles_B5NIiaim;
var init_entry_styles_B5NIiaim = __esm({
  ".netlify/functions-internal/server/chunks/build/entry-styles.B5NIiaim.mjs"() {
    "use strict";
    init_nitro();
    index2 = '@charset "UTF-8";\n/*!\n * Bootstrap  v5.3.3 (https://getbootstrap.com/)\n * Copyright 2011-2024 The Bootstrap Authors\n * Licensed under MIT (https://github.com/twbs/bootstrap/blob/main/LICENSE)\n */\n/*!\n * Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com\n * License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License)\n * Copyright 2024 Fonticons, Inc.\n */.fa{font-family:var(--fa-style-family,"Font Awesome 6 Free");font-weight:var(--fa-style,900)}.fa,.fa-brands,.fa-classic,.fa-regular,.fa-sharp-solid,.fa-solid,.fab,.far,.fas{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;display:var(--fa-display,inline-block);font-style:normal;font-variant:normal;line-height:1;text-rendering:auto}.fa-classic,.fa-regular,.fa-solid,.far,.fas{font-family:Font Awesome\\ 6 Free}.fa-brands,.fab{font-family:Font Awesome\\ 6 Brands}.fa-1x{font-size:1em}.fa-2x{font-size:2em}.fa-3x{font-size:3em}.fa-4x{font-size:4em}.fa-5x{font-size:5em}.fa-6x{font-size:6em}.fa-7x{font-size:7em}.fa-8x{font-size:8em}.fa-9x{font-size:9em}.fa-10x{font-size:10em}.fa-2xs{font-size:.625em;line-height:.1em;vertical-align:.225em}.fa-xs{font-size:.75em;line-height:.08333em;vertical-align:.125em}.fa-sm{font-size:.875em;line-height:.07143em;vertical-align:.05357em}.fa-lg{font-size:1.25em;line-height:.05em;vertical-align:-.075em}.fa-xl{font-size:1.5em;line-height:.04167em;vertical-align:-.125em}.fa-2xl{font-size:2em;line-height:.03125em;vertical-align:-.1875em}.fa-fw{text-align:center;width:1.25em}.fa-ul{list-style-type:none;margin-left:var(--fa-li-margin,2.5em);padding-left:0}.fa-ul>li{position:relative}.fa-li{left:calc(var(--fa-li-width, 2em)*-1);line-height:inherit;position:absolute;text-align:center;width:var(--fa-li-width,2em)}.fa-border{border:var(--fa-border-width,.08em) var(--fa-border-style,solid) var(--fa-border-color,#eee);border-radius:var(--fa-border-radius,.1em);padding:var(--fa-border-padding,.2em .25em .15em)}.fa-pull-left{float:left;margin-right:var(--fa-pull-margin,.3em)}.fa-pull-right{float:right;margin-left:var(--fa-pull-margin,.3em)}.fa-beat{animation-delay:var(--fa-animation-delay,0s);animation-direction:var(--fa-animation-direction,normal);animation-duration:var(--fa-animation-duration,1s);animation-iteration-count:var(--fa-animation-iteration-count,infinite);animation-name:fa-beat;animation-timing-function:var(--fa-animation-timing,ease-in-out)}.fa-bounce{animation-delay:var(--fa-animation-delay,0s);animation-direction:var(--fa-animation-direction,normal);animation-duration:var(--fa-animation-duration,1s);animation-iteration-count:var(--fa-animation-iteration-count,infinite);animation-name:fa-bounce;animation-timing-function:var(--fa-animation-timing,cubic-bezier(.28,.84,.42,1))}.fa-fade{animation-iteration-count:var(--fa-animation-iteration-count,infinite);animation-name:fa-fade;animation-timing-function:var(--fa-animation-timing,cubic-bezier(.4,0,.6,1))}.fa-beat-fade,.fa-fade{animation-delay:var(--fa-animation-delay,0s);animation-direction:var(--fa-animation-direction,normal);animation-duration:var(--fa-animation-duration,1s)}.fa-beat-fade{animation-iteration-count:var(--fa-animation-iteration-count,infinite);animation-name:fa-beat-fade;animation-timing-function:var(--fa-animation-timing,cubic-bezier(.4,0,.6,1))}.fa-flip{animation-delay:var(--fa-animation-delay,0s);animation-direction:var(--fa-animation-direction,normal);animation-duration:var(--fa-animation-duration,1s);animation-iteration-count:var(--fa-animation-iteration-count,infinite);animation-name:fa-flip;animation-timing-function:var(--fa-animation-timing,ease-in-out)}.fa-shake{animation-duration:var(--fa-animation-duration,1s);animation-iteration-count:var(--fa-animation-iteration-count,infinite);animation-name:fa-shake;animation-timing-function:var(--fa-animation-timing,linear)}.fa-shake,.fa-spin{animation-delay:var(--fa-animation-delay,0s);animation-direction:var(--fa-animation-direction,normal)}.fa-spin{animation-duration:var(--fa-animation-duration,2s);animation-iteration-count:var(--fa-animation-iteration-count,infinite);animation-name:fa-spin;animation-timing-function:var(--fa-animation-timing,linear)}.fa-spin-reverse{--fa-animation-direction:reverse}.fa-pulse,.fa-spin-pulse{animation-direction:var(--fa-animation-direction,normal);animation-duration:var(--fa-animation-duration,1s);animation-iteration-count:var(--fa-animation-iteration-count,infinite);animation-name:fa-spin;animation-timing-function:var(--fa-animation-timing,steps(8))}@media (prefers-reduced-motion:reduce){.fa-beat,.fa-beat-fade,.fa-bounce,.fa-fade,.fa-flip,.fa-pulse,.fa-shake,.fa-spin,.fa-spin-pulse{animation-delay:-1ms;animation-duration:1ms;animation-iteration-count:1;transition-delay:0s;transition-duration:0s}}@keyframes fa-beat{0%,90%{transform:scale(1)}45%{transform:scale(var(--fa-beat-scale,1.25))}}@keyframes fa-bounce{0%{transform:scale(1) translateY(0)}10%{transform:scale(var(--fa-bounce-start-scale-x,1.1),var(--fa-bounce-start-scale-y,.9)) translateY(0)}30%{transform:scale(var(--fa-bounce-jump-scale-x,.9),var(--fa-bounce-jump-scale-y,1.1)) translateY(var(--fa-bounce-height,-.5em))}50%{transform:scale(var(--fa-bounce-land-scale-x,1.05),var(--fa-bounce-land-scale-y,.95)) translateY(0)}57%{transform:scale(1) translateY(var(--fa-bounce-rebound,-.125em))}64%{transform:scale(1) translateY(0)}to{transform:scale(1) translateY(0)}}@keyframes fa-fade{50%{opacity:var(--fa-fade-opacity,.4)}}@keyframes fa-beat-fade{0%,to{opacity:var(--fa-beat-fade-opacity,.4);transform:scale(1)}50%{opacity:1;transform:scale(var(--fa-beat-fade-scale,1.125))}}@keyframes fa-flip{50%{transform:rotate3d(var(--fa-flip-x,0),var(--fa-flip-y,1),var(--fa-flip-z,0),var(--fa-flip-angle,-180deg))}}@keyframes fa-shake{0%{transform:rotate(-15deg)}4%{transform:rotate(15deg)}24%,8%{transform:rotate(-18deg)}12%,28%{transform:rotate(18deg)}16%{transform:rotate(-22deg)}20%{transform:rotate(22deg)}32%{transform:rotate(-12deg)}36%{transform:rotate(12deg)}40%,to{transform:rotate(0deg)}}@keyframes fa-spin{0%{transform:rotate(0deg)}to{transform:rotate(1turn)}}.fa-rotate-90{transform:rotate(90deg)}.fa-rotate-180{transform:rotate(180deg)}.fa-rotate-270{transform:rotate(270deg)}.fa-flip-horizontal{transform:scaleX(-1)}.fa-flip-vertical{transform:scaleY(-1)}.fa-flip-both,.fa-flip-horizontal.fa-flip-vertical{transform:scale(-1)}.fa-rotate-by{transform:rotate(var(--fa-rotate-angle,0))}.fa-stack{display:inline-block;height:2em;line-height:2em;position:relative;vertical-align:middle;width:2.5em}.fa-stack-1x,.fa-stack-2x{left:0;position:absolute;text-align:center;width:100%;z-index:var(--fa-stack-z-index,auto)}.fa-stack-1x{line-height:inherit}.fa-stack-2x{font-size:2em}.fa-inverse{color:var(--fa-inverse,#fff)}.fa-0:before{content:"\\30"}.fa-1:before{content:"\\31"}.fa-2:before{content:"\\32"}.fa-3:before{content:"\\33"}.fa-4:before{content:"\\34"}.fa-5:before{content:"\\35"}.fa-6:before{content:"\\36"}.fa-7:before{content:"\\37"}.fa-8:before{content:"\\38"}.fa-9:before{content:"\\39"}.fa-fill-drip:before{content:"\\f576"}.fa-arrows-to-circle:before{content:"\\e4bd"}.fa-chevron-circle-right:before,.fa-circle-chevron-right:before{content:"\\f138"}.fa-at:before{content:"\\40"}.fa-trash-alt:before,.fa-trash-can:before{content:"\\f2ed"}.fa-text-height:before{content:"\\f034"}.fa-user-times:before,.fa-user-xmark:before{content:"\\f235"}.fa-stethoscope:before{content:"\\f0f1"}.fa-comment-alt:before,.fa-message:before{content:"\\f27a"}.fa-info:before{content:"\\f129"}.fa-compress-alt:before,.fa-down-left-and-up-right-to-center:before{content:"\\f422"}.fa-explosion:before{content:"\\e4e9"}.fa-file-alt:before,.fa-file-lines:before,.fa-file-text:before{content:"\\f15c"}.fa-wave-square:before{content:"\\f83e"}.fa-ring:before{content:"\\f70b"}.fa-building-un:before{content:"\\e4d9"}.fa-dice-three:before{content:"\\f527"}.fa-calendar-alt:before,.fa-calendar-days:before{content:"\\f073"}.fa-anchor-circle-check:before{content:"\\e4aa"}.fa-building-circle-arrow-right:before{content:"\\e4d1"}.fa-volleyball-ball:before,.fa-volleyball:before{content:"\\f45f"}.fa-arrows-up-to-line:before{content:"\\e4c2"}.fa-sort-desc:before,.fa-sort-down:before{content:"\\f0dd"}.fa-circle-minus:before,.fa-minus-circle:before{content:"\\f056"}.fa-door-open:before{content:"\\f52b"}.fa-right-from-bracket:before,.fa-sign-out-alt:before{content:"\\f2f5"}.fa-atom:before{content:"\\f5d2"}.fa-soap:before{content:"\\e06e"}.fa-heart-music-camera-bolt:before,.fa-icons:before{content:"\\f86d"}.fa-microphone-alt-slash:before,.fa-microphone-lines-slash:before{content:"\\f539"}.fa-bridge-circle-check:before{content:"\\e4c9"}.fa-pump-medical:before{content:"\\e06a"}.fa-fingerprint:before{content:"\\f577"}.fa-hand-point-right:before{content:"\\f0a4"}.fa-magnifying-glass-location:before,.fa-search-location:before{content:"\\f689"}.fa-forward-step:before,.fa-step-forward:before{content:"\\f051"}.fa-face-smile-beam:before,.fa-smile-beam:before{content:"\\f5b8"}.fa-flag-checkered:before{content:"\\f11e"}.fa-football-ball:before,.fa-football:before{content:"\\f44e"}.fa-school-circle-exclamation:before{content:"\\e56c"}.fa-crop:before{content:"\\f125"}.fa-angle-double-down:before,.fa-angles-down:before{content:"\\f103"}.fa-users-rectangle:before{content:"\\e594"}.fa-people-roof:before{content:"\\e537"}.fa-people-line:before{content:"\\e534"}.fa-beer-mug-empty:before,.fa-beer:before{content:"\\f0fc"}.fa-diagram-predecessor:before{content:"\\e477"}.fa-arrow-up-long:before,.fa-long-arrow-up:before{content:"\\f176"}.fa-burn:before,.fa-fire-flame-simple:before{content:"\\f46a"}.fa-male:before,.fa-person:before{content:"\\f183"}.fa-laptop:before{content:"\\f109"}.fa-file-csv:before{content:"\\f6dd"}.fa-menorah:before{content:"\\f676"}.fa-truck-plane:before{content:"\\e58f"}.fa-record-vinyl:before{content:"\\f8d9"}.fa-face-grin-stars:before,.fa-grin-stars:before{content:"\\f587"}.fa-bong:before{content:"\\f55c"}.fa-pastafarianism:before,.fa-spaghetti-monster-flying:before{content:"\\f67b"}.fa-arrow-down-up-across-line:before{content:"\\e4af"}.fa-spoon:before,.fa-utensil-spoon:before{content:"\\f2e5"}.fa-jar-wheat:before{content:"\\e517"}.fa-envelopes-bulk:before,.fa-mail-bulk:before{content:"\\f674"}.fa-file-circle-exclamation:before{content:"\\e4eb"}.fa-circle-h:before,.fa-hospital-symbol:before{content:"\\f47e"}.fa-pager:before{content:"\\f815"}.fa-address-book:before,.fa-contact-book:before{content:"\\f2b9"}.fa-strikethrough:before{content:"\\f0cc"}.fa-k:before{content:"\\4b"}.fa-landmark-flag:before{content:"\\e51c"}.fa-pencil-alt:before,.fa-pencil:before{content:"\\f303"}.fa-backward:before{content:"\\f04a"}.fa-caret-right:before{content:"\\f0da"}.fa-comments:before{content:"\\f086"}.fa-file-clipboard:before,.fa-paste:before{content:"\\f0ea"}.fa-code-pull-request:before{content:"\\e13c"}.fa-clipboard-list:before{content:"\\f46d"}.fa-truck-loading:before,.fa-truck-ramp-box:before{content:"\\f4de"}.fa-user-check:before{content:"\\f4fc"}.fa-vial-virus:before{content:"\\e597"}.fa-sheet-plastic:before{content:"\\e571"}.fa-blog:before{content:"\\f781"}.fa-user-ninja:before{content:"\\f504"}.fa-person-arrow-up-from-line:before{content:"\\e539"}.fa-scroll-torah:before,.fa-torah:before{content:"\\f6a0"}.fa-broom-ball:before,.fa-quidditch-broom-ball:before,.fa-quidditch:before{content:"\\f458"}.fa-toggle-off:before{content:"\\f204"}.fa-archive:before,.fa-box-archive:before{content:"\\f187"}.fa-person-drowning:before{content:"\\e545"}.fa-arrow-down-9-1:before,.fa-sort-numeric-desc:before,.fa-sort-numeric-down-alt:before{content:"\\f886"}.fa-face-grin-tongue-squint:before,.fa-grin-tongue-squint:before{content:"\\f58a"}.fa-spray-can:before{content:"\\f5bd"}.fa-truck-monster:before{content:"\\f63b"}.fa-w:before{content:"\\57"}.fa-earth-africa:before,.fa-globe-africa:before{content:"\\f57c"}.fa-rainbow:before{content:"\\f75b"}.fa-circle-notch:before{content:"\\f1ce"}.fa-tablet-alt:before,.fa-tablet-screen-button:before{content:"\\f3fa"}.fa-paw:before{content:"\\f1b0"}.fa-cloud:before{content:"\\f0c2"}.fa-trowel-bricks:before{content:"\\e58a"}.fa-face-flushed:before,.fa-flushed:before{content:"\\f579"}.fa-hospital-user:before{content:"\\f80d"}.fa-tent-arrow-left-right:before{content:"\\e57f"}.fa-gavel:before,.fa-legal:before{content:"\\f0e3"}.fa-binoculars:before{content:"\\f1e5"}.fa-microphone-slash:before{content:"\\f131"}.fa-box-tissue:before{content:"\\e05b"}.fa-motorcycle:before{content:"\\f21c"}.fa-bell-concierge:before,.fa-concierge-bell:before{content:"\\f562"}.fa-pen-ruler:before,.fa-pencil-ruler:before{content:"\\f5ae"}.fa-people-arrows-left-right:before,.fa-people-arrows:before{content:"\\e068"}.fa-mars-and-venus-burst:before{content:"\\e523"}.fa-caret-square-right:before,.fa-square-caret-right:before{content:"\\f152"}.fa-cut:before,.fa-scissors:before{content:"\\f0c4"}.fa-sun-plant-wilt:before{content:"\\e57a"}.fa-toilets-portable:before{content:"\\e584"}.fa-hockey-puck:before{content:"\\f453"}.fa-table:before{content:"\\f0ce"}.fa-magnifying-glass-arrow-right:before{content:"\\e521"}.fa-digital-tachograph:before,.fa-tachograph-digital:before{content:"\\f566"}.fa-users-slash:before{content:"\\e073"}.fa-clover:before{content:"\\e139"}.fa-mail-reply:before,.fa-reply:before{content:"\\f3e5"}.fa-star-and-crescent:before{content:"\\f699"}.fa-house-fire:before{content:"\\e50c"}.fa-minus-square:before,.fa-square-minus:before{content:"\\f146"}.fa-helicopter:before{content:"\\f533"}.fa-compass:before{content:"\\f14e"}.fa-caret-square-down:before,.fa-square-caret-down:before{content:"\\f150"}.fa-file-circle-question:before{content:"\\e4ef"}.fa-laptop-code:before{content:"\\f5fc"}.fa-swatchbook:before{content:"\\f5c3"}.fa-prescription-bottle:before{content:"\\f485"}.fa-bars:before,.fa-navicon:before{content:"\\f0c9"}.fa-people-group:before{content:"\\e533"}.fa-hourglass-3:before,.fa-hourglass-end:before{content:"\\f253"}.fa-heart-broken:before,.fa-heart-crack:before{content:"\\f7a9"}.fa-external-link-square-alt:before,.fa-square-up-right:before{content:"\\f360"}.fa-face-kiss-beam:before,.fa-kiss-beam:before{content:"\\f597"}.fa-film:before{content:"\\f008"}.fa-ruler-horizontal:before{content:"\\f547"}.fa-people-robbery:before{content:"\\e536"}.fa-lightbulb:before{content:"\\f0eb"}.fa-caret-left:before{content:"\\f0d9"}.fa-circle-exclamation:before,.fa-exclamation-circle:before{content:"\\f06a"}.fa-school-circle-xmark:before{content:"\\e56d"}.fa-arrow-right-from-bracket:before,.fa-sign-out:before{content:"\\f08b"}.fa-chevron-circle-down:before,.fa-circle-chevron-down:before{content:"\\f13a"}.fa-unlock-alt:before,.fa-unlock-keyhole:before{content:"\\f13e"}.fa-cloud-showers-heavy:before{content:"\\f740"}.fa-headphones-alt:before,.fa-headphones-simple:before{content:"\\f58f"}.fa-sitemap:before{content:"\\f0e8"}.fa-circle-dollar-to-slot:before,.fa-donate:before{content:"\\f4b9"}.fa-memory:before{content:"\\f538"}.fa-road-spikes:before{content:"\\e568"}.fa-fire-burner:before{content:"\\e4f1"}.fa-flag:before{content:"\\f024"}.fa-hanukiah:before{content:"\\f6e6"}.fa-feather:before{content:"\\f52d"}.fa-volume-down:before,.fa-volume-low:before{content:"\\f027"}.fa-comment-slash:before{content:"\\f4b3"}.fa-cloud-sun-rain:before{content:"\\f743"}.fa-compress:before{content:"\\f066"}.fa-wheat-alt:before,.fa-wheat-awn:before{content:"\\e2cd"}.fa-ankh:before{content:"\\f644"}.fa-hands-holding-child:before{content:"\\e4fa"}.fa-asterisk:before{content:"\\2a"}.fa-check-square:before,.fa-square-check:before{content:"\\f14a"}.fa-peseta-sign:before{content:"\\e221"}.fa-header:before,.fa-heading:before{content:"\\f1dc"}.fa-ghost:before{content:"\\f6e2"}.fa-list-squares:before,.fa-list:before{content:"\\f03a"}.fa-phone-square-alt:before,.fa-square-phone-flip:before{content:"\\f87b"}.fa-cart-plus:before{content:"\\f217"}.fa-gamepad:before{content:"\\f11b"}.fa-circle-dot:before,.fa-dot-circle:before{content:"\\f192"}.fa-dizzy:before,.fa-face-dizzy:before{content:"\\f567"}.fa-egg:before{content:"\\f7fb"}.fa-house-medical-circle-xmark:before{content:"\\e513"}.fa-campground:before{content:"\\f6bb"}.fa-folder-plus:before{content:"\\f65e"}.fa-futbol-ball:before,.fa-futbol:before,.fa-soccer-ball:before{content:"\\f1e3"}.fa-paint-brush:before,.fa-paintbrush:before{content:"\\f1fc"}.fa-lock:before{content:"\\f023"}.fa-gas-pump:before{content:"\\f52f"}.fa-hot-tub-person:before,.fa-hot-tub:before{content:"\\f593"}.fa-map-location:before,.fa-map-marked:before{content:"\\f59f"}.fa-house-flood-water:before{content:"\\e50e"}.fa-tree:before{content:"\\f1bb"}.fa-bridge-lock:before{content:"\\e4cc"}.fa-sack-dollar:before{content:"\\f81d"}.fa-edit:before,.fa-pen-to-square:before{content:"\\f044"}.fa-car-side:before{content:"\\f5e4"}.fa-share-alt:before,.fa-share-nodes:before{content:"\\f1e0"}.fa-heart-circle-minus:before{content:"\\e4ff"}.fa-hourglass-2:before,.fa-hourglass-half:before{content:"\\f252"}.fa-microscope:before{content:"\\f610"}.fa-sink:before{content:"\\e06d"}.fa-bag-shopping:before,.fa-shopping-bag:before{content:"\\f290"}.fa-arrow-down-z-a:before,.fa-sort-alpha-desc:before,.fa-sort-alpha-down-alt:before{content:"\\f881"}.fa-mitten:before{content:"\\f7b5"}.fa-person-rays:before{content:"\\e54d"}.fa-users:before{content:"\\f0c0"}.fa-eye-slash:before{content:"\\f070"}.fa-flask-vial:before{content:"\\e4f3"}.fa-hand-paper:before,.fa-hand:before{content:"\\f256"}.fa-om:before{content:"\\f679"}.fa-worm:before{content:"\\e599"}.fa-house-circle-xmark:before{content:"\\e50b"}.fa-plug:before{content:"\\f1e6"}.fa-chevron-up:before{content:"\\f077"}.fa-hand-spock:before{content:"\\f259"}.fa-stopwatch:before{content:"\\f2f2"}.fa-face-kiss:before,.fa-kiss:before{content:"\\f596"}.fa-bridge-circle-xmark:before{content:"\\e4cb"}.fa-face-grin-tongue:before,.fa-grin-tongue:before{content:"\\f589"}.fa-chess-bishop:before{content:"\\f43a"}.fa-face-grin-wink:before,.fa-grin-wink:before{content:"\\f58c"}.fa-deaf:before,.fa-deafness:before,.fa-ear-deaf:before,.fa-hard-of-hearing:before{content:"\\f2a4"}.fa-road-circle-check:before{content:"\\e564"}.fa-dice-five:before{content:"\\f523"}.fa-rss-square:before,.fa-square-rss:before{content:"\\f143"}.fa-land-mine-on:before{content:"\\e51b"}.fa-i-cursor:before{content:"\\f246"}.fa-stamp:before{content:"\\f5bf"}.fa-stairs:before{content:"\\e289"}.fa-i:before{content:"\\49"}.fa-hryvnia-sign:before,.fa-hryvnia:before{content:"\\f6f2"}.fa-pills:before{content:"\\f484"}.fa-face-grin-wide:before,.fa-grin-alt:before{content:"\\f581"}.fa-tooth:before{content:"\\f5c9"}.fa-v:before{content:"\\56"}.fa-bangladeshi-taka-sign:before{content:"\\e2e6"}.fa-bicycle:before{content:"\\f206"}.fa-rod-asclepius:before,.fa-rod-snake:before,.fa-staff-aesculapius:before,.fa-staff-snake:before{content:"\\e579"}.fa-head-side-cough-slash:before{content:"\\e062"}.fa-ambulance:before,.fa-truck-medical:before{content:"\\f0f9"}.fa-wheat-awn-circle-exclamation:before{content:"\\e598"}.fa-snowman:before{content:"\\f7d0"}.fa-mortar-pestle:before{content:"\\f5a7"}.fa-road-barrier:before{content:"\\e562"}.fa-school:before{content:"\\f549"}.fa-igloo:before{content:"\\f7ae"}.fa-joint:before{content:"\\f595"}.fa-angle-right:before{content:"\\f105"}.fa-horse:before{content:"\\f6f0"}.fa-q:before{content:"\\51"}.fa-g:before{content:"\\47"}.fa-notes-medical:before{content:"\\f481"}.fa-temperature-2:before,.fa-temperature-half:before,.fa-thermometer-2:before,.fa-thermometer-half:before{content:"\\f2c9"}.fa-dong-sign:before{content:"\\e169"}.fa-capsules:before{content:"\\f46b"}.fa-poo-bolt:before,.fa-poo-storm:before{content:"\\f75a"}.fa-face-frown-open:before,.fa-frown-open:before{content:"\\f57a"}.fa-hand-point-up:before{content:"\\f0a6"}.fa-money-bill:before{content:"\\f0d6"}.fa-bookmark:before{content:"\\f02e"}.fa-align-justify:before{content:"\\f039"}.fa-umbrella-beach:before{content:"\\f5ca"}.fa-helmet-un:before{content:"\\e503"}.fa-bullseye:before{content:"\\f140"}.fa-bacon:before{content:"\\f7e5"}.fa-hand-point-down:before{content:"\\f0a7"}.fa-arrow-up-from-bracket:before{content:"\\e09a"}.fa-folder-blank:before,.fa-folder:before{content:"\\f07b"}.fa-file-medical-alt:before,.fa-file-waveform:before{content:"\\f478"}.fa-radiation:before{content:"\\f7b9"}.fa-chart-simple:before{content:"\\e473"}.fa-mars-stroke:before{content:"\\f229"}.fa-vial:before{content:"\\f492"}.fa-dashboard:before,.fa-gauge-med:before,.fa-gauge:before,.fa-tachometer-alt-average:before{content:"\\f624"}.fa-magic-wand-sparkles:before,.fa-wand-magic-sparkles:before{content:"\\e2ca"}.fa-e:before{content:"\\45"}.fa-pen-alt:before,.fa-pen-clip:before{content:"\\f305"}.fa-bridge-circle-exclamation:before{content:"\\e4ca"}.fa-user:before{content:"\\f007"}.fa-school-circle-check:before{content:"\\e56b"}.fa-dumpster:before{content:"\\f793"}.fa-shuttle-van:before,.fa-van-shuttle:before{content:"\\f5b6"}.fa-building-user:before{content:"\\e4da"}.fa-caret-square-left:before,.fa-square-caret-left:before{content:"\\f191"}.fa-highlighter:before{content:"\\f591"}.fa-key:before{content:"\\f084"}.fa-bullhorn:before{content:"\\f0a1"}.fa-globe:before{content:"\\f0ac"}.fa-synagogue:before{content:"\\f69b"}.fa-person-half-dress:before{content:"\\e548"}.fa-road-bridge:before{content:"\\e563"}.fa-location-arrow:before{content:"\\f124"}.fa-c:before{content:"\\43"}.fa-tablet-button:before{content:"\\f10a"}.fa-building-lock:before{content:"\\e4d6"}.fa-pizza-slice:before{content:"\\f818"}.fa-money-bill-wave:before{content:"\\f53a"}.fa-area-chart:before,.fa-chart-area:before{content:"\\f1fe"}.fa-house-flag:before{content:"\\e50d"}.fa-person-circle-minus:before{content:"\\e540"}.fa-ban:before,.fa-cancel:before{content:"\\f05e"}.fa-camera-rotate:before{content:"\\e0d8"}.fa-air-freshener:before,.fa-spray-can-sparkles:before{content:"\\f5d0"}.fa-star:before{content:"\\f005"}.fa-repeat:before{content:"\\f363"}.fa-cross:before{content:"\\f654"}.fa-box:before{content:"\\f466"}.fa-venus-mars:before{content:"\\f228"}.fa-arrow-pointer:before,.fa-mouse-pointer:before{content:"\\f245"}.fa-expand-arrows-alt:before,.fa-maximize:before{content:"\\f31e"}.fa-charging-station:before{content:"\\f5e7"}.fa-shapes:before,.fa-triangle-circle-square:before{content:"\\f61f"}.fa-random:before,.fa-shuffle:before{content:"\\f074"}.fa-person-running:before,.fa-running:before{content:"\\f70c"}.fa-mobile-retro:before{content:"\\e527"}.fa-grip-lines-vertical:before{content:"\\f7a5"}.fa-spider:before{content:"\\f717"}.fa-hands-bound:before{content:"\\e4f9"}.fa-file-invoice-dollar:before{content:"\\f571"}.fa-plane-circle-exclamation:before{content:"\\e556"}.fa-x-ray:before{content:"\\f497"}.fa-spell-check:before{content:"\\f891"}.fa-slash:before{content:"\\f715"}.fa-computer-mouse:before,.fa-mouse:before{content:"\\f8cc"}.fa-arrow-right-to-bracket:before,.fa-sign-in:before{content:"\\f090"}.fa-shop-slash:before,.fa-store-alt-slash:before{content:"\\e070"}.fa-server:before{content:"\\f233"}.fa-virus-covid-slash:before{content:"\\e4a9"}.fa-shop-lock:before{content:"\\e4a5"}.fa-hourglass-1:before,.fa-hourglass-start:before{content:"\\f251"}.fa-blender-phone:before{content:"\\f6b6"}.fa-building-wheat:before{content:"\\e4db"}.fa-person-breastfeeding:before{content:"\\e53a"}.fa-right-to-bracket:before,.fa-sign-in-alt:before{content:"\\f2f6"}.fa-venus:before{content:"\\f221"}.fa-passport:before{content:"\\f5ab"}.fa-thumb-tack-slash:before,.fa-thumbtack-slash:before{content:"\\e68f"}.fa-heart-pulse:before,.fa-heartbeat:before{content:"\\f21e"}.fa-people-carry-box:before,.fa-people-carry:before{content:"\\f4ce"}.fa-temperature-high:before{content:"\\f769"}.fa-microchip:before{content:"\\f2db"}.fa-crown:before{content:"\\f521"}.fa-weight-hanging:before{content:"\\f5cd"}.fa-xmarks-lines:before{content:"\\e59a"}.fa-file-prescription:before{content:"\\f572"}.fa-weight-scale:before,.fa-weight:before{content:"\\f496"}.fa-user-friends:before,.fa-user-group:before{content:"\\f500"}.fa-arrow-up-a-z:before,.fa-sort-alpha-up:before{content:"\\f15e"}.fa-chess-knight:before{content:"\\f441"}.fa-face-laugh-squint:before,.fa-laugh-squint:before{content:"\\f59b"}.fa-wheelchair:before{content:"\\f193"}.fa-arrow-circle-up:before,.fa-circle-arrow-up:before{content:"\\f0aa"}.fa-toggle-on:before{content:"\\f205"}.fa-person-walking:before,.fa-walking:before{content:"\\f554"}.fa-l:before{content:"\\4c"}.fa-fire:before{content:"\\f06d"}.fa-bed-pulse:before,.fa-procedures:before{content:"\\f487"}.fa-shuttle-space:before,.fa-space-shuttle:before{content:"\\f197"}.fa-face-laugh:before,.fa-laugh:before{content:"\\f599"}.fa-folder-open:before{content:"\\f07c"}.fa-heart-circle-plus:before{content:"\\e500"}.fa-code-fork:before{content:"\\e13b"}.fa-city:before{content:"\\f64f"}.fa-microphone-alt:before,.fa-microphone-lines:before{content:"\\f3c9"}.fa-pepper-hot:before{content:"\\f816"}.fa-unlock:before{content:"\\f09c"}.fa-colon-sign:before{content:"\\e140"}.fa-headset:before{content:"\\f590"}.fa-store-slash:before{content:"\\e071"}.fa-road-circle-xmark:before{content:"\\e566"}.fa-user-minus:before{content:"\\f503"}.fa-mars-stroke-up:before,.fa-mars-stroke-v:before{content:"\\f22a"}.fa-champagne-glasses:before,.fa-glass-cheers:before{content:"\\f79f"}.fa-clipboard:before{content:"\\f328"}.fa-house-circle-exclamation:before{content:"\\e50a"}.fa-file-arrow-up:before,.fa-file-upload:before{content:"\\f574"}.fa-wifi-3:before,.fa-wifi-strong:before,.fa-wifi:before{content:"\\f1eb"}.fa-bath:before,.fa-bathtub:before{content:"\\f2cd"}.fa-underline:before{content:"\\f0cd"}.fa-user-edit:before,.fa-user-pen:before{content:"\\f4ff"}.fa-signature:before{content:"\\f5b7"}.fa-stroopwafel:before{content:"\\f551"}.fa-bold:before{content:"\\f032"}.fa-anchor-lock:before{content:"\\e4ad"}.fa-building-ngo:before{content:"\\e4d7"}.fa-manat-sign:before{content:"\\e1d5"}.fa-not-equal:before{content:"\\f53e"}.fa-border-style:before,.fa-border-top-left:before{content:"\\f853"}.fa-map-location-dot:before,.fa-map-marked-alt:before{content:"\\f5a0"}.fa-jedi:before{content:"\\f669"}.fa-poll:before,.fa-square-poll-vertical:before{content:"\\f681"}.fa-mug-hot:before{content:"\\f7b6"}.fa-battery-car:before,.fa-car-battery:before{content:"\\f5df"}.fa-gift:before{content:"\\f06b"}.fa-dice-two:before{content:"\\f528"}.fa-chess-queen:before{content:"\\f445"}.fa-glasses:before{content:"\\f530"}.fa-chess-board:before{content:"\\f43c"}.fa-building-circle-check:before{content:"\\e4d2"}.fa-person-chalkboard:before{content:"\\e53d"}.fa-mars-stroke-h:before,.fa-mars-stroke-right:before{content:"\\f22b"}.fa-hand-back-fist:before,.fa-hand-rock:before{content:"\\f255"}.fa-caret-square-up:before,.fa-square-caret-up:before{content:"\\f151"}.fa-cloud-showers-water:before{content:"\\e4e4"}.fa-bar-chart:before,.fa-chart-bar:before{content:"\\f080"}.fa-hands-bubbles:before,.fa-hands-wash:before{content:"\\e05e"}.fa-less-than-equal:before{content:"\\f537"}.fa-train:before{content:"\\f238"}.fa-eye-low-vision:before,.fa-low-vision:before{content:"\\f2a8"}.fa-crow:before{content:"\\f520"}.fa-sailboat:before{content:"\\e445"}.fa-window-restore:before{content:"\\f2d2"}.fa-plus-square:before,.fa-square-plus:before{content:"\\f0fe"}.fa-torii-gate:before{content:"\\f6a1"}.fa-frog:before{content:"\\f52e"}.fa-bucket:before{content:"\\e4cf"}.fa-image:before{content:"\\f03e"}.fa-microphone:before{content:"\\f130"}.fa-cow:before{content:"\\f6c8"}.fa-caret-up:before{content:"\\f0d8"}.fa-screwdriver:before{content:"\\f54a"}.fa-folder-closed:before{content:"\\e185"}.fa-house-tsunami:before{content:"\\e515"}.fa-square-nfi:before{content:"\\e576"}.fa-arrow-up-from-ground-water:before{content:"\\e4b5"}.fa-glass-martini-alt:before,.fa-martini-glass:before{content:"\\f57b"}.fa-rotate-back:before,.fa-rotate-backward:before,.fa-rotate-left:before,.fa-undo-alt:before{content:"\\f2ea"}.fa-columns:before,.fa-table-columns:before{content:"\\f0db"}.fa-lemon:before{content:"\\f094"}.fa-head-side-mask:before{content:"\\e063"}.fa-handshake:before{content:"\\f2b5"}.fa-gem:before{content:"\\f3a5"}.fa-dolly-box:before,.fa-dolly:before{content:"\\f472"}.fa-smoking:before{content:"\\f48d"}.fa-compress-arrows-alt:before,.fa-minimize:before{content:"\\f78c"}.fa-monument:before{content:"\\f5a6"}.fa-snowplow:before{content:"\\f7d2"}.fa-angle-double-right:before,.fa-angles-right:before{content:"\\f101"}.fa-cannabis:before{content:"\\f55f"}.fa-circle-play:before,.fa-play-circle:before{content:"\\f144"}.fa-tablets:before{content:"\\f490"}.fa-ethernet:before{content:"\\f796"}.fa-eur:before,.fa-euro-sign:before,.fa-euro:before{content:"\\f153"}.fa-chair:before{content:"\\f6c0"}.fa-check-circle:before,.fa-circle-check:before{content:"\\f058"}.fa-circle-stop:before,.fa-stop-circle:before{content:"\\f28d"}.fa-compass-drafting:before,.fa-drafting-compass:before{content:"\\f568"}.fa-plate-wheat:before{content:"\\e55a"}.fa-icicles:before{content:"\\f7ad"}.fa-person-shelter:before{content:"\\e54f"}.fa-neuter:before{content:"\\f22c"}.fa-id-badge:before{content:"\\f2c1"}.fa-marker:before{content:"\\f5a1"}.fa-face-laugh-beam:before,.fa-laugh-beam:before{content:"\\f59a"}.fa-helicopter-symbol:before{content:"\\e502"}.fa-universal-access:before{content:"\\f29a"}.fa-chevron-circle-up:before,.fa-circle-chevron-up:before{content:"\\f139"}.fa-lari-sign:before{content:"\\e1c8"}.fa-volcano:before{content:"\\f770"}.fa-person-walking-dashed-line-arrow-right:before{content:"\\e553"}.fa-gbp:before,.fa-pound-sign:before,.fa-sterling-sign:before{content:"\\f154"}.fa-viruses:before{content:"\\e076"}.fa-square-person-confined:before{content:"\\e577"}.fa-user-tie:before{content:"\\f508"}.fa-arrow-down-long:before,.fa-long-arrow-down:before{content:"\\f175"}.fa-tent-arrow-down-to-line:before{content:"\\e57e"}.fa-certificate:before{content:"\\f0a3"}.fa-mail-reply-all:before,.fa-reply-all:before{content:"\\f122"}.fa-suitcase:before{content:"\\f0f2"}.fa-person-skating:before,.fa-skating:before{content:"\\f7c5"}.fa-filter-circle-dollar:before,.fa-funnel-dollar:before{content:"\\f662"}.fa-camera-retro:before{content:"\\f083"}.fa-arrow-circle-down:before,.fa-circle-arrow-down:before{content:"\\f0ab"}.fa-arrow-right-to-file:before,.fa-file-import:before{content:"\\f56f"}.fa-external-link-square:before,.fa-square-arrow-up-right:before{content:"\\f14c"}.fa-box-open:before{content:"\\f49e"}.fa-scroll:before{content:"\\f70e"}.fa-spa:before{content:"\\f5bb"}.fa-location-pin-lock:before{content:"\\e51f"}.fa-pause:before{content:"\\f04c"}.fa-hill-avalanche:before{content:"\\e507"}.fa-temperature-0:before,.fa-temperature-empty:before,.fa-thermometer-0:before,.fa-thermometer-empty:before{content:"\\f2cb"}.fa-bomb:before{content:"\\f1e2"}.fa-registered:before{content:"\\f25d"}.fa-address-card:before,.fa-contact-card:before,.fa-vcard:before{content:"\\f2bb"}.fa-balance-scale-right:before,.fa-scale-unbalanced-flip:before{content:"\\f516"}.fa-subscript:before{content:"\\f12c"}.fa-diamond-turn-right:before,.fa-directions:before{content:"\\f5eb"}.fa-burst:before{content:"\\e4dc"}.fa-house-laptop:before,.fa-laptop-house:before{content:"\\e066"}.fa-face-tired:before,.fa-tired:before{content:"\\f5c8"}.fa-money-bills:before{content:"\\e1f3"}.fa-smog:before{content:"\\f75f"}.fa-crutch:before{content:"\\f7f7"}.fa-cloud-arrow-up:before,.fa-cloud-upload-alt:before,.fa-cloud-upload:before{content:"\\f0ee"}.fa-palette:before{content:"\\f53f"}.fa-arrows-turn-right:before{content:"\\e4c0"}.fa-vest:before{content:"\\e085"}.fa-ferry:before{content:"\\e4ea"}.fa-arrows-down-to-people:before{content:"\\e4b9"}.fa-seedling:before,.fa-sprout:before{content:"\\f4d8"}.fa-arrows-alt-h:before,.fa-left-right:before{content:"\\f337"}.fa-boxes-packing:before{content:"\\e4c7"}.fa-arrow-circle-left:before,.fa-circle-arrow-left:before{content:"\\f0a8"}.fa-group-arrows-rotate:before{content:"\\e4f6"}.fa-bowl-food:before{content:"\\e4c6"}.fa-candy-cane:before{content:"\\f786"}.fa-arrow-down-wide-short:before,.fa-sort-amount-asc:before,.fa-sort-amount-down:before{content:"\\f160"}.fa-cloud-bolt:before,.fa-thunderstorm:before{content:"\\f76c"}.fa-remove-format:before,.fa-text-slash:before{content:"\\f87d"}.fa-face-smile-wink:before,.fa-smile-wink:before{content:"\\f4da"}.fa-file-word:before{content:"\\f1c2"}.fa-file-powerpoint:before{content:"\\f1c4"}.fa-arrows-h:before,.fa-arrows-left-right:before{content:"\\f07e"}.fa-house-lock:before{content:"\\e510"}.fa-cloud-arrow-down:before,.fa-cloud-download-alt:before,.fa-cloud-download:before{content:"\\f0ed"}.fa-children:before{content:"\\e4e1"}.fa-blackboard:before,.fa-chalkboard:before{content:"\\f51b"}.fa-user-alt-slash:before,.fa-user-large-slash:before{content:"\\f4fa"}.fa-envelope-open:before{content:"\\f2b6"}.fa-handshake-alt-slash:before,.fa-handshake-simple-slash:before{content:"\\e05f"}.fa-mattress-pillow:before{content:"\\e525"}.fa-guarani-sign:before{content:"\\e19a"}.fa-arrows-rotate:before,.fa-refresh:before,.fa-sync:before{content:"\\f021"}.fa-fire-extinguisher:before{content:"\\f134"}.fa-cruzeiro-sign:before{content:"\\e152"}.fa-greater-than-equal:before{content:"\\f532"}.fa-shield-alt:before,.fa-shield-halved:before{content:"\\f3ed"}.fa-atlas:before,.fa-book-atlas:before{content:"\\f558"}.fa-virus:before{content:"\\e074"}.fa-envelope-circle-check:before{content:"\\e4e8"}.fa-layer-group:before{content:"\\f5fd"}.fa-arrows-to-dot:before{content:"\\e4be"}.fa-archway:before{content:"\\f557"}.fa-heart-circle-check:before{content:"\\e4fd"}.fa-house-chimney-crack:before,.fa-house-damage:before{content:"\\f6f1"}.fa-file-archive:before,.fa-file-zipper:before{content:"\\f1c6"}.fa-square:before{content:"\\f0c8"}.fa-glass-martini:before,.fa-martini-glass-empty:before{content:"\\f000"}.fa-couch:before{content:"\\f4b8"}.fa-cedi-sign:before{content:"\\e0df"}.fa-italic:before{content:"\\f033"}.fa-table-cells-column-lock:before{content:"\\e678"}.fa-church:before{content:"\\f51d"}.fa-comments-dollar:before{content:"\\f653"}.fa-democrat:before{content:"\\f747"}.fa-z:before{content:"\\5a"}.fa-person-skiing:before,.fa-skiing:before{content:"\\f7c9"}.fa-road-lock:before{content:"\\e567"}.fa-a:before{content:"\\41"}.fa-temperature-arrow-down:before,.fa-temperature-down:before{content:"\\e03f"}.fa-feather-alt:before,.fa-feather-pointed:before{content:"\\f56b"}.fa-p:before{content:"\\50"}.fa-snowflake:before{content:"\\f2dc"}.fa-newspaper:before{content:"\\f1ea"}.fa-ad:before,.fa-rectangle-ad:before{content:"\\f641"}.fa-arrow-circle-right:before,.fa-circle-arrow-right:before{content:"\\f0a9"}.fa-filter-circle-xmark:before{content:"\\e17b"}.fa-locust:before{content:"\\e520"}.fa-sort:before,.fa-unsorted:before{content:"\\f0dc"}.fa-list-1-2:before,.fa-list-numeric:before,.fa-list-ol:before{content:"\\f0cb"}.fa-person-dress-burst:before{content:"\\e544"}.fa-money-check-alt:before,.fa-money-check-dollar:before{content:"\\f53d"}.fa-vector-square:before{content:"\\f5cb"}.fa-bread-slice:before{content:"\\f7ec"}.fa-language:before{content:"\\f1ab"}.fa-face-kiss-wink-heart:before,.fa-kiss-wink-heart:before{content:"\\f598"}.fa-filter:before{content:"\\f0b0"}.fa-question:before{content:"\\3f"}.fa-file-signature:before{content:"\\f573"}.fa-arrows-alt:before,.fa-up-down-left-right:before{content:"\\f0b2"}.fa-house-chimney-user:before{content:"\\e065"}.fa-hand-holding-heart:before{content:"\\f4be"}.fa-puzzle-piece:before{content:"\\f12e"}.fa-money-check:before{content:"\\f53c"}.fa-star-half-alt:before,.fa-star-half-stroke:before{content:"\\f5c0"}.fa-code:before{content:"\\f121"}.fa-glass-whiskey:before,.fa-whiskey-glass:before{content:"\\f7a0"}.fa-building-circle-exclamation:before{content:"\\e4d3"}.fa-magnifying-glass-chart:before{content:"\\e522"}.fa-arrow-up-right-from-square:before,.fa-external-link:before{content:"\\f08e"}.fa-cubes-stacked:before{content:"\\e4e6"}.fa-krw:before,.fa-won-sign:before,.fa-won:before{content:"\\f159"}.fa-virus-covid:before{content:"\\e4a8"}.fa-austral-sign:before{content:"\\e0a9"}.fa-f:before{content:"\\46"}.fa-leaf:before{content:"\\f06c"}.fa-road:before{content:"\\f018"}.fa-cab:before,.fa-taxi:before{content:"\\f1ba"}.fa-person-circle-plus:before{content:"\\e541"}.fa-chart-pie:before,.fa-pie-chart:before{content:"\\f200"}.fa-bolt-lightning:before{content:"\\e0b7"}.fa-sack-xmark:before{content:"\\e56a"}.fa-file-excel:before{content:"\\f1c3"}.fa-file-contract:before{content:"\\f56c"}.fa-fish-fins:before{content:"\\e4f2"}.fa-building-flag:before{content:"\\e4d5"}.fa-face-grin-beam:before,.fa-grin-beam:before{content:"\\f582"}.fa-object-ungroup:before{content:"\\f248"}.fa-poop:before{content:"\\f619"}.fa-location-pin:before,.fa-map-marker:before{content:"\\f041"}.fa-kaaba:before{content:"\\f66b"}.fa-toilet-paper:before{content:"\\f71e"}.fa-hard-hat:before,.fa-hat-hard:before,.fa-helmet-safety:before{content:"\\f807"}.fa-eject:before{content:"\\f052"}.fa-arrow-alt-circle-right:before,.fa-circle-right:before{content:"\\f35a"}.fa-plane-circle-check:before{content:"\\e555"}.fa-face-rolling-eyes:before,.fa-meh-rolling-eyes:before{content:"\\f5a5"}.fa-object-group:before{content:"\\f247"}.fa-chart-line:before,.fa-line-chart:before{content:"\\f201"}.fa-mask-ventilator:before{content:"\\e524"}.fa-arrow-right:before{content:"\\f061"}.fa-map-signs:before,.fa-signs-post:before{content:"\\f277"}.fa-cash-register:before{content:"\\f788"}.fa-person-circle-question:before{content:"\\e542"}.fa-h:before{content:"\\48"}.fa-tarp:before{content:"\\e57b"}.fa-screwdriver-wrench:before,.fa-tools:before{content:"\\f7d9"}.fa-arrows-to-eye:before{content:"\\e4bf"}.fa-plug-circle-bolt:before{content:"\\e55b"}.fa-heart:before{content:"\\f004"}.fa-mars-and-venus:before{content:"\\f224"}.fa-home-user:before,.fa-house-user:before{content:"\\e1b0"}.fa-dumpster-fire:before{content:"\\f794"}.fa-house-crack:before{content:"\\e3b1"}.fa-cocktail:before,.fa-martini-glass-citrus:before{content:"\\f561"}.fa-face-surprise:before,.fa-surprise:before{content:"\\f5c2"}.fa-bottle-water:before{content:"\\e4c5"}.fa-circle-pause:before,.fa-pause-circle:before{content:"\\f28b"}.fa-toilet-paper-slash:before{content:"\\e072"}.fa-apple-alt:before,.fa-apple-whole:before{content:"\\f5d1"}.fa-kitchen-set:before{content:"\\e51a"}.fa-r:before{content:"\\52"}.fa-temperature-1:before,.fa-temperature-quarter:before,.fa-thermometer-1:before,.fa-thermometer-quarter:before{content:"\\f2ca"}.fa-cube:before{content:"\\f1b2"}.fa-bitcoin-sign:before{content:"\\e0b4"}.fa-shield-dog:before{content:"\\e573"}.fa-solar-panel:before{content:"\\f5ba"}.fa-lock-open:before{content:"\\f3c1"}.fa-elevator:before{content:"\\e16d"}.fa-money-bill-transfer:before{content:"\\e528"}.fa-money-bill-trend-up:before{content:"\\e529"}.fa-house-flood-water-circle-arrow-right:before{content:"\\e50f"}.fa-poll-h:before,.fa-square-poll-horizontal:before{content:"\\f682"}.fa-circle:before{content:"\\f111"}.fa-backward-fast:before,.fa-fast-backward:before{content:"\\f049"}.fa-recycle:before{content:"\\f1b8"}.fa-user-astronaut:before{content:"\\f4fb"}.fa-plane-slash:before{content:"\\e069"}.fa-trademark:before{content:"\\f25c"}.fa-basketball-ball:before,.fa-basketball:before{content:"\\f434"}.fa-satellite-dish:before{content:"\\f7c0"}.fa-arrow-alt-circle-up:before,.fa-circle-up:before{content:"\\f35b"}.fa-mobile-alt:before,.fa-mobile-screen-button:before{content:"\\f3cd"}.fa-volume-high:before,.fa-volume-up:before{content:"\\f028"}.fa-users-rays:before{content:"\\e593"}.fa-wallet:before{content:"\\f555"}.fa-clipboard-check:before{content:"\\f46c"}.fa-file-audio:before{content:"\\f1c7"}.fa-burger:before,.fa-hamburger:before{content:"\\f805"}.fa-wrench:before{content:"\\f0ad"}.fa-bugs:before{content:"\\e4d0"}.fa-rupee-sign:before,.fa-rupee:before{content:"\\f156"}.fa-file-image:before{content:"\\f1c5"}.fa-circle-question:before,.fa-question-circle:before{content:"\\f059"}.fa-plane-departure:before{content:"\\f5b0"}.fa-handshake-slash:before{content:"\\e060"}.fa-book-bookmark:before{content:"\\e0bb"}.fa-code-branch:before{content:"\\f126"}.fa-hat-cowboy:before{content:"\\f8c0"}.fa-bridge:before{content:"\\e4c8"}.fa-phone-alt:before,.fa-phone-flip:before{content:"\\f879"}.fa-truck-front:before{content:"\\e2b7"}.fa-cat:before{content:"\\f6be"}.fa-anchor-circle-exclamation:before{content:"\\e4ab"}.fa-truck-field:before{content:"\\e58d"}.fa-route:before{content:"\\f4d7"}.fa-clipboard-question:before{content:"\\e4e3"}.fa-panorama:before{content:"\\e209"}.fa-comment-medical:before{content:"\\f7f5"}.fa-teeth-open:before{content:"\\f62f"}.fa-file-circle-minus:before{content:"\\e4ed"}.fa-tags:before{content:"\\f02c"}.fa-wine-glass:before{content:"\\f4e3"}.fa-fast-forward:before,.fa-forward-fast:before{content:"\\f050"}.fa-face-meh-blank:before,.fa-meh-blank:before{content:"\\f5a4"}.fa-parking:before,.fa-square-parking:before{content:"\\f540"}.fa-house-signal:before{content:"\\e012"}.fa-bars-progress:before,.fa-tasks-alt:before{content:"\\f828"}.fa-faucet-drip:before{content:"\\e006"}.fa-cart-flatbed:before,.fa-dolly-flatbed:before{content:"\\f474"}.fa-ban-smoking:before,.fa-smoking-ban:before{content:"\\f54d"}.fa-terminal:before{content:"\\f120"}.fa-mobile-button:before{content:"\\f10b"}.fa-house-medical-flag:before{content:"\\e514"}.fa-basket-shopping:before,.fa-shopping-basket:before{content:"\\f291"}.fa-tape:before{content:"\\f4db"}.fa-bus-alt:before,.fa-bus-simple:before{content:"\\f55e"}.fa-eye:before{content:"\\f06e"}.fa-face-sad-cry:before,.fa-sad-cry:before{content:"\\f5b3"}.fa-audio-description:before{content:"\\f29e"}.fa-person-military-to-person:before{content:"\\e54c"}.fa-file-shield:before{content:"\\e4f0"}.fa-user-slash:before{content:"\\f506"}.fa-pen:before{content:"\\f304"}.fa-tower-observation:before{content:"\\e586"}.fa-file-code:before{content:"\\f1c9"}.fa-signal-5:before,.fa-signal-perfect:before,.fa-signal:before{content:"\\f012"}.fa-bus:before{content:"\\f207"}.fa-heart-circle-xmark:before{content:"\\e501"}.fa-home-lg:before,.fa-house-chimney:before{content:"\\e3af"}.fa-window-maximize:before{content:"\\f2d0"}.fa-face-frown:before,.fa-frown:before{content:"\\f119"}.fa-prescription:before{content:"\\f5b1"}.fa-shop:before,.fa-store-alt:before{content:"\\f54f"}.fa-floppy-disk:before,.fa-save:before{content:"\\f0c7"}.fa-vihara:before{content:"\\f6a7"}.fa-balance-scale-left:before,.fa-scale-unbalanced:before{content:"\\f515"}.fa-sort-asc:before,.fa-sort-up:before{content:"\\f0de"}.fa-comment-dots:before,.fa-commenting:before{content:"\\f4ad"}.fa-plant-wilt:before{content:"\\e5aa"}.fa-diamond:before{content:"\\f219"}.fa-face-grin-squint:before,.fa-grin-squint:before{content:"\\f585"}.fa-hand-holding-dollar:before,.fa-hand-holding-usd:before{content:"\\f4c0"}.fa-bacterium:before{content:"\\e05a"}.fa-hand-pointer:before{content:"\\f25a"}.fa-drum-steelpan:before{content:"\\f56a"}.fa-hand-scissors:before{content:"\\f257"}.fa-hands-praying:before,.fa-praying-hands:before{content:"\\f684"}.fa-arrow-right-rotate:before,.fa-arrow-rotate-forward:before,.fa-arrow-rotate-right:before,.fa-redo:before{content:"\\f01e"}.fa-biohazard:before{content:"\\f780"}.fa-location-crosshairs:before,.fa-location:before{content:"\\f601"}.fa-mars-double:before{content:"\\f227"}.fa-child-dress:before{content:"\\e59c"}.fa-users-between-lines:before{content:"\\e591"}.fa-lungs-virus:before{content:"\\e067"}.fa-face-grin-tears:before,.fa-grin-tears:before{content:"\\f588"}.fa-phone:before{content:"\\f095"}.fa-calendar-times:before,.fa-calendar-xmark:before{content:"\\f273"}.fa-child-reaching:before{content:"\\e59d"}.fa-head-side-virus:before{content:"\\e064"}.fa-user-cog:before,.fa-user-gear:before{content:"\\f4fe"}.fa-arrow-up-1-9:before,.fa-sort-numeric-up:before{content:"\\f163"}.fa-door-closed:before{content:"\\f52a"}.fa-shield-virus:before{content:"\\e06c"}.fa-dice-six:before{content:"\\f526"}.fa-mosquito-net:before{content:"\\e52c"}.fa-bridge-water:before{content:"\\e4ce"}.fa-person-booth:before{content:"\\f756"}.fa-text-width:before{content:"\\f035"}.fa-hat-wizard:before{content:"\\f6e8"}.fa-pen-fancy:before{content:"\\f5ac"}.fa-digging:before,.fa-person-digging:before{content:"\\f85e"}.fa-trash:before{content:"\\f1f8"}.fa-gauge-simple-med:before,.fa-gauge-simple:before,.fa-tachometer-average:before{content:"\\f629"}.fa-book-medical:before{content:"\\f7e6"}.fa-poo:before{content:"\\f2fe"}.fa-quote-right-alt:before,.fa-quote-right:before{content:"\\f10e"}.fa-shirt:before,.fa-t-shirt:before,.fa-tshirt:before{content:"\\f553"}.fa-cubes:before{content:"\\f1b3"}.fa-divide:before{content:"\\f529"}.fa-tenge-sign:before,.fa-tenge:before{content:"\\f7d7"}.fa-headphones:before{content:"\\f025"}.fa-hands-holding:before{content:"\\f4c2"}.fa-hands-clapping:before{content:"\\e1a8"}.fa-republican:before{content:"\\f75e"}.fa-arrow-left:before{content:"\\f060"}.fa-person-circle-xmark:before{content:"\\e543"}.fa-ruler:before{content:"\\f545"}.fa-align-left:before{content:"\\f036"}.fa-dice-d6:before{content:"\\f6d1"}.fa-restroom:before{content:"\\f7bd"}.fa-j:before{content:"\\4a"}.fa-users-viewfinder:before{content:"\\e595"}.fa-file-video:before{content:"\\f1c8"}.fa-external-link-alt:before,.fa-up-right-from-square:before{content:"\\f35d"}.fa-table-cells:before,.fa-th:before{content:"\\f00a"}.fa-file-pdf:before{content:"\\f1c1"}.fa-bible:before,.fa-book-bible:before{content:"\\f647"}.fa-o:before{content:"\\4f"}.fa-medkit:before,.fa-suitcase-medical:before{content:"\\f0fa"}.fa-user-secret:before{content:"\\f21b"}.fa-otter:before{content:"\\f700"}.fa-female:before,.fa-person-dress:before{content:"\\f182"}.fa-comment-dollar:before{content:"\\f651"}.fa-briefcase-clock:before,.fa-business-time:before{content:"\\f64a"}.fa-table-cells-large:before,.fa-th-large:before{content:"\\f009"}.fa-book-tanakh:before,.fa-tanakh:before{content:"\\f827"}.fa-phone-volume:before,.fa-volume-control-phone:before{content:"\\f2a0"}.fa-hat-cowboy-side:before{content:"\\f8c1"}.fa-clipboard-user:before{content:"\\f7f3"}.fa-child:before{content:"\\f1ae"}.fa-lira-sign:before{content:"\\f195"}.fa-satellite:before{content:"\\f7bf"}.fa-plane-lock:before{content:"\\e558"}.fa-tag:before{content:"\\f02b"}.fa-comment:before{content:"\\f075"}.fa-birthday-cake:before,.fa-cake-candles:before,.fa-cake:before{content:"\\f1fd"}.fa-envelope:before{content:"\\f0e0"}.fa-angle-double-up:before,.fa-angles-up:before{content:"\\f102"}.fa-paperclip:before{content:"\\f0c6"}.fa-arrow-right-to-city:before{content:"\\e4b3"}.fa-ribbon:before{content:"\\f4d6"}.fa-lungs:before{content:"\\f604"}.fa-arrow-up-9-1:before,.fa-sort-numeric-up-alt:before{content:"\\f887"}.fa-litecoin-sign:before{content:"\\e1d3"}.fa-border-none:before{content:"\\f850"}.fa-circle-nodes:before{content:"\\e4e2"}.fa-parachute-box:before{content:"\\f4cd"}.fa-indent:before{content:"\\f03c"}.fa-truck-field-un:before{content:"\\e58e"}.fa-hourglass-empty:before,.fa-hourglass:before{content:"\\f254"}.fa-mountain:before{content:"\\f6fc"}.fa-user-doctor:before,.fa-user-md:before{content:"\\f0f0"}.fa-circle-info:before,.fa-info-circle:before{content:"\\f05a"}.fa-cloud-meatball:before{content:"\\f73b"}.fa-camera-alt:before,.fa-camera:before{content:"\\f030"}.fa-square-virus:before{content:"\\e578"}.fa-meteor:before{content:"\\f753"}.fa-car-on:before{content:"\\e4dd"}.fa-sleigh:before{content:"\\f7cc"}.fa-arrow-down-1-9:before,.fa-sort-numeric-asc:before,.fa-sort-numeric-down:before{content:"\\f162"}.fa-hand-holding-droplet:before,.fa-hand-holding-water:before{content:"\\f4c1"}.fa-water:before{content:"\\f773"}.fa-calendar-check:before{content:"\\f274"}.fa-braille:before{content:"\\f2a1"}.fa-prescription-bottle-alt:before,.fa-prescription-bottle-medical:before{content:"\\f486"}.fa-landmark:before{content:"\\f66f"}.fa-truck:before{content:"\\f0d1"}.fa-crosshairs:before{content:"\\f05b"}.fa-person-cane:before{content:"\\e53c"}.fa-tent:before{content:"\\e57d"}.fa-vest-patches:before{content:"\\e086"}.fa-check-double:before{content:"\\f560"}.fa-arrow-down-a-z:before,.fa-sort-alpha-asc:before,.fa-sort-alpha-down:before{content:"\\f15d"}.fa-money-bill-wheat:before{content:"\\e52a"}.fa-cookie:before{content:"\\f563"}.fa-arrow-left-rotate:before,.fa-arrow-rotate-back:before,.fa-arrow-rotate-backward:before,.fa-arrow-rotate-left:before,.fa-undo:before{content:"\\f0e2"}.fa-hard-drive:before,.fa-hdd:before{content:"\\f0a0"}.fa-face-grin-squint-tears:before,.fa-grin-squint-tears:before{content:"\\f586"}.fa-dumbbell:before{content:"\\f44b"}.fa-list-alt:before,.fa-rectangle-list:before{content:"\\f022"}.fa-tarp-droplet:before{content:"\\e57c"}.fa-house-medical-circle-check:before{content:"\\e511"}.fa-person-skiing-nordic:before,.fa-skiing-nordic:before{content:"\\f7ca"}.fa-calendar-plus:before{content:"\\f271"}.fa-plane-arrival:before{content:"\\f5af"}.fa-arrow-alt-circle-left:before,.fa-circle-left:before{content:"\\f359"}.fa-subway:before,.fa-train-subway:before{content:"\\f239"}.fa-chart-gantt:before{content:"\\e0e4"}.fa-indian-rupee-sign:before,.fa-indian-rupee:before,.fa-inr:before{content:"\\e1bc"}.fa-crop-alt:before,.fa-crop-simple:before{content:"\\f565"}.fa-money-bill-1:before,.fa-money-bill-alt:before{content:"\\f3d1"}.fa-left-long:before,.fa-long-arrow-alt-left:before{content:"\\f30a"}.fa-dna:before{content:"\\f471"}.fa-virus-slash:before{content:"\\e075"}.fa-minus:before,.fa-subtract:before{content:"\\f068"}.fa-chess:before{content:"\\f439"}.fa-arrow-left-long:before,.fa-long-arrow-left:before{content:"\\f177"}.fa-plug-circle-check:before{content:"\\e55c"}.fa-street-view:before{content:"\\f21d"}.fa-franc-sign:before{content:"\\e18f"}.fa-volume-off:before{content:"\\f026"}.fa-american-sign-language-interpreting:before,.fa-asl-interpreting:before,.fa-hands-american-sign-language-interpreting:before,.fa-hands-asl-interpreting:before{content:"\\f2a3"}.fa-cog:before,.fa-gear:before{content:"\\f013"}.fa-droplet-slash:before,.fa-tint-slash:before{content:"\\f5c7"}.fa-mosque:before{content:"\\f678"}.fa-mosquito:before{content:"\\e52b"}.fa-star-of-david:before{content:"\\f69a"}.fa-person-military-rifle:before{content:"\\e54b"}.fa-cart-shopping:before,.fa-shopping-cart:before{content:"\\f07a"}.fa-vials:before{content:"\\f493"}.fa-plug-circle-plus:before{content:"\\e55f"}.fa-place-of-worship:before{content:"\\f67f"}.fa-grip-vertical:before{content:"\\f58e"}.fa-arrow-turn-up:before,.fa-level-up:before{content:"\\f148"}.fa-u:before{content:"\\55"}.fa-square-root-alt:before,.fa-square-root-variable:before{content:"\\f698"}.fa-clock-four:before,.fa-clock:before{content:"\\f017"}.fa-backward-step:before,.fa-step-backward:before{content:"\\f048"}.fa-pallet:before{content:"\\f482"}.fa-faucet:before{content:"\\e005"}.fa-baseball-bat-ball:before{content:"\\f432"}.fa-s:before{content:"\\53"}.fa-timeline:before{content:"\\e29c"}.fa-keyboard:before{content:"\\f11c"}.fa-caret-down:before{content:"\\f0d7"}.fa-clinic-medical:before,.fa-house-chimney-medical:before{content:"\\f7f2"}.fa-temperature-3:before,.fa-temperature-three-quarters:before,.fa-thermometer-3:before,.fa-thermometer-three-quarters:before{content:"\\f2c8"}.fa-mobile-android-alt:before,.fa-mobile-screen:before{content:"\\f3cf"}.fa-plane-up:before{content:"\\e22d"}.fa-piggy-bank:before{content:"\\f4d3"}.fa-battery-3:before,.fa-battery-half:before{content:"\\f242"}.fa-mountain-city:before{content:"\\e52e"}.fa-coins:before{content:"\\f51e"}.fa-khanda:before{content:"\\f66d"}.fa-sliders-h:before,.fa-sliders:before{content:"\\f1de"}.fa-folder-tree:before{content:"\\f802"}.fa-network-wired:before{content:"\\f6ff"}.fa-map-pin:before{content:"\\f276"}.fa-hamsa:before{content:"\\f665"}.fa-cent-sign:before{content:"\\e3f5"}.fa-flask:before{content:"\\f0c3"}.fa-person-pregnant:before{content:"\\e31e"}.fa-wand-sparkles:before{content:"\\f72b"}.fa-ellipsis-v:before,.fa-ellipsis-vertical:before{content:"\\f142"}.fa-ticket:before{content:"\\f145"}.fa-power-off:before{content:"\\f011"}.fa-long-arrow-alt-right:before,.fa-right-long:before{content:"\\f30b"}.fa-flag-usa:before{content:"\\f74d"}.fa-laptop-file:before{content:"\\e51d"}.fa-teletype:before,.fa-tty:before{content:"\\f1e4"}.fa-diagram-next:before{content:"\\e476"}.fa-person-rifle:before{content:"\\e54e"}.fa-house-medical-circle-exclamation:before{content:"\\e512"}.fa-closed-captioning:before{content:"\\f20a"}.fa-hiking:before,.fa-person-hiking:before{content:"\\f6ec"}.fa-venus-double:before{content:"\\f226"}.fa-images:before{content:"\\f302"}.fa-calculator:before{content:"\\f1ec"}.fa-people-pulling:before{content:"\\e535"}.fa-n:before{content:"\\4e"}.fa-cable-car:before,.fa-tram:before{content:"\\f7da"}.fa-cloud-rain:before{content:"\\f73d"}.fa-building-circle-xmark:before{content:"\\e4d4"}.fa-ship:before{content:"\\f21a"}.fa-arrows-down-to-line:before{content:"\\e4b8"}.fa-download:before{content:"\\f019"}.fa-face-grin:before,.fa-grin:before{content:"\\f580"}.fa-backspace:before,.fa-delete-left:before{content:"\\f55a"}.fa-eye-dropper-empty:before,.fa-eye-dropper:before,.fa-eyedropper:before{content:"\\f1fb"}.fa-file-circle-check:before{content:"\\e5a0"}.fa-forward:before{content:"\\f04e"}.fa-mobile-android:before,.fa-mobile-phone:before,.fa-mobile:before{content:"\\f3ce"}.fa-face-meh:before,.fa-meh:before{content:"\\f11a"}.fa-align-center:before{content:"\\f037"}.fa-book-dead:before,.fa-book-skull:before{content:"\\f6b7"}.fa-drivers-license:before,.fa-id-card:before{content:"\\f2c2"}.fa-dedent:before,.fa-outdent:before{content:"\\f03b"}.fa-heart-circle-exclamation:before{content:"\\e4fe"}.fa-home-alt:before,.fa-home-lg-alt:before,.fa-home:before,.fa-house:before{content:"\\f015"}.fa-calendar-week:before{content:"\\f784"}.fa-laptop-medical:before{content:"\\f812"}.fa-b:before{content:"\\42"}.fa-file-medical:before{content:"\\f477"}.fa-dice-one:before{content:"\\f525"}.fa-kiwi-bird:before{content:"\\f535"}.fa-arrow-right-arrow-left:before,.fa-exchange:before{content:"\\f0ec"}.fa-redo-alt:before,.fa-rotate-forward:before,.fa-rotate-right:before{content:"\\f2f9"}.fa-cutlery:before,.fa-utensils:before{content:"\\f2e7"}.fa-arrow-up-wide-short:before,.fa-sort-amount-up:before{content:"\\f161"}.fa-mill-sign:before{content:"\\e1ed"}.fa-bowl-rice:before{content:"\\e2eb"}.fa-skull:before{content:"\\f54c"}.fa-broadcast-tower:before,.fa-tower-broadcast:before{content:"\\f519"}.fa-truck-pickup:before{content:"\\f63c"}.fa-long-arrow-alt-up:before,.fa-up-long:before{content:"\\f30c"}.fa-stop:before{content:"\\f04d"}.fa-code-merge:before{content:"\\f387"}.fa-upload:before{content:"\\f093"}.fa-hurricane:before{content:"\\f751"}.fa-mound:before{content:"\\e52d"}.fa-toilet-portable:before{content:"\\e583"}.fa-compact-disc:before{content:"\\f51f"}.fa-file-arrow-down:before,.fa-file-download:before{content:"\\f56d"}.fa-caravan:before{content:"\\f8ff"}.fa-shield-cat:before{content:"\\e572"}.fa-bolt:before,.fa-zap:before{content:"\\f0e7"}.fa-glass-water:before{content:"\\e4f4"}.fa-oil-well:before{content:"\\e532"}.fa-vault:before{content:"\\e2c5"}.fa-mars:before{content:"\\f222"}.fa-toilet:before{content:"\\f7d8"}.fa-plane-circle-xmark:before{content:"\\e557"}.fa-cny:before,.fa-jpy:before,.fa-rmb:before,.fa-yen-sign:before,.fa-yen:before{content:"\\f157"}.fa-rouble:before,.fa-rub:before,.fa-ruble-sign:before,.fa-ruble:before{content:"\\f158"}.fa-sun:before{content:"\\f185"}.fa-guitar:before{content:"\\f7a6"}.fa-face-laugh-wink:before,.fa-laugh-wink:before{content:"\\f59c"}.fa-horse-head:before{content:"\\f7ab"}.fa-bore-hole:before{content:"\\e4c3"}.fa-industry:before{content:"\\f275"}.fa-arrow-alt-circle-down:before,.fa-circle-down:before{content:"\\f358"}.fa-arrows-turn-to-dots:before{content:"\\e4c1"}.fa-florin-sign:before{content:"\\e184"}.fa-arrow-down-short-wide:before,.fa-sort-amount-desc:before,.fa-sort-amount-down-alt:before{content:"\\f884"}.fa-less-than:before{content:"\\3c"}.fa-angle-down:before{content:"\\f107"}.fa-car-tunnel:before{content:"\\e4de"}.fa-head-side-cough:before{content:"\\e061"}.fa-grip-lines:before{content:"\\f7a4"}.fa-thumbs-down:before{content:"\\f165"}.fa-user-lock:before{content:"\\f502"}.fa-arrow-right-long:before,.fa-long-arrow-right:before{content:"\\f178"}.fa-anchor-circle-xmark:before{content:"\\e4ac"}.fa-ellipsis-h:before,.fa-ellipsis:before{content:"\\f141"}.fa-chess-pawn:before{content:"\\f443"}.fa-first-aid:before,.fa-kit-medical:before{content:"\\f479"}.fa-person-through-window:before{content:"\\e5a9"}.fa-toolbox:before{content:"\\f552"}.fa-hands-holding-circle:before{content:"\\e4fb"}.fa-bug:before{content:"\\f188"}.fa-credit-card-alt:before,.fa-credit-card:before{content:"\\f09d"}.fa-automobile:before,.fa-car:before{content:"\\f1b9"}.fa-hand-holding-hand:before{content:"\\e4f7"}.fa-book-open-reader:before,.fa-book-reader:before{content:"\\f5da"}.fa-mountain-sun:before{content:"\\e52f"}.fa-arrows-left-right-to-line:before{content:"\\e4ba"}.fa-dice-d20:before{content:"\\f6cf"}.fa-truck-droplet:before{content:"\\e58c"}.fa-file-circle-xmark:before{content:"\\e5a1"}.fa-temperature-arrow-up:before,.fa-temperature-up:before{content:"\\e040"}.fa-medal:before{content:"\\f5a2"}.fa-bed:before{content:"\\f236"}.fa-h-square:before,.fa-square-h:before{content:"\\f0fd"}.fa-podcast:before{content:"\\f2ce"}.fa-temperature-4:before,.fa-temperature-full:before,.fa-thermometer-4:before,.fa-thermometer-full:before{content:"\\f2c7"}.fa-bell:before{content:"\\f0f3"}.fa-superscript:before{content:"\\f12b"}.fa-plug-circle-xmark:before{content:"\\e560"}.fa-star-of-life:before{content:"\\f621"}.fa-phone-slash:before{content:"\\f3dd"}.fa-paint-roller:before{content:"\\f5aa"}.fa-hands-helping:before,.fa-handshake-angle:before{content:"\\f4c4"}.fa-location-dot:before,.fa-map-marker-alt:before{content:"\\f3c5"}.fa-file:before{content:"\\f15b"}.fa-greater-than:before{content:"\\3e"}.fa-person-swimming:before,.fa-swimmer:before{content:"\\f5c4"}.fa-arrow-down:before{content:"\\f063"}.fa-droplet:before,.fa-tint:before{content:"\\f043"}.fa-eraser:before{content:"\\f12d"}.fa-earth-america:before,.fa-earth-americas:before,.fa-earth:before,.fa-globe-americas:before{content:"\\f57d"}.fa-person-burst:before{content:"\\e53b"}.fa-dove:before{content:"\\f4ba"}.fa-battery-0:before,.fa-battery-empty:before{content:"\\f244"}.fa-socks:before{content:"\\f696"}.fa-inbox:before{content:"\\f01c"}.fa-section:before{content:"\\e447"}.fa-gauge-high:before,.fa-tachometer-alt-fast:before,.fa-tachometer-alt:before{content:"\\f625"}.fa-envelope-open-text:before{content:"\\f658"}.fa-hospital-alt:before,.fa-hospital-wide:before,.fa-hospital:before{content:"\\f0f8"}.fa-wine-bottle:before{content:"\\f72f"}.fa-chess-rook:before{content:"\\f447"}.fa-bars-staggered:before,.fa-reorder:before,.fa-stream:before{content:"\\f550"}.fa-dharmachakra:before{content:"\\f655"}.fa-hotdog:before{content:"\\f80f"}.fa-blind:before,.fa-person-walking-with-cane:before{content:"\\f29d"}.fa-drum:before{content:"\\f569"}.fa-ice-cream:before{content:"\\f810"}.fa-heart-circle-bolt:before{content:"\\e4fc"}.fa-fax:before{content:"\\f1ac"}.fa-paragraph:before{content:"\\f1dd"}.fa-check-to-slot:before,.fa-vote-yea:before{content:"\\f772"}.fa-star-half:before{content:"\\f089"}.fa-boxes-alt:before,.fa-boxes-stacked:before,.fa-boxes:before{content:"\\f468"}.fa-chain:before,.fa-link:before{content:"\\f0c1"}.fa-assistive-listening-systems:before,.fa-ear-listen:before{content:"\\f2a2"}.fa-tree-city:before{content:"\\e587"}.fa-play:before{content:"\\f04b"}.fa-font:before{content:"\\f031"}.fa-table-cells-row-lock:before{content:"\\e67a"}.fa-rupiah-sign:before{content:"\\e23d"}.fa-magnifying-glass:before,.fa-search:before{content:"\\f002"}.fa-ping-pong-paddle-ball:before,.fa-table-tennis-paddle-ball:before,.fa-table-tennis:before{content:"\\f45d"}.fa-diagnoses:before,.fa-person-dots-from-line:before{content:"\\f470"}.fa-trash-can-arrow-up:before,.fa-trash-restore-alt:before{content:"\\f82a"}.fa-naira-sign:before{content:"\\e1f6"}.fa-cart-arrow-down:before{content:"\\f218"}.fa-walkie-talkie:before{content:"\\f8ef"}.fa-file-edit:before,.fa-file-pen:before{content:"\\f31c"}.fa-receipt:before{content:"\\f543"}.fa-pen-square:before,.fa-pencil-square:before,.fa-square-pen:before{content:"\\f14b"}.fa-suitcase-rolling:before{content:"\\f5c1"}.fa-person-circle-exclamation:before{content:"\\e53f"}.fa-chevron-down:before{content:"\\f078"}.fa-battery-5:before,.fa-battery-full:before,.fa-battery:before{content:"\\f240"}.fa-skull-crossbones:before{content:"\\f714"}.fa-code-compare:before{content:"\\e13a"}.fa-list-dots:before,.fa-list-ul:before{content:"\\f0ca"}.fa-school-lock:before{content:"\\e56f"}.fa-tower-cell:before{content:"\\e585"}.fa-down-long:before,.fa-long-arrow-alt-down:before{content:"\\f309"}.fa-ranking-star:before{content:"\\e561"}.fa-chess-king:before{content:"\\f43f"}.fa-person-harassing:before{content:"\\e549"}.fa-brazilian-real-sign:before{content:"\\e46c"}.fa-landmark-alt:before,.fa-landmark-dome:before{content:"\\f752"}.fa-arrow-up:before{content:"\\f062"}.fa-television:before,.fa-tv-alt:before,.fa-tv:before{content:"\\f26c"}.fa-shrimp:before{content:"\\e448"}.fa-list-check:before,.fa-tasks:before{content:"\\f0ae"}.fa-jug-detergent:before{content:"\\e519"}.fa-circle-user:before,.fa-user-circle:before{content:"\\f2bd"}.fa-user-shield:before{content:"\\f505"}.fa-wind:before{content:"\\f72e"}.fa-car-burst:before,.fa-car-crash:before{content:"\\f5e1"}.fa-y:before{content:"\\59"}.fa-person-snowboarding:before,.fa-snowboarding:before{content:"\\f7ce"}.fa-shipping-fast:before,.fa-truck-fast:before{content:"\\f48b"}.fa-fish:before{content:"\\f578"}.fa-user-graduate:before{content:"\\f501"}.fa-adjust:before,.fa-circle-half-stroke:before{content:"\\f042"}.fa-clapperboard:before{content:"\\e131"}.fa-circle-radiation:before,.fa-radiation-alt:before{content:"\\f7ba"}.fa-baseball-ball:before,.fa-baseball:before{content:"\\f433"}.fa-jet-fighter-up:before{content:"\\e518"}.fa-diagram-project:before,.fa-project-diagram:before{content:"\\f542"}.fa-copy:before{content:"\\f0c5"}.fa-volume-mute:before,.fa-volume-times:before,.fa-volume-xmark:before{content:"\\f6a9"}.fa-hand-sparkles:before{content:"\\e05d"}.fa-grip-horizontal:before,.fa-grip:before{content:"\\f58d"}.fa-share-from-square:before,.fa-share-square:before{content:"\\f14d"}.fa-child-combatant:before,.fa-child-rifle:before{content:"\\e4e0"}.fa-gun:before{content:"\\e19b"}.fa-phone-square:before,.fa-square-phone:before{content:"\\f098"}.fa-add:before,.fa-plus:before{content:"\\2b"}.fa-expand:before{content:"\\f065"}.fa-computer:before{content:"\\e4e5"}.fa-close:before,.fa-multiply:before,.fa-remove:before,.fa-times:before,.fa-xmark:before{content:"\\f00d"}.fa-arrows-up-down-left-right:before,.fa-arrows:before{content:"\\f047"}.fa-chalkboard-teacher:before,.fa-chalkboard-user:before{content:"\\f51c"}.fa-peso-sign:before{content:"\\e222"}.fa-building-shield:before{content:"\\e4d8"}.fa-baby:before{content:"\\f77c"}.fa-users-line:before{content:"\\e592"}.fa-quote-left-alt:before,.fa-quote-left:before{content:"\\f10d"}.fa-tractor:before{content:"\\f722"}.fa-trash-arrow-up:before,.fa-trash-restore:before{content:"\\f829"}.fa-arrow-down-up-lock:before{content:"\\e4b0"}.fa-lines-leaning:before{content:"\\e51e"}.fa-ruler-combined:before{content:"\\f546"}.fa-copyright:before{content:"\\f1f9"}.fa-equals:before{content:"\\3d"}.fa-blender:before{content:"\\f517"}.fa-teeth:before{content:"\\f62e"}.fa-ils:before,.fa-shekel-sign:before,.fa-shekel:before,.fa-sheqel-sign:before,.fa-sheqel:before{content:"\\f20b"}.fa-map:before{content:"\\f279"}.fa-rocket:before{content:"\\f135"}.fa-photo-film:before,.fa-photo-video:before{content:"\\f87c"}.fa-folder-minus:before{content:"\\f65d"}.fa-store:before{content:"\\f54e"}.fa-arrow-trend-up:before{content:"\\e098"}.fa-plug-circle-minus:before{content:"\\e55e"}.fa-sign-hanging:before,.fa-sign:before{content:"\\f4d9"}.fa-bezier-curve:before{content:"\\f55b"}.fa-bell-slash:before{content:"\\f1f6"}.fa-tablet-android:before,.fa-tablet:before{content:"\\f3fb"}.fa-school-flag:before{content:"\\e56e"}.fa-fill:before{content:"\\f575"}.fa-angle-up:before{content:"\\f106"}.fa-drumstick-bite:before{content:"\\f6d7"}.fa-holly-berry:before{content:"\\f7aa"}.fa-chevron-left:before{content:"\\f053"}.fa-bacteria:before{content:"\\e059"}.fa-hand-lizard:before{content:"\\f258"}.fa-notdef:before{content:"\\e1fe"}.fa-disease:before{content:"\\f7fa"}.fa-briefcase-medical:before{content:"\\f469"}.fa-genderless:before{content:"\\f22d"}.fa-chevron-right:before{content:"\\f054"}.fa-retweet:before{content:"\\f079"}.fa-car-alt:before,.fa-car-rear:before{content:"\\f5de"}.fa-pump-soap:before{content:"\\e06b"}.fa-video-slash:before{content:"\\f4e2"}.fa-battery-2:before,.fa-battery-quarter:before{content:"\\f243"}.fa-radio:before{content:"\\f8d7"}.fa-baby-carriage:before,.fa-carriage-baby:before{content:"\\f77d"}.fa-traffic-light:before{content:"\\f637"}.fa-thermometer:before{content:"\\f491"}.fa-vr-cardboard:before{content:"\\f729"}.fa-hand-middle-finger:before{content:"\\f806"}.fa-percent:before,.fa-percentage:before{content:"\\25"}.fa-truck-moving:before{content:"\\f4df"}.fa-glass-water-droplet:before{content:"\\e4f5"}.fa-display:before{content:"\\e163"}.fa-face-smile:before,.fa-smile:before{content:"\\f118"}.fa-thumb-tack:before,.fa-thumbtack:before{content:"\\f08d"}.fa-trophy:before{content:"\\f091"}.fa-person-praying:before,.fa-pray:before{content:"\\f683"}.fa-hammer:before{content:"\\f6e3"}.fa-hand-peace:before{content:"\\f25b"}.fa-rotate:before,.fa-sync-alt:before{content:"\\f2f1"}.fa-spinner:before{content:"\\f110"}.fa-robot:before{content:"\\f544"}.fa-peace:before{content:"\\f67c"}.fa-cogs:before,.fa-gears:before{content:"\\f085"}.fa-warehouse:before{content:"\\f494"}.fa-arrow-up-right-dots:before{content:"\\e4b7"}.fa-splotch:before{content:"\\f5bc"}.fa-face-grin-hearts:before,.fa-grin-hearts:before{content:"\\f584"}.fa-dice-four:before{content:"\\f524"}.fa-sim-card:before{content:"\\f7c4"}.fa-transgender-alt:before,.fa-transgender:before{content:"\\f225"}.fa-mercury:before{content:"\\f223"}.fa-arrow-turn-down:before,.fa-level-down:before{content:"\\f149"}.fa-person-falling-burst:before{content:"\\e547"}.fa-award:before{content:"\\f559"}.fa-ticket-alt:before,.fa-ticket-simple:before{content:"\\f3ff"}.fa-building:before{content:"\\f1ad"}.fa-angle-double-left:before,.fa-angles-left:before{content:"\\f100"}.fa-qrcode:before{content:"\\f029"}.fa-clock-rotate-left:before,.fa-history:before{content:"\\f1da"}.fa-face-grin-beam-sweat:before,.fa-grin-beam-sweat:before{content:"\\f583"}.fa-arrow-right-from-file:before,.fa-file-export:before{content:"\\f56e"}.fa-shield-blank:before,.fa-shield:before{content:"\\f132"}.fa-arrow-up-short-wide:before,.fa-sort-amount-up-alt:before{content:"\\f885"}.fa-house-medical:before{content:"\\e3b2"}.fa-golf-ball-tee:before,.fa-golf-ball:before{content:"\\f450"}.fa-chevron-circle-left:before,.fa-circle-chevron-left:before{content:"\\f137"}.fa-house-chimney-window:before{content:"\\e00d"}.fa-pen-nib:before{content:"\\f5ad"}.fa-tent-arrow-turn-left:before{content:"\\e580"}.fa-tents:before{content:"\\e582"}.fa-magic:before,.fa-wand-magic:before{content:"\\f0d0"}.fa-dog:before{content:"\\f6d3"}.fa-carrot:before{content:"\\f787"}.fa-moon:before{content:"\\f186"}.fa-wine-glass-alt:before,.fa-wine-glass-empty:before{content:"\\f5ce"}.fa-cheese:before{content:"\\f7ef"}.fa-yin-yang:before{content:"\\f6ad"}.fa-music:before{content:"\\f001"}.fa-code-commit:before{content:"\\f386"}.fa-temperature-low:before{content:"\\f76b"}.fa-biking:before,.fa-person-biking:before{content:"\\f84a"}.fa-broom:before{content:"\\f51a"}.fa-shield-heart:before{content:"\\e574"}.fa-gopuram:before{content:"\\f664"}.fa-earth-oceania:before,.fa-globe-oceania:before{content:"\\e47b"}.fa-square-xmark:before,.fa-times-square:before,.fa-xmark-square:before{content:"\\f2d3"}.fa-hashtag:before{content:"\\23"}.fa-expand-alt:before,.fa-up-right-and-down-left-from-center:before{content:"\\f424"}.fa-oil-can:before{content:"\\f613"}.fa-t:before{content:"\\54"}.fa-hippo:before{content:"\\f6ed"}.fa-chart-column:before{content:"\\e0e3"}.fa-infinity:before{content:"\\f534"}.fa-vial-circle-check:before{content:"\\e596"}.fa-person-arrow-down-to-line:before{content:"\\e538"}.fa-voicemail:before{content:"\\f897"}.fa-fan:before{content:"\\f863"}.fa-person-walking-luggage:before{content:"\\e554"}.fa-arrows-alt-v:before,.fa-up-down:before{content:"\\f338"}.fa-cloud-moon-rain:before{content:"\\f73c"}.fa-calendar:before{content:"\\f133"}.fa-trailer:before{content:"\\e041"}.fa-bahai:before,.fa-haykal:before{content:"\\f666"}.fa-sd-card:before{content:"\\f7c2"}.fa-dragon:before{content:"\\f6d5"}.fa-shoe-prints:before{content:"\\f54b"}.fa-circle-plus:before,.fa-plus-circle:before{content:"\\f055"}.fa-face-grin-tongue-wink:before,.fa-grin-tongue-wink:before{content:"\\f58b"}.fa-hand-holding:before{content:"\\f4bd"}.fa-plug-circle-exclamation:before{content:"\\e55d"}.fa-chain-broken:before,.fa-chain-slash:before,.fa-link-slash:before,.fa-unlink:before{content:"\\f127"}.fa-clone:before{content:"\\f24d"}.fa-person-walking-arrow-loop-left:before{content:"\\e551"}.fa-arrow-up-z-a:before,.fa-sort-alpha-up-alt:before{content:"\\f882"}.fa-fire-alt:before,.fa-fire-flame-curved:before{content:"\\f7e4"}.fa-tornado:before{content:"\\f76f"}.fa-file-circle-plus:before{content:"\\e494"}.fa-book-quran:before,.fa-quran:before{content:"\\f687"}.fa-anchor:before{content:"\\f13d"}.fa-border-all:before{content:"\\f84c"}.fa-angry:before,.fa-face-angry:before{content:"\\f556"}.fa-cookie-bite:before{content:"\\f564"}.fa-arrow-trend-down:before{content:"\\e097"}.fa-feed:before,.fa-rss:before{content:"\\f09e"}.fa-draw-polygon:before{content:"\\f5ee"}.fa-balance-scale:before,.fa-scale-balanced:before{content:"\\f24e"}.fa-gauge-simple-high:before,.fa-tachometer-fast:before,.fa-tachometer:before{content:"\\f62a"}.fa-shower:before{content:"\\f2cc"}.fa-desktop-alt:before,.fa-desktop:before{content:"\\f390"}.fa-m:before{content:"\\4d"}.fa-table-list:before,.fa-th-list:before{content:"\\f00b"}.fa-comment-sms:before,.fa-sms:before{content:"\\f7cd"}.fa-book:before{content:"\\f02d"}.fa-user-plus:before{content:"\\f234"}.fa-check:before{content:"\\f00c"}.fa-battery-4:before,.fa-battery-three-quarters:before{content:"\\f241"}.fa-house-circle-check:before{content:"\\e509"}.fa-angle-left:before{content:"\\f104"}.fa-diagram-successor:before{content:"\\e47a"}.fa-truck-arrow-right:before{content:"\\e58b"}.fa-arrows-split-up-and-left:before{content:"\\e4bc"}.fa-fist-raised:before,.fa-hand-fist:before{content:"\\f6de"}.fa-cloud-moon:before{content:"\\f6c3"}.fa-briefcase:before{content:"\\f0b1"}.fa-person-falling:before{content:"\\e546"}.fa-image-portrait:before,.fa-portrait:before{content:"\\f3e0"}.fa-user-tag:before{content:"\\f507"}.fa-rug:before{content:"\\e569"}.fa-earth-europe:before,.fa-globe-europe:before{content:"\\f7a2"}.fa-cart-flatbed-suitcase:before,.fa-luggage-cart:before{content:"\\f59d"}.fa-rectangle-times:before,.fa-rectangle-xmark:before,.fa-times-rectangle:before,.fa-window-close:before{content:"\\f410"}.fa-baht-sign:before{content:"\\e0ac"}.fa-book-open:before{content:"\\f518"}.fa-book-journal-whills:before,.fa-journal-whills:before{content:"\\f66a"}.fa-handcuffs:before{content:"\\e4f8"}.fa-exclamation-triangle:before,.fa-triangle-exclamation:before,.fa-warning:before{content:"\\f071"}.fa-database:before{content:"\\f1c0"}.fa-mail-forward:before,.fa-share:before{content:"\\f064"}.fa-bottle-droplet:before{content:"\\e4c4"}.fa-mask-face:before{content:"\\e1d7"}.fa-hill-rockslide:before{content:"\\e508"}.fa-exchange-alt:before,.fa-right-left:before{content:"\\f362"}.fa-paper-plane:before{content:"\\f1d8"}.fa-road-circle-exclamation:before{content:"\\e565"}.fa-dungeon:before{content:"\\f6d9"}.fa-align-right:before{content:"\\f038"}.fa-money-bill-1-wave:before,.fa-money-bill-wave-alt:before{content:"\\f53b"}.fa-life-ring:before{content:"\\f1cd"}.fa-hands:before,.fa-sign-language:before,.fa-signing:before{content:"\\f2a7"}.fa-calendar-day:before{content:"\\f783"}.fa-ladder-water:before,.fa-swimming-pool:before,.fa-water-ladder:before{content:"\\f5c5"}.fa-arrows-up-down:before,.fa-arrows-v:before{content:"\\f07d"}.fa-face-grimace:before,.fa-grimace:before{content:"\\f57f"}.fa-wheelchair-alt:before,.fa-wheelchair-move:before{content:"\\e2ce"}.fa-level-down-alt:before,.fa-turn-down:before{content:"\\f3be"}.fa-person-walking-arrow-right:before{content:"\\e552"}.fa-envelope-square:before,.fa-square-envelope:before{content:"\\f199"}.fa-dice:before{content:"\\f522"}.fa-bowling-ball:before{content:"\\f436"}.fa-brain:before{content:"\\f5dc"}.fa-band-aid:before,.fa-bandage:before{content:"\\f462"}.fa-calendar-minus:before{content:"\\f272"}.fa-circle-xmark:before,.fa-times-circle:before,.fa-xmark-circle:before{content:"\\f057"}.fa-gifts:before{content:"\\f79c"}.fa-hotel:before{content:"\\f594"}.fa-earth-asia:before,.fa-globe-asia:before{content:"\\f57e"}.fa-id-card-alt:before,.fa-id-card-clip:before{content:"\\f47f"}.fa-magnifying-glass-plus:before,.fa-search-plus:before{content:"\\f00e"}.fa-thumbs-up:before{content:"\\f164"}.fa-user-clock:before{content:"\\f4fd"}.fa-allergies:before,.fa-hand-dots:before{content:"\\f461"}.fa-file-invoice:before{content:"\\f570"}.fa-window-minimize:before{content:"\\f2d1"}.fa-coffee:before,.fa-mug-saucer:before{content:"\\f0f4"}.fa-brush:before{content:"\\f55d"}.fa-mask:before{content:"\\f6fa"}.fa-magnifying-glass-minus:before,.fa-search-minus:before{content:"\\f010"}.fa-ruler-vertical:before{content:"\\f548"}.fa-user-alt:before,.fa-user-large:before{content:"\\f406"}.fa-train-tram:before{content:"\\e5b4"}.fa-user-nurse:before{content:"\\f82f"}.fa-syringe:before{content:"\\f48e"}.fa-cloud-sun:before{content:"\\f6c4"}.fa-stopwatch-20:before{content:"\\e06f"}.fa-square-full:before{content:"\\f45c"}.fa-magnet:before{content:"\\f076"}.fa-jar:before{content:"\\e516"}.fa-note-sticky:before,.fa-sticky-note:before{content:"\\f249"}.fa-bug-slash:before{content:"\\e490"}.fa-arrow-up-from-water-pump:before{content:"\\e4b6"}.fa-bone:before{content:"\\f5d7"}.fa-table-cells-row-unlock:before{content:"\\e691"}.fa-user-injured:before{content:"\\f728"}.fa-face-sad-tear:before,.fa-sad-tear:before{content:"\\f5b4"}.fa-plane:before{content:"\\f072"}.fa-tent-arrows-down:before{content:"\\e581"}.fa-exclamation:before{content:"\\21"}.fa-arrows-spin:before{content:"\\e4bb"}.fa-print:before{content:"\\f02f"}.fa-try:before,.fa-turkish-lira-sign:before,.fa-turkish-lira:before{content:"\\e2bb"}.fa-dollar-sign:before,.fa-dollar:before,.fa-usd:before{content:"\\24"}.fa-x:before{content:"\\58"}.fa-magnifying-glass-dollar:before,.fa-search-dollar:before{content:"\\f688"}.fa-users-cog:before,.fa-users-gear:before{content:"\\f509"}.fa-person-military-pointing:before{content:"\\e54a"}.fa-bank:before,.fa-building-columns:before,.fa-institution:before,.fa-museum:before,.fa-university:before{content:"\\f19c"}.fa-umbrella:before{content:"\\f0e9"}.fa-trowel:before{content:"\\e589"}.fa-d:before{content:"\\44"}.fa-stapler:before{content:"\\e5af"}.fa-masks-theater:before,.fa-theater-masks:before{content:"\\f630"}.fa-kip-sign:before{content:"\\e1c4"}.fa-hand-point-left:before{content:"\\f0a5"}.fa-handshake-alt:before,.fa-handshake-simple:before{content:"\\f4c6"}.fa-fighter-jet:before,.fa-jet-fighter:before{content:"\\f0fb"}.fa-share-alt-square:before,.fa-square-share-nodes:before{content:"\\f1e1"}.fa-barcode:before{content:"\\f02a"}.fa-plus-minus:before{content:"\\e43c"}.fa-video-camera:before,.fa-video:before{content:"\\f03d"}.fa-graduation-cap:before,.fa-mortar-board:before{content:"\\f19d"}.fa-hand-holding-medical:before{content:"\\e05c"}.fa-person-circle-check:before{content:"\\e53e"}.fa-level-up-alt:before,.fa-turn-up:before{content:"\\f3bf"}.fa-sr-only,.fa-sr-only-focusable:not(:focus),.sr-only,.sr-only-focusable:not(:focus){height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;width:1px;clip:rect(0,0,0,0);border-width:0;white-space:nowrap}:host,:root{--fa-style-family-brands:"Font Awesome 6 Brands";--fa-font-brands:normal 400 1em/1 "Font Awesome 6 Brands"}@font-face{font-display:block;font-family:Font Awesome\\ 6 Brands;font-style:normal;font-weight:400;src:url(' + buildAssetsURL("fa-brands-400.O7nZalfM.woff2") + ') format("woff2"),url(' + buildAssetsURL("fa-brands-400.Dur5g48u.ttf") + ') format("truetype")}.fa-brands,.fab{font-weight:400}.fa-monero:before{content:"\\f3d0"}.fa-hooli:before{content:"\\f427"}.fa-yelp:before{content:"\\f1e9"}.fa-cc-visa:before{content:"\\f1f0"}.fa-lastfm:before{content:"\\f202"}.fa-shopware:before{content:"\\f5b5"}.fa-creative-commons-nc:before{content:"\\f4e8"}.fa-aws:before{content:"\\f375"}.fa-redhat:before{content:"\\f7bc"}.fa-yoast:before{content:"\\f2b1"}.fa-cloudflare:before{content:"\\e07d"}.fa-ups:before{content:"\\f7e0"}.fa-pixiv:before{content:"\\e640"}.fa-wpexplorer:before{content:"\\f2de"}.fa-dyalog:before{content:"\\f399"}.fa-bity:before{content:"\\f37a"}.fa-stackpath:before{content:"\\f842"}.fa-buysellads:before{content:"\\f20d"}.fa-first-order:before{content:"\\f2b0"}.fa-modx:before{content:"\\f285"}.fa-guilded:before{content:"\\e07e"}.fa-vnv:before{content:"\\f40b"}.fa-js-square:before,.fa-square-js:before{content:"\\f3b9"}.fa-microsoft:before{content:"\\f3ca"}.fa-qq:before{content:"\\f1d6"}.fa-orcid:before{content:"\\f8d2"}.fa-java:before{content:"\\f4e4"}.fa-invision:before{content:"\\f7b0"}.fa-creative-commons-pd-alt:before{content:"\\f4ed"}.fa-centercode:before{content:"\\f380"}.fa-glide-g:before{content:"\\f2a6"}.fa-drupal:before{content:"\\f1a9"}.fa-jxl:before{content:"\\e67b"}.fa-dart-lang:before{content:"\\e693"}.fa-hire-a-helper:before{content:"\\f3b0"}.fa-creative-commons-by:before{content:"\\f4e7"}.fa-unity:before{content:"\\e049"}.fa-whmcs:before{content:"\\f40d"}.fa-rocketchat:before{content:"\\f3e8"}.fa-vk:before{content:"\\f189"}.fa-untappd:before{content:"\\f405"}.fa-mailchimp:before{content:"\\f59e"}.fa-css3-alt:before{content:"\\f38b"}.fa-reddit-square:before,.fa-square-reddit:before{content:"\\f1a2"}.fa-vimeo-v:before{content:"\\f27d"}.fa-contao:before{content:"\\f26d"}.fa-square-font-awesome:before{content:"\\e5ad"}.fa-deskpro:before{content:"\\f38f"}.fa-brave:before{content:"\\e63c"}.fa-sistrix:before{content:"\\f3ee"}.fa-instagram-square:before,.fa-square-instagram:before{content:"\\e055"}.fa-battle-net:before{content:"\\f835"}.fa-the-red-yeti:before{content:"\\f69d"}.fa-hacker-news-square:before,.fa-square-hacker-news:before{content:"\\f3af"}.fa-edge:before{content:"\\f282"}.fa-threads:before{content:"\\e618"}.fa-napster:before{content:"\\f3d2"}.fa-snapchat-square:before,.fa-square-snapchat:before{content:"\\f2ad"}.fa-google-plus-g:before{content:"\\f0d5"}.fa-artstation:before{content:"\\f77a"}.fa-markdown:before{content:"\\f60f"}.fa-sourcetree:before{content:"\\f7d3"}.fa-google-plus:before{content:"\\f2b3"}.fa-diaspora:before{content:"\\f791"}.fa-foursquare:before{content:"\\f180"}.fa-stack-overflow:before{content:"\\f16c"}.fa-github-alt:before{content:"\\f113"}.fa-phoenix-squadron:before{content:"\\f511"}.fa-pagelines:before{content:"\\f18c"}.fa-algolia:before{content:"\\f36c"}.fa-red-river:before{content:"\\f3e3"}.fa-creative-commons-sa:before{content:"\\f4ef"}.fa-safari:before{content:"\\f267"}.fa-google:before{content:"\\f1a0"}.fa-font-awesome-alt:before,.fa-square-font-awesome-stroke:before{content:"\\f35c"}.fa-atlassian:before{content:"\\f77b"}.fa-linkedin-in:before{content:"\\f0e1"}.fa-digital-ocean:before{content:"\\f391"}.fa-nimblr:before{content:"\\f5a8"}.fa-chromecast:before{content:"\\f838"}.fa-evernote:before{content:"\\f839"}.fa-hacker-news:before{content:"\\f1d4"}.fa-creative-commons-sampling:before{content:"\\f4f0"}.fa-adversal:before{content:"\\f36a"}.fa-creative-commons:before{content:"\\f25e"}.fa-watchman-monitoring:before{content:"\\e087"}.fa-fonticons:before{content:"\\f280"}.fa-weixin:before{content:"\\f1d7"}.fa-shirtsinbulk:before{content:"\\f214"}.fa-codepen:before{content:"\\f1cb"}.fa-git-alt:before{content:"\\f841"}.fa-lyft:before{content:"\\f3c3"}.fa-rev:before{content:"\\f5b2"}.fa-windows:before{content:"\\f17a"}.fa-wizards-of-the-coast:before{content:"\\f730"}.fa-square-viadeo:before,.fa-viadeo-square:before{content:"\\f2aa"}.fa-meetup:before{content:"\\f2e0"}.fa-centos:before{content:"\\f789"}.fa-adn:before{content:"\\f170"}.fa-cloudsmith:before{content:"\\f384"}.fa-opensuse:before{content:"\\e62b"}.fa-pied-piper-alt:before{content:"\\f1a8"}.fa-dribbble-square:before,.fa-square-dribbble:before{content:"\\f397"}.fa-codiepie:before{content:"\\f284"}.fa-node:before{content:"\\f419"}.fa-mix:before{content:"\\f3cb"}.fa-steam:before{content:"\\f1b6"}.fa-cc-apple-pay:before{content:"\\f416"}.fa-scribd:before{content:"\\f28a"}.fa-debian:before{content:"\\e60b"}.fa-openid:before{content:"\\f19b"}.fa-instalod:before{content:"\\e081"}.fa-expeditedssl:before{content:"\\f23e"}.fa-sellcast:before{content:"\\f2da"}.fa-square-twitter:before,.fa-twitter-square:before{content:"\\f081"}.fa-r-project:before{content:"\\f4f7"}.fa-delicious:before{content:"\\f1a5"}.fa-freebsd:before{content:"\\f3a4"}.fa-vuejs:before{content:"\\f41f"}.fa-accusoft:before{content:"\\f369"}.fa-ioxhost:before{content:"\\f208"}.fa-fonticons-fi:before{content:"\\f3a2"}.fa-app-store:before{content:"\\f36f"}.fa-cc-mastercard:before{content:"\\f1f1"}.fa-itunes-note:before{content:"\\f3b5"}.fa-golang:before{content:"\\e40f"}.fa-kickstarter:before,.fa-square-kickstarter:before{content:"\\f3bb"}.fa-grav:before{content:"\\f2d6"}.fa-weibo:before{content:"\\f18a"}.fa-uncharted:before{content:"\\e084"}.fa-firstdraft:before{content:"\\f3a1"}.fa-square-youtube:before,.fa-youtube-square:before{content:"\\f431"}.fa-wikipedia-w:before{content:"\\f266"}.fa-rendact:before,.fa-wpressr:before{content:"\\f3e4"}.fa-angellist:before{content:"\\f209"}.fa-galactic-republic:before{content:"\\f50c"}.fa-nfc-directional:before{content:"\\e530"}.fa-skype:before{content:"\\f17e"}.fa-joget:before{content:"\\f3b7"}.fa-fedora:before{content:"\\f798"}.fa-stripe-s:before{content:"\\f42a"}.fa-meta:before{content:"\\e49b"}.fa-laravel:before{content:"\\f3bd"}.fa-hotjar:before{content:"\\f3b1"}.fa-bluetooth-b:before{content:"\\f294"}.fa-square-letterboxd:before{content:"\\e62e"}.fa-sticker-mule:before{content:"\\f3f7"}.fa-creative-commons-zero:before{content:"\\f4f3"}.fa-hips:before{content:"\\f452"}.fa-behance:before{content:"\\f1b4"}.fa-reddit:before{content:"\\f1a1"}.fa-discord:before{content:"\\f392"}.fa-chrome:before{content:"\\f268"}.fa-app-store-ios:before{content:"\\f370"}.fa-cc-discover:before{content:"\\f1f2"}.fa-wpbeginner:before{content:"\\f297"}.fa-confluence:before{content:"\\f78d"}.fa-shoelace:before{content:"\\e60c"}.fa-mdb:before{content:"\\f8ca"}.fa-dochub:before{content:"\\f394"}.fa-accessible-icon:before{content:"\\f368"}.fa-ebay:before{content:"\\f4f4"}.fa-amazon:before{content:"\\f270"}.fa-unsplash:before{content:"\\e07c"}.fa-yarn:before{content:"\\f7e3"}.fa-square-steam:before,.fa-steam-square:before{content:"\\f1b7"}.fa-500px:before{content:"\\f26e"}.fa-square-vimeo:before,.fa-vimeo-square:before{content:"\\f194"}.fa-asymmetrik:before{content:"\\f372"}.fa-font-awesome-flag:before,.fa-font-awesome-logo-full:before,.fa-font-awesome:before{content:"\\f2b4"}.fa-gratipay:before{content:"\\f184"}.fa-apple:before{content:"\\f179"}.fa-hive:before{content:"\\e07f"}.fa-gitkraken:before{content:"\\f3a6"}.fa-keybase:before{content:"\\f4f5"}.fa-apple-pay:before{content:"\\f415"}.fa-padlet:before{content:"\\e4a0"}.fa-amazon-pay:before{content:"\\f42c"}.fa-github-square:before,.fa-square-github:before{content:"\\f092"}.fa-stumbleupon:before{content:"\\f1a4"}.fa-fedex:before{content:"\\f797"}.fa-phoenix-framework:before{content:"\\f3dc"}.fa-shopify:before{content:"\\e057"}.fa-neos:before{content:"\\f612"}.fa-square-threads:before{content:"\\e619"}.fa-hackerrank:before{content:"\\f5f7"}.fa-researchgate:before{content:"\\f4f8"}.fa-swift:before{content:"\\f8e1"}.fa-angular:before{content:"\\f420"}.fa-speakap:before{content:"\\f3f3"}.fa-angrycreative:before{content:"\\f36e"}.fa-y-combinator:before{content:"\\f23b"}.fa-empire:before{content:"\\f1d1"}.fa-envira:before{content:"\\f299"}.fa-google-scholar:before{content:"\\e63b"}.fa-gitlab-square:before,.fa-square-gitlab:before{content:"\\e5ae"}.fa-studiovinari:before{content:"\\f3f8"}.fa-pied-piper:before{content:"\\f2ae"}.fa-wordpress:before{content:"\\f19a"}.fa-product-hunt:before{content:"\\f288"}.fa-firefox:before{content:"\\f269"}.fa-linode:before{content:"\\f2b8"}.fa-goodreads:before{content:"\\f3a8"}.fa-odnoklassniki-square:before,.fa-square-odnoklassniki:before{content:"\\f264"}.fa-jsfiddle:before{content:"\\f1cc"}.fa-sith:before{content:"\\f512"}.fa-themeisle:before{content:"\\f2b2"}.fa-page4:before{content:"\\f3d7"}.fa-hashnode:before{content:"\\e499"}.fa-react:before{content:"\\f41b"}.fa-cc-paypal:before{content:"\\f1f4"}.fa-squarespace:before{content:"\\f5be"}.fa-cc-stripe:before{content:"\\f1f5"}.fa-creative-commons-share:before{content:"\\f4f2"}.fa-bitcoin:before{content:"\\f379"}.fa-keycdn:before{content:"\\f3ba"}.fa-opera:before{content:"\\f26a"}.fa-itch-io:before{content:"\\f83a"}.fa-umbraco:before{content:"\\f8e8"}.fa-galactic-senate:before{content:"\\f50d"}.fa-ubuntu:before{content:"\\f7df"}.fa-draft2digital:before{content:"\\f396"}.fa-stripe:before{content:"\\f429"}.fa-houzz:before{content:"\\f27c"}.fa-gg:before{content:"\\f260"}.fa-dhl:before{content:"\\f790"}.fa-pinterest-square:before,.fa-square-pinterest:before{content:"\\f0d3"}.fa-xing:before{content:"\\f168"}.fa-blackberry:before{content:"\\f37b"}.fa-creative-commons-pd:before{content:"\\f4ec"}.fa-playstation:before{content:"\\f3df"}.fa-quinscape:before{content:"\\f459"}.fa-less:before{content:"\\f41d"}.fa-blogger-b:before{content:"\\f37d"}.fa-opencart:before{content:"\\f23d"}.fa-vine:before{content:"\\f1ca"}.fa-signal-messenger:before{content:"\\e663"}.fa-paypal:before{content:"\\f1ed"}.fa-gitlab:before{content:"\\f296"}.fa-typo3:before{content:"\\f42b"}.fa-reddit-alien:before{content:"\\f281"}.fa-yahoo:before{content:"\\f19e"}.fa-dailymotion:before{content:"\\e052"}.fa-affiliatetheme:before{content:"\\f36b"}.fa-pied-piper-pp:before{content:"\\f1a7"}.fa-bootstrap:before{content:"\\f836"}.fa-odnoklassniki:before{content:"\\f263"}.fa-nfc-symbol:before{content:"\\e531"}.fa-mintbit:before{content:"\\e62f"}.fa-ethereum:before{content:"\\f42e"}.fa-speaker-deck:before{content:"\\f83c"}.fa-creative-commons-nc-eu:before{content:"\\f4e9"}.fa-patreon:before{content:"\\f3d9"}.fa-avianex:before{content:"\\f374"}.fa-ello:before{content:"\\f5f1"}.fa-gofore:before{content:"\\f3a7"}.fa-bimobject:before{content:"\\f378"}.fa-brave-reverse:before{content:"\\e63d"}.fa-facebook-f:before{content:"\\f39e"}.fa-google-plus-square:before,.fa-square-google-plus:before{content:"\\f0d4"}.fa-web-awesome:before{content:"\\e682"}.fa-mandalorian:before{content:"\\f50f"}.fa-first-order-alt:before{content:"\\f50a"}.fa-osi:before{content:"\\f41a"}.fa-google-wallet:before{content:"\\f1ee"}.fa-d-and-d-beyond:before{content:"\\f6ca"}.fa-periscope:before{content:"\\f3da"}.fa-fulcrum:before{content:"\\f50b"}.fa-cloudscale:before{content:"\\f383"}.fa-forumbee:before{content:"\\f211"}.fa-mizuni:before{content:"\\f3cc"}.fa-schlix:before{content:"\\f3ea"}.fa-square-xing:before,.fa-xing-square:before{content:"\\f169"}.fa-bandcamp:before{content:"\\f2d5"}.fa-wpforms:before{content:"\\f298"}.fa-cloudversify:before{content:"\\f385"}.fa-usps:before{content:"\\f7e1"}.fa-megaport:before{content:"\\f5a3"}.fa-magento:before{content:"\\f3c4"}.fa-spotify:before{content:"\\f1bc"}.fa-optin-monster:before{content:"\\f23c"}.fa-fly:before{content:"\\f417"}.fa-aviato:before{content:"\\f421"}.fa-itunes:before{content:"\\f3b4"}.fa-cuttlefish:before{content:"\\f38c"}.fa-blogger:before{content:"\\f37c"}.fa-flickr:before{content:"\\f16e"}.fa-viber:before{content:"\\f409"}.fa-soundcloud:before{content:"\\f1be"}.fa-digg:before{content:"\\f1a6"}.fa-tencent-weibo:before{content:"\\f1d5"}.fa-letterboxd:before{content:"\\e62d"}.fa-symfony:before{content:"\\f83d"}.fa-maxcdn:before{content:"\\f136"}.fa-etsy:before{content:"\\f2d7"}.fa-facebook-messenger:before{content:"\\f39f"}.fa-audible:before{content:"\\f373"}.fa-think-peaks:before{content:"\\f731"}.fa-bilibili:before{content:"\\e3d9"}.fa-erlang:before{content:"\\f39d"}.fa-x-twitter:before{content:"\\e61b"}.fa-cotton-bureau:before{content:"\\f89e"}.fa-dashcube:before{content:"\\f210"}.fa-42-group:before,.fa-innosoft:before{content:"\\e080"}.fa-stack-exchange:before{content:"\\f18d"}.fa-elementor:before{content:"\\f430"}.fa-pied-piper-square:before,.fa-square-pied-piper:before{content:"\\e01e"}.fa-creative-commons-nd:before{content:"\\f4eb"}.fa-palfed:before{content:"\\f3d8"}.fa-superpowers:before{content:"\\f2dd"}.fa-resolving:before{content:"\\f3e7"}.fa-xbox:before{content:"\\f412"}.fa-square-web-awesome-stroke:before{content:"\\e684"}.fa-searchengin:before{content:"\\f3eb"}.fa-tiktok:before{content:"\\e07b"}.fa-facebook-square:before,.fa-square-facebook:before{content:"\\f082"}.fa-renren:before{content:"\\f18b"}.fa-linux:before{content:"\\f17c"}.fa-glide:before{content:"\\f2a5"}.fa-linkedin:before{content:"\\f08c"}.fa-hubspot:before{content:"\\f3b2"}.fa-deploydog:before{content:"\\f38e"}.fa-twitch:before{content:"\\f1e8"}.fa-flutter:before{content:"\\e694"}.fa-ravelry:before{content:"\\f2d9"}.fa-mixer:before{content:"\\e056"}.fa-lastfm-square:before,.fa-square-lastfm:before{content:"\\f203"}.fa-vimeo:before{content:"\\f40a"}.fa-mendeley:before{content:"\\f7b3"}.fa-uniregistry:before{content:"\\f404"}.fa-figma:before{content:"\\f799"}.fa-creative-commons-remix:before{content:"\\f4ee"}.fa-cc-amazon-pay:before{content:"\\f42d"}.fa-dropbox:before{content:"\\f16b"}.fa-instagram:before{content:"\\f16d"}.fa-cmplid:before{content:"\\e360"}.fa-upwork:before{content:"\\e641"}.fa-facebook:before{content:"\\f09a"}.fa-gripfire:before{content:"\\f3ac"}.fa-jedi-order:before{content:"\\f50e"}.fa-uikit:before{content:"\\f403"}.fa-fort-awesome-alt:before{content:"\\f3a3"}.fa-phabricator:before{content:"\\f3db"}.fa-ussunnah:before{content:"\\f407"}.fa-earlybirds:before{content:"\\f39a"}.fa-trade-federation:before{content:"\\f513"}.fa-autoprefixer:before{content:"\\f41c"}.fa-whatsapp:before{content:"\\f232"}.fa-square-upwork:before{content:"\\e67c"}.fa-slideshare:before{content:"\\f1e7"}.fa-google-play:before{content:"\\f3ab"}.fa-viadeo:before{content:"\\f2a9"}.fa-line:before{content:"\\f3c0"}.fa-google-drive:before{content:"\\f3aa"}.fa-servicestack:before{content:"\\f3ec"}.fa-simplybuilt:before{content:"\\f215"}.fa-bitbucket:before{content:"\\f171"}.fa-imdb:before{content:"\\f2d8"}.fa-deezer:before{content:"\\e077"}.fa-raspberry-pi:before{content:"\\f7bb"}.fa-jira:before{content:"\\f7b1"}.fa-docker:before{content:"\\f395"}.fa-screenpal:before{content:"\\e570"}.fa-bluetooth:before{content:"\\f293"}.fa-gitter:before{content:"\\f426"}.fa-d-and-d:before{content:"\\f38d"}.fa-microblog:before{content:"\\e01a"}.fa-cc-diners-club:before{content:"\\f24c"}.fa-gg-circle:before{content:"\\f261"}.fa-pied-piper-hat:before{content:"\\f4e5"}.fa-kickstarter-k:before{content:"\\f3bc"}.fa-yandex:before{content:"\\f413"}.fa-readme:before{content:"\\f4d5"}.fa-html5:before{content:"\\f13b"}.fa-sellsy:before{content:"\\f213"}.fa-square-web-awesome:before{content:"\\e683"}.fa-sass:before{content:"\\f41e"}.fa-wirsindhandwerk:before,.fa-wsh:before{content:"\\e2d0"}.fa-buromobelexperte:before{content:"\\f37f"}.fa-salesforce:before{content:"\\f83b"}.fa-octopus-deploy:before{content:"\\e082"}.fa-medapps:before{content:"\\f3c6"}.fa-ns8:before{content:"\\f3d5"}.fa-pinterest-p:before{content:"\\f231"}.fa-apper:before{content:"\\f371"}.fa-fort-awesome:before{content:"\\f286"}.fa-waze:before{content:"\\f83f"}.fa-bluesky:before{content:"\\e671"}.fa-cc-jcb:before{content:"\\f24b"}.fa-snapchat-ghost:before,.fa-snapchat:before{content:"\\f2ab"}.fa-fantasy-flight-games:before{content:"\\f6dc"}.fa-rust:before{content:"\\e07a"}.fa-wix:before{content:"\\f5cf"}.fa-behance-square:before,.fa-square-behance:before{content:"\\f1b5"}.fa-supple:before{content:"\\f3f9"}.fa-webflow:before{content:"\\e65c"}.fa-rebel:before{content:"\\f1d0"}.fa-css3:before{content:"\\f13c"}.fa-staylinked:before{content:"\\f3f5"}.fa-kaggle:before{content:"\\f5fa"}.fa-space-awesome:before{content:"\\e5ac"}.fa-deviantart:before{content:"\\f1bd"}.fa-cpanel:before{content:"\\f388"}.fa-goodreads-g:before{content:"\\f3a9"}.fa-git-square:before,.fa-square-git:before{content:"\\f1d2"}.fa-square-tumblr:before,.fa-tumblr-square:before{content:"\\f174"}.fa-trello:before{content:"\\f181"}.fa-creative-commons-nc-jp:before{content:"\\f4ea"}.fa-get-pocket:before{content:"\\f265"}.fa-perbyte:before{content:"\\e083"}.fa-grunt:before{content:"\\f3ad"}.fa-weebly:before{content:"\\f5cc"}.fa-connectdevelop:before{content:"\\f20e"}.fa-leanpub:before{content:"\\f212"}.fa-black-tie:before{content:"\\f27e"}.fa-themeco:before{content:"\\f5c6"}.fa-python:before{content:"\\f3e2"}.fa-android:before{content:"\\f17b"}.fa-bots:before{content:"\\e340"}.fa-free-code-camp:before{content:"\\f2c5"}.fa-hornbill:before{content:"\\f592"}.fa-js:before{content:"\\f3b8"}.fa-ideal:before{content:"\\e013"}.fa-git:before{content:"\\f1d3"}.fa-dev:before{content:"\\f6cc"}.fa-sketch:before{content:"\\f7c6"}.fa-yandex-international:before{content:"\\f414"}.fa-cc-amex:before{content:"\\f1f3"}.fa-uber:before{content:"\\f402"}.fa-github:before{content:"\\f09b"}.fa-php:before{content:"\\f457"}.fa-alipay:before{content:"\\f642"}.fa-youtube:before{content:"\\f167"}.fa-skyatlas:before{content:"\\f216"}.fa-firefox-browser:before{content:"\\e007"}.fa-replyd:before{content:"\\f3e6"}.fa-suse:before{content:"\\f7d6"}.fa-jenkins:before{content:"\\f3b6"}.fa-twitter:before{content:"\\f099"}.fa-rockrms:before{content:"\\f3e9"}.fa-pinterest:before{content:"\\f0d2"}.fa-buffer:before{content:"\\f837"}.fa-npm:before{content:"\\f3d4"}.fa-yammer:before{content:"\\f840"}.fa-btc:before{content:"\\f15a"}.fa-dribbble:before{content:"\\f17d"}.fa-stumbleupon-circle:before{content:"\\f1a3"}.fa-internet-explorer:before{content:"\\f26b"}.fa-stubber:before{content:"\\e5c7"}.fa-telegram-plane:before,.fa-telegram:before{content:"\\f2c6"}.fa-old-republic:before{content:"\\f510"}.fa-odysee:before{content:"\\e5c6"}.fa-square-whatsapp:before,.fa-whatsapp-square:before{content:"\\f40c"}.fa-node-js:before{content:"\\f3d3"}.fa-edge-legacy:before{content:"\\e078"}.fa-slack-hash:before,.fa-slack:before{content:"\\f198"}.fa-medrt:before{content:"\\f3c8"}.fa-usb:before{content:"\\f287"}.fa-tumblr:before{content:"\\f173"}.fa-vaadin:before{content:"\\f408"}.fa-quora:before{content:"\\f2c4"}.fa-square-x-twitter:before{content:"\\e61a"}.fa-reacteurope:before{content:"\\f75d"}.fa-medium-m:before,.fa-medium:before{content:"\\f23a"}.fa-amilia:before{content:"\\f36d"}.fa-mixcloud:before{content:"\\f289"}.fa-flipboard:before{content:"\\f44d"}.fa-viacoin:before{content:"\\f237"}.fa-critical-role:before{content:"\\f6c9"}.fa-sitrox:before{content:"\\e44a"}.fa-discourse:before{content:"\\f393"}.fa-joomla:before{content:"\\f1aa"}.fa-mastodon:before{content:"\\f4f6"}.fa-airbnb:before{content:"\\f834"}.fa-wolf-pack-battalion:before{content:"\\f514"}.fa-buy-n-large:before{content:"\\f8a6"}.fa-gulp:before{content:"\\f3ae"}.fa-creative-commons-sampling-plus:before{content:"\\f4f1"}.fa-strava:before{content:"\\f428"}.fa-ember:before{content:"\\f423"}.fa-canadian-maple-leaf:before{content:"\\f785"}.fa-teamspeak:before{content:"\\f4f9"}.fa-pushed:before{content:"\\f3e1"}.fa-wordpress-simple:before{content:"\\f411"}.fa-nutritionix:before{content:"\\f3d6"}.fa-wodu:before{content:"\\e088"}.fa-google-pay:before{content:"\\e079"}.fa-intercom:before{content:"\\f7af"}.fa-zhihu:before{content:"\\f63f"}.fa-korvue:before{content:"\\f42f"}.fa-pix:before{content:"\\e43a"}.fa-steam-symbol:before{content:"\\f3f6"}:host,:root{--fa-font-regular:normal 400 1em/1 "Font Awesome 6 Free"}@font-face{font-display:block;font-family:Font Awesome\\ 6 Free;font-style:normal;font-weight:400;src:url(' + buildAssetsURL("fa-regular-400.DgEfZSYE.woff2") + ') format("woff2"),url(' + buildAssetsURL("fa-regular-400.Bf3rG5Nx.ttf") + ') format("truetype")}.fa-regular,.far{font-weight:400}:host,:root{--fa-style-family-classic:"Font Awesome 6 Free";--fa-font-solid:normal 900 1em/1 "Font Awesome 6 Free"}@font-face{font-display:block;font-family:Font Awesome\\ 6 Free;font-style:normal;font-weight:900;src:url(' + buildAssetsURL("fa-solid-900.DOQJEhcS.woff2") + ') format("woff2"),url(' + buildAssetsURL("fa-solid-900.BV3CbEM2.ttf") + ') format("truetype")}.fa-solid,.fas{font-weight:900}@font-face{font-display:block;font-family:Font Awesome\\ 5 Brands;font-weight:400;src:url(' + buildAssetsURL("fa-brands-400.O7nZalfM.woff2") + ') format("woff2"),url(' + buildAssetsURL("fa-brands-400.Dur5g48u.ttf") + ') format("truetype")}@font-face{font-display:block;font-family:Font Awesome\\ 5 Free;font-weight:900;src:url(' + buildAssetsURL("fa-solid-900.DOQJEhcS.woff2") + ') format("woff2"),url(' + buildAssetsURL("fa-solid-900.BV3CbEM2.ttf") + ') format("truetype")}@font-face{font-display:block;font-family:Font Awesome\\ 5 Free;font-weight:400;src:url(' + buildAssetsURL("fa-regular-400.DgEfZSYE.woff2") + ') format("woff2"),url(' + buildAssetsURL("fa-regular-400.Bf3rG5Nx.ttf") + ') format("truetype")}@font-face{font-display:block;font-family:FontAwesome;src:url(' + buildAssetsURL("fa-solid-900.DOQJEhcS.woff2") + ') format("woff2"),url(' + buildAssetsURL("fa-solid-900.BV3CbEM2.ttf") + ') format("truetype")}@font-face{font-display:block;font-family:FontAwesome;src:url(' + buildAssetsURL("fa-brands-400.O7nZalfM.woff2") + ') format("woff2"),url(' + buildAssetsURL("fa-brands-400.Dur5g48u.ttf") + ') format("truetype")}@font-face{font-display:block;font-family:FontAwesome;src:url(' + buildAssetsURL("fa-regular-400.DgEfZSYE.woff2") + ') format("woff2"),url(' + buildAssetsURL("fa-regular-400.Bf3rG5Nx.ttf") + ') format("truetype");unicode-range:u+f003,u+f006,u+f014,u+f016-f017,u+f01a-f01b,u+f01d,u+f022,u+f03e,u+f044,u+f046,u+f05c-f05d,u+f06e,u+f070,u+f087-f088,u+f08a,u+f094,u+f096-f097,u+f09d,u+f0a0,u+f0a2,u+f0a4-f0a7,u+f0c5,u+f0c7,u+f0e5-f0e6,u+f0eb,u+f0f6-f0f8,u+f10c,u+f114-f115,u+f118-f11a,u+f11c-f11d,u+f133,u+f147,u+f14e,u+f150-f152,u+f185-f186,u+f18e,u+f190-f192,u+f196,u+f1c1-f1c9,u+f1d9,u+f1db,u+f1e3,u+f1ea,u+f1f7,u+f1f9,u+f20a,u+f247-f248,u+f24a,u+f24d,u+f255-f25b,u+f25d,u+f271-f274,u+f278,u+f27b,u+f28c,u+f28e,u+f29c,u+f2b5,u+f2b7,u+f2ba,u+f2bc,u+f2be,u+f2c0-f2c1,u+f2c3,u+f2d0,u+f2d2,u+f2d4,u+f2dc}@font-face{font-display:block;font-family:FontAwesome;src:url(' + buildAssetsURL("fa-v4compatibility.BX8XWJtE.woff2") + ') format("woff2"),url(' + buildAssetsURL("fa-v4compatibility.B9MWI-E6.ttf") + `) format("truetype");unicode-range:u+f041,u+f047,u+f065-f066,u+f07d-f07e,u+f080,u+f08b,u+f08e,u+f090,u+f09a,u+f0ac,u+f0ae,u+f0b2,u+f0d0,u+f0d6,u+f0e4,u+f0ec,u+f10a-f10b,u+f123,u+f13e,u+f148-f149,u+f14c,u+f156,u+f15e,u+f160-f161,u+f163,u+f175-f178,u+f195,u+f1f8,u+f219,u+f27a}:root,[data-bs-theme=light]{--bs-blue:#0d6efd;--bs-indigo:#6610f2;--bs-purple:#6f42c1;--bs-pink:#d63384;--bs-red:#dc3545;--bs-orange:#fd7e14;--bs-yellow:#ffc107;--bs-green:#198754;--bs-teal:#20c997;--bs-cyan:#0dcaf0;--bs-black:#000;--bs-white:#fff;--bs-gray:#6c757d;--bs-gray-dark:#343a40;--bs-gray-100:#f8f9fa;--bs-gray-200:#e9ecef;--bs-gray-300:#dee2e6;--bs-gray-400:#ced4da;--bs-gray-500:#adb5bd;--bs-gray-600:#6c757d;--bs-gray-700:#495057;--bs-gray-800:#343a40;--bs-gray-900:#212529;--bs-primary:#3c83eb;--bs-secondary:#6c757d;--bs-success:#198754;--bs-info:#0dcaf0;--bs-warning:#ffc107;--bs-danger:#dc3545;--bs-light:#f8f9fa;--bs-dark:#212529;--bs-primary-rgb:60,131,235;--bs-secondary-rgb:108,117,125;--bs-success-rgb:25,135,84;--bs-info-rgb:13,202,240;--bs-warning-rgb:255,193,7;--bs-danger-rgb:220,53,69;--bs-light-rgb:248,249,250;--bs-dark-rgb:33,37,41;--bs-primary-text-emphasis:#18345e;--bs-secondary-text-emphasis:#2b2f32;--bs-success-text-emphasis:#0a3622;--bs-info-text-emphasis:#055160;--bs-warning-text-emphasis:#664d03;--bs-danger-text-emphasis:#58151c;--bs-light-text-emphasis:#495057;--bs-dark-text-emphasis:#495057;--bs-primary-bg-subtle:#d8e6fb;--bs-secondary-bg-subtle:#e2e3e5;--bs-success-bg-subtle:#d1e7dd;--bs-info-bg-subtle:#cff4fc;--bs-warning-bg-subtle:#fff3cd;--bs-danger-bg-subtle:#f8d7da;--bs-light-bg-subtle:#fcfcfd;--bs-dark-bg-subtle:#ced4da;--bs-primary-border-subtle:#b1cdf7;--bs-secondary-border-subtle:#c4c8cb;--bs-success-border-subtle:#a3cfbb;--bs-info-border-subtle:#9eeaf9;--bs-warning-border-subtle:#ffe69c;--bs-danger-border-subtle:#f1aeb5;--bs-light-border-subtle:#e9ecef;--bs-dark-border-subtle:#adb5bd;--bs-white-rgb:255,255,255;--bs-black-rgb:0,0,0;--bs-font-sans-serif:system-ui,-apple-system,"Segoe UI",Roboto,"Helvetica Neue","Noto Sans","Liberation Sans",Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol","Noto Color Emoji";--bs-font-monospace:SFMono-Regular,Menlo,Monaco,Consolas,"Liberation Mono","Courier New",monospace;--bs-gradient:linear-gradient(180deg,hsla(0,0%,100%,.15),hsla(0,0%,100%,0));--bs-body-font-family:var(--bs-font-sans-serif);--bs-body-font-size:1rem;--bs-body-font-weight:400;--bs-body-line-height:1.5;--bs-body-color:#212529;--bs-body-color-rgb:33,37,41;--bs-body-bg:#fff;--bs-body-bg-rgb:255,255,255;--bs-emphasis-color:#000;--bs-emphasis-color-rgb:0,0,0;--bs-secondary-color:rgba(33,37,41,.75);--bs-secondary-color-rgb:33,37,41;--bs-secondary-bg:#e9ecef;--bs-secondary-bg-rgb:233,236,239;--bs-tertiary-color:rgba(33,37,41,.5);--bs-tertiary-color-rgb:33,37,41;--bs-tertiary-bg:#f8f9fa;--bs-tertiary-bg-rgb:248,249,250;--bs-heading-color:inherit;--bs-link-color:#3c83eb;--bs-link-color-rgb:60,131,235;--bs-link-decoration:underline;--bs-link-hover-color:#3069bc;--bs-link-hover-color-rgb:48,105,188;--bs-code-color:#d63384;--bs-highlight-color:#212529;--bs-highlight-bg:#fff3cd;--bs-border-width:1px;--bs-border-style:solid;--bs-border-color:#dee2e6;--bs-border-color-translucent:rgba(0,0,0,.175);--bs-border-radius:0.375rem;--bs-border-radius-sm:0.25rem;--bs-border-radius-lg:0.5rem;--bs-border-radius-xl:1rem;--bs-border-radius-xxl:2rem;--bs-border-radius-2xl:var(--bs-border-radius-xxl);--bs-border-radius-pill:50rem;--bs-box-shadow:0 0.5rem 1rem rgba(0,0,0,.15);--bs-box-shadow-sm:0 0.125rem 0.25rem rgba(0,0,0,.075);--bs-box-shadow-lg:0 1rem 3rem rgba(0,0,0,.175);--bs-box-shadow-inset:inset 0 1px 2px rgba(0,0,0,.075);--bs-focus-ring-width:0.25rem;--bs-focus-ring-opacity:0.25;--bs-focus-ring-color:rgba(60,131,235,.25);--bs-form-valid-color:#198754;--bs-form-valid-border-color:#198754;--bs-form-invalid-color:#dc3545;--bs-form-invalid-border-color:#dc3545}[data-bs-theme=dark]{color-scheme:dark;--bs-body-color:#dee2e6;--bs-body-color-rgb:222,226,230;--bs-body-bg:#212529;--bs-body-bg-rgb:33,37,41;--bs-emphasis-color:#fff;--bs-emphasis-color-rgb:255,255,255;--bs-secondary-color:rgba(222,226,230,.75);--bs-secondary-color-rgb:222,226,230;--bs-secondary-bg:#343a40;--bs-secondary-bg-rgb:52,58,64;--bs-tertiary-color:rgba(222,226,230,.5);--bs-tertiary-color-rgb:222,226,230;--bs-tertiary-bg:#2b3035;--bs-tertiary-bg-rgb:43,48,53;--bs-primary-text-emphasis:#8ab5f3;--bs-secondary-text-emphasis:#a7acb1;--bs-success-text-emphasis:#75b798;--bs-info-text-emphasis:#6edff6;--bs-warning-text-emphasis:#ffda6a;--bs-danger-text-emphasis:#ea868f;--bs-light-text-emphasis:#f8f9fa;--bs-dark-text-emphasis:#dee2e6;--bs-primary-bg-subtle:#0c1a2f;--bs-secondary-bg-subtle:#161719;--bs-success-bg-subtle:#051b11;--bs-info-bg-subtle:#032830;--bs-warning-bg-subtle:#332701;--bs-danger-bg-subtle:#2c0b0e;--bs-light-bg-subtle:#343a40;--bs-dark-bg-subtle:#1a1d20;--bs-primary-border-subtle:#244f8d;--bs-secondary-border-subtle:#41464b;--bs-success-border-subtle:#0f5132;--bs-info-border-subtle:#087990;--bs-warning-border-subtle:#997404;--bs-danger-border-subtle:#842029;--bs-light-border-subtle:#495057;--bs-dark-border-subtle:#343a40;--bs-heading-color:inherit;--bs-link-color:#8ab5f3;--bs-link-hover-color:#a1c4f5;--bs-link-color-rgb:138,181,243;--bs-link-hover-color-rgb:161,196,245;--bs-code-color:#e685b5;--bs-highlight-color:#dee2e6;--bs-highlight-bg:#664d03;--bs-border-color:#495057;--bs-border-color-translucent:hsla(0,0%,100%,.15);--bs-form-valid-color:#75b798;--bs-form-valid-border-color:#75b798;--bs-form-invalid-color:#ea868f;--bs-form-invalid-border-color:#ea868f}*,:after,:before{box-sizing:border-box}@media (prefers-reduced-motion:no-preference){:root{scroll-behavior:smooth}}body{background-color:var(--bs-body-bg);color:var(--bs-body-color);font-family:var(--bs-body-font-family);font-size:var(--bs-body-font-size);font-weight:var(--bs-body-font-weight);line-height:var(--bs-body-line-height);margin:0;text-align:var(--bs-body-text-align);-webkit-text-size-adjust:100%;-webkit-tap-highlight-color:rgba(0,0,0,0)}hr{border:0;border-top:var(--bs-border-width) solid;color:inherit;margin:1rem 0;opacity:.25}.h1,.h2,.h3,.h4,.h5,.h6,h1,h2,h3,h4,h5,h6{color:var(--bs-heading-color);font-weight:500;line-height:1.2;margin-bottom:.5rem;margin-top:0}.h1,h1{font-size:calc(1.375rem + 1.5vw)}@media (min-width:1200px){.h1,h1{font-size:2.5rem}}.h2,h2{font-size:calc(1.325rem + .9vw)}@media (min-width:1200px){.h2,h2{font-size:2rem}}.h3,h3{font-size:calc(1.3rem + .6vw)}@media (min-width:1200px){.h3,h3{font-size:1.75rem}}.h4,h4{font-size:calc(1.275rem + .3vw)}@media (min-width:1200px){.h4,h4{font-size:1.5rem}}.h5,h5{font-size:1.25rem}.h6,h6{font-size:1rem}p{margin-bottom:1rem;margin-top:0}abbr[title]{cursor:help;-webkit-text-decoration:underline dotted;text-decoration:underline dotted;-webkit-text-decoration-skip-ink:none;text-decoration-skip-ink:none}address{font-style:normal;line-height:inherit;margin-bottom:1rem}ol,ul{padding-left:2rem}dl,ol,ul{margin-bottom:1rem;margin-top:0}ol ol,ol ul,ul ol,ul ul{margin-bottom:0}dt{font-weight:700}dd{margin-bottom:.5rem;margin-left:0}blockquote{margin:0 0 1rem}b,strong{font-weight:bolder}.small,small{font-size:.875em}.mark,mark{background-color:var(--bs-highlight-bg);color:var(--bs-highlight-color);padding:.1875em}sub,sup{font-size:.75em;line-height:0;position:relative;vertical-align:baseline}sub{bottom:-.25em}sup{top:-.5em}a{color:rgba(var(--bs-link-color-rgb),var(--bs-link-opacity,1));text-decoration:underline}a:hover{--bs-link-color-rgb:var(--bs-link-hover-color-rgb)}a:not([href]):not([class]),a:not([href]):not([class]):hover{color:inherit;text-decoration:none}code,kbd,pre,samp{font-family:var(--bs-font-monospace);font-size:1em}pre{display:block;font-size:.875em;margin-bottom:1rem;margin-top:0;overflow:auto}pre code{color:inherit;font-size:inherit;word-break:normal}code{color:var(--bs-code-color);font-size:.875em;word-wrap:break-word}a>code{color:inherit}kbd{background-color:var(--bs-body-color);border-radius:.25rem;color:var(--bs-body-bg);font-size:.875em;padding:.1875rem .375rem}kbd kbd{font-size:1em;padding:0}figure{margin:0 0 1rem}img,svg{vertical-align:middle}table{border-collapse:collapse;caption-side:bottom}caption{color:var(--bs-secondary-color);padding-bottom:.5rem;padding-top:.5rem;text-align:left}th{text-align:inherit;text-align:-webkit-match-parent}tbody,td,tfoot,th,thead,tr{border:0 solid;border-color:inherit}label{display:inline-block}button{border-radius:0}button:focus:not(:focus-visible){outline:0}button,input,optgroup,select,textarea{font-family:inherit;font-size:inherit;line-height:inherit;margin:0}button,select{text-transform:none}[role=button]{cursor:pointer}select{word-wrap:normal}select:disabled{opacity:1}[list]:not([type=date]):not([type=datetime-local]):not([type=month]):not([type=week]):not([type=time])::-webkit-calendar-picker-indicator{display:none!important}[type=button],[type=reset],[type=submit],button{-webkit-appearance:button}[type=button]:not(:disabled),[type=reset]:not(:disabled),[type=submit]:not(:disabled),button:not(:disabled){cursor:pointer}::-moz-focus-inner{border-style:none;padding:0}textarea{resize:vertical}fieldset{border:0;margin:0;min-width:0;padding:0}legend{float:left;font-size:calc(1.275rem + .3vw);line-height:inherit;margin-bottom:.5rem;padding:0;width:100%}@media (min-width:1200px){legend{font-size:1.5rem}}legend+*{clear:left}::-webkit-datetime-edit-day-field,::-webkit-datetime-edit-fields-wrapper,::-webkit-datetime-edit-hour-field,::-webkit-datetime-edit-minute,::-webkit-datetime-edit-month-field,::-webkit-datetime-edit-text,::-webkit-datetime-edit-year-field{padding:0}::-webkit-inner-spin-button{height:auto}[type=search]{-webkit-appearance:textfield;outline-offset:-2px}::-webkit-search-decoration{-webkit-appearance:none}::-webkit-color-swatch-wrapper{padding:0}::file-selector-button{-webkit-appearance:button;font:inherit}output{display:inline-block}iframe{border:0}summary{cursor:pointer;display:list-item}progress{vertical-align:baseline}[hidden]{display:none!important}.lead{font-size:1.25rem;font-weight:300}.display-1{font-size:calc(1.625rem + 4.5vw);font-weight:300;line-height:1.2}@media (min-width:1200px){.display-1{font-size:5rem}}.display-2{font-size:calc(1.575rem + 3.9vw);font-weight:300;line-height:1.2}@media (min-width:1200px){.display-2{font-size:4.5rem}}.display-3{font-size:calc(1.525rem + 3.3vw);font-weight:300;line-height:1.2}@media (min-width:1200px){.display-3{font-size:4rem}}.display-4{font-size:calc(1.475rem + 2.7vw);font-weight:300;line-height:1.2}@media (min-width:1200px){.display-4{font-size:3.5rem}}.display-5{font-size:calc(1.425rem + 2.1vw);font-weight:300;line-height:1.2}@media (min-width:1200px){.display-5{font-size:3rem}}.display-6{font-size:calc(1.375rem + 1.5vw);font-weight:300;line-height:1.2}@media (min-width:1200px){.display-6{font-size:2.5rem}}.list-inline,.list-unstyled{list-style:none;padding-left:0}.list-inline-item{display:inline-block}.list-inline-item:not(:last-child){margin-right:.5rem}.initialism{font-size:.875em;text-transform:uppercase}.blockquote{font-size:1.25rem;margin-bottom:1rem}.blockquote>:last-child{margin-bottom:0}.blockquote-footer{color:#6c757d;font-size:.875em;margin-bottom:1rem;margin-top:-1rem}.blockquote-footer:before{content:"\u2014\xA0"}.img-fluid,.img-thumbnail{height:auto;max-width:100%}.img-thumbnail{background-color:var(--bs-body-bg);border:var(--bs-border-width) solid var(--bs-border-color);border-radius:var(--bs-border-radius);padding:.25rem}.figure{display:inline-block}.figure-img{line-height:1;margin-bottom:.5rem}.figure-caption{color:var(--bs-secondary-color);font-size:.875em}.container,.container-fluid,.container-lg,.container-md,.container-sm,.container-xl,.container-xxl{--bs-gutter-x:1.5rem;--bs-gutter-y:0;margin-left:auto;margin-right:auto;padding-left:calc(var(--bs-gutter-x)*.5);padding-right:calc(var(--bs-gutter-x)*.5);width:100%}@media (min-width:576px){.container,.container-sm{max-width:540px}}@media (min-width:768px){.container,.container-md,.container-sm{max-width:720px}}@media (min-width:992px){.container,.container-lg,.container-md,.container-sm{max-width:960px}}@media (min-width:1200px){.container,.container-lg,.container-md,.container-sm,.container-xl{max-width:1140px}}@media (min-width:1400px){.container,.container-lg,.container-md,.container-sm,.container-xl,.container-xxl{max-width:1320px}}:root{--bs-breakpoint-xs:0;--bs-breakpoint-sm:576px;--bs-breakpoint-md:768px;--bs-breakpoint-lg:992px;--bs-breakpoint-xl:1200px;--bs-breakpoint-xxl:1400px}.row{--bs-gutter-x:1.5rem;--bs-gutter-y:0;display:flex;flex-wrap:wrap;margin-left:calc(var(--bs-gutter-x)*-.5);margin-right:calc(var(--bs-gutter-x)*-.5);margin-top:calc(var(--bs-gutter-y)*-1)}.row>*{flex-shrink:0;margin-top:var(--bs-gutter-y);max-width:100%;padding-left:calc(var(--bs-gutter-x)*.5);padding-right:calc(var(--bs-gutter-x)*.5);width:100%}.col{flex:1 0 0%}.row-cols-auto>*{flex:0 0 auto;width:auto}.row-cols-1>*{flex:0 0 auto;width:100%}.row-cols-2>*{flex:0 0 auto;width:50%}.row-cols-3>*{flex:0 0 auto;width:33.33333333%}.row-cols-4>*{flex:0 0 auto;width:25%}.row-cols-5>*{flex:0 0 auto;width:20%}.row-cols-6>*{flex:0 0 auto;width:16.66666667%}.col-auto{flex:0 0 auto;width:auto}.col-1{flex:0 0 auto;width:8.33333333%}.col-2{flex:0 0 auto;width:16.66666667%}.col-3{flex:0 0 auto;width:25%}.col-4{flex:0 0 auto;width:33.33333333%}.col-5{flex:0 0 auto;width:41.66666667%}.col-6{flex:0 0 auto;width:50%}.col-7{flex:0 0 auto;width:58.33333333%}.col-8{flex:0 0 auto;width:66.66666667%}.col-9{flex:0 0 auto;width:75%}.col-10{flex:0 0 auto;width:83.33333333%}.col-11{flex:0 0 auto;width:91.66666667%}.col-12{flex:0 0 auto;width:100%}.offset-1{margin-left:8.33333333%}.offset-2{margin-left:16.66666667%}.offset-3{margin-left:25%}.offset-4{margin-left:33.33333333%}.offset-5{margin-left:41.66666667%}.offset-6{margin-left:50%}.offset-7{margin-left:58.33333333%}.offset-8{margin-left:66.66666667%}.offset-9{margin-left:75%}.offset-10{margin-left:83.33333333%}.offset-11{margin-left:91.66666667%}.g-0,.gx-0{--bs-gutter-x:0}.g-0,.gy-0{--bs-gutter-y:0}.g-1,.gx-1{--bs-gutter-x:0.25rem}.g-1,.gy-1{--bs-gutter-y:0.25rem}.g-2,.gx-2{--bs-gutter-x:0.5rem}.g-2,.gy-2{--bs-gutter-y:0.5rem}.g-3,.gx-3{--bs-gutter-x:1rem}.g-3,.gy-3{--bs-gutter-y:1rem}.g-4,.gx-4{--bs-gutter-x:1.5rem}.g-4,.gy-4{--bs-gutter-y:1.5rem}.g-5,.gx-5{--bs-gutter-x:3rem}.g-5,.gy-5{--bs-gutter-y:3rem}@media (min-width:576px){.col-sm{flex:1 0 0%}.row-cols-sm-auto>*{flex:0 0 auto;width:auto}.row-cols-sm-1>*{flex:0 0 auto;width:100%}.row-cols-sm-2>*{flex:0 0 auto;width:50%}.row-cols-sm-3>*{flex:0 0 auto;width:33.33333333%}.row-cols-sm-4>*{flex:0 0 auto;width:25%}.row-cols-sm-5>*{flex:0 0 auto;width:20%}.row-cols-sm-6>*{flex:0 0 auto;width:16.66666667%}.col-sm-auto{flex:0 0 auto;width:auto}.col-sm-1{flex:0 0 auto;width:8.33333333%}.col-sm-2{flex:0 0 auto;width:16.66666667%}.col-sm-3{flex:0 0 auto;width:25%}.col-sm-4{flex:0 0 auto;width:33.33333333%}.col-sm-5{flex:0 0 auto;width:41.66666667%}.col-sm-6{flex:0 0 auto;width:50%}.col-sm-7{flex:0 0 auto;width:58.33333333%}.col-sm-8{flex:0 0 auto;width:66.66666667%}.col-sm-9{flex:0 0 auto;width:75%}.col-sm-10{flex:0 0 auto;width:83.33333333%}.col-sm-11{flex:0 0 auto;width:91.66666667%}.col-sm-12{flex:0 0 auto;width:100%}.offset-sm-0{margin-left:0}.offset-sm-1{margin-left:8.33333333%}.offset-sm-2{margin-left:16.66666667%}.offset-sm-3{margin-left:25%}.offset-sm-4{margin-left:33.33333333%}.offset-sm-5{margin-left:41.66666667%}.offset-sm-6{margin-left:50%}.offset-sm-7{margin-left:58.33333333%}.offset-sm-8{margin-left:66.66666667%}.offset-sm-9{margin-left:75%}.offset-sm-10{margin-left:83.33333333%}.offset-sm-11{margin-left:91.66666667%}.g-sm-0,.gx-sm-0{--bs-gutter-x:0}.g-sm-0,.gy-sm-0{--bs-gutter-y:0}.g-sm-1,.gx-sm-1{--bs-gutter-x:0.25rem}.g-sm-1,.gy-sm-1{--bs-gutter-y:0.25rem}.g-sm-2,.gx-sm-2{--bs-gutter-x:0.5rem}.g-sm-2,.gy-sm-2{--bs-gutter-y:0.5rem}.g-sm-3,.gx-sm-3{--bs-gutter-x:1rem}.g-sm-3,.gy-sm-3{--bs-gutter-y:1rem}.g-sm-4,.gx-sm-4{--bs-gutter-x:1.5rem}.g-sm-4,.gy-sm-4{--bs-gutter-y:1.5rem}.g-sm-5,.gx-sm-5{--bs-gutter-x:3rem}.g-sm-5,.gy-sm-5{--bs-gutter-y:3rem}}@media (min-width:768px){.col-md{flex:1 0 0%}.row-cols-md-auto>*{flex:0 0 auto;width:auto}.row-cols-md-1>*{flex:0 0 auto;width:100%}.row-cols-md-2>*{flex:0 0 auto;width:50%}.row-cols-md-3>*{flex:0 0 auto;width:33.33333333%}.row-cols-md-4>*{flex:0 0 auto;width:25%}.row-cols-md-5>*{flex:0 0 auto;width:20%}.row-cols-md-6>*{flex:0 0 auto;width:16.66666667%}.col-md-auto{flex:0 0 auto;width:auto}.col-md-1{flex:0 0 auto;width:8.33333333%}.col-md-2{flex:0 0 auto;width:16.66666667%}.col-md-3{flex:0 0 auto;width:25%}.col-md-4{flex:0 0 auto;width:33.33333333%}.col-md-5{flex:0 0 auto;width:41.66666667%}.col-md-6{flex:0 0 auto;width:50%}.col-md-7{flex:0 0 auto;width:58.33333333%}.col-md-8{flex:0 0 auto;width:66.66666667%}.col-md-9{flex:0 0 auto;width:75%}.col-md-10{flex:0 0 auto;width:83.33333333%}.col-md-11{flex:0 0 auto;width:91.66666667%}.col-md-12{flex:0 0 auto;width:100%}.offset-md-0{margin-left:0}.offset-md-1{margin-left:8.33333333%}.offset-md-2{margin-left:16.66666667%}.offset-md-3{margin-left:25%}.offset-md-4{margin-left:33.33333333%}.offset-md-5{margin-left:41.66666667%}.offset-md-6{margin-left:50%}.offset-md-7{margin-left:58.33333333%}.offset-md-8{margin-left:66.66666667%}.offset-md-9{margin-left:75%}.offset-md-10{margin-left:83.33333333%}.offset-md-11{margin-left:91.66666667%}.g-md-0,.gx-md-0{--bs-gutter-x:0}.g-md-0,.gy-md-0{--bs-gutter-y:0}.g-md-1,.gx-md-1{--bs-gutter-x:0.25rem}.g-md-1,.gy-md-1{--bs-gutter-y:0.25rem}.g-md-2,.gx-md-2{--bs-gutter-x:0.5rem}.g-md-2,.gy-md-2{--bs-gutter-y:0.5rem}.g-md-3,.gx-md-3{--bs-gutter-x:1rem}.g-md-3,.gy-md-3{--bs-gutter-y:1rem}.g-md-4,.gx-md-4{--bs-gutter-x:1.5rem}.g-md-4,.gy-md-4{--bs-gutter-y:1.5rem}.g-md-5,.gx-md-5{--bs-gutter-x:3rem}.g-md-5,.gy-md-5{--bs-gutter-y:3rem}}@media (min-width:992px){.col-lg{flex:1 0 0%}.row-cols-lg-auto>*{flex:0 0 auto;width:auto}.row-cols-lg-1>*{flex:0 0 auto;width:100%}.row-cols-lg-2>*{flex:0 0 auto;width:50%}.row-cols-lg-3>*{flex:0 0 auto;width:33.33333333%}.row-cols-lg-4>*{flex:0 0 auto;width:25%}.row-cols-lg-5>*{flex:0 0 auto;width:20%}.row-cols-lg-6>*{flex:0 0 auto;width:16.66666667%}.col-lg-auto{flex:0 0 auto;width:auto}.col-lg-1{flex:0 0 auto;width:8.33333333%}.col-lg-2{flex:0 0 auto;width:16.66666667%}.col-lg-3{flex:0 0 auto;width:25%}.col-lg-4{flex:0 0 auto;width:33.33333333%}.col-lg-5{flex:0 0 auto;width:41.66666667%}.col-lg-6{flex:0 0 auto;width:50%}.col-lg-7{flex:0 0 auto;width:58.33333333%}.col-lg-8{flex:0 0 auto;width:66.66666667%}.col-lg-9{flex:0 0 auto;width:75%}.col-lg-10{flex:0 0 auto;width:83.33333333%}.col-lg-11{flex:0 0 auto;width:91.66666667%}.col-lg-12{flex:0 0 auto;width:100%}.offset-lg-0{margin-left:0}.offset-lg-1{margin-left:8.33333333%}.offset-lg-2{margin-left:16.66666667%}.offset-lg-3{margin-left:25%}.offset-lg-4{margin-left:33.33333333%}.offset-lg-5{margin-left:41.66666667%}.offset-lg-6{margin-left:50%}.offset-lg-7{margin-left:58.33333333%}.offset-lg-8{margin-left:66.66666667%}.offset-lg-9{margin-left:75%}.offset-lg-10{margin-left:83.33333333%}.offset-lg-11{margin-left:91.66666667%}.g-lg-0,.gx-lg-0{--bs-gutter-x:0}.g-lg-0,.gy-lg-0{--bs-gutter-y:0}.g-lg-1,.gx-lg-1{--bs-gutter-x:0.25rem}.g-lg-1,.gy-lg-1{--bs-gutter-y:0.25rem}.g-lg-2,.gx-lg-2{--bs-gutter-x:0.5rem}.g-lg-2,.gy-lg-2{--bs-gutter-y:0.5rem}.g-lg-3,.gx-lg-3{--bs-gutter-x:1rem}.g-lg-3,.gy-lg-3{--bs-gutter-y:1rem}.g-lg-4,.gx-lg-4{--bs-gutter-x:1.5rem}.g-lg-4,.gy-lg-4{--bs-gutter-y:1.5rem}.g-lg-5,.gx-lg-5{--bs-gutter-x:3rem}.g-lg-5,.gy-lg-5{--bs-gutter-y:3rem}}@media (min-width:1200px){.col-xl{flex:1 0 0%}.row-cols-xl-auto>*{flex:0 0 auto;width:auto}.row-cols-xl-1>*{flex:0 0 auto;width:100%}.row-cols-xl-2>*{flex:0 0 auto;width:50%}.row-cols-xl-3>*{flex:0 0 auto;width:33.33333333%}.row-cols-xl-4>*{flex:0 0 auto;width:25%}.row-cols-xl-5>*{flex:0 0 auto;width:20%}.row-cols-xl-6>*{flex:0 0 auto;width:16.66666667%}.col-xl-auto{flex:0 0 auto;width:auto}.col-xl-1{flex:0 0 auto;width:8.33333333%}.col-xl-2{flex:0 0 auto;width:16.66666667%}.col-xl-3{flex:0 0 auto;width:25%}.col-xl-4{flex:0 0 auto;width:33.33333333%}.col-xl-5{flex:0 0 auto;width:41.66666667%}.col-xl-6{flex:0 0 auto;width:50%}.col-xl-7{flex:0 0 auto;width:58.33333333%}.col-xl-8{flex:0 0 auto;width:66.66666667%}.col-xl-9{flex:0 0 auto;width:75%}.col-xl-10{flex:0 0 auto;width:83.33333333%}.col-xl-11{flex:0 0 auto;width:91.66666667%}.col-xl-12{flex:0 0 auto;width:100%}.offset-xl-0{margin-left:0}.offset-xl-1{margin-left:8.33333333%}.offset-xl-2{margin-left:16.66666667%}.offset-xl-3{margin-left:25%}.offset-xl-4{margin-left:33.33333333%}.offset-xl-5{margin-left:41.66666667%}.offset-xl-6{margin-left:50%}.offset-xl-7{margin-left:58.33333333%}.offset-xl-8{margin-left:66.66666667%}.offset-xl-9{margin-left:75%}.offset-xl-10{margin-left:83.33333333%}.offset-xl-11{margin-left:91.66666667%}.g-xl-0,.gx-xl-0{--bs-gutter-x:0}.g-xl-0,.gy-xl-0{--bs-gutter-y:0}.g-xl-1,.gx-xl-1{--bs-gutter-x:0.25rem}.g-xl-1,.gy-xl-1{--bs-gutter-y:0.25rem}.g-xl-2,.gx-xl-2{--bs-gutter-x:0.5rem}.g-xl-2,.gy-xl-2{--bs-gutter-y:0.5rem}.g-xl-3,.gx-xl-3{--bs-gutter-x:1rem}.g-xl-3,.gy-xl-3{--bs-gutter-y:1rem}.g-xl-4,.gx-xl-4{--bs-gutter-x:1.5rem}.g-xl-4,.gy-xl-4{--bs-gutter-y:1.5rem}.g-xl-5,.gx-xl-5{--bs-gutter-x:3rem}.g-xl-5,.gy-xl-5{--bs-gutter-y:3rem}}@media (min-width:1400px){.col-xxl{flex:1 0 0%}.row-cols-xxl-auto>*{flex:0 0 auto;width:auto}.row-cols-xxl-1>*{flex:0 0 auto;width:100%}.row-cols-xxl-2>*{flex:0 0 auto;width:50%}.row-cols-xxl-3>*{flex:0 0 auto;width:33.33333333%}.row-cols-xxl-4>*{flex:0 0 auto;width:25%}.row-cols-xxl-5>*{flex:0 0 auto;width:20%}.row-cols-xxl-6>*{flex:0 0 auto;width:16.66666667%}.col-xxl-auto{flex:0 0 auto;width:auto}.col-xxl-1{flex:0 0 auto;width:8.33333333%}.col-xxl-2{flex:0 0 auto;width:16.66666667%}.col-xxl-3{flex:0 0 auto;width:25%}.col-xxl-4{flex:0 0 auto;width:33.33333333%}.col-xxl-5{flex:0 0 auto;width:41.66666667%}.col-xxl-6{flex:0 0 auto;width:50%}.col-xxl-7{flex:0 0 auto;width:58.33333333%}.col-xxl-8{flex:0 0 auto;width:66.66666667%}.col-xxl-9{flex:0 0 auto;width:75%}.col-xxl-10{flex:0 0 auto;width:83.33333333%}.col-xxl-11{flex:0 0 auto;width:91.66666667%}.col-xxl-12{flex:0 0 auto;width:100%}.offset-xxl-0{margin-left:0}.offset-xxl-1{margin-left:8.33333333%}.offset-xxl-2{margin-left:16.66666667%}.offset-xxl-3{margin-left:25%}.offset-xxl-4{margin-left:33.33333333%}.offset-xxl-5{margin-left:41.66666667%}.offset-xxl-6{margin-left:50%}.offset-xxl-7{margin-left:58.33333333%}.offset-xxl-8{margin-left:66.66666667%}.offset-xxl-9{margin-left:75%}.offset-xxl-10{margin-left:83.33333333%}.offset-xxl-11{margin-left:91.66666667%}.g-xxl-0,.gx-xxl-0{--bs-gutter-x:0}.g-xxl-0,.gy-xxl-0{--bs-gutter-y:0}.g-xxl-1,.gx-xxl-1{--bs-gutter-x:0.25rem}.g-xxl-1,.gy-xxl-1{--bs-gutter-y:0.25rem}.g-xxl-2,.gx-xxl-2{--bs-gutter-x:0.5rem}.g-xxl-2,.gy-xxl-2{--bs-gutter-y:0.5rem}.g-xxl-3,.gx-xxl-3{--bs-gutter-x:1rem}.g-xxl-3,.gy-xxl-3{--bs-gutter-y:1rem}.g-xxl-4,.gx-xxl-4{--bs-gutter-x:1.5rem}.g-xxl-4,.gy-xxl-4{--bs-gutter-y:1.5rem}.g-xxl-5,.gx-xxl-5{--bs-gutter-x:3rem}.g-xxl-5,.gy-xxl-5{--bs-gutter-y:3rem}}.table{--bs-table-color-type:initial;--bs-table-bg-type:initial;--bs-table-color-state:initial;--bs-table-bg-state:initial;--bs-table-color:var(--bs-emphasis-color);--bs-table-bg:var(--bs-body-bg);--bs-table-border-color:var(--bs-border-color);--bs-table-accent-bg:transparent;--bs-table-striped-color:var(--bs-emphasis-color);--bs-table-striped-bg:rgba(var(--bs-emphasis-color-rgb),0.05);--bs-table-active-color:var(--bs-emphasis-color);--bs-table-active-bg:rgba(var(--bs-emphasis-color-rgb),0.1);--bs-table-hover-color:var(--bs-emphasis-color);--bs-table-hover-bg:rgba(var(--bs-emphasis-color-rgb),0.075);border-color:var(--bs-table-border-color);margin-bottom:1rem;vertical-align:top;width:100%}.table>:not(caption)>*>*{background-color:var(--bs-table-bg);border-bottom-width:var(--bs-border-width);box-shadow:inset 0 0 0 9999px var(--bs-table-bg-state,var(--bs-table-bg-type,var(--bs-table-accent-bg)));color:var(--bs-table-color-state,var(--bs-table-color-type,var(--bs-table-color)));padding:.5rem}.table>tbody{vertical-align:inherit}.table>thead{vertical-align:bottom}.table-group-divider{border-top:calc(var(--bs-border-width)*2) solid}.caption-top{caption-side:top}.table-sm>:not(caption)>*>*{padding:.25rem}.table-bordered>:not(caption)>*{border-width:var(--bs-border-width) 0}.table-bordered>:not(caption)>*>*{border-width:0 var(--bs-border-width)}.table-borderless>:not(caption)>*>*{border-bottom-width:0}.table-borderless>:not(:first-child){border-top-width:0}.table-striped-columns>:not(caption)>tr>:nth-child(2n),.table-striped>tbody>tr:nth-of-type(odd)>*{--bs-table-color-type:var(--bs-table-striped-color);--bs-table-bg-type:var(--bs-table-striped-bg)}.table-active{--bs-table-color-state:var(--bs-table-active-color);--bs-table-bg-state:var(--bs-table-active-bg)}.table-hover>tbody>tr:hover>*{--bs-table-color-state:var(--bs-table-hover-color);--bs-table-bg-state:var(--bs-table-hover-bg)}.table-primary{--bs-table-color:#000;--bs-table-bg:#d8e6fb;--bs-table-border-color:#adb8c9;--bs-table-striped-bg:#cddbee;--bs-table-striped-color:#000;--bs-table-active-bg:#c2cfe2;--bs-table-active-color:#000;--bs-table-hover-bg:#c8d5e8;--bs-table-hover-color:#000}.table-primary,.table-secondary{border-color:var(--bs-table-border-color);color:var(--bs-table-color)}.table-secondary{--bs-table-color:#000;--bs-table-bg:#e2e3e5;--bs-table-border-color:#b5b6b7;--bs-table-striped-bg:#d7d8da;--bs-table-striped-color:#000;--bs-table-active-bg:#cbccce;--bs-table-active-color:#000;--bs-table-hover-bg:#d1d2d4;--bs-table-hover-color:#000}.table-success{--bs-table-color:#000;--bs-table-bg:#d1e7dd;--bs-table-border-color:#a7b9b1;--bs-table-striped-bg:#c7dbd2;--bs-table-striped-color:#000;--bs-table-active-bg:#bcd0c7;--bs-table-active-color:#000;--bs-table-hover-bg:#c1d6cc;--bs-table-hover-color:#000}.table-info,.table-success{border-color:var(--bs-table-border-color);color:var(--bs-table-color)}.table-info{--bs-table-color:#000;--bs-table-bg:#cff4fc;--bs-table-border-color:#a6c3ca;--bs-table-striped-bg:#c5e8ef;--bs-table-striped-color:#000;--bs-table-active-bg:#badce3;--bs-table-active-color:#000;--bs-table-hover-bg:#bfe2e9;--bs-table-hover-color:#000}.table-warning{--bs-table-color:#000;--bs-table-bg:#fff3cd;--bs-table-border-color:#ccc2a4;--bs-table-striped-bg:#f2e7c3;--bs-table-striped-color:#000;--bs-table-active-bg:#e6dbb9;--bs-table-active-color:#000;--bs-table-hover-bg:#ece1be;--bs-table-hover-color:#000}.table-danger,.table-warning{border-color:var(--bs-table-border-color);color:var(--bs-table-color)}.table-danger{--bs-table-color:#000;--bs-table-bg:#f8d7da;--bs-table-border-color:#c6acae;--bs-table-striped-bg:#eccccf;--bs-table-striped-color:#000;--bs-table-active-bg:#dfc2c4;--bs-table-active-color:#000;--bs-table-hover-bg:#e5c7ca;--bs-table-hover-color:#000}.table-light{--bs-table-color:#000;--bs-table-bg:#f8f9fa;--bs-table-border-color:#c6c7c8;--bs-table-striped-bg:#ecedee;--bs-table-striped-color:#000;--bs-table-active-bg:#dfe0e1;--bs-table-active-color:#000;--bs-table-hover-bg:#e5e6e7;--bs-table-hover-color:#000}.table-dark,.table-light{border-color:var(--bs-table-border-color);color:var(--bs-table-color)}.table-dark{--bs-table-color:#fff;--bs-table-bg:#212529;--bs-table-border-color:#4d5154;--bs-table-striped-bg:#2c3034;--bs-table-striped-color:#fff;--bs-table-active-bg:#373b3e;--bs-table-active-color:#fff;--bs-table-hover-bg:#323539;--bs-table-hover-color:#fff}.table-responsive{overflow-x:auto;-webkit-overflow-scrolling:touch}@media (max-width:575.98px){.table-responsive-sm{overflow-x:auto;-webkit-overflow-scrolling:touch}}@media (max-width:767.98px){.table-responsive-md{overflow-x:auto;-webkit-overflow-scrolling:touch}}@media (max-width:991.98px){.table-responsive-lg{overflow-x:auto;-webkit-overflow-scrolling:touch}}@media (max-width:1199.98px){.table-responsive-xl{overflow-x:auto;-webkit-overflow-scrolling:touch}}@media (max-width:1399.98px){.table-responsive-xxl{overflow-x:auto;-webkit-overflow-scrolling:touch}}.form-label{margin-bottom:.5rem}.col-form-label{font-size:inherit;line-height:1.5;margin-bottom:0;padding-bottom:calc(.375rem + var(--bs-border-width));padding-top:calc(.375rem + var(--bs-border-width))}.col-form-label-lg{font-size:1.25rem;padding-bottom:calc(.5rem + var(--bs-border-width));padding-top:calc(.5rem + var(--bs-border-width))}.col-form-label-sm{font-size:.875rem;padding-bottom:calc(.25rem + var(--bs-border-width));padding-top:calc(.25rem + var(--bs-border-width))}.form-text{color:var(--bs-secondary-color);font-size:.875em;margin-top:.25rem}.form-control{-webkit-appearance:none;-moz-appearance:none;appearance:none;background-clip:padding-box;background-color:var(--bs-body-bg);border:var(--bs-border-width) solid var(--bs-border-color);border-radius:var(--bs-border-radius);color:var(--bs-body-color);display:block;font-size:1rem;font-weight:400;line-height:1.5;padding:.375rem .75rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;width:100%}@media (prefers-reduced-motion:reduce){.form-control{transition:none}}.form-control[type=file]{overflow:hidden}.form-control[type=file]:not(:disabled):not([readonly]){cursor:pointer}.form-control:focus{background-color:var(--bs-body-bg);border-color:#9ec1f5;box-shadow:0 0 0 .25rem rgba(60,131,235,.25);color:var(--bs-body-color);outline:0}.form-control::-webkit-date-and-time-value{height:1.5em;margin:0;min-width:85px}.form-control::-webkit-datetime-edit{display:block;padding:0}.form-control::-moz-placeholder{color:var(--bs-secondary-color);opacity:1}.form-control::placeholder{color:var(--bs-secondary-color);opacity:1}.form-control:disabled{background-color:var(--bs-secondary-bg);opacity:1}.form-control::file-selector-button{background-color:var(--bs-tertiary-bg);border:0 solid;border-color:inherit;border-inline-end-width:var(--bs-border-width);border-radius:0;color:var(--bs-body-color);margin:-.375rem -.75rem;margin-inline-end:.75rem;padding:.375rem .75rem;pointer-events:none;transition:color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out}@media (prefers-reduced-motion:reduce){.form-control::file-selector-button{transition:none}}.form-control:hover:not(:disabled):not([readonly])::file-selector-button{background-color:var(--bs-secondary-bg)}.form-control-plaintext{background-color:transparent;border:solid transparent;border-width:var(--bs-border-width) 0;color:var(--bs-body-color);display:block;line-height:1.5;margin-bottom:0;padding:.375rem 0;width:100%}.form-control-plaintext:focus{outline:0}.form-control-plaintext.form-control-lg,.form-control-plaintext.form-control-sm{padding-left:0;padding-right:0}.form-control-sm{border-radius:var(--bs-border-radius-sm);font-size:.875rem;min-height:calc(1.5em + .5rem + var(--bs-border-width)*2);padding:.25rem .5rem}.form-control-sm::file-selector-button{margin:-.25rem -.5rem;margin-inline-end:.5rem;padding:.25rem .5rem}.form-control-lg{border-radius:var(--bs-border-radius-lg);font-size:1.25rem;min-height:calc(1.5em + 1rem + var(--bs-border-width)*2);padding:.5rem 1rem}.form-control-lg::file-selector-button{margin:-.5rem -1rem;margin-inline-end:1rem;padding:.5rem 1rem}textarea.form-control{min-height:calc(1.5em + .75rem + var(--bs-border-width)*2)}textarea.form-control-sm{min-height:calc(1.5em + .5rem + var(--bs-border-width)*2)}textarea.form-control-lg{min-height:calc(1.5em + 1rem + var(--bs-border-width)*2)}.form-control-color{height:calc(1.5em + .75rem + var(--bs-border-width)*2);padding:.375rem;width:3rem}.form-control-color:not(:disabled):not([readonly]){cursor:pointer}.form-control-color::-moz-color-swatch{border:0!important;border-radius:var(--bs-border-radius)}.form-control-color::-webkit-color-swatch{border:0!important;border-radius:var(--bs-border-radius)}.form-control-color.form-control-sm{height:calc(1.5em + .5rem + var(--bs-border-width)*2)}.form-control-color.form-control-lg{height:calc(1.5em + 1rem + var(--bs-border-width)*2)}.form-select{--bs-form-select-bg-img:url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3E%3Cpath fill='none' stroke='%23343a40' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='m2 5 6 6 6-6'/%3E%3C/svg%3E");-webkit-appearance:none;-moz-appearance:none;appearance:none;background-color:var(--bs-body-bg);background-image:var(--bs-form-select-bg-img),var(--bs-form-select-bg-icon,none);background-position:right .75rem center;background-repeat:no-repeat;background-size:16px 12px;border:var(--bs-border-width) solid var(--bs-border-color);border-radius:var(--bs-border-radius);color:var(--bs-body-color);display:block;font-size:1rem;font-weight:400;line-height:1.5;padding:.375rem 2.25rem .375rem .75rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;width:100%}@media (prefers-reduced-motion:reduce){.form-select{transition:none}}.form-select:focus{border-color:#9ec1f5;box-shadow:0 0 0 .25rem rgba(60,131,235,.25);outline:0}.form-select[multiple],.form-select[size]:not([size="1"]){background-image:none;padding-right:.75rem}.form-select:disabled{background-color:var(--bs-secondary-bg)}.form-select:-moz-focusring{color:transparent;text-shadow:0 0 0 var(--bs-body-color)}.form-select-sm{border-radius:var(--bs-border-radius-sm);font-size:.875rem;padding-bottom:.25rem;padding-left:.5rem;padding-top:.25rem}.form-select-lg{border-radius:var(--bs-border-radius-lg);font-size:1.25rem;padding-bottom:.5rem;padding-left:1rem;padding-top:.5rem}[data-bs-theme=dark] .form-select{--bs-form-select-bg-img:url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3E%3Cpath fill='none' stroke='%23dee2e6' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='m2 5 6 6 6-6'/%3E%3C/svg%3E")}.form-check{display:block;margin-bottom:.125rem;min-height:1.5rem;padding-left:1.5em}.form-check .form-check-input{float:left;margin-left:-1.5em}.form-check-reverse{padding-left:0;padding-right:1.5em;text-align:right}.form-check-reverse .form-check-input{float:right;margin-left:0;margin-right:-1.5em}.form-check-input{--bs-form-check-bg:var(--bs-body-bg);-webkit-appearance:none;-moz-appearance:none;appearance:none;background-color:var(--bs-form-check-bg);background-image:var(--bs-form-check-bg-image);background-position:50%;background-repeat:no-repeat;background-size:contain;border:var(--bs-border-width) solid var(--bs-border-color);flex-shrink:0;height:1em;margin-top:.25em;-webkit-print-color-adjust:exact;print-color-adjust:exact;vertical-align:top;width:1em}.form-check-input[type=checkbox]{border-radius:.25em}.form-check-input[type=radio]{border-radius:50%}.form-check-input:active{filter:brightness(90%)}.form-check-input:focus{border-color:#9ec1f5;box-shadow:0 0 0 .25rem rgba(60,131,235,.25);outline:0}.form-check-input:checked{background-color:#3c83eb;border-color:#3c83eb}.form-check-input:checked[type=checkbox]{--bs-form-check-bg-image:url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 20 20'%3E%3Cpath fill='none' stroke='%23fff' stroke-linecap='round' stroke-linejoin='round' stroke-width='3' d='m6 10 3 3 6-6'/%3E%3C/svg%3E")}.form-check-input:checked[type=radio]{--bs-form-check-bg-image:url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='-4 -4 8 8'%3E%3Ccircle r='2' fill='%23fff'/%3E%3C/svg%3E")}.form-check-input[type=checkbox]:indeterminate{background-color:#3c83eb;border-color:#3c83eb;--bs-form-check-bg-image:url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 20 20'%3E%3Cpath fill='none' stroke='%23fff' stroke-linecap='round' stroke-linejoin='round' stroke-width='3' d='M6 10h8'/%3E%3C/svg%3E")}.form-check-input:disabled{filter:none;opacity:.5;pointer-events:none}.form-check-input:disabled~.form-check-label,.form-check-input[disabled]~.form-check-label{cursor:default;opacity:.5}.form-switch{padding-left:2.5em}.form-switch .form-check-input{--bs-form-switch-bg:url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='-4 -4 8 8'%3E%3Ccircle r='3' fill='rgba(0, 0, 0, 0.25)'/%3E%3C/svg%3E");background-image:var(--bs-form-switch-bg);background-position:0;border-radius:2em;margin-left:-2.5em;transition:background-position .15s ease-in-out;width:2em}@media (prefers-reduced-motion:reduce){.form-switch .form-check-input{transition:none}}.form-switch .form-check-input:focus{--bs-form-switch-bg:url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='-4 -4 8 8'%3E%3Ccircle r='3' fill='%239ec1f5'/%3E%3C/svg%3E")}.form-switch .form-check-input:checked{background-position:100%;--bs-form-switch-bg:url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='-4 -4 8 8'%3E%3Ccircle r='3' fill='%23fff'/%3E%3C/svg%3E")}.form-switch.form-check-reverse{padding-left:0;padding-right:2.5em}.form-switch.form-check-reverse .form-check-input{margin-left:0;margin-right:-2.5em}.form-check-inline{display:inline-block;margin-right:1rem}.btn-check{position:absolute;clip:rect(0,0,0,0);pointer-events:none}.btn-check:disabled+.btn,.btn-check[disabled]+.btn{filter:none;opacity:.65;pointer-events:none}[data-bs-theme=dark] .form-switch .form-check-input:not(:checked):not(:focus){--bs-form-switch-bg:url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='-4 -4 8 8'%3E%3Ccircle r='3' fill='rgba(255, 255, 255, 0.25)'/%3E%3C/svg%3E")}.form-range{-webkit-appearance:none;-moz-appearance:none;appearance:none;background-color:transparent;height:1.5rem;padding:0;width:100%}.form-range:focus{outline:0}.form-range:focus::-webkit-slider-thumb{box-shadow:0 0 0 1px #fff,0 0 0 .25rem rgba(60,131,235,.25)}.form-range:focus::-moz-range-thumb{box-shadow:0 0 0 1px #fff,0 0 0 .25rem rgba(60,131,235,.25)}.form-range::-moz-focus-outer{border:0}.form-range::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;background-color:#3c83eb;border:0;border-radius:1rem;height:1rem;margin-top:-.25rem;-webkit-transition:background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;transition:background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;width:1rem}@media (prefers-reduced-motion:reduce){.form-range::-webkit-slider-thumb{-webkit-transition:none;transition:none}}.form-range::-webkit-slider-thumb:active{background-color:#c5daf9}.form-range::-webkit-slider-runnable-track{background-color:var(--bs-secondary-bg);border-color:transparent;border-radius:1rem;color:transparent;cursor:pointer;height:.5rem;width:100%}.form-range::-moz-range-thumb{-moz-appearance:none;appearance:none;background-color:#3c83eb;border:0;border-radius:1rem;height:1rem;-moz-transition:background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;transition:background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;width:1rem}@media (prefers-reduced-motion:reduce){.form-range::-moz-range-thumb{-moz-transition:none;transition:none}}.form-range::-moz-range-thumb:active{background-color:#c5daf9}.form-range::-moz-range-track{background-color:var(--bs-secondary-bg);border-color:transparent;border-radius:1rem;color:transparent;cursor:pointer;height:.5rem;width:100%}.form-range:disabled{pointer-events:none}.form-range:disabled::-webkit-slider-thumb{background-color:var(--bs-secondary-color)}.form-range:disabled::-moz-range-thumb{background-color:var(--bs-secondary-color)}.form-floating{position:relative}.form-floating>.form-control,.form-floating>.form-control-plaintext,.form-floating>.form-select{height:calc(3.5rem + var(--bs-border-width)*2);line-height:1.25;min-height:calc(3.5rem + var(--bs-border-width)*2)}.form-floating>label{border:var(--bs-border-width) solid transparent;height:100%;left:0;overflow:hidden;padding:1rem .75rem;pointer-events:none;position:absolute;text-align:start;text-overflow:ellipsis;top:0;transform-origin:0 0;transition:opacity .1s ease-in-out,transform .1s ease-in-out;white-space:nowrap;z-index:2}@media (prefers-reduced-motion:reduce){.form-floating>label{transition:none}}.form-floating>.form-control,.form-floating>.form-control-plaintext{padding:1rem .75rem}.form-floating>.form-control-plaintext::-moz-placeholder,.form-floating>.form-control::-moz-placeholder{color:transparent}.form-floating>.form-control-plaintext::placeholder,.form-floating>.form-control::placeholder{color:transparent}.form-floating>.form-control-plaintext:not(:-moz-placeholder-shown),.form-floating>.form-control:not(:-moz-placeholder-shown){padding-bottom:.625rem;padding-top:1.625rem}.form-floating>.form-control-plaintext:focus,.form-floating>.form-control-plaintext:not(:placeholder-shown),.form-floating>.form-control:focus,.form-floating>.form-control:not(:placeholder-shown){padding-bottom:.625rem;padding-top:1.625rem}.form-floating>.form-control-plaintext:-webkit-autofill,.form-floating>.form-control:-webkit-autofill{padding-bottom:.625rem;padding-top:1.625rem}.form-floating>.form-select{padding-bottom:.625rem;padding-top:1.625rem}.form-floating>.form-control:not(:-moz-placeholder-shown)~label{color:rgba(var(--bs-body-color-rgb),.65);transform:scale(.85) translateY(-.5rem) translateX(.15rem)}.form-floating>.form-control-plaintext~label,.form-floating>.form-control:focus~label,.form-floating>.form-control:not(:placeholder-shown)~label,.form-floating>.form-select~label{color:rgba(var(--bs-body-color-rgb),.65);transform:scale(.85) translateY(-.5rem) translateX(.15rem)}.form-floating>.form-control:not(:-moz-placeholder-shown)~label:after{background-color:var(--bs-body-bg);border-radius:var(--bs-border-radius);content:"";height:1.5em;inset:1rem .375rem;position:absolute;z-index:-1}.form-floating>.form-control-plaintext~label:after,.form-floating>.form-control:focus~label:after,.form-floating>.form-control:not(:placeholder-shown)~label:after,.form-floating>.form-select~label:after{background-color:var(--bs-body-bg);border-radius:var(--bs-border-radius);content:"";height:1.5em;inset:1rem .375rem;position:absolute;z-index:-1}.form-floating>.form-control:-webkit-autofill~label{color:rgba(var(--bs-body-color-rgb),.65);transform:scale(.85) translateY(-.5rem) translateX(.15rem)}.form-floating>.form-control-plaintext~label{border-width:var(--bs-border-width) 0}.form-floating>.form-control:disabled~label,.form-floating>:disabled~label{color:#6c757d}.form-floating>.form-control:disabled~label:after,.form-floating>:disabled~label:after{background-color:var(--bs-secondary-bg)}.input-group{align-items:stretch;display:flex;flex-wrap:wrap;position:relative;width:100%}.input-group>.form-control,.input-group>.form-floating,.input-group>.form-select{flex:1 1 auto;min-width:0;position:relative;width:1%}.input-group>.form-control:focus,.input-group>.form-floating:focus-within,.input-group>.form-select:focus{z-index:5}.input-group .btn{position:relative;z-index:2}.input-group .btn:focus{z-index:5}.input-group-text{align-items:center;background-color:var(--bs-tertiary-bg);border:var(--bs-border-width) solid var(--bs-border-color);border-radius:var(--bs-border-radius);color:var(--bs-body-color);display:flex;font-size:1rem;font-weight:400;line-height:1.5;padding:.375rem .75rem;text-align:center;white-space:nowrap}.input-group-lg>.btn,.input-group-lg>.form-control,.input-group-lg>.form-select,.input-group-lg>.input-group-text{border-radius:var(--bs-border-radius-lg);font-size:1.25rem;padding:.5rem 1rem}.input-group-sm>.btn,.input-group-sm>.form-control,.input-group-sm>.form-select,.input-group-sm>.input-group-text{border-radius:var(--bs-border-radius-sm);font-size:.875rem;padding:.25rem .5rem}.input-group-lg>.form-select,.input-group-sm>.form-select{padding-right:3rem}.input-group.has-validation>.dropdown-toggle:nth-last-child(n+4),.input-group.has-validation>.form-floating:nth-last-child(n+3)>.form-control,.input-group.has-validation>.form-floating:nth-last-child(n+3)>.form-select,.input-group.has-validation>:nth-last-child(n+3):not(.dropdown-toggle):not(.dropdown-menu):not(.form-floating),.input-group:not(.has-validation)>.dropdown-toggle:nth-last-child(n+3),.input-group:not(.has-validation)>.form-floating:not(:last-child)>.form-control,.input-group:not(.has-validation)>.form-floating:not(:last-child)>.form-select,.input-group:not(.has-validation)>:not(:last-child):not(.dropdown-toggle):not(.dropdown-menu):not(.form-floating){border-bottom-right-radius:0;border-top-right-radius:0}.input-group>:not(:first-child):not(.dropdown-menu):not(.valid-tooltip):not(.valid-feedback):not(.invalid-tooltip):not(.invalid-feedback){border-bottom-left-radius:0;border-top-left-radius:0;margin-left:calc(var(--bs-border-width)*-1)}.input-group>.form-floating:not(:first-child)>.form-control,.input-group>.form-floating:not(:first-child)>.form-select{border-bottom-left-radius:0;border-top-left-radius:0}.valid-feedback{color:var(--bs-form-valid-color);display:none;font-size:.875em;margin-top:.25rem;width:100%}.valid-tooltip{background-color:var(--bs-success);border-radius:var(--bs-border-radius);color:#fff;display:none;font-size:.875rem;margin-top:.1rem;max-width:100%;padding:.25rem .5rem;position:absolute;top:100%;z-index:5}.is-valid~.valid-feedback,.is-valid~.valid-tooltip,.was-validated :valid~.valid-feedback,.was-validated :valid~.valid-tooltip{display:block}.form-control.is-valid,.was-validated .form-control:valid{background-image:url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 8 8'%3E%3Cpath fill='%23198754' d='M2.3 6.73.6 4.53c-.4-1.04.46-1.4 1.1-.8l1.1 1.4 3.4-3.8c.6-.63 1.6-.27 1.2.7l-4 4.6c-.43.5-.8.4-1.1.1'/%3E%3C/svg%3E");background-position:right calc(.375em + .1875rem) center;background-repeat:no-repeat;background-size:calc(.75em + .375rem) calc(.75em + .375rem);border-color:var(--bs-form-valid-border-color);padding-right:calc(1.5em + .75rem)}.form-control.is-valid:focus,.was-validated .form-control:valid:focus{border-color:var(--bs-form-valid-border-color);box-shadow:0 0 0 .25rem rgba(var(--bs-success-rgb),.25)}.was-validated textarea.form-control:valid,textarea.form-control.is-valid{background-position:top calc(.375em + .1875rem) right calc(.375em + .1875rem);padding-right:calc(1.5em + .75rem)}.form-select.is-valid,.was-validated .form-select:valid{border-color:var(--bs-form-valid-border-color)}.form-select.is-valid:not([multiple]):not([size]),.form-select.is-valid:not([multiple])[size="1"],.was-validated .form-select:valid:not([multiple]):not([size]),.was-validated .form-select:valid:not([multiple])[size="1"]{--bs-form-select-bg-icon:url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 8 8'%3E%3Cpath fill='%23198754' d='M2.3 6.73.6 4.53c-.4-1.04.46-1.4 1.1-.8l1.1 1.4 3.4-3.8c.6-.63 1.6-.27 1.2.7l-4 4.6c-.43.5-.8.4-1.1.1'/%3E%3C/svg%3E");background-position:right .75rem center,center right 2.25rem;background-size:16px 12px,calc(.75em + .375rem) calc(.75em + .375rem);padding-right:4.125rem}.form-select.is-valid:focus,.was-validated .form-select:valid:focus{border-color:var(--bs-form-valid-border-color);box-shadow:0 0 0 .25rem rgba(var(--bs-success-rgb),.25)}.form-control-color.is-valid,.was-validated .form-control-color:valid{width:calc(3.75rem + 1.5em)}.form-check-input.is-valid,.was-validated .form-check-input:valid{border-color:var(--bs-form-valid-border-color)}.form-check-input.is-valid:checked,.was-validated .form-check-input:valid:checked{background-color:var(--bs-form-valid-color)}.form-check-input.is-valid:focus,.was-validated .form-check-input:valid:focus{box-shadow:0 0 0 .25rem rgba(var(--bs-success-rgb),.25)}.form-check-input.is-valid~.form-check-label,.was-validated .form-check-input:valid~.form-check-label{color:var(--bs-form-valid-color)}.form-check-inline .form-check-input~.valid-feedback{margin-left:.5em}.input-group>.form-control:not(:focus).is-valid,.input-group>.form-floating:not(:focus-within).is-valid,.input-group>.form-select:not(:focus).is-valid,.was-validated .input-group>.form-control:not(:focus):valid,.was-validated .input-group>.form-floating:not(:focus-within):valid,.was-validated .input-group>.form-select:not(:focus):valid{z-index:3}.invalid-feedback{color:var(--bs-form-invalid-color);display:none;font-size:.875em;margin-top:.25rem;width:100%}.invalid-tooltip{background-color:var(--bs-danger);border-radius:var(--bs-border-radius);color:#fff;display:none;font-size:.875rem;margin-top:.1rem;max-width:100%;padding:.25rem .5rem;position:absolute;top:100%;z-index:5}.is-invalid~.invalid-feedback,.is-invalid~.invalid-tooltip,.was-validated :invalid~.invalid-feedback,.was-validated :invalid~.invalid-tooltip{display:block}.form-control.is-invalid,.was-validated .form-control:invalid{background-image:url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' fill='none' stroke='%23dc3545' viewBox='0 0 12 12'%3E%3Ccircle cx='6' cy='6' r='4.5'/%3E%3Cpath stroke-linejoin='round' d='M5.8 3.6h.4L6 6.5z'/%3E%3Ccircle cx='6' cy='8.2' r='.6' fill='%23dc3545' stroke='none'/%3E%3C/svg%3E");background-position:right calc(.375em + .1875rem) center;background-repeat:no-repeat;background-size:calc(.75em + .375rem) calc(.75em + .375rem);border-color:var(--bs-form-invalid-border-color);padding-right:calc(1.5em + .75rem)}.form-control.is-invalid:focus,.was-validated .form-control:invalid:focus{border-color:var(--bs-form-invalid-border-color);box-shadow:0 0 0 .25rem rgba(var(--bs-danger-rgb),.25)}.was-validated textarea.form-control:invalid,textarea.form-control.is-invalid{background-position:top calc(.375em + .1875rem) right calc(.375em + .1875rem);padding-right:calc(1.5em + .75rem)}.form-select.is-invalid,.was-validated .form-select:invalid{border-color:var(--bs-form-invalid-border-color)}.form-select.is-invalid:not([multiple]):not([size]),.form-select.is-invalid:not([multiple])[size="1"],.was-validated .form-select:invalid:not([multiple]):not([size]),.was-validated .form-select:invalid:not([multiple])[size="1"]{--bs-form-select-bg-icon:url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' fill='none' stroke='%23dc3545' viewBox='0 0 12 12'%3E%3Ccircle cx='6' cy='6' r='4.5'/%3E%3Cpath stroke-linejoin='round' d='M5.8 3.6h.4L6 6.5z'/%3E%3Ccircle cx='6' cy='8.2' r='.6' fill='%23dc3545' stroke='none'/%3E%3C/svg%3E");background-position:right .75rem center,center right 2.25rem;background-size:16px 12px,calc(.75em + .375rem) calc(.75em + .375rem);padding-right:4.125rem}.form-select.is-invalid:focus,.was-validated .form-select:invalid:focus{border-color:var(--bs-form-invalid-border-color);box-shadow:0 0 0 .25rem rgba(var(--bs-danger-rgb),.25)}.form-control-color.is-invalid,.was-validated .form-control-color:invalid{width:calc(3.75rem + 1.5em)}.form-check-input.is-invalid,.was-validated .form-check-input:invalid{border-color:var(--bs-form-invalid-border-color)}.form-check-input.is-invalid:checked,.was-validated .form-check-input:invalid:checked{background-color:var(--bs-form-invalid-color)}.form-check-input.is-invalid:focus,.was-validated .form-check-input:invalid:focus{box-shadow:0 0 0 .25rem rgba(var(--bs-danger-rgb),.25)}.form-check-input.is-invalid~.form-check-label,.was-validated .form-check-input:invalid~.form-check-label{color:var(--bs-form-invalid-color)}.form-check-inline .form-check-input~.invalid-feedback{margin-left:.5em}.input-group>.form-control:not(:focus).is-invalid,.input-group>.form-floating:not(:focus-within).is-invalid,.input-group>.form-select:not(:focus).is-invalid,.was-validated .input-group>.form-control:not(:focus):invalid,.was-validated .input-group>.form-floating:not(:focus-within):invalid,.was-validated .input-group>.form-select:not(:focus):invalid{z-index:4}.btn{--bs-btn-padding-x:0.75rem;--bs-btn-padding-y:0.375rem;--bs-btn-font-family: ;--bs-btn-font-size:1rem;--bs-btn-font-weight:400;--bs-btn-line-height:1.5;--bs-btn-color:var(--bs-body-color);--bs-btn-bg:transparent;--bs-btn-border-width:var(--bs-border-width);--bs-btn-border-color:transparent;--bs-btn-border-radius:var(--bs-border-radius);--bs-btn-hover-border-color:transparent;--bs-btn-box-shadow:inset 0 1px 0 hsla(0,0%,100%,.15),0 1px 1px rgba(0,0,0,.075);--bs-btn-disabled-opacity:0.65;--bs-btn-focus-box-shadow:0 0 0 0.25rem rgba(var(--bs-btn-focus-shadow-rgb),.5);background-color:var(--bs-btn-bg);border:var(--bs-btn-border-width) solid var(--bs-btn-border-color);border-radius:var(--bs-btn-border-radius);color:var(--bs-btn-color);cursor:pointer;display:inline-block;font-family:var(--bs-btn-font-family);font-size:var(--bs-btn-font-size);font-weight:var(--bs-btn-font-weight);line-height:var(--bs-btn-line-height);padding:var(--bs-btn-padding-y) var(--bs-btn-padding-x);text-align:center;text-decoration:none;transition:color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;-webkit-user-select:none;-moz-user-select:none;user-select:none;vertical-align:middle}@media (prefers-reduced-motion:reduce){.btn{transition:none}}.btn:hover{background-color:var(--bs-btn-hover-bg);border-color:var(--bs-btn-hover-border-color);color:var(--bs-btn-hover-color)}.btn-check+.btn:hover{background-color:var(--bs-btn-bg);border-color:var(--bs-btn-border-color);color:var(--bs-btn-color)}.btn:focus-visible{background-color:var(--bs-btn-hover-bg);border-color:var(--bs-btn-hover-border-color);box-shadow:var(--bs-btn-focus-box-shadow);color:var(--bs-btn-hover-color);outline:0}.btn-check:focus-visible+.btn{border-color:var(--bs-btn-hover-border-color);box-shadow:var(--bs-btn-focus-box-shadow);outline:0}.btn-check:checked+.btn,.btn.active,.btn.show,.btn:first-child:active,:not(.btn-check)+.btn:active{background-color:var(--bs-btn-active-bg);border-color:var(--bs-btn-active-border-color);color:var(--bs-btn-active-color)}.btn-check:checked+.btn:focus-visible,.btn.active:focus-visible,.btn.show:focus-visible,.btn:first-child:active:focus-visible,:not(.btn-check)+.btn:active:focus-visible{box-shadow:var(--bs-btn-focus-box-shadow)}.btn-check:checked:focus-visible+.btn{box-shadow:var(--bs-btn-focus-box-shadow)}.btn.disabled,.btn:disabled,fieldset:disabled .btn{background-color:var(--bs-btn-disabled-bg);border-color:var(--bs-btn-disabled-border-color);color:var(--bs-btn-disabled-color);opacity:var(--bs-btn-disabled-opacity);pointer-events:none}.btn-primary{--bs-btn-color:#000;--bs-btn-bg:#3c83eb;--bs-btn-border-color:#3c83eb;--bs-btn-hover-color:#000;--bs-btn-hover-bg:#5996ee;--bs-btn-hover-border-color:#508fed;--bs-btn-focus-shadow-rgb:51,111,200;--bs-btn-active-color:#000;--bs-btn-active-bg:#639cef;--bs-btn-active-border-color:#508fed;--bs-btn-active-shadow:inset 0 3px 5px rgba(0,0,0,.125);--bs-btn-disabled-color:#000;--bs-btn-disabled-bg:#3c83eb;--bs-btn-disabled-border-color:#3c83eb}.btn-secondary{--bs-btn-color:#fff;--bs-btn-bg:#6c757d;--bs-btn-border-color:#6c757d;--bs-btn-hover-color:#fff;--bs-btn-hover-bg:#5c636a;--bs-btn-hover-border-color:#565e64;--bs-btn-focus-shadow-rgb:130,138,145;--bs-btn-active-color:#fff;--bs-btn-active-bg:#565e64;--bs-btn-active-border-color:#51585e;--bs-btn-active-shadow:inset 0 3px 5px rgba(0,0,0,.125);--bs-btn-disabled-color:#fff;--bs-btn-disabled-bg:#6c757d;--bs-btn-disabled-border-color:#6c757d}.btn-success{--bs-btn-color:#fff;--bs-btn-bg:#198754;--bs-btn-border-color:#198754;--bs-btn-hover-color:#fff;--bs-btn-hover-bg:#157347;--bs-btn-hover-border-color:#146c43;--bs-btn-focus-shadow-rgb:60,153,110;--bs-btn-active-color:#fff;--bs-btn-active-bg:#146c43;--bs-btn-active-border-color:#13653f;--bs-btn-active-shadow:inset 0 3px 5px rgba(0,0,0,.125);--bs-btn-disabled-color:#fff;--bs-btn-disabled-bg:#198754;--bs-btn-disabled-border-color:#198754}.btn-info{--bs-btn-color:#000;--bs-btn-bg:#0dcaf0;--bs-btn-border-color:#0dcaf0;--bs-btn-hover-color:#000;--bs-btn-hover-bg:#31d2f2;--bs-btn-hover-border-color:#25cff2;--bs-btn-focus-shadow-rgb:11,172,204;--bs-btn-active-color:#000;--bs-btn-active-bg:#3dd5f3;--bs-btn-active-border-color:#25cff2;--bs-btn-active-shadow:inset 0 3px 5px rgba(0,0,0,.125);--bs-btn-disabled-color:#000;--bs-btn-disabled-bg:#0dcaf0;--bs-btn-disabled-border-color:#0dcaf0}.btn-warning{--bs-btn-color:#000;--bs-btn-bg:#ffc107;--bs-btn-border-color:#ffc107;--bs-btn-hover-color:#000;--bs-btn-hover-bg:#ffca2c;--bs-btn-hover-border-color:#ffc720;--bs-btn-focus-shadow-rgb:217,164,6;--bs-btn-active-color:#000;--bs-btn-active-bg:#ffcd39;--bs-btn-active-border-color:#ffc720;--bs-btn-active-shadow:inset 0 3px 5px rgba(0,0,0,.125);--bs-btn-disabled-color:#000;--bs-btn-disabled-bg:#ffc107;--bs-btn-disabled-border-color:#ffc107}.btn-danger{--bs-btn-color:#fff;--bs-btn-bg:#dc3545;--bs-btn-border-color:#dc3545;--bs-btn-hover-color:#fff;--bs-btn-hover-bg:#bb2d3b;--bs-btn-hover-border-color:#b02a37;--bs-btn-focus-shadow-rgb:225,83,97;--bs-btn-active-color:#fff;--bs-btn-active-bg:#b02a37;--bs-btn-active-border-color:#a52834;--bs-btn-active-shadow:inset 0 3px 5px rgba(0,0,0,.125);--bs-btn-disabled-color:#fff;--bs-btn-disabled-bg:#dc3545;--bs-btn-disabled-border-color:#dc3545}.btn-light{--bs-btn-color:#000;--bs-btn-bg:#f8f9fa;--bs-btn-border-color:#f8f9fa;--bs-btn-hover-color:#000;--bs-btn-hover-bg:#d3d4d5;--bs-btn-hover-border-color:#c6c7c8;--bs-btn-focus-shadow-rgb:211,212,213;--bs-btn-active-color:#000;--bs-btn-active-bg:#c6c7c8;--bs-btn-active-border-color:#babbbc;--bs-btn-active-shadow:inset 0 3px 5px rgba(0,0,0,.125);--bs-btn-disabled-color:#000;--bs-btn-disabled-bg:#f8f9fa;--bs-btn-disabled-border-color:#f8f9fa}.btn-dark{--bs-btn-color:#fff;--bs-btn-bg:#212529;--bs-btn-border-color:#212529;--bs-btn-hover-color:#fff;--bs-btn-hover-bg:#424649;--bs-btn-hover-border-color:#373b3e;--bs-btn-focus-shadow-rgb:66,70,73;--bs-btn-active-color:#fff;--bs-btn-active-bg:#4d5154;--bs-btn-active-border-color:#373b3e;--bs-btn-active-shadow:inset 0 3px 5px rgba(0,0,0,.125);--bs-btn-disabled-color:#fff;--bs-btn-disabled-bg:#212529;--bs-btn-disabled-border-color:#212529}.btn-outline-primary{--bs-btn-color:#3c83eb;--bs-btn-border-color:#3c83eb;--bs-btn-hover-color:#000;--bs-btn-hover-bg:#3c83eb;--bs-btn-hover-border-color:#3c83eb;--bs-btn-focus-shadow-rgb:60,131,235;--bs-btn-active-color:#000;--bs-btn-active-bg:#3c83eb;--bs-btn-active-border-color:#3c83eb;--bs-btn-active-shadow:inset 0 3px 5px rgba(0,0,0,.125);--bs-btn-disabled-color:#3c83eb;--bs-btn-disabled-bg:transparent;--bs-btn-disabled-border-color:#3c83eb;--bs-gradient:none}.btn-outline-secondary{--bs-btn-color:#6c757d;--bs-btn-border-color:#6c757d;--bs-btn-hover-color:#fff;--bs-btn-hover-bg:#6c757d;--bs-btn-hover-border-color:#6c757d;--bs-btn-focus-shadow-rgb:108,117,125;--bs-btn-active-color:#fff;--bs-btn-active-bg:#6c757d;--bs-btn-active-border-color:#6c757d;--bs-btn-active-shadow:inset 0 3px 5px rgba(0,0,0,.125);--bs-btn-disabled-color:#6c757d;--bs-btn-disabled-bg:transparent;--bs-btn-disabled-border-color:#6c757d;--bs-gradient:none}.btn-outline-success{--bs-btn-color:#198754;--bs-btn-border-color:#198754;--bs-btn-hover-color:#fff;--bs-btn-hover-bg:#198754;--bs-btn-hover-border-color:#198754;--bs-btn-focus-shadow-rgb:25,135,84;--bs-btn-active-color:#fff;--bs-btn-active-bg:#198754;--bs-btn-active-border-color:#198754;--bs-btn-active-shadow:inset 0 3px 5px rgba(0,0,0,.125);--bs-btn-disabled-color:#198754;--bs-btn-disabled-bg:transparent;--bs-btn-disabled-border-color:#198754;--bs-gradient:none}.btn-outline-info{--bs-btn-color:#0dcaf0;--bs-btn-border-color:#0dcaf0;--bs-btn-hover-color:#000;--bs-btn-hover-bg:#0dcaf0;--bs-btn-hover-border-color:#0dcaf0;--bs-btn-focus-shadow-rgb:13,202,240;--bs-btn-active-color:#000;--bs-btn-active-bg:#0dcaf0;--bs-btn-active-border-color:#0dcaf0;--bs-btn-active-shadow:inset 0 3px 5px rgba(0,0,0,.125);--bs-btn-disabled-color:#0dcaf0;--bs-btn-disabled-bg:transparent;--bs-btn-disabled-border-color:#0dcaf0;--bs-gradient:none}.btn-outline-warning{--bs-btn-color:#ffc107;--bs-btn-border-color:#ffc107;--bs-btn-hover-color:#000;--bs-btn-hover-bg:#ffc107;--bs-btn-hover-border-color:#ffc107;--bs-btn-focus-shadow-rgb:255,193,7;--bs-btn-active-color:#000;--bs-btn-active-bg:#ffc107;--bs-btn-active-border-color:#ffc107;--bs-btn-active-shadow:inset 0 3px 5px rgba(0,0,0,.125);--bs-btn-disabled-color:#ffc107;--bs-btn-disabled-bg:transparent;--bs-btn-disabled-border-color:#ffc107;--bs-gradient:none}.btn-outline-danger{--bs-btn-color:#dc3545;--bs-btn-border-color:#dc3545;--bs-btn-hover-color:#fff;--bs-btn-hover-bg:#dc3545;--bs-btn-hover-border-color:#dc3545;--bs-btn-focus-shadow-rgb:220,53,69;--bs-btn-active-color:#fff;--bs-btn-active-bg:#dc3545;--bs-btn-active-border-color:#dc3545;--bs-btn-active-shadow:inset 0 3px 5px rgba(0,0,0,.125);--bs-btn-disabled-color:#dc3545;--bs-btn-disabled-bg:transparent;--bs-btn-disabled-border-color:#dc3545;--bs-gradient:none}.btn-outline-light{--bs-btn-color:#f8f9fa;--bs-btn-border-color:#f8f9fa;--bs-btn-hover-color:#000;--bs-btn-hover-bg:#f8f9fa;--bs-btn-hover-border-color:#f8f9fa;--bs-btn-focus-shadow-rgb:248,249,250;--bs-btn-active-color:#000;--bs-btn-active-bg:#f8f9fa;--bs-btn-active-border-color:#f8f9fa;--bs-btn-active-shadow:inset 0 3px 5px rgba(0,0,0,.125);--bs-btn-disabled-color:#f8f9fa;--bs-btn-disabled-bg:transparent;--bs-btn-disabled-border-color:#f8f9fa;--bs-gradient:none}.btn-outline-dark{--bs-btn-color:#212529;--bs-btn-border-color:#212529;--bs-btn-hover-color:#fff;--bs-btn-hover-bg:#212529;--bs-btn-hover-border-color:#212529;--bs-btn-focus-shadow-rgb:33,37,41;--bs-btn-active-color:#fff;--bs-btn-active-bg:#212529;--bs-btn-active-border-color:#212529;--bs-btn-active-shadow:inset 0 3px 5px rgba(0,0,0,.125);--bs-btn-disabled-color:#212529;--bs-btn-disabled-bg:transparent;--bs-btn-disabled-border-color:#212529;--bs-gradient:none}.btn-link{--bs-btn-font-weight:400;--bs-btn-color:var(--bs-link-color);--bs-btn-bg:transparent;--bs-btn-border-color:transparent;--bs-btn-hover-color:var(--bs-link-hover-color);--bs-btn-hover-border-color:transparent;--bs-btn-active-color:var(--bs-link-hover-color);--bs-btn-active-border-color:transparent;--bs-btn-disabled-color:#6c757d;--bs-btn-disabled-border-color:transparent;--bs-btn-box-shadow:0 0 0 #000;--bs-btn-focus-shadow-rgb:51,111,200;text-decoration:underline}.btn-link:focus-visible{color:var(--bs-btn-color)}.btn-link:hover{color:var(--bs-btn-hover-color)}.btn-group-lg>.btn,.btn-lg{--bs-btn-padding-y:0.5rem;--bs-btn-padding-x:1rem;--bs-btn-font-size:1.25rem;--bs-btn-border-radius:var(--bs-border-radius-lg)}.btn-group-sm>.btn,.btn-sm{--bs-btn-padding-y:0.25rem;--bs-btn-padding-x:0.5rem;--bs-btn-font-size:0.875rem;--bs-btn-border-radius:var(--bs-border-radius-sm)}.fade{transition:opacity .15s linear}@media (prefers-reduced-motion:reduce){.fade{transition:none}}.fade:not(.show){opacity:0}.collapse:not(.show){display:none}.collapsing{height:0;overflow:hidden;transition:height .35s ease}@media (prefers-reduced-motion:reduce){.collapsing{transition:none}}.collapsing.collapse-horizontal{height:auto;transition:width .35s ease;width:0}@media (prefers-reduced-motion:reduce){.collapsing.collapse-horizontal{transition:none}}.dropdown,.dropdown-center,.dropend,.dropstart,.dropup,.dropup-center{position:relative}.dropdown-toggle{white-space:nowrap}.dropdown-toggle:after{border-bottom:0;border-left:.3em solid transparent;border-right:.3em solid transparent;border-top:.3em solid;content:"";display:inline-block;margin-left:.255em;vertical-align:.255em}.dropdown-toggle:empty:after{margin-left:0}.dropdown-menu{--bs-dropdown-zindex:1000;--bs-dropdown-min-width:10rem;--bs-dropdown-padding-x:0;--bs-dropdown-padding-y:0.5rem;--bs-dropdown-spacer:0.125rem;--bs-dropdown-font-size:1rem;--bs-dropdown-color:var(--bs-body-color);--bs-dropdown-bg:var(--bs-body-bg);--bs-dropdown-border-color:var(--bs-border-color-translucent);--bs-dropdown-border-radius:var(--bs-border-radius);--bs-dropdown-border-width:var(--bs-border-width);--bs-dropdown-inner-border-radius:calc(var(--bs-border-radius) - var(--bs-border-width));--bs-dropdown-divider-bg:var(--bs-border-color-translucent);--bs-dropdown-divider-margin-y:0.5rem;--bs-dropdown-box-shadow:var(--bs-box-shadow);--bs-dropdown-link-color:var(--bs-body-color);--bs-dropdown-link-hover-color:var(--bs-body-color);--bs-dropdown-link-hover-bg:var(--bs-tertiary-bg);--bs-dropdown-link-active-color:#fff;--bs-dropdown-link-active-bg:#3c83eb;--bs-dropdown-link-disabled-color:var(--bs-tertiary-color);--bs-dropdown-item-padding-x:1rem;--bs-dropdown-item-padding-y:0.25rem;--bs-dropdown-header-color:#6c757d;--bs-dropdown-header-padding-x:1rem;--bs-dropdown-header-padding-y:0.5rem;background-clip:padding-box;background-color:var(--bs-dropdown-bg);border:var(--bs-dropdown-border-width) solid var(--bs-dropdown-border-color);border-radius:var(--bs-dropdown-border-radius);color:var(--bs-dropdown-color);display:none;font-size:var(--bs-dropdown-font-size);list-style:none;margin:0;min-width:var(--bs-dropdown-min-width);padding:var(--bs-dropdown-padding-y) var(--bs-dropdown-padding-x);position:absolute;text-align:left;z-index:var(--bs-dropdown-zindex)}.dropdown-menu[data-bs-popper]{left:0;margin-top:var(--bs-dropdown-spacer);top:100%}.dropdown-menu-start{--bs-position:start}.dropdown-menu-start[data-bs-popper]{left:0;right:auto}.dropdown-menu-end{--bs-position:end}.dropdown-menu-end[data-bs-popper]{left:auto;right:0}@media (min-width:576px){.dropdown-menu-sm-start{--bs-position:start}.dropdown-menu-sm-start[data-bs-popper]{left:0;right:auto}.dropdown-menu-sm-end{--bs-position:end}.dropdown-menu-sm-end[data-bs-popper]{left:auto;right:0}}@media (min-width:768px){.dropdown-menu-md-start{--bs-position:start}.dropdown-menu-md-start[data-bs-popper]{left:0;right:auto}.dropdown-menu-md-end{--bs-position:end}.dropdown-menu-md-end[data-bs-popper]{left:auto;right:0}}@media (min-width:992px){.dropdown-menu-lg-start{--bs-position:start}.dropdown-menu-lg-start[data-bs-popper]{left:0;right:auto}.dropdown-menu-lg-end{--bs-position:end}.dropdown-menu-lg-end[data-bs-popper]{left:auto;right:0}}@media (min-width:1200px){.dropdown-menu-xl-start{--bs-position:start}.dropdown-menu-xl-start[data-bs-popper]{left:0;right:auto}.dropdown-menu-xl-end{--bs-position:end}.dropdown-menu-xl-end[data-bs-popper]{left:auto;right:0}}@media (min-width:1400px){.dropdown-menu-xxl-start{--bs-position:start}.dropdown-menu-xxl-start[data-bs-popper]{left:0;right:auto}.dropdown-menu-xxl-end{--bs-position:end}.dropdown-menu-xxl-end[data-bs-popper]{left:auto;right:0}}.dropup .dropdown-menu[data-bs-popper]{bottom:100%;margin-bottom:var(--bs-dropdown-spacer);margin-top:0;top:auto}.dropup .dropdown-toggle:after{border-bottom:.3em solid;border-left:.3em solid transparent;border-right:.3em solid transparent;border-top:0;content:"";display:inline-block;margin-left:.255em;vertical-align:.255em}.dropup .dropdown-toggle:empty:after{margin-left:0}.dropend .dropdown-menu[data-bs-popper]{left:100%;margin-left:var(--bs-dropdown-spacer);margin-top:0;right:auto;top:0}.dropend .dropdown-toggle:after{border-bottom:.3em solid transparent;border-left:.3em solid;border-right:0;border-top:.3em solid transparent;content:"";display:inline-block;margin-left:.255em;vertical-align:.255em}.dropend .dropdown-toggle:empty:after{margin-left:0}.dropend .dropdown-toggle:after{vertical-align:0}.dropstart .dropdown-menu[data-bs-popper]{left:auto;margin-right:var(--bs-dropdown-spacer);margin-top:0;right:100%;top:0}.dropstart .dropdown-toggle:after{content:"";display:inline-block;display:none;margin-left:.255em;vertical-align:.255em}.dropstart .dropdown-toggle:before{border-bottom:.3em solid transparent;border-right:.3em solid;border-top:.3em solid transparent;content:"";display:inline-block;margin-right:.255em;vertical-align:.255em}.dropstart .dropdown-toggle:empty:after{margin-left:0}.dropstart .dropdown-toggle:before{vertical-align:0}.dropdown-divider{border-top:1px solid var(--bs-dropdown-divider-bg);height:0;margin:var(--bs-dropdown-divider-margin-y) 0;opacity:1;overflow:hidden}.dropdown-item{background-color:transparent;border:0;border-radius:var(--bs-dropdown-item-border-radius,0);clear:both;color:var(--bs-dropdown-link-color);display:block;font-weight:400;padding:var(--bs-dropdown-item-padding-y) var(--bs-dropdown-item-padding-x);text-align:inherit;text-decoration:none;white-space:nowrap;width:100%}.dropdown-item:focus,.dropdown-item:hover{background-color:var(--bs-dropdown-link-hover-bg);color:var(--bs-dropdown-link-hover-color)}.dropdown-item.active,.dropdown-item:active{background-color:var(--bs-dropdown-link-active-bg);color:var(--bs-dropdown-link-active-color);text-decoration:none}.dropdown-item.disabled,.dropdown-item:disabled{background-color:transparent;color:var(--bs-dropdown-link-disabled-color);pointer-events:none}.dropdown-menu.show{display:block}.dropdown-header{color:var(--bs-dropdown-header-color);display:block;font-size:.875rem;margin-bottom:0;padding:var(--bs-dropdown-header-padding-y) var(--bs-dropdown-header-padding-x);white-space:nowrap}.dropdown-item-text{color:var(--bs-dropdown-link-color);display:block;padding:var(--bs-dropdown-item-padding-y) var(--bs-dropdown-item-padding-x)}.dropdown-menu-dark{--bs-dropdown-color:#dee2e6;--bs-dropdown-bg:#343a40;--bs-dropdown-border-color:var(--bs-border-color-translucent);--bs-dropdown-box-shadow: ;--bs-dropdown-link-color:#dee2e6;--bs-dropdown-link-hover-color:#fff;--bs-dropdown-divider-bg:var(--bs-border-color-translucent);--bs-dropdown-link-hover-bg:hsla(0,0%,100%,.15);--bs-dropdown-link-active-color:#fff;--bs-dropdown-link-active-bg:#3c83eb;--bs-dropdown-link-disabled-color:#adb5bd;--bs-dropdown-header-color:#adb5bd}.btn-group,.btn-group-vertical{display:inline-flex;position:relative;vertical-align:middle}.btn-group-vertical>.btn,.btn-group>.btn{flex:1 1 auto;position:relative}.btn-group-vertical>.btn-check:checked+.btn,.btn-group-vertical>.btn-check:focus+.btn,.btn-group-vertical>.btn.active,.btn-group-vertical>.btn:active,.btn-group-vertical>.btn:focus,.btn-group-vertical>.btn:hover,.btn-group>.btn-check:checked+.btn,.btn-group>.btn-check:focus+.btn,.btn-group>.btn.active,.btn-group>.btn:active,.btn-group>.btn:focus,.btn-group>.btn:hover{z-index:1}.btn-toolbar{display:flex;flex-wrap:wrap;justify-content:flex-start}.btn-toolbar .input-group{width:auto}.btn-group{border-radius:var(--bs-border-radius)}.btn-group>.btn-group:not(:first-child),.btn-group>:not(.btn-check:first-child)+.btn{margin-left:calc(var(--bs-border-width)*-1)}.btn-group>.btn-group:not(:last-child)>.btn,.btn-group>.btn.dropdown-toggle-split:first-child,.btn-group>.btn:not(:last-child):not(.dropdown-toggle){border-bottom-right-radius:0;border-top-right-radius:0}.btn-group>.btn-group:not(:first-child)>.btn,.btn-group>.btn:nth-child(n+3),.btn-group>:not(.btn-check)+.btn{border-bottom-left-radius:0;border-top-left-radius:0}.dropdown-toggle-split{padding-left:.5625rem;padding-right:.5625rem}.dropdown-toggle-split:after,.dropend .dropdown-toggle-split:after,.dropup .dropdown-toggle-split:after{margin-left:0}.dropstart .dropdown-toggle-split:before{margin-right:0}.btn-group-sm>.btn+.dropdown-toggle-split,.btn-sm+.dropdown-toggle-split{padding-left:.375rem;padding-right:.375rem}.btn-group-lg>.btn+.dropdown-toggle-split,.btn-lg+.dropdown-toggle-split{padding-left:.75rem;padding-right:.75rem}.btn-group-vertical{align-items:flex-start;flex-direction:column;justify-content:center}.btn-group-vertical>.btn,.btn-group-vertical>.btn-group{width:100%}.btn-group-vertical>.btn-group:not(:first-child),.btn-group-vertical>.btn:not(:first-child){margin-top:calc(var(--bs-border-width)*-1)}.btn-group-vertical>.btn-group:not(:last-child)>.btn,.btn-group-vertical>.btn:not(:last-child):not(.dropdown-toggle){border-bottom-left-radius:0;border-bottom-right-radius:0}.btn-group-vertical>.btn-group:not(:first-child)>.btn,.btn-group-vertical>.btn~.btn{border-top-left-radius:0;border-top-right-radius:0}.nav{--bs-nav-link-padding-x:1rem;--bs-nav-link-padding-y:0.5rem;--bs-nav-link-font-weight: ;--bs-nav-link-color:var(--bs-link-color);--bs-nav-link-hover-color:var(--bs-link-hover-color);--bs-nav-link-disabled-color:var(--bs-secondary-color);display:flex;flex-wrap:wrap;list-style:none;margin-bottom:0;padding-left:0}.nav-link{background:none;border:0;color:var(--bs-nav-link-color);display:block;font-size:var(--bs-nav-link-font-size);font-weight:var(--bs-nav-link-font-weight);padding:var(--bs-nav-link-padding-y) var(--bs-nav-link-padding-x);text-decoration:none;transition:color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out}@media (prefers-reduced-motion:reduce){.nav-link{transition:none}}.nav-link:focus,.nav-link:hover{color:var(--bs-nav-link-hover-color)}.nav-link:focus-visible{box-shadow:0 0 0 .25rem rgba(60,131,235,.25);outline:0}.nav-link.disabled,.nav-link:disabled{color:var(--bs-nav-link-disabled-color);cursor:default;pointer-events:none}.nav-tabs{--bs-nav-tabs-border-width:var(--bs-border-width);--bs-nav-tabs-border-color:var(--bs-border-color);--bs-nav-tabs-border-radius:var(--bs-border-radius);--bs-nav-tabs-link-hover-border-color:var(--bs-secondary-bg) var(--bs-secondary-bg) var(--bs-border-color);--bs-nav-tabs-link-active-color:var(--bs-emphasis-color);--bs-nav-tabs-link-active-bg:var(--bs-body-bg);--bs-nav-tabs-link-active-border-color:var(--bs-border-color) var(--bs-border-color) var(--bs-body-bg);border-bottom:var(--bs-nav-tabs-border-width) solid var(--bs-nav-tabs-border-color)}.nav-tabs .nav-link{border:var(--bs-nav-tabs-border-width) solid transparent;border-top-left-radius:var(--bs-nav-tabs-border-radius);border-top-right-radius:var(--bs-nav-tabs-border-radius);margin-bottom:calc(var(--bs-nav-tabs-border-width)*-1)}.nav-tabs .nav-link:focus,.nav-tabs .nav-link:hover{border-color:var(--bs-nav-tabs-link-hover-border-color);isolation:isolate}.nav-tabs .nav-item.show .nav-link,.nav-tabs .nav-link.active{background-color:var(--bs-nav-tabs-link-active-bg);border-color:var(--bs-nav-tabs-link-active-border-color);color:var(--bs-nav-tabs-link-active-color)}.nav-tabs .dropdown-menu{border-top-left-radius:0;border-top-right-radius:0;margin-top:calc(var(--bs-nav-tabs-border-width)*-1)}.nav-pills{--bs-nav-pills-border-radius:var(--bs-border-radius);--bs-nav-pills-link-active-color:#fff;--bs-nav-pills-link-active-bg:#3c83eb}.nav-pills .nav-link{border-radius:var(--bs-nav-pills-border-radius)}.nav-pills .nav-link.active,.nav-pills .show>.nav-link{background-color:var(--bs-nav-pills-link-active-bg);color:var(--bs-nav-pills-link-active-color)}.nav-underline{--bs-nav-underline-gap:1rem;--bs-nav-underline-border-width:0.125rem;--bs-nav-underline-link-active-color:var(--bs-emphasis-color);gap:var(--bs-nav-underline-gap)}.nav-underline .nav-link{border-bottom:var(--bs-nav-underline-border-width) solid transparent;padding-left:0;padding-right:0}.nav-underline .nav-link:focus,.nav-underline .nav-link:hover{border-bottom-color:currentcolor}.nav-underline .nav-link.active,.nav-underline .show>.nav-link{border-bottom-color:currentcolor;color:var(--bs-nav-underline-link-active-color);font-weight:700}.nav-fill .nav-item,.nav-fill>.nav-link{flex:1 1 auto;text-align:center}.nav-justified .nav-item,.nav-justified>.nav-link{flex-basis:0;flex-grow:1;text-align:center}.nav-fill .nav-item .nav-link,.nav-justified .nav-item .nav-link{width:100%}.tab-content>.tab-pane{display:none}.tab-content>.active{display:block}.navbar{--bs-navbar-padding-x:0;--bs-navbar-padding-y:0.5rem;--bs-navbar-color:rgba(var(--bs-emphasis-color-rgb),0.65);--bs-navbar-hover-color:rgba(var(--bs-emphasis-color-rgb),0.8);--bs-navbar-disabled-color:rgba(var(--bs-emphasis-color-rgb),0.3);--bs-navbar-active-color:rgba(var(--bs-emphasis-color-rgb),1);--bs-navbar-brand-padding-y:0.3125rem;--bs-navbar-brand-margin-end:1rem;--bs-navbar-brand-font-size:1.25rem;--bs-navbar-brand-color:rgba(var(--bs-emphasis-color-rgb),1);--bs-navbar-brand-hover-color:rgba(var(--bs-emphasis-color-rgb),1);--bs-navbar-nav-link-padding-x:0.5rem;--bs-navbar-toggler-padding-y:0.25rem;--bs-navbar-toggler-padding-x:0.75rem;--bs-navbar-toggler-font-size:1.25rem;--bs-navbar-toggler-icon-bg:url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3E%3Cpath stroke='rgba(33, 37, 41, 0.75)' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3E%3C/svg%3E");--bs-navbar-toggler-border-color:rgba(var(--bs-emphasis-color-rgb),0.15);--bs-navbar-toggler-border-radius:var(--bs-border-radius);--bs-navbar-toggler-focus-width:0.25rem;--bs-navbar-toggler-transition:box-shadow 0.15s ease-in-out;align-items:center;display:flex;flex-wrap:wrap;justify-content:space-between;padding:var(--bs-navbar-padding-y) var(--bs-navbar-padding-x);position:relative}.navbar>.container,.navbar>.container-fluid,.navbar>.container-lg,.navbar>.container-md,.navbar>.container-sm,.navbar>.container-xl,.navbar>.container-xxl{align-items:center;display:flex;flex-wrap:inherit;justify-content:space-between}.navbar-brand{color:var(--bs-navbar-brand-color);font-size:var(--bs-navbar-brand-font-size);margin-right:var(--bs-navbar-brand-margin-end);padding-bottom:var(--bs-navbar-brand-padding-y);padding-top:var(--bs-navbar-brand-padding-y);text-decoration:none;white-space:nowrap}.navbar-brand:focus,.navbar-brand:hover{color:var(--bs-navbar-brand-hover-color)}.navbar-nav{--bs-nav-link-padding-x:0;--bs-nav-link-padding-y:0.5rem;--bs-nav-link-font-weight: ;--bs-nav-link-color:var(--bs-navbar-color);--bs-nav-link-hover-color:var(--bs-navbar-hover-color);--bs-nav-link-disabled-color:var(--bs-navbar-disabled-color);display:flex;flex-direction:column;list-style:none;margin-bottom:0;padding-left:0}.navbar-nav .nav-link.active,.navbar-nav .nav-link.show{color:var(--bs-navbar-active-color)}.navbar-nav .dropdown-menu{position:static}.navbar-text{color:var(--bs-navbar-color);padding-bottom:.5rem;padding-top:.5rem}.navbar-text a,.navbar-text a:focus,.navbar-text a:hover{color:var(--bs-navbar-active-color)}.navbar-collapse{align-items:center;flex-basis:100%;flex-grow:1}.navbar-toggler{background-color:transparent;border:var(--bs-border-width) solid var(--bs-navbar-toggler-border-color);border-radius:var(--bs-navbar-toggler-border-radius);color:var(--bs-navbar-color);font-size:var(--bs-navbar-toggler-font-size);line-height:1;padding:var(--bs-navbar-toggler-padding-y) var(--bs-navbar-toggler-padding-x);transition:var(--bs-navbar-toggler-transition)}@media (prefers-reduced-motion:reduce){.navbar-toggler{transition:none}}.navbar-toggler:hover{text-decoration:none}.navbar-toggler:focus{box-shadow:0 0 0 var(--bs-navbar-toggler-focus-width);outline:0;text-decoration:none}.navbar-toggler-icon{background-image:var(--bs-navbar-toggler-icon-bg);background-position:50%;background-repeat:no-repeat;background-size:100%;display:inline-block;height:1.5em;vertical-align:middle;width:1.5em}.navbar-nav-scroll{max-height:var(--bs-scroll-height,75vh);overflow-y:auto}@media (min-width:576px){.navbar-expand-sm{flex-wrap:nowrap;justify-content:flex-start}.navbar-expand-sm .navbar-nav{flex-direction:row}.navbar-expand-sm .navbar-nav .dropdown-menu{position:absolute}.navbar-expand-sm .navbar-nav .nav-link{padding-left:var(--bs-navbar-nav-link-padding-x);padding-right:var(--bs-navbar-nav-link-padding-x)}.navbar-expand-sm .navbar-nav-scroll{overflow:visible}.navbar-expand-sm .navbar-collapse{display:flex!important;flex-basis:auto}.navbar-expand-sm .navbar-toggler{display:none}.navbar-expand-sm .offcanvas{background-color:transparent!important;border:0!important;flex-grow:1;height:auto!important;position:static;transform:none!important;transition:none;visibility:visible!important;width:auto!important;z-index:auto}.navbar-expand-sm .offcanvas .offcanvas-header{display:none}.navbar-expand-sm .offcanvas .offcanvas-body{display:flex;flex-grow:0;overflow-y:visible;padding:0}}@media (min-width:768px){.navbar-expand-md{flex-wrap:nowrap;justify-content:flex-start}.navbar-expand-md .navbar-nav{flex-direction:row}.navbar-expand-md .navbar-nav .dropdown-menu{position:absolute}.navbar-expand-md .navbar-nav .nav-link{padding-left:var(--bs-navbar-nav-link-padding-x);padding-right:var(--bs-navbar-nav-link-padding-x)}.navbar-expand-md .navbar-nav-scroll{overflow:visible}.navbar-expand-md .navbar-collapse{display:flex!important;flex-basis:auto}.navbar-expand-md .navbar-toggler{display:none}.navbar-expand-md .offcanvas{background-color:transparent!important;border:0!important;flex-grow:1;height:auto!important;position:static;transform:none!important;transition:none;visibility:visible!important;width:auto!important;z-index:auto}.navbar-expand-md .offcanvas .offcanvas-header{display:none}.navbar-expand-md .offcanvas .offcanvas-body{display:flex;flex-grow:0;overflow-y:visible;padding:0}}@media (min-width:992px){.navbar-expand-lg{flex-wrap:nowrap;justify-content:flex-start}.navbar-expand-lg .navbar-nav{flex-direction:row}.navbar-expand-lg .navbar-nav .dropdown-menu{position:absolute}.navbar-expand-lg .navbar-nav .nav-link{padding-left:var(--bs-navbar-nav-link-padding-x);padding-right:var(--bs-navbar-nav-link-padding-x)}.navbar-expand-lg .navbar-nav-scroll{overflow:visible}.navbar-expand-lg .navbar-collapse{display:flex!important;flex-basis:auto}.navbar-expand-lg .navbar-toggler{display:none}.navbar-expand-lg .offcanvas{background-color:transparent!important;border:0!important;flex-grow:1;height:auto!important;position:static;transform:none!important;transition:none;visibility:visible!important;width:auto!important;z-index:auto}.navbar-expand-lg .offcanvas .offcanvas-header{display:none}.navbar-expand-lg .offcanvas .offcanvas-body{display:flex;flex-grow:0;overflow-y:visible;padding:0}}@media (min-width:1200px){.navbar-expand-xl{flex-wrap:nowrap;justify-content:flex-start}.navbar-expand-xl .navbar-nav{flex-direction:row}.navbar-expand-xl .navbar-nav .dropdown-menu{position:absolute}.navbar-expand-xl .navbar-nav .nav-link{padding-left:var(--bs-navbar-nav-link-padding-x);padding-right:var(--bs-navbar-nav-link-padding-x)}.navbar-expand-xl .navbar-nav-scroll{overflow:visible}.navbar-expand-xl .navbar-collapse{display:flex!important;flex-basis:auto}.navbar-expand-xl .navbar-toggler{display:none}.navbar-expand-xl .offcanvas{background-color:transparent!important;border:0!important;flex-grow:1;height:auto!important;position:static;transform:none!important;transition:none;visibility:visible!important;width:auto!important;z-index:auto}.navbar-expand-xl .offcanvas .offcanvas-header{display:none}.navbar-expand-xl .offcanvas .offcanvas-body{display:flex;flex-grow:0;overflow-y:visible;padding:0}}@media (min-width:1400px){.navbar-expand-xxl{flex-wrap:nowrap;justify-content:flex-start}.navbar-expand-xxl .navbar-nav{flex-direction:row}.navbar-expand-xxl .navbar-nav .dropdown-menu{position:absolute}.navbar-expand-xxl .navbar-nav .nav-link{padding-left:var(--bs-navbar-nav-link-padding-x);padding-right:var(--bs-navbar-nav-link-padding-x)}.navbar-expand-xxl .navbar-nav-scroll{overflow:visible}.navbar-expand-xxl .navbar-collapse{display:flex!important;flex-basis:auto}.navbar-expand-xxl .navbar-toggler{display:none}.navbar-expand-xxl .offcanvas{background-color:transparent!important;border:0!important;flex-grow:1;height:auto!important;position:static;transform:none!important;transition:none;visibility:visible!important;width:auto!important;z-index:auto}.navbar-expand-xxl .offcanvas .offcanvas-header{display:none}.navbar-expand-xxl .offcanvas .offcanvas-body{display:flex;flex-grow:0;overflow-y:visible;padding:0}}.navbar-expand{flex-wrap:nowrap;justify-content:flex-start}.navbar-expand .navbar-nav{flex-direction:row}.navbar-expand .navbar-nav .dropdown-menu{position:absolute}.navbar-expand .navbar-nav .nav-link{padding-left:var(--bs-navbar-nav-link-padding-x);padding-right:var(--bs-navbar-nav-link-padding-x)}.navbar-expand .navbar-nav-scroll{overflow:visible}.navbar-expand .navbar-collapse{display:flex!important;flex-basis:auto}.navbar-expand .navbar-toggler{display:none}.navbar-expand .offcanvas{background-color:transparent!important;border:0!important;flex-grow:1;height:auto!important;position:static;transform:none!important;transition:none;visibility:visible!important;width:auto!important;z-index:auto}.navbar-expand .offcanvas .offcanvas-header{display:none}.navbar-expand .offcanvas .offcanvas-body{display:flex;flex-grow:0;overflow-y:visible;padding:0}.navbar-dark,.navbar[data-bs-theme=dark]{--bs-navbar-color:hsla(0,0%,100%,.55);--bs-navbar-hover-color:hsla(0,0%,100%,.75);--bs-navbar-disabled-color:hsla(0,0%,100%,.25);--bs-navbar-active-color:#fff;--bs-navbar-brand-color:#fff;--bs-navbar-brand-hover-color:#fff;--bs-navbar-toggler-border-color:hsla(0,0%,100%,.1)}.navbar-dark,.navbar[data-bs-theme=dark],[data-bs-theme=dark] .navbar-toggler-icon{--bs-navbar-toggler-icon-bg:url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3E%3Cpath stroke='rgba(255, 255, 255, 0.55)' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3E%3C/svg%3E")}.card{--bs-card-spacer-y:1rem;--bs-card-spacer-x:1rem;--bs-card-title-spacer-y:0.5rem;--bs-card-title-color: ;--bs-card-subtitle-color: ;--bs-card-border-width:var(--bs-border-width);--bs-card-border-color:var(--bs-border-color-translucent);--bs-card-border-radius:var(--bs-border-radius);--bs-card-box-shadow: ;--bs-card-inner-border-radius:calc(var(--bs-border-radius) - var(--bs-border-width));--bs-card-cap-padding-y:0.5rem;--bs-card-cap-padding-x:1rem;--bs-card-cap-bg:rgba(var(--bs-body-color-rgb),0.03);--bs-card-cap-color: ;--bs-card-height: ;--bs-card-color: ;--bs-card-bg:var(--bs-body-bg);--bs-card-img-overlay-padding:1rem;--bs-card-group-margin:0.75rem;color:var(--bs-body-color);display:flex;flex-direction:column;height:var(--bs-card-height);min-width:0;position:relative;word-wrap:break-word;background-clip:border-box;background-color:var(--bs-card-bg);border:var(--bs-card-border-width) solid var(--bs-card-border-color);border-radius:var(--bs-card-border-radius)}.card>hr{margin-left:0;margin-right:0}.card>.list-group{border-bottom:inherit;border-top:inherit}.card>.list-group:first-child{border-top-left-radius:var(--bs-card-inner-border-radius);border-top-right-radius:var(--bs-card-inner-border-radius);border-top-width:0}.card>.list-group:last-child{border-bottom-left-radius:var(--bs-card-inner-border-radius);border-bottom-right-radius:var(--bs-card-inner-border-radius);border-bottom-width:0}.card>.card-header+.list-group,.card>.list-group+.card-footer{border-top:0}.card-body{color:var(--bs-card-color);flex:1 1 auto;padding:var(--bs-card-spacer-y) var(--bs-card-spacer-x)}.card-title{color:var(--bs-card-title-color);margin-bottom:var(--bs-card-title-spacer-y)}.card-subtitle{color:var(--bs-card-subtitle-color);margin-top:calc(var(--bs-card-title-spacer-y)*-.5)}.card-subtitle,.card-text:last-child{margin-bottom:0}.card-link+.card-link{margin-left:var(--bs-card-spacer-x)}.card-header{background-color:var(--bs-card-cap-bg);border-bottom:var(--bs-card-border-width) solid var(--bs-card-border-color);color:var(--bs-card-cap-color);margin-bottom:0;padding:var(--bs-card-cap-padding-y) var(--bs-card-cap-padding-x)}.card-header:first-child{border-radius:var(--bs-card-inner-border-radius) var(--bs-card-inner-border-radius) 0 0}.card-footer{background-color:var(--bs-card-cap-bg);border-top:var(--bs-card-border-width) solid var(--bs-card-border-color);color:var(--bs-card-cap-color);padding:var(--bs-card-cap-padding-y) var(--bs-card-cap-padding-x)}.card-footer:last-child{border-radius:0 0 var(--bs-card-inner-border-radius) var(--bs-card-inner-border-radius)}.card-header-tabs{border-bottom:0;margin-bottom:calc(var(--bs-card-cap-padding-y)*-1);margin-left:calc(var(--bs-card-cap-padding-x)*-.5);margin-right:calc(var(--bs-card-cap-padding-x)*-.5)}.card-header-tabs .nav-link.active{background-color:var(--bs-card-bg);border-bottom-color:var(--bs-card-bg)}.card-header-pills{margin-left:calc(var(--bs-card-cap-padding-x)*-.5);margin-right:calc(var(--bs-card-cap-padding-x)*-.5)}.card-img-overlay{border-radius:var(--bs-card-inner-border-radius);bottom:0;left:0;padding:var(--bs-card-img-overlay-padding);position:absolute;right:0;top:0}.card-img,.card-img-bottom,.card-img-top{width:100%}.card-img,.card-img-top{border-top-left-radius:var(--bs-card-inner-border-radius);border-top-right-radius:var(--bs-card-inner-border-radius)}.card-img,.card-img-bottom{border-bottom-left-radius:var(--bs-card-inner-border-radius);border-bottom-right-radius:var(--bs-card-inner-border-radius)}.card-group>.card{margin-bottom:var(--bs-card-group-margin)}@media (min-width:576px){.card-group{display:flex;flex-flow:row wrap}.card-group>.card{flex:1 0 0%;margin-bottom:0}.card-group>.card+.card{border-left:0;margin-left:0}.card-group>.card:not(:last-child){border-bottom-right-radius:0;border-top-right-radius:0}.card-group>.card:not(:last-child) .card-header,.card-group>.card:not(:last-child) .card-img-top{border-top-right-radius:0}.card-group>.card:not(:last-child) .card-footer,.card-group>.card:not(:last-child) .card-img-bottom{border-bottom-right-radius:0}.card-group>.card:not(:first-child){border-bottom-left-radius:0;border-top-left-radius:0}.card-group>.card:not(:first-child) .card-header,.card-group>.card:not(:first-child) .card-img-top{border-top-left-radius:0}.card-group>.card:not(:first-child) .card-footer,.card-group>.card:not(:first-child) .card-img-bottom{border-bottom-left-radius:0}}.accordion{--bs-accordion-color:var(--bs-body-color);--bs-accordion-bg:var(--bs-body-bg);--bs-accordion-transition:color 0.15s ease-in-out,background-color 0.15s ease-in-out,border-color 0.15s ease-in-out,box-shadow 0.15s ease-in-out,border-radius 0.15s ease;--bs-accordion-border-color:var(--bs-border-color);--bs-accordion-border-width:var(--bs-border-width);--bs-accordion-border-radius:var(--bs-border-radius);--bs-accordion-inner-border-radius:calc(var(--bs-border-radius) - var(--bs-border-width));--bs-accordion-btn-padding-x:1.25rem;--bs-accordion-btn-padding-y:1rem;--bs-accordion-btn-color:var(--bs-body-color);--bs-accordion-btn-bg:var(--bs-accordion-bg);--bs-accordion-btn-icon:url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' stroke='%23212529' stroke-linecap='round' stroke-linejoin='round' viewBox='0 0 16 16'%3E%3Cpath d='m2 5 6 6 6-6'/%3E%3C/svg%3E");--bs-accordion-btn-icon-width:1.25rem;--bs-accordion-btn-icon-transform:rotate(-180deg);--bs-accordion-btn-icon-transition:transform 0.2s ease-in-out;--bs-accordion-btn-active-icon:url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' stroke='%2318345e' stroke-linecap='round' stroke-linejoin='round' viewBox='0 0 16 16'%3E%3Cpath d='m2 5 6 6 6-6'/%3E%3C/svg%3E");--bs-accordion-btn-focus-box-shadow:0 0 0 0.25rem rgba(60,131,235,.25);--bs-accordion-body-padding-x:1.25rem;--bs-accordion-body-padding-y:1rem;--bs-accordion-active-color:var(--bs-primary-text-emphasis);--bs-accordion-active-bg:var(--bs-primary-bg-subtle)}.accordion-button{align-items:center;background-color:var(--bs-accordion-btn-bg);border:0;border-radius:0;color:var(--bs-accordion-btn-color);display:flex;font-size:1rem;overflow-anchor:none;padding:var(--bs-accordion-btn-padding-y) var(--bs-accordion-btn-padding-x);position:relative;text-align:left;transition:var(--bs-accordion-transition);width:100%}@media (prefers-reduced-motion:reduce){.accordion-button{transition:none}}.accordion-button:not(.collapsed){background-color:var(--bs-accordion-active-bg);box-shadow:inset 0 calc(var(--bs-accordion-border-width)*-1) 0 var(--bs-accordion-border-color);color:var(--bs-accordion-active-color)}.accordion-button:not(.collapsed):after{background-image:var(--bs-accordion-btn-active-icon);transform:var(--bs-accordion-btn-icon-transform)}.accordion-button:after{background-image:var(--bs-accordion-btn-icon);background-repeat:no-repeat;background-size:var(--bs-accordion-btn-icon-width);content:"";flex-shrink:0;height:var(--bs-accordion-btn-icon-width);margin-left:auto;transition:var(--bs-accordion-btn-icon-transition);width:var(--bs-accordion-btn-icon-width)}@media (prefers-reduced-motion:reduce){.accordion-button:after{transition:none}}.accordion-button:hover{z-index:2}.accordion-button:focus{box-shadow:var(--bs-accordion-btn-focus-box-shadow);outline:0;z-index:3}.accordion-header{margin-bottom:0}.accordion-item{background-color:var(--bs-accordion-bg);border:var(--bs-accordion-border-width) solid var(--bs-accordion-border-color);color:var(--bs-accordion-color)}.accordion-item:first-of-type{border-top-left-radius:var(--bs-accordion-border-radius);border-top-right-radius:var(--bs-accordion-border-radius)}.accordion-item:first-of-type>.accordion-header .accordion-button{border-top-left-radius:var(--bs-accordion-inner-border-radius);border-top-right-radius:var(--bs-accordion-inner-border-radius)}.accordion-item:not(:first-of-type){border-top:0}.accordion-item:last-of-type{border-bottom-left-radius:var(--bs-accordion-border-radius);border-bottom-right-radius:var(--bs-accordion-border-radius)}.accordion-item:last-of-type>.accordion-header .accordion-button.collapsed{border-bottom-left-radius:var(--bs-accordion-inner-border-radius);border-bottom-right-radius:var(--bs-accordion-inner-border-radius)}.accordion-item:last-of-type>.accordion-collapse{border-bottom-left-radius:var(--bs-accordion-border-radius);border-bottom-right-radius:var(--bs-accordion-border-radius)}.accordion-body{padding:var(--bs-accordion-body-padding-y) var(--bs-accordion-body-padding-x)}.accordion-flush>.accordion-item{border-left:0;border-radius:0;border-right:0}.accordion-flush>.accordion-item:first-child{border-top:0}.accordion-flush>.accordion-item:last-child{border-bottom:0}.accordion-flush>.accordion-item>.accordion-collapse,.accordion-flush>.accordion-item>.accordion-header .accordion-button,.accordion-flush>.accordion-item>.accordion-header .accordion-button.collapsed{border-radius:0}[data-bs-theme=dark] .accordion-button:after{--bs-accordion-btn-icon:url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='%238ab5f3' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708'/%3E%3C/svg%3E");--bs-accordion-btn-active-icon:url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='%238ab5f3' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708'/%3E%3C/svg%3E")}.breadcrumb{--bs-breadcrumb-padding-x:0;--bs-breadcrumb-padding-y:0;--bs-breadcrumb-margin-bottom:1rem;--bs-breadcrumb-bg: ;--bs-breadcrumb-border-radius: ;--bs-breadcrumb-divider-color:var(--bs-secondary-color);--bs-breadcrumb-item-padding-x:0.5rem;--bs-breadcrumb-item-active-color:var(--bs-secondary-color);background-color:var(--bs-breadcrumb-bg);border-radius:var(--bs-breadcrumb-border-radius);display:flex;flex-wrap:wrap;font-size:var(--bs-breadcrumb-font-size);list-style:none;margin-bottom:var(--bs-breadcrumb-margin-bottom);padding:var(--bs-breadcrumb-padding-y) var(--bs-breadcrumb-padding-x)}.breadcrumb-item+.breadcrumb-item{padding-left:var(--bs-breadcrumb-item-padding-x)}.breadcrumb-item+.breadcrumb-item:before{color:var(--bs-breadcrumb-divider-color);content:var(--bs-breadcrumb-divider,"/");float:left;padding-right:var(--bs-breadcrumb-item-padding-x)}.breadcrumb-item.active{color:var(--bs-breadcrumb-item-active-color)}.pagination{--bs-pagination-padding-x:0.75rem;--bs-pagination-padding-y:0.375rem;--bs-pagination-font-size:1rem;--bs-pagination-color:var(--bs-link-color);--bs-pagination-bg:var(--bs-body-bg);--bs-pagination-border-width:var(--bs-border-width);--bs-pagination-border-color:var(--bs-border-color);--bs-pagination-border-radius:var(--bs-border-radius);--bs-pagination-hover-color:var(--bs-link-hover-color);--bs-pagination-hover-bg:var(--bs-tertiary-bg);--bs-pagination-hover-border-color:var(--bs-border-color);--bs-pagination-focus-color:var(--bs-link-hover-color);--bs-pagination-focus-bg:var(--bs-secondary-bg);--bs-pagination-focus-box-shadow:0 0 0 0.25rem rgba(60,131,235,.25);--bs-pagination-active-color:#fff;--bs-pagination-active-bg:#3c83eb;--bs-pagination-active-border-color:#3c83eb;--bs-pagination-disabled-color:var(--bs-secondary-color);--bs-pagination-disabled-bg:var(--bs-secondary-bg);--bs-pagination-disabled-border-color:var(--bs-border-color);display:flex;list-style:none;padding-left:0}.page-link{background-color:var(--bs-pagination-bg);border:var(--bs-pagination-border-width) solid var(--bs-pagination-border-color);color:var(--bs-pagination-color);display:block;font-size:var(--bs-pagination-font-size);padding:var(--bs-pagination-padding-y) var(--bs-pagination-padding-x);position:relative;text-decoration:none;transition:color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out}@media (prefers-reduced-motion:reduce){.page-link{transition:none}}.page-link:hover{background-color:var(--bs-pagination-hover-bg);border-color:var(--bs-pagination-hover-border-color);color:var(--bs-pagination-hover-color);z-index:2}.page-link:focus{background-color:var(--bs-pagination-focus-bg);box-shadow:var(--bs-pagination-focus-box-shadow);color:var(--bs-pagination-focus-color);outline:0;z-index:3}.active>.page-link,.page-link.active{background-color:var(--bs-pagination-active-bg);border-color:var(--bs-pagination-active-border-color);color:var(--bs-pagination-active-color);z-index:3}.disabled>.page-link,.page-link.disabled{background-color:var(--bs-pagination-disabled-bg);border-color:var(--bs-pagination-disabled-border-color);color:var(--bs-pagination-disabled-color);pointer-events:none}.page-item:not(:first-child) .page-link{margin-left:calc(var(--bs-border-width)*-1)}.page-item:first-child .page-link{border-bottom-left-radius:var(--bs-pagination-border-radius);border-top-left-radius:var(--bs-pagination-border-radius)}.page-item:last-child .page-link{border-bottom-right-radius:var(--bs-pagination-border-radius);border-top-right-radius:var(--bs-pagination-border-radius)}.pagination-lg{--bs-pagination-padding-x:1.5rem;--bs-pagination-padding-y:0.75rem;--bs-pagination-font-size:1.25rem;--bs-pagination-border-radius:var(--bs-border-radius-lg)}.pagination-sm{--bs-pagination-padding-x:0.5rem;--bs-pagination-padding-y:0.25rem;--bs-pagination-font-size:0.875rem;--bs-pagination-border-radius:var(--bs-border-radius-sm)}.badge{--bs-badge-padding-x:0.65em;--bs-badge-padding-y:0.35em;--bs-badge-font-size:0.75em;--bs-badge-font-weight:700;--bs-badge-color:#fff;--bs-badge-border-radius:var(--bs-border-radius);border-radius:var(--bs-badge-border-radius);color:var(--bs-badge-color);display:inline-block;font-size:var(--bs-badge-font-size);font-weight:var(--bs-badge-font-weight);line-height:1;padding:var(--bs-badge-padding-y) var(--bs-badge-padding-x);text-align:center;vertical-align:baseline;white-space:nowrap}.badge:empty{display:none}.btn .badge{position:relative;top:-1px}.alert{--bs-alert-bg:transparent;--bs-alert-padding-x:1rem;--bs-alert-padding-y:1rem;--bs-alert-margin-bottom:1rem;--bs-alert-color:inherit;--bs-alert-border-color:transparent;--bs-alert-border:var(--bs-border-width) solid var(--bs-alert-border-color);--bs-alert-border-radius:var(--bs-border-radius);--bs-alert-link-color:inherit;background-color:var(--bs-alert-bg);border:var(--bs-alert-border);border-radius:var(--bs-alert-border-radius);color:var(--bs-alert-color);margin-bottom:var(--bs-alert-margin-bottom);padding:var(--bs-alert-padding-y) var(--bs-alert-padding-x);position:relative}.alert-heading{color:inherit}.alert-link{color:var(--bs-alert-link-color);font-weight:700}.alert-dismissible{padding-right:3rem}.alert-dismissible .btn-close{padding:1.25rem 1rem;position:absolute;right:0;top:0;z-index:2}.alert-primary{--bs-alert-color:var(--bs-primary-text-emphasis);--bs-alert-bg:var(--bs-primary-bg-subtle);--bs-alert-border-color:var(--bs-primary-border-subtle);--bs-alert-link-color:var(--bs-primary-text-emphasis)}.alert-secondary{--bs-alert-color:var(--bs-secondary-text-emphasis);--bs-alert-bg:var(--bs-secondary-bg-subtle);--bs-alert-border-color:var(--bs-secondary-border-subtle);--bs-alert-link-color:var(--bs-secondary-text-emphasis)}.alert-success{--bs-alert-color:var(--bs-success-text-emphasis);--bs-alert-bg:var(--bs-success-bg-subtle);--bs-alert-border-color:var(--bs-success-border-subtle);--bs-alert-link-color:var(--bs-success-text-emphasis)}.alert-info{--bs-alert-color:var(--bs-info-text-emphasis);--bs-alert-bg:var(--bs-info-bg-subtle);--bs-alert-border-color:var(--bs-info-border-subtle);--bs-alert-link-color:var(--bs-info-text-emphasis)}.alert-warning{--bs-alert-color:var(--bs-warning-text-emphasis);--bs-alert-bg:var(--bs-warning-bg-subtle);--bs-alert-border-color:var(--bs-warning-border-subtle);--bs-alert-link-color:var(--bs-warning-text-emphasis)}.alert-danger{--bs-alert-color:var(--bs-danger-text-emphasis);--bs-alert-bg:var(--bs-danger-bg-subtle);--bs-alert-border-color:var(--bs-danger-border-subtle);--bs-alert-link-color:var(--bs-danger-text-emphasis)}.alert-light{--bs-alert-color:var(--bs-light-text-emphasis);--bs-alert-bg:var(--bs-light-bg-subtle);--bs-alert-border-color:var(--bs-light-border-subtle);--bs-alert-link-color:var(--bs-light-text-emphasis)}.alert-dark{--bs-alert-color:var(--bs-dark-text-emphasis);--bs-alert-bg:var(--bs-dark-bg-subtle);--bs-alert-border-color:var(--bs-dark-border-subtle);--bs-alert-link-color:var(--bs-dark-text-emphasis)}@keyframes progress-bar-stripes{0%{background-position-x:1rem}}.progress,.progress-stacked{--bs-progress-height:1rem;--bs-progress-font-size:0.75rem;--bs-progress-bg:var(--bs-secondary-bg);--bs-progress-border-radius:var(--bs-border-radius);--bs-progress-box-shadow:var(--bs-box-shadow-inset);--bs-progress-bar-color:#fff;--bs-progress-bar-bg:#3c83eb;--bs-progress-bar-transition:width 0.6s ease;background-color:var(--bs-progress-bg);border-radius:var(--bs-progress-border-radius);display:flex;font-size:var(--bs-progress-font-size);height:var(--bs-progress-height);overflow:hidden}.progress-bar{background-color:var(--bs-progress-bar-bg);color:var(--bs-progress-bar-color);display:flex;flex-direction:column;justify-content:center;overflow:hidden;text-align:center;transition:var(--bs-progress-bar-transition);white-space:nowrap}@media (prefers-reduced-motion:reduce){.progress-bar{transition:none}}.progress-bar-striped{background-image:linear-gradient(45deg,hsla(0,0%,100%,.15) 25%,transparent 0,transparent 50%,hsla(0,0%,100%,.15) 0,hsla(0,0%,100%,.15) 75%,transparent 0,transparent);background-size:var(--bs-progress-height) var(--bs-progress-height)}.progress-stacked>.progress{overflow:visible}.progress-stacked>.progress>.progress-bar{width:100%}.progress-bar-animated{animation:progress-bar-stripes 1s linear infinite}@media (prefers-reduced-motion:reduce){.progress-bar-animated{animation:none}}.list-group{--bs-list-group-color:var(--bs-body-color);--bs-list-group-bg:var(--bs-body-bg);--bs-list-group-border-color:var(--bs-border-color);--bs-list-group-border-width:var(--bs-border-width);--bs-list-group-border-radius:var(--bs-border-radius);--bs-list-group-item-padding-x:1rem;--bs-list-group-item-padding-y:0.5rem;--bs-list-group-action-color:var(--bs-secondary-color);--bs-list-group-action-hover-color:var(--bs-emphasis-color);--bs-list-group-action-hover-bg:var(--bs-tertiary-bg);--bs-list-group-action-active-color:var(--bs-body-color);--bs-list-group-action-active-bg:var(--bs-secondary-bg);--bs-list-group-disabled-color:var(--bs-secondary-color);--bs-list-group-disabled-bg:var(--bs-body-bg);--bs-list-group-active-color:#fff;--bs-list-group-active-bg:#3c83eb;--bs-list-group-active-border-color:#3c83eb;border-radius:var(--bs-list-group-border-radius);display:flex;flex-direction:column;margin-bottom:0;padding-left:0}.list-group-numbered{counter-reset:section;list-style-type:none}.list-group-numbered>.list-group-item:before{content:counters(section,".") ". ";counter-increment:section}.list-group-item-action{color:var(--bs-list-group-action-color);text-align:inherit;width:100%}.list-group-item-action:focus,.list-group-item-action:hover{background-color:var(--bs-list-group-action-hover-bg);color:var(--bs-list-group-action-hover-color);text-decoration:none;z-index:1}.list-group-item-action:active{background-color:var(--bs-list-group-action-active-bg);color:var(--bs-list-group-action-active-color)}.list-group-item{background-color:var(--bs-list-group-bg);border:var(--bs-list-group-border-width) solid var(--bs-list-group-border-color);color:var(--bs-list-group-color);display:block;padding:var(--bs-list-group-item-padding-y) var(--bs-list-group-item-padding-x);position:relative;text-decoration:none}.list-group-item:first-child{border-top-left-radius:inherit;border-top-right-radius:inherit}.list-group-item:last-child{border-bottom-left-radius:inherit;border-bottom-right-radius:inherit}.list-group-item.disabled,.list-group-item:disabled{background-color:var(--bs-list-group-disabled-bg);color:var(--bs-list-group-disabled-color);pointer-events:none}.list-group-item.active{background-color:var(--bs-list-group-active-bg);border-color:var(--bs-list-group-active-border-color);color:var(--bs-list-group-active-color);z-index:2}.list-group-item+.list-group-item{border-top-width:0}.list-group-item+.list-group-item.active{border-top-width:var(--bs-list-group-border-width);margin-top:calc(var(--bs-list-group-border-width)*-1)}.list-group-horizontal{flex-direction:row}.list-group-horizontal>.list-group-item:first-child:not(:last-child){border-bottom-left-radius:var(--bs-list-group-border-radius);border-top-right-radius:0}.list-group-horizontal>.list-group-item:last-child:not(:first-child){border-bottom-left-radius:0;border-top-right-radius:var(--bs-list-group-border-radius)}.list-group-horizontal>.list-group-item.active{margin-top:0}.list-group-horizontal>.list-group-item+.list-group-item{border-left-width:0;border-top-width:var(--bs-list-group-border-width)}.list-group-horizontal>.list-group-item+.list-group-item.active{border-left-width:var(--bs-list-group-border-width);margin-left:calc(var(--bs-list-group-border-width)*-1)}@media (min-width:576px){.list-group-horizontal-sm{flex-direction:row}.list-group-horizontal-sm>.list-group-item:first-child:not(:last-child){border-bottom-left-radius:var(--bs-list-group-border-radius);border-top-right-radius:0}.list-group-horizontal-sm>.list-group-item:last-child:not(:first-child){border-bottom-left-radius:0;border-top-right-radius:var(--bs-list-group-border-radius)}.list-group-horizontal-sm>.list-group-item.active{margin-top:0}.list-group-horizontal-sm>.list-group-item+.list-group-item{border-left-width:0;border-top-width:var(--bs-list-group-border-width)}.list-group-horizontal-sm>.list-group-item+.list-group-item.active{border-left-width:var(--bs-list-group-border-width);margin-left:calc(var(--bs-list-group-border-width)*-1)}}@media (min-width:768px){.list-group-horizontal-md{flex-direction:row}.list-group-horizontal-md>.list-group-item:first-child:not(:last-child){border-bottom-left-radius:var(--bs-list-group-border-radius);border-top-right-radius:0}.list-group-horizontal-md>.list-group-item:last-child:not(:first-child){border-bottom-left-radius:0;border-top-right-radius:var(--bs-list-group-border-radius)}.list-group-horizontal-md>.list-group-item.active{margin-top:0}.list-group-horizontal-md>.list-group-item+.list-group-item{border-left-width:0;border-top-width:var(--bs-list-group-border-width)}.list-group-horizontal-md>.list-group-item+.list-group-item.active{border-left-width:var(--bs-list-group-border-width);margin-left:calc(var(--bs-list-group-border-width)*-1)}}@media (min-width:992px){.list-group-horizontal-lg{flex-direction:row}.list-group-horizontal-lg>.list-group-item:first-child:not(:last-child){border-bottom-left-radius:var(--bs-list-group-border-radius);border-top-right-radius:0}.list-group-horizontal-lg>.list-group-item:last-child:not(:first-child){border-bottom-left-radius:0;border-top-right-radius:var(--bs-list-group-border-radius)}.list-group-horizontal-lg>.list-group-item.active{margin-top:0}.list-group-horizontal-lg>.list-group-item+.list-group-item{border-left-width:0;border-top-width:var(--bs-list-group-border-width)}.list-group-horizontal-lg>.list-group-item+.list-group-item.active{border-left-width:var(--bs-list-group-border-width);margin-left:calc(var(--bs-list-group-border-width)*-1)}}@media (min-width:1200px){.list-group-horizontal-xl{flex-direction:row}.list-group-horizontal-xl>.list-group-item:first-child:not(:last-child){border-bottom-left-radius:var(--bs-list-group-border-radius);border-top-right-radius:0}.list-group-horizontal-xl>.list-group-item:last-child:not(:first-child){border-bottom-left-radius:0;border-top-right-radius:var(--bs-list-group-border-radius)}.list-group-horizontal-xl>.list-group-item.active{margin-top:0}.list-group-horizontal-xl>.list-group-item+.list-group-item{border-left-width:0;border-top-width:var(--bs-list-group-border-width)}.list-group-horizontal-xl>.list-group-item+.list-group-item.active{border-left-width:var(--bs-list-group-border-width);margin-left:calc(var(--bs-list-group-border-width)*-1)}}@media (min-width:1400px){.list-group-horizontal-xxl{flex-direction:row}.list-group-horizontal-xxl>.list-group-item:first-child:not(:last-child){border-bottom-left-radius:var(--bs-list-group-border-radius);border-top-right-radius:0}.list-group-horizontal-xxl>.list-group-item:last-child:not(:first-child){border-bottom-left-radius:0;border-top-right-radius:var(--bs-list-group-border-radius)}.list-group-horizontal-xxl>.list-group-item.active{margin-top:0}.list-group-horizontal-xxl>.list-group-item+.list-group-item{border-left-width:0;border-top-width:var(--bs-list-group-border-width)}.list-group-horizontal-xxl>.list-group-item+.list-group-item.active{border-left-width:var(--bs-list-group-border-width);margin-left:calc(var(--bs-list-group-border-width)*-1)}}.list-group-flush{border-radius:0}.list-group-flush>.list-group-item{border-width:0 0 var(--bs-list-group-border-width)}.list-group-flush>.list-group-item:last-child{border-bottom-width:0}.list-group-item-primary{--bs-list-group-color:var(--bs-primary-text-emphasis);--bs-list-group-bg:var(--bs-primary-bg-subtle);--bs-list-group-border-color:var(--bs-primary-border-subtle);--bs-list-group-action-hover-color:var(--bs-emphasis-color);--bs-list-group-action-hover-bg:var(--bs-primary-border-subtle);--bs-list-group-action-active-color:var(--bs-emphasis-color);--bs-list-group-action-active-bg:var(--bs-primary-border-subtle);--bs-list-group-active-color:var(--bs-primary-bg-subtle);--bs-list-group-active-bg:var(--bs-primary-text-emphasis);--bs-list-group-active-border-color:var(--bs-primary-text-emphasis)}.list-group-item-secondary{--bs-list-group-color:var(--bs-secondary-text-emphasis);--bs-list-group-bg:var(--bs-secondary-bg-subtle);--bs-list-group-border-color:var(--bs-secondary-border-subtle);--bs-list-group-action-hover-color:var(--bs-emphasis-color);--bs-list-group-action-hover-bg:var(--bs-secondary-border-subtle);--bs-list-group-action-active-color:var(--bs-emphasis-color);--bs-list-group-action-active-bg:var(--bs-secondary-border-subtle);--bs-list-group-active-color:var(--bs-secondary-bg-subtle);--bs-list-group-active-bg:var(--bs-secondary-text-emphasis);--bs-list-group-active-border-color:var(--bs-secondary-text-emphasis)}.list-group-item-success{--bs-list-group-color:var(--bs-success-text-emphasis);--bs-list-group-bg:var(--bs-success-bg-subtle);--bs-list-group-border-color:var(--bs-success-border-subtle);--bs-list-group-action-hover-color:var(--bs-emphasis-color);--bs-list-group-action-hover-bg:var(--bs-success-border-subtle);--bs-list-group-action-active-color:var(--bs-emphasis-color);--bs-list-group-action-active-bg:var(--bs-success-border-subtle);--bs-list-group-active-color:var(--bs-success-bg-subtle);--bs-list-group-active-bg:var(--bs-success-text-emphasis);--bs-list-group-active-border-color:var(--bs-success-text-emphasis)}.list-group-item-info{--bs-list-group-color:var(--bs-info-text-emphasis);--bs-list-group-bg:var(--bs-info-bg-subtle);--bs-list-group-border-color:var(--bs-info-border-subtle);--bs-list-group-action-hover-color:var(--bs-emphasis-color);--bs-list-group-action-hover-bg:var(--bs-info-border-subtle);--bs-list-group-action-active-color:var(--bs-emphasis-color);--bs-list-group-action-active-bg:var(--bs-info-border-subtle);--bs-list-group-active-color:var(--bs-info-bg-subtle);--bs-list-group-active-bg:var(--bs-info-text-emphasis);--bs-list-group-active-border-color:var(--bs-info-text-emphasis)}.list-group-item-warning{--bs-list-group-color:var(--bs-warning-text-emphasis);--bs-list-group-bg:var(--bs-warning-bg-subtle);--bs-list-group-border-color:var(--bs-warning-border-subtle);--bs-list-group-action-hover-color:var(--bs-emphasis-color);--bs-list-group-action-hover-bg:var(--bs-warning-border-subtle);--bs-list-group-action-active-color:var(--bs-emphasis-color);--bs-list-group-action-active-bg:var(--bs-warning-border-subtle);--bs-list-group-active-color:var(--bs-warning-bg-subtle);--bs-list-group-active-bg:var(--bs-warning-text-emphasis);--bs-list-group-active-border-color:var(--bs-warning-text-emphasis)}.list-group-item-danger{--bs-list-group-color:var(--bs-danger-text-emphasis);--bs-list-group-bg:var(--bs-danger-bg-subtle);--bs-list-group-border-color:var(--bs-danger-border-subtle);--bs-list-group-action-hover-color:var(--bs-emphasis-color);--bs-list-group-action-hover-bg:var(--bs-danger-border-subtle);--bs-list-group-action-active-color:var(--bs-emphasis-color);--bs-list-group-action-active-bg:var(--bs-danger-border-subtle);--bs-list-group-active-color:var(--bs-danger-bg-subtle);--bs-list-group-active-bg:var(--bs-danger-text-emphasis);--bs-list-group-active-border-color:var(--bs-danger-text-emphasis)}.list-group-item-light{--bs-list-group-color:var(--bs-light-text-emphasis);--bs-list-group-bg:var(--bs-light-bg-subtle);--bs-list-group-border-color:var(--bs-light-border-subtle);--bs-list-group-action-hover-color:var(--bs-emphasis-color);--bs-list-group-action-hover-bg:var(--bs-light-border-subtle);--bs-list-group-action-active-color:var(--bs-emphasis-color);--bs-list-group-action-active-bg:var(--bs-light-border-subtle);--bs-list-group-active-color:var(--bs-light-bg-subtle);--bs-list-group-active-bg:var(--bs-light-text-emphasis);--bs-list-group-active-border-color:var(--bs-light-text-emphasis)}.list-group-item-dark{--bs-list-group-color:var(--bs-dark-text-emphasis);--bs-list-group-bg:var(--bs-dark-bg-subtle);--bs-list-group-border-color:var(--bs-dark-border-subtle);--bs-list-group-action-hover-color:var(--bs-emphasis-color);--bs-list-group-action-hover-bg:var(--bs-dark-border-subtle);--bs-list-group-action-active-color:var(--bs-emphasis-color);--bs-list-group-action-active-bg:var(--bs-dark-border-subtle);--bs-list-group-active-color:var(--bs-dark-bg-subtle);--bs-list-group-active-bg:var(--bs-dark-text-emphasis);--bs-list-group-active-border-color:var(--bs-dark-text-emphasis)}.btn-close{--bs-btn-close-color:#000;--bs-btn-close-bg:url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3E%3Cpath d='M.293.293a1 1 0 0 1 1.414 0L8 6.586 14.293.293a1 1 0 1 1 1.414 1.414L9.414 8l6.293 6.293a1 1 0 0 1-1.414 1.414L8 9.414l-6.293 6.293a1 1 0 0 1-1.414-1.414L6.586 8 .293 1.707a1 1 0 0 1 0-1.414'/%3E%3C/svg%3E");--bs-btn-close-opacity:0.5;--bs-btn-close-hover-opacity:0.75;--bs-btn-close-focus-shadow:0 0 0 0.25rem rgba(60,131,235,.25);--bs-btn-close-focus-opacity:1;--bs-btn-close-disabled-opacity:0.25;--bs-btn-close-white-filter:invert(1) grayscale(100%) brightness(200%);background:transparent var(--bs-btn-close-bg) center/1em auto no-repeat;border:0;border-radius:.375rem;box-sizing:content-box;height:1em;opacity:var(--bs-btn-close-opacity);padding:.25em;width:1em}.btn-close,.btn-close:hover{color:var(--bs-btn-close-color)}.btn-close:hover{opacity:var(--bs-btn-close-hover-opacity);text-decoration:none}.btn-close:focus{box-shadow:var(--bs-btn-close-focus-shadow);opacity:var(--bs-btn-close-focus-opacity);outline:0}.btn-close.disabled,.btn-close:disabled{opacity:var(--bs-btn-close-disabled-opacity);pointer-events:none;-webkit-user-select:none;-moz-user-select:none;user-select:none}.btn-close-white,[data-bs-theme=dark] .btn-close{filter:var(--bs-btn-close-white-filter)}.toast{--bs-toast-zindex:1090;--bs-toast-padding-x:0.75rem;--bs-toast-padding-y:0.5rem;--bs-toast-spacing:1.5rem;--bs-toast-max-width:350px;--bs-toast-font-size:0.875rem;--bs-toast-color: ;--bs-toast-bg:rgba(var(--bs-body-bg-rgb),0.85);--bs-toast-border-width:var(--bs-border-width);--bs-toast-border-color:var(--bs-border-color-translucent);--bs-toast-border-radius:var(--bs-border-radius);--bs-toast-box-shadow:var(--bs-box-shadow);--bs-toast-header-color:var(--bs-secondary-color);--bs-toast-header-bg:rgba(var(--bs-body-bg-rgb),0.85);--bs-toast-header-border-color:var(--bs-border-color-translucent);background-clip:padding-box;background-color:var(--bs-toast-bg);border:var(--bs-toast-border-width) solid var(--bs-toast-border-color);border-radius:var(--bs-toast-border-radius);box-shadow:var(--bs-toast-box-shadow);color:var(--bs-toast-color);font-size:var(--bs-toast-font-size);max-width:100%;pointer-events:auto;width:var(--bs-toast-max-width)}.toast.showing{opacity:0}.toast:not(.show){display:none}.toast-container{--bs-toast-zindex:1090;max-width:100%;pointer-events:none;position:absolute;width:-moz-max-content;width:max-content;z-index:var(--bs-toast-zindex)}.toast-container>:not(:last-child){margin-bottom:var(--bs-toast-spacing)}.toast-header{align-items:center;background-clip:padding-box;background-color:var(--bs-toast-header-bg);border-bottom:var(--bs-toast-border-width) solid var(--bs-toast-header-border-color);border-top-left-radius:calc(var(--bs-toast-border-radius) - var(--bs-toast-border-width));border-top-right-radius:calc(var(--bs-toast-border-radius) - var(--bs-toast-border-width));color:var(--bs-toast-header-color);display:flex;padding:var(--bs-toast-padding-y) var(--bs-toast-padding-x)}.toast-header .btn-close{margin-left:var(--bs-toast-padding-x);margin-right:calc(var(--bs-toast-padding-x)*-.5)}.toast-body{padding:var(--bs-toast-padding-x);word-wrap:break-word}.modal{--bs-modal-zindex:1055;--bs-modal-width:500px;--bs-modal-padding:1rem;--bs-modal-margin:0.5rem;--bs-modal-color: ;--bs-modal-bg:var(--bs-body-bg);--bs-modal-border-color:var(--bs-border-color-translucent);--bs-modal-border-width:var(--bs-border-width);--bs-modal-border-radius:var(--bs-border-radius-lg);--bs-modal-box-shadow:var(--bs-box-shadow-sm);--bs-modal-inner-border-radius:calc(var(--bs-border-radius-lg) - var(--bs-border-width));--bs-modal-header-padding-x:1rem;--bs-modal-header-padding-y:1rem;--bs-modal-header-padding:1rem 1rem;--bs-modal-header-border-color:var(--bs-border-color);--bs-modal-header-border-width:var(--bs-border-width);--bs-modal-title-line-height:1.5;--bs-modal-footer-gap:0.5rem;--bs-modal-footer-bg: ;--bs-modal-footer-border-color:var(--bs-border-color);--bs-modal-footer-border-width:var(--bs-border-width);display:none;height:100%;left:0;outline:0;overflow-x:hidden;overflow-y:auto;position:fixed;top:0;width:100%;z-index:var(--bs-modal-zindex)}.modal-dialog{margin:var(--bs-modal-margin);pointer-events:none;position:relative;width:auto}.modal.fade .modal-dialog{transform:translateY(-50px);transition:transform .3s ease-out}@media (prefers-reduced-motion:reduce){.modal.fade .modal-dialog{transition:none}}.modal.show .modal-dialog{transform:none}.modal.modal-static .modal-dialog{transform:scale(1.02)}.modal-dialog-scrollable{height:calc(100% - var(--bs-modal-margin)*2)}.modal-dialog-scrollable .modal-content{max-height:100%;overflow:hidden}.modal-dialog-scrollable .modal-body{overflow-y:auto}.modal-dialog-centered{align-items:center;display:flex;min-height:calc(100% - var(--bs-modal-margin)*2)}.modal-content{background-clip:padding-box;background-color:var(--bs-modal-bg);border:var(--bs-modal-border-width) solid var(--bs-modal-border-color);border-radius:var(--bs-modal-border-radius);color:var(--bs-modal-color);display:flex;flex-direction:column;outline:0;pointer-events:auto;position:relative;width:100%}.modal-backdrop{--bs-backdrop-zindex:1050;--bs-backdrop-bg:#000;--bs-backdrop-opacity:0.5;background-color:var(--bs-backdrop-bg);height:100vh;left:0;position:fixed;top:0;width:100vw;z-index:var(--bs-backdrop-zindex)}.modal-backdrop.fade{opacity:0}.modal-backdrop.show{opacity:var(--bs-backdrop-opacity)}.modal-header{align-items:center;border-bottom:var(--bs-modal-header-border-width) solid var(--bs-modal-header-border-color);border-top-left-radius:var(--bs-modal-inner-border-radius);border-top-right-radius:var(--bs-modal-inner-border-radius);display:flex;flex-shrink:0;padding:var(--bs-modal-header-padding)}.modal-header .btn-close{margin:calc(var(--bs-modal-header-padding-y)*-.5) calc(var(--bs-modal-header-padding-x)*-.5) calc(var(--bs-modal-header-padding-y)*-.5) auto;padding:calc(var(--bs-modal-header-padding-y)*.5) calc(var(--bs-modal-header-padding-x)*.5)}.modal-title{line-height:var(--bs-modal-title-line-height);margin-bottom:0}.modal-body{flex:1 1 auto;padding:var(--bs-modal-padding);position:relative}.modal-footer{align-items:center;background-color:var(--bs-modal-footer-bg);border-bottom-left-radius:var(--bs-modal-inner-border-radius);border-bottom-right-radius:var(--bs-modal-inner-border-radius);border-top:var(--bs-modal-footer-border-width) solid var(--bs-modal-footer-border-color);display:flex;flex-shrink:0;flex-wrap:wrap;justify-content:flex-end;padding:calc(var(--bs-modal-padding) - var(--bs-modal-footer-gap)*.5)}.modal-footer>*{margin:calc(var(--bs-modal-footer-gap)*.5)}@media (min-width:576px){.modal{--bs-modal-margin:1.75rem;--bs-modal-box-shadow:var(--bs-box-shadow)}.modal-dialog{margin-left:auto;margin-right:auto;max-width:var(--bs-modal-width)}.modal-sm{--bs-modal-width:300px}}@media (min-width:992px){.modal-lg,.modal-xl{--bs-modal-width:800px}}@media (min-width:1200px){.modal-xl{--bs-modal-width:1140px}}.modal-fullscreen{height:100%;margin:0;max-width:none;width:100vw}.modal-fullscreen .modal-content{border:0;border-radius:0;height:100%}.modal-fullscreen .modal-footer,.modal-fullscreen .modal-header{border-radius:0}.modal-fullscreen .modal-body{overflow-y:auto}@media (max-width:575.98px){.modal-fullscreen-sm-down{height:100%;margin:0;max-width:none;width:100vw}.modal-fullscreen-sm-down .modal-content{border:0;border-radius:0;height:100%}.modal-fullscreen-sm-down .modal-footer,.modal-fullscreen-sm-down .modal-header{border-radius:0}.modal-fullscreen-sm-down .modal-body{overflow-y:auto}}@media (max-width:767.98px){.modal-fullscreen-md-down{height:100%;margin:0;max-width:none;width:100vw}.modal-fullscreen-md-down .modal-content{border:0;border-radius:0;height:100%}.modal-fullscreen-md-down .modal-footer,.modal-fullscreen-md-down .modal-header{border-radius:0}.modal-fullscreen-md-down .modal-body{overflow-y:auto}}@media (max-width:991.98px){.modal-fullscreen-lg-down{height:100%;margin:0;max-width:none;width:100vw}.modal-fullscreen-lg-down .modal-content{border:0;border-radius:0;height:100%}.modal-fullscreen-lg-down .modal-footer,.modal-fullscreen-lg-down .modal-header{border-radius:0}.modal-fullscreen-lg-down .modal-body{overflow-y:auto}}@media (max-width:1199.98px){.modal-fullscreen-xl-down{height:100%;margin:0;max-width:none;width:100vw}.modal-fullscreen-xl-down .modal-content{border:0;border-radius:0;height:100%}.modal-fullscreen-xl-down .modal-footer,.modal-fullscreen-xl-down .modal-header{border-radius:0}.modal-fullscreen-xl-down .modal-body{overflow-y:auto}}@media (max-width:1399.98px){.modal-fullscreen-xxl-down{height:100%;margin:0;max-width:none;width:100vw}.modal-fullscreen-xxl-down .modal-content{border:0;border-radius:0;height:100%}.modal-fullscreen-xxl-down .modal-footer,.modal-fullscreen-xxl-down .modal-header{border-radius:0}.modal-fullscreen-xxl-down .modal-body{overflow-y:auto}}.tooltip{--bs-tooltip-zindex:1080;--bs-tooltip-max-width:200px;--bs-tooltip-padding-x:0.5rem;--bs-tooltip-padding-y:0.25rem;--bs-tooltip-margin: ;--bs-tooltip-font-size:0.875rem;--bs-tooltip-color:var(--bs-body-bg);--bs-tooltip-bg:var(--bs-emphasis-color);--bs-tooltip-border-radius:var(--bs-border-radius);--bs-tooltip-opacity:0.9;--bs-tooltip-arrow-width:0.8rem;--bs-tooltip-arrow-height:0.4rem;display:block;font-family:var(--bs-font-sans-serif);font-size:var(--bs-tooltip-font-size);font-style:normal;font-weight:400;letter-spacing:normal;line-break:auto;line-height:1.5;margin:var(--bs-tooltip-margin);text-align:left;text-align:start;text-decoration:none;text-shadow:none;text-transform:none;white-space:normal;word-break:normal;word-spacing:normal;z-index:var(--bs-tooltip-zindex);word-wrap:break-word;opacity:0}.tooltip.show{opacity:var(--bs-tooltip-opacity)}.tooltip .tooltip-arrow{display:block;height:var(--bs-tooltip-arrow-height);width:var(--bs-tooltip-arrow-width)}.tooltip .tooltip-arrow:before{border-color:transparent;border-style:solid;content:"";position:absolute}.bs-tooltip-auto[data-popper-placement^=top] .tooltip-arrow,.bs-tooltip-top .tooltip-arrow{bottom:calc(var(--bs-tooltip-arrow-height)*-1)}.bs-tooltip-auto[data-popper-placement^=top] .tooltip-arrow:before,.bs-tooltip-top .tooltip-arrow:before{border-top-color:var(--bs-tooltip-bg);border-width:var(--bs-tooltip-arrow-height) calc(var(--bs-tooltip-arrow-width)*.5) 0;top:-1px}.bs-tooltip-auto[data-popper-placement^=right] .tooltip-arrow,.bs-tooltip-end .tooltip-arrow{height:var(--bs-tooltip-arrow-width);left:calc(var(--bs-tooltip-arrow-height)*-1);width:var(--bs-tooltip-arrow-height)}.bs-tooltip-auto[data-popper-placement^=right] .tooltip-arrow:before,.bs-tooltip-end .tooltip-arrow:before{border-right-color:var(--bs-tooltip-bg);border-width:calc(var(--bs-tooltip-arrow-width)*.5) var(--bs-tooltip-arrow-height) calc(var(--bs-tooltip-arrow-width)*.5) 0;right:-1px}.bs-tooltip-auto[data-popper-placement^=bottom] .tooltip-arrow,.bs-tooltip-bottom .tooltip-arrow{top:calc(var(--bs-tooltip-arrow-height)*-1)}.bs-tooltip-auto[data-popper-placement^=bottom] .tooltip-arrow:before,.bs-tooltip-bottom .tooltip-arrow:before{border-bottom-color:var(--bs-tooltip-bg);border-width:0 calc(var(--bs-tooltip-arrow-width)*.5) var(--bs-tooltip-arrow-height);bottom:-1px}.bs-tooltip-auto[data-popper-placement^=left] .tooltip-arrow,.bs-tooltip-start .tooltip-arrow{height:var(--bs-tooltip-arrow-width);right:calc(var(--bs-tooltip-arrow-height)*-1);width:var(--bs-tooltip-arrow-height)}.bs-tooltip-auto[data-popper-placement^=left] .tooltip-arrow:before,.bs-tooltip-start .tooltip-arrow:before{border-left-color:var(--bs-tooltip-bg);border-width:calc(var(--bs-tooltip-arrow-width)*.5) 0 calc(var(--bs-tooltip-arrow-width)*.5) var(--bs-tooltip-arrow-height);left:-1px}.tooltip-inner{background-color:var(--bs-tooltip-bg);border-radius:var(--bs-tooltip-border-radius);color:var(--bs-tooltip-color);max-width:var(--bs-tooltip-max-width);padding:var(--bs-tooltip-padding-y) var(--bs-tooltip-padding-x);text-align:center}.popover{--bs-popover-zindex:1070;--bs-popover-max-width:276px;--bs-popover-font-size:0.875rem;--bs-popover-bg:var(--bs-body-bg);--bs-popover-border-width:var(--bs-border-width);--bs-popover-border-color:var(--bs-border-color-translucent);--bs-popover-border-radius:var(--bs-border-radius-lg);--bs-popover-inner-border-radius:calc(var(--bs-border-radius-lg) - var(--bs-border-width));--bs-popover-box-shadow:var(--bs-box-shadow);--bs-popover-header-padding-x:1rem;--bs-popover-header-padding-y:0.5rem;--bs-popover-header-font-size:1rem;--bs-popover-header-color:inherit;--bs-popover-header-bg:var(--bs-secondary-bg);--bs-popover-body-padding-x:1rem;--bs-popover-body-padding-y:1rem;--bs-popover-body-color:var(--bs-body-color);--bs-popover-arrow-width:1rem;--bs-popover-arrow-height:0.5rem;--bs-popover-arrow-border:var(--bs-popover-border-color);display:block;font-family:var(--bs-font-sans-serif);font-size:var(--bs-popover-font-size);font-style:normal;font-weight:400;letter-spacing:normal;line-break:auto;line-height:1.5;max-width:var(--bs-popover-max-width);text-align:left;text-align:start;text-decoration:none;text-shadow:none;text-transform:none;white-space:normal;word-break:normal;word-spacing:normal;z-index:var(--bs-popover-zindex);word-wrap:break-word;background-clip:padding-box;background-color:var(--bs-popover-bg);border:var(--bs-popover-border-width) solid var(--bs-popover-border-color);border-radius:var(--bs-popover-border-radius)}.popover .popover-arrow{display:block;height:var(--bs-popover-arrow-height);width:var(--bs-popover-arrow-width)}.popover .popover-arrow:after,.popover .popover-arrow:before{border:0 solid transparent;content:"";display:block;position:absolute}.bs-popover-auto[data-popper-placement^=top]>.popover-arrow,.bs-popover-top>.popover-arrow{bottom:calc((var(--bs-popover-arrow-height))*-1 - var(--bs-popover-border-width))}.bs-popover-auto[data-popper-placement^=top]>.popover-arrow:after,.bs-popover-auto[data-popper-placement^=top]>.popover-arrow:before,.bs-popover-top>.popover-arrow:after,.bs-popover-top>.popover-arrow:before{border-width:var(--bs-popover-arrow-height) calc(var(--bs-popover-arrow-width)*.5) 0}.bs-popover-auto[data-popper-placement^=top]>.popover-arrow:before,.bs-popover-top>.popover-arrow:before{border-top-color:var(--bs-popover-arrow-border);bottom:0}.bs-popover-auto[data-popper-placement^=top]>.popover-arrow:after,.bs-popover-top>.popover-arrow:after{border-top-color:var(--bs-popover-bg);bottom:var(--bs-popover-border-width)}.bs-popover-auto[data-popper-placement^=right]>.popover-arrow,.bs-popover-end>.popover-arrow{height:var(--bs-popover-arrow-width);left:calc((var(--bs-popover-arrow-height))*-1 - var(--bs-popover-border-width));width:var(--bs-popover-arrow-height)}.bs-popover-auto[data-popper-placement^=right]>.popover-arrow:after,.bs-popover-auto[data-popper-placement^=right]>.popover-arrow:before,.bs-popover-end>.popover-arrow:after,.bs-popover-end>.popover-arrow:before{border-width:calc(var(--bs-popover-arrow-width)*.5) var(--bs-popover-arrow-height) calc(var(--bs-popover-arrow-width)*.5) 0}.bs-popover-auto[data-popper-placement^=right]>.popover-arrow:before,.bs-popover-end>.popover-arrow:before{border-right-color:var(--bs-popover-arrow-border);left:0}.bs-popover-auto[data-popper-placement^=right]>.popover-arrow:after,.bs-popover-end>.popover-arrow:after{border-right-color:var(--bs-popover-bg);left:var(--bs-popover-border-width)}.bs-popover-auto[data-popper-placement^=bottom]>.popover-arrow,.bs-popover-bottom>.popover-arrow{top:calc((var(--bs-popover-arrow-height))*-1 - var(--bs-popover-border-width))}.bs-popover-auto[data-popper-placement^=bottom]>.popover-arrow:after,.bs-popover-auto[data-popper-placement^=bottom]>.popover-arrow:before,.bs-popover-bottom>.popover-arrow:after,.bs-popover-bottom>.popover-arrow:before{border-width:0 calc(var(--bs-popover-arrow-width)*.5) var(--bs-popover-arrow-height)}.bs-popover-auto[data-popper-placement^=bottom]>.popover-arrow:before,.bs-popover-bottom>.popover-arrow:before{border-bottom-color:var(--bs-popover-arrow-border);top:0}.bs-popover-auto[data-popper-placement^=bottom]>.popover-arrow:after,.bs-popover-bottom>.popover-arrow:after{border-bottom-color:var(--bs-popover-bg);top:var(--bs-popover-border-width)}.bs-popover-auto[data-popper-placement^=bottom] .popover-header:before,.bs-popover-bottom .popover-header:before{border-bottom:var(--bs-popover-border-width) solid var(--bs-popover-header-bg);content:"";display:block;left:50%;margin-left:calc(var(--bs-popover-arrow-width)*-.5);position:absolute;top:0;width:var(--bs-popover-arrow-width)}.bs-popover-auto[data-popper-placement^=left]>.popover-arrow,.bs-popover-start>.popover-arrow{height:var(--bs-popover-arrow-width);right:calc((var(--bs-popover-arrow-height))*-1 - var(--bs-popover-border-width));width:var(--bs-popover-arrow-height)}.bs-popover-auto[data-popper-placement^=left]>.popover-arrow:after,.bs-popover-auto[data-popper-placement^=left]>.popover-arrow:before,.bs-popover-start>.popover-arrow:after,.bs-popover-start>.popover-arrow:before{border-width:calc(var(--bs-popover-arrow-width)*.5) 0 calc(var(--bs-popover-arrow-width)*.5) var(--bs-popover-arrow-height)}.bs-popover-auto[data-popper-placement^=left]>.popover-arrow:before,.bs-popover-start>.popover-arrow:before{border-left-color:var(--bs-popover-arrow-border);right:0}.bs-popover-auto[data-popper-placement^=left]>.popover-arrow:after,.bs-popover-start>.popover-arrow:after{border-left-color:var(--bs-popover-bg);right:var(--bs-popover-border-width)}.popover-header{background-color:var(--bs-popover-header-bg);border-bottom:var(--bs-popover-border-width) solid var(--bs-popover-border-color);border-top-left-radius:var(--bs-popover-inner-border-radius);border-top-right-radius:var(--bs-popover-inner-border-radius);color:var(--bs-popover-header-color);font-size:var(--bs-popover-header-font-size);margin-bottom:0;padding:var(--bs-popover-header-padding-y) var(--bs-popover-header-padding-x)}.popover-header:empty{display:none}.popover-body{color:var(--bs-popover-body-color);padding:var(--bs-popover-body-padding-y) var(--bs-popover-body-padding-x)}.carousel{position:relative}.carousel.pointer-event{touch-action:pan-y}.carousel-inner{overflow:hidden;position:relative;width:100%}.carousel-inner:after{clear:both;content:"";display:block}.carousel-item{backface-visibility:hidden;display:none;float:left;margin-right:-100%;position:relative;transition:transform .6s ease-in-out;width:100%}@media (prefers-reduced-motion:reduce){.carousel-item{transition:none}}.carousel-item-next,.carousel-item-prev,.carousel-item.active{display:block}.active.carousel-item-end,.carousel-item-next:not(.carousel-item-start){transform:translateX(100%)}.active.carousel-item-start,.carousel-item-prev:not(.carousel-item-end){transform:translateX(-100%)}.carousel-fade .carousel-item{opacity:0;transform:none;transition-property:opacity}.carousel-fade .carousel-item-next.carousel-item-start,.carousel-fade .carousel-item-prev.carousel-item-end,.carousel-fade .carousel-item.active{opacity:1;z-index:1}.carousel-fade .active.carousel-item-end,.carousel-fade .active.carousel-item-start{opacity:0;transition:opacity 0s .6s;z-index:0}@media (prefers-reduced-motion:reduce){.carousel-fade .active.carousel-item-end,.carousel-fade .active.carousel-item-start{transition:none}}.carousel-control-next,.carousel-control-prev{align-items:center;background:none;border:0;bottom:0;color:#fff;display:flex;justify-content:center;opacity:.5;padding:0;position:absolute;text-align:center;top:0;transition:opacity .15s ease;width:15%;z-index:1}@media (prefers-reduced-motion:reduce){.carousel-control-next,.carousel-control-prev{transition:none}}.carousel-control-next:focus,.carousel-control-next:hover,.carousel-control-prev:focus,.carousel-control-prev:hover{color:#fff;opacity:.9;outline:0;text-decoration:none}.carousel-control-prev{left:0}.carousel-control-next{right:0}.carousel-control-next-icon,.carousel-control-prev-icon{background-position:50%;background-repeat:no-repeat;background-size:100% 100%;display:inline-block;height:2rem;width:2rem}.carousel-control-prev-icon{background-image:url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='%23fff' viewBox='0 0 16 16'%3E%3Cpath d='M11.354 1.646a.5.5 0 0 1 0 .708L5.707 8l5.647 5.646a.5.5 0 0 1-.708.708l-6-6a.5.5 0 0 1 0-.708l6-6a.5.5 0 0 1 .708 0'/%3E%3C/svg%3E")}.carousel-control-next-icon{background-image:url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='%23fff' viewBox='0 0 16 16'%3E%3Cpath d='M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708'/%3E%3C/svg%3E")}.carousel-indicators{bottom:0;display:flex;justify-content:center;left:0;margin-bottom:1rem;margin-left:15%;margin-right:15%;padding:0;position:absolute;right:0;z-index:2}.carousel-indicators [data-bs-target]{background-clip:padding-box;background-color:#fff;border:0;border-bottom:10px solid transparent;border-top:10px solid transparent;box-sizing:content-box;cursor:pointer;flex:0 1 auto;height:3px;margin-left:3px;margin-right:3px;opacity:.5;padding:0;text-indent:-999px;transition:opacity .6s ease;width:30px}@media (prefers-reduced-motion:reduce){.carousel-indicators [data-bs-target]{transition:none}}.carousel-indicators .active{opacity:1}.carousel-caption{bottom:1.25rem;color:#fff;left:15%;padding-bottom:1.25rem;padding-top:1.25rem;position:absolute;right:15%;text-align:center}.carousel-dark .carousel-control-next-icon,.carousel-dark .carousel-control-prev-icon{filter:invert(1) grayscale(100)}.carousel-dark .carousel-indicators [data-bs-target]{background-color:#000}.carousel-dark .carousel-caption{color:#000}[data-bs-theme=dark] .carousel .carousel-control-next-icon,[data-bs-theme=dark] .carousel .carousel-control-prev-icon,[data-bs-theme=dark].carousel .carousel-control-next-icon,[data-bs-theme=dark].carousel .carousel-control-prev-icon{filter:invert(1) grayscale(100)}[data-bs-theme=dark] .carousel .carousel-indicators [data-bs-target],[data-bs-theme=dark].carousel .carousel-indicators [data-bs-target]{background-color:#000}[data-bs-theme=dark] .carousel .carousel-caption,[data-bs-theme=dark].carousel .carousel-caption{color:#000}.spinner-border,.spinner-grow{animation:var(--bs-spinner-animation-speed) linear infinite var(--bs-spinner-animation-name);border-radius:50%;display:inline-block;height:var(--bs-spinner-height);vertical-align:var(--bs-spinner-vertical-align);width:var(--bs-spinner-width)}@keyframes spinner-border{to{transform:rotate(1turn)}}.spinner-border{--bs-spinner-width:2rem;--bs-spinner-height:2rem;--bs-spinner-vertical-align:-0.125em;--bs-spinner-border-width:0.25em;--bs-spinner-animation-speed:0.75s;--bs-spinner-animation-name:spinner-border;border-right-color:currentcolor;border:var(--bs-spinner-border-width) solid;border-right:var(--bs-spinner-border-width) solid transparent}.spinner-border-sm{--bs-spinner-width:1rem;--bs-spinner-height:1rem;--bs-spinner-border-width:0.2em}@keyframes spinner-grow{0%{transform:scale(0)}50%{opacity:1;transform:none}}.spinner-grow{--bs-spinner-width:2rem;--bs-spinner-height:2rem;--bs-spinner-vertical-align:-0.125em;--bs-spinner-animation-speed:0.75s;--bs-spinner-animation-name:spinner-grow;background-color:currentcolor;opacity:0}.spinner-grow-sm{--bs-spinner-width:1rem;--bs-spinner-height:1rem}@media (prefers-reduced-motion:reduce){.spinner-border,.spinner-grow{--bs-spinner-animation-speed:1.5s}}.offcanvas,.offcanvas-lg,.offcanvas-md,.offcanvas-sm,.offcanvas-xl,.offcanvas-xxl{--bs-offcanvas-zindex:1045;--bs-offcanvas-width:400px;--bs-offcanvas-height:30vh;--bs-offcanvas-padding-x:1rem;--bs-offcanvas-padding-y:1rem;--bs-offcanvas-color:var(--bs-body-color);--bs-offcanvas-bg:var(--bs-body-bg);--bs-offcanvas-border-width:var(--bs-border-width);--bs-offcanvas-border-color:var(--bs-border-color-translucent);--bs-offcanvas-box-shadow:var(--bs-box-shadow-sm);--bs-offcanvas-transition:transform 0.3s ease-in-out;--bs-offcanvas-title-line-height:1.5}@media (max-width:575.98px){.offcanvas-sm{background-clip:padding-box;background-color:var(--bs-offcanvas-bg);bottom:0;color:var(--bs-offcanvas-color);display:flex;flex-direction:column;max-width:100%;outline:0;position:fixed;transition:var(--bs-offcanvas-transition);visibility:hidden;z-index:var(--bs-offcanvas-zindex)}}@media (max-width:575.98px) and (prefers-reduced-motion:reduce){.offcanvas-sm{transition:none}}@media (max-width:575.98px){.offcanvas-sm.offcanvas-start{border-right:var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);left:0;top:0;transform:translateX(-100%);width:var(--bs-offcanvas-width)}.offcanvas-sm.offcanvas-end{border-left:var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);right:0;top:0;transform:translateX(100%);width:var(--bs-offcanvas-width)}.offcanvas-sm.offcanvas-top{border-bottom:var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);top:0;transform:translateY(-100%)}.offcanvas-sm.offcanvas-bottom,.offcanvas-sm.offcanvas-top{height:var(--bs-offcanvas-height);left:0;max-height:100%;right:0}.offcanvas-sm.offcanvas-bottom{border-top:var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);transform:translateY(100%)}.offcanvas-sm.show:not(.hiding),.offcanvas-sm.showing{transform:none}.offcanvas-sm.hiding,.offcanvas-sm.show,.offcanvas-sm.showing{visibility:visible}}@media (min-width:576px){.offcanvas-sm{--bs-offcanvas-height:auto;--bs-offcanvas-border-width:0;background-color:transparent!important}.offcanvas-sm .offcanvas-header{display:none}.offcanvas-sm .offcanvas-body{background-color:transparent!important;display:flex;flex-grow:0;overflow-y:visible;padding:0}}@media (max-width:767.98px){.offcanvas-md{background-clip:padding-box;background-color:var(--bs-offcanvas-bg);bottom:0;color:var(--bs-offcanvas-color);display:flex;flex-direction:column;max-width:100%;outline:0;position:fixed;transition:var(--bs-offcanvas-transition);visibility:hidden;z-index:var(--bs-offcanvas-zindex)}}@media (max-width:767.98px) and (prefers-reduced-motion:reduce){.offcanvas-md{transition:none}}@media (max-width:767.98px){.offcanvas-md.offcanvas-start{border-right:var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);left:0;top:0;transform:translateX(-100%);width:var(--bs-offcanvas-width)}.offcanvas-md.offcanvas-end{border-left:var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);right:0;top:0;transform:translateX(100%);width:var(--bs-offcanvas-width)}.offcanvas-md.offcanvas-top{border-bottom:var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);top:0;transform:translateY(-100%)}.offcanvas-md.offcanvas-bottom,.offcanvas-md.offcanvas-top{height:var(--bs-offcanvas-height);left:0;max-height:100%;right:0}.offcanvas-md.offcanvas-bottom{border-top:var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);transform:translateY(100%)}.offcanvas-md.show:not(.hiding),.offcanvas-md.showing{transform:none}.offcanvas-md.hiding,.offcanvas-md.show,.offcanvas-md.showing{visibility:visible}}@media (min-width:768px){.offcanvas-md{--bs-offcanvas-height:auto;--bs-offcanvas-border-width:0;background-color:transparent!important}.offcanvas-md .offcanvas-header{display:none}.offcanvas-md .offcanvas-body{background-color:transparent!important;display:flex;flex-grow:0;overflow-y:visible;padding:0}}@media (max-width:991.98px){.offcanvas-lg{background-clip:padding-box;background-color:var(--bs-offcanvas-bg);bottom:0;color:var(--bs-offcanvas-color);display:flex;flex-direction:column;max-width:100%;outline:0;position:fixed;transition:var(--bs-offcanvas-transition);visibility:hidden;z-index:var(--bs-offcanvas-zindex)}}@media (max-width:991.98px) and (prefers-reduced-motion:reduce){.offcanvas-lg{transition:none}}@media (max-width:991.98px){.offcanvas-lg.offcanvas-start{border-right:var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);left:0;top:0;transform:translateX(-100%);width:var(--bs-offcanvas-width)}.offcanvas-lg.offcanvas-end{border-left:var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);right:0;top:0;transform:translateX(100%);width:var(--bs-offcanvas-width)}.offcanvas-lg.offcanvas-top{border-bottom:var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);top:0;transform:translateY(-100%)}.offcanvas-lg.offcanvas-bottom,.offcanvas-lg.offcanvas-top{height:var(--bs-offcanvas-height);left:0;max-height:100%;right:0}.offcanvas-lg.offcanvas-bottom{border-top:var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);transform:translateY(100%)}.offcanvas-lg.show:not(.hiding),.offcanvas-lg.showing{transform:none}.offcanvas-lg.hiding,.offcanvas-lg.show,.offcanvas-lg.showing{visibility:visible}}@media (min-width:992px){.offcanvas-lg{--bs-offcanvas-height:auto;--bs-offcanvas-border-width:0;background-color:transparent!important}.offcanvas-lg .offcanvas-header{display:none}.offcanvas-lg .offcanvas-body{background-color:transparent!important;display:flex;flex-grow:0;overflow-y:visible;padding:0}}@media (max-width:1199.98px){.offcanvas-xl{background-clip:padding-box;background-color:var(--bs-offcanvas-bg);bottom:0;color:var(--bs-offcanvas-color);display:flex;flex-direction:column;max-width:100%;outline:0;position:fixed;transition:var(--bs-offcanvas-transition);visibility:hidden;z-index:var(--bs-offcanvas-zindex)}}@media (max-width:1199.98px) and (prefers-reduced-motion:reduce){.offcanvas-xl{transition:none}}@media (max-width:1199.98px){.offcanvas-xl.offcanvas-start{border-right:var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);left:0;top:0;transform:translateX(-100%);width:var(--bs-offcanvas-width)}.offcanvas-xl.offcanvas-end{border-left:var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);right:0;top:0;transform:translateX(100%);width:var(--bs-offcanvas-width)}.offcanvas-xl.offcanvas-top{border-bottom:var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);top:0;transform:translateY(-100%)}.offcanvas-xl.offcanvas-bottom,.offcanvas-xl.offcanvas-top{height:var(--bs-offcanvas-height);left:0;max-height:100%;right:0}.offcanvas-xl.offcanvas-bottom{border-top:var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);transform:translateY(100%)}.offcanvas-xl.show:not(.hiding),.offcanvas-xl.showing{transform:none}.offcanvas-xl.hiding,.offcanvas-xl.show,.offcanvas-xl.showing{visibility:visible}}@media (min-width:1200px){.offcanvas-xl{--bs-offcanvas-height:auto;--bs-offcanvas-border-width:0;background-color:transparent!important}.offcanvas-xl .offcanvas-header{display:none}.offcanvas-xl .offcanvas-body{background-color:transparent!important;display:flex;flex-grow:0;overflow-y:visible;padding:0}}@media (max-width:1399.98px){.offcanvas-xxl{background-clip:padding-box;background-color:var(--bs-offcanvas-bg);bottom:0;color:var(--bs-offcanvas-color);display:flex;flex-direction:column;max-width:100%;outline:0;position:fixed;transition:var(--bs-offcanvas-transition);visibility:hidden;z-index:var(--bs-offcanvas-zindex)}}@media (max-width:1399.98px) and (prefers-reduced-motion:reduce){.offcanvas-xxl{transition:none}}@media (max-width:1399.98px){.offcanvas-xxl.offcanvas-start{border-right:var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);left:0;top:0;transform:translateX(-100%);width:var(--bs-offcanvas-width)}.offcanvas-xxl.offcanvas-end{border-left:var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);right:0;top:0;transform:translateX(100%);width:var(--bs-offcanvas-width)}.offcanvas-xxl.offcanvas-top{border-bottom:var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);top:0;transform:translateY(-100%)}.offcanvas-xxl.offcanvas-bottom,.offcanvas-xxl.offcanvas-top{height:var(--bs-offcanvas-height);left:0;max-height:100%;right:0}.offcanvas-xxl.offcanvas-bottom{border-top:var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);transform:translateY(100%)}.offcanvas-xxl.show:not(.hiding),.offcanvas-xxl.showing{transform:none}.offcanvas-xxl.hiding,.offcanvas-xxl.show,.offcanvas-xxl.showing{visibility:visible}}@media (min-width:1400px){.offcanvas-xxl{--bs-offcanvas-height:auto;--bs-offcanvas-border-width:0;background-color:transparent!important}.offcanvas-xxl .offcanvas-header{display:none}.offcanvas-xxl .offcanvas-body{background-color:transparent!important;display:flex;flex-grow:0;overflow-y:visible;padding:0}}.offcanvas{background-clip:padding-box;background-color:var(--bs-offcanvas-bg);bottom:0;color:var(--bs-offcanvas-color);display:flex;flex-direction:column;max-width:100%;outline:0;position:fixed;transition:var(--bs-offcanvas-transition);visibility:hidden;z-index:var(--bs-offcanvas-zindex)}@media (prefers-reduced-motion:reduce){.offcanvas{transition:none}}.offcanvas.offcanvas-start{border-right:var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);left:0;top:0;transform:translateX(-100%);width:var(--bs-offcanvas-width)}.offcanvas.offcanvas-end{border-left:var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);right:0;top:0;transform:translateX(100%);width:var(--bs-offcanvas-width)}.offcanvas.offcanvas-top{border-bottom:var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);top:0;transform:translateY(-100%)}.offcanvas.offcanvas-bottom,.offcanvas.offcanvas-top{height:var(--bs-offcanvas-height);left:0;max-height:100%;right:0}.offcanvas.offcanvas-bottom{border-top:var(--bs-offcanvas-border-width) solid var(--bs-offcanvas-border-color);transform:translateY(100%)}.offcanvas.show:not(.hiding),.offcanvas.showing{transform:none}.offcanvas.hiding,.offcanvas.show,.offcanvas.showing{visibility:visible}.offcanvas-backdrop{background-color:#000;height:100vh;left:0;position:fixed;top:0;width:100vw;z-index:1040}.offcanvas-backdrop.fade{opacity:0}.offcanvas-backdrop.show{opacity:.5}.offcanvas-header{align-items:center;display:flex;padding:var(--bs-offcanvas-padding-y) var(--bs-offcanvas-padding-x)}.offcanvas-header .btn-close{margin:calc(var(--bs-offcanvas-padding-y)*-.5) calc(var(--bs-offcanvas-padding-x)*-.5) calc(var(--bs-offcanvas-padding-y)*-.5) auto;padding:calc(var(--bs-offcanvas-padding-y)*.5) calc(var(--bs-offcanvas-padding-x)*.5)}.offcanvas-title{line-height:var(--bs-offcanvas-title-line-height);margin-bottom:0}.offcanvas-body{flex-grow:1;overflow-y:auto;padding:var(--bs-offcanvas-padding-y) var(--bs-offcanvas-padding-x)}.placeholder{background-color:currentcolor;cursor:wait;display:inline-block;min-height:1em;opacity:.5;vertical-align:middle}.placeholder.btn:before{content:"";display:inline-block}.placeholder-xs{min-height:.6em}.placeholder-sm{min-height:.8em}.placeholder-lg{min-height:1.2em}.placeholder-glow .placeholder{animation:placeholder-glow 2s ease-in-out infinite}@keyframes placeholder-glow{50%{opacity:.2}}.placeholder-wave{animation:placeholder-wave 2s linear infinite;-webkit-mask-image:linear-gradient(130deg,#000 55%,rgba(0,0,0,.8) 75%,#000 95%);mask-image:linear-gradient(130deg,#000 55%,rgba(0,0,0,.8) 75%,#000 95%);-webkit-mask-size:200% 100%;mask-size:200% 100%}@keyframes placeholder-wave{to{-webkit-mask-position:-200% 0;mask-position:-200% 0}}.clearfix:after{clear:both;content:"";display:block}.text-bg-primary{background-color:RGBA(var(--bs-primary-rgb),var(--bs-bg-opacity,1))!important;color:#000!important}.text-bg-secondary{background-color:RGBA(var(--bs-secondary-rgb),var(--bs-bg-opacity,1))!important;color:#fff!important}.text-bg-success{background-color:RGBA(var(--bs-success-rgb),var(--bs-bg-opacity,1))!important;color:#fff!important}.text-bg-info{background-color:RGBA(var(--bs-info-rgb),var(--bs-bg-opacity,1))!important;color:#000!important}.text-bg-warning{background-color:RGBA(var(--bs-warning-rgb),var(--bs-bg-opacity,1))!important;color:#000!important}.text-bg-danger{background-color:RGBA(var(--bs-danger-rgb),var(--bs-bg-opacity,1))!important;color:#fff!important}.text-bg-light{background-color:RGBA(var(--bs-light-rgb),var(--bs-bg-opacity,1))!important;color:#000!important}.text-bg-dark{background-color:RGBA(var(--bs-dark-rgb),var(--bs-bg-opacity,1))!important;color:#fff!important}.link-primary{color:RGBA(var(--bs-primary-rgb),var(--bs-link-opacity,1))!important;text-decoration-color:RGBA(var(--bs-primary-rgb),var(--bs-link-underline-opacity,1))!important}.link-primary:focus,.link-primary:hover{color:RGBA(99,156,239,var(--bs-link-opacity,1))!important;text-decoration-color:RGBA(99,156,239,var(--bs-link-underline-opacity,1))!important}.link-secondary{color:RGBA(var(--bs-secondary-rgb),var(--bs-link-opacity,1))!important;text-decoration-color:RGBA(var(--bs-secondary-rgb),var(--bs-link-underline-opacity,1))!important}.link-secondary:focus,.link-secondary:hover{color:RGBA(86,94,100,var(--bs-link-opacity,1))!important;text-decoration-color:RGBA(86,94,100,var(--bs-link-underline-opacity,1))!important}.link-success{color:RGBA(var(--bs-success-rgb),var(--bs-link-opacity,1))!important;text-decoration-color:RGBA(var(--bs-success-rgb),var(--bs-link-underline-opacity,1))!important}.link-success:focus,.link-success:hover{color:RGBA(20,108,67,var(--bs-link-opacity,1))!important;text-decoration-color:RGBA(20,108,67,var(--bs-link-underline-opacity,1))!important}.link-info{color:RGBA(var(--bs-info-rgb),var(--bs-link-opacity,1))!important;text-decoration-color:RGBA(var(--bs-info-rgb),var(--bs-link-underline-opacity,1))!important}.link-info:focus,.link-info:hover{color:RGBA(61,213,243,var(--bs-link-opacity,1))!important;text-decoration-color:RGBA(61,213,243,var(--bs-link-underline-opacity,1))!important}.link-warning{color:RGBA(var(--bs-warning-rgb),var(--bs-link-opacity,1))!important;text-decoration-color:RGBA(var(--bs-warning-rgb),var(--bs-link-underline-opacity,1))!important}.link-warning:focus,.link-warning:hover{color:RGBA(255,205,57,var(--bs-link-opacity,1))!important;text-decoration-color:RGBA(255,205,57,var(--bs-link-underline-opacity,1))!important}.link-danger{color:RGBA(var(--bs-danger-rgb),var(--bs-link-opacity,1))!important;text-decoration-color:RGBA(var(--bs-danger-rgb),var(--bs-link-underline-opacity,1))!important}.link-danger:focus,.link-danger:hover{color:RGBA(176,42,55,var(--bs-link-opacity,1))!important;text-decoration-color:RGBA(176,42,55,var(--bs-link-underline-opacity,1))!important}.link-light{color:RGBA(var(--bs-light-rgb),var(--bs-link-opacity,1))!important;text-decoration-color:RGBA(var(--bs-light-rgb),var(--bs-link-underline-opacity,1))!important}.link-light:focus,.link-light:hover{color:RGBA(249,250,251,var(--bs-link-opacity,1))!important;text-decoration-color:RGBA(249,250,251,var(--bs-link-underline-opacity,1))!important}.link-dark{color:RGBA(var(--bs-dark-rgb),var(--bs-link-opacity,1))!important;text-decoration-color:RGBA(var(--bs-dark-rgb),var(--bs-link-underline-opacity,1))!important}.link-dark:focus,.link-dark:hover{color:RGBA(26,30,33,var(--bs-link-opacity,1))!important;text-decoration-color:RGBA(26,30,33,var(--bs-link-underline-opacity,1))!important}.link-body-emphasis{color:RGBA(var(--bs-emphasis-color-rgb),var(--bs-link-opacity,1))!important;text-decoration-color:RGBA(var(--bs-emphasis-color-rgb),var(--bs-link-underline-opacity,1))!important}.link-body-emphasis:focus,.link-body-emphasis:hover{color:RGBA(var(--bs-emphasis-color-rgb),var(--bs-link-opacity,.75))!important;text-decoration-color:RGBA(var(--bs-emphasis-color-rgb),var(--bs-link-underline-opacity,.75))!important}.focus-ring:focus{box-shadow:var(--bs-focus-ring-x,0) var(--bs-focus-ring-y,0) var(--bs-focus-ring-blur,0) var(--bs-focus-ring-width) var(--bs-focus-ring-color);outline:0}.icon-link{align-items:center;backface-visibility:hidden;display:inline-flex;gap:.375rem;text-decoration-color:rgba(var(--bs-link-color-rgb),var(--bs-link-opacity,.5));text-underline-offset:.25em}.icon-link>.bi{flex-shrink:0;height:1em;width:1em;fill:currentcolor;transition:transform .2s ease-in-out}@media (prefers-reduced-motion:reduce){.icon-link>.bi{transition:none}}.icon-link-hover:focus-visible>.bi,.icon-link-hover:hover>.bi{transform:var(--bs-icon-link-transform,translate3d(.25em,0,0))}.ratio{position:relative;width:100%}.ratio:before{content:"";display:block;padding-top:var(--bs-aspect-ratio)}.ratio>*{height:100%;left:0;position:absolute;top:0;width:100%}.ratio-1x1{--bs-aspect-ratio:100%}.ratio-4x3{--bs-aspect-ratio:75%}.ratio-16x9{--bs-aspect-ratio:56.25%}.ratio-21x9{--bs-aspect-ratio:42.8571428571%}.fixed-top{top:0}.fixed-bottom,.fixed-top{left:0;position:fixed;right:0;z-index:1030}.fixed-bottom{bottom:0}.sticky-top{top:0}.sticky-bottom,.sticky-top{position:sticky;z-index:1020}.sticky-bottom{bottom:0}@media (min-width:576px){.sticky-sm-top{position:sticky;top:0;z-index:1020}.sticky-sm-bottom{bottom:0;position:sticky;z-index:1020}}@media (min-width:768px){.sticky-md-top{position:sticky;top:0;z-index:1020}.sticky-md-bottom{bottom:0;position:sticky;z-index:1020}}@media (min-width:992px){.sticky-lg-top{position:sticky;top:0;z-index:1020}.sticky-lg-bottom{bottom:0;position:sticky;z-index:1020}}@media (min-width:1200px){.sticky-xl-top{position:sticky;top:0;z-index:1020}.sticky-xl-bottom{bottom:0;position:sticky;z-index:1020}}@media (min-width:1400px){.sticky-xxl-top{position:sticky;top:0;z-index:1020}.sticky-xxl-bottom{bottom:0;position:sticky;z-index:1020}}.hstack{align-items:center;flex-direction:row}.hstack,.vstack{align-self:stretch;display:flex}.vstack{flex:1 1 auto;flex-direction:column}.visually-hidden,.visually-hidden-focusable:not(:focus):not(:focus-within){height:1px!important;margin:-1px!important;overflow:hidden!important;padding:0!important;width:1px!important;clip:rect(0,0,0,0)!important;border:0!important;white-space:nowrap!important}.visually-hidden-focusable:not(:focus):not(:focus-within):not(caption),.visually-hidden:not(caption){position:absolute!important}.stretched-link:after{bottom:0;content:"";left:0;position:absolute;right:0;top:0;z-index:1}.text-truncate{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.vr{align-self:stretch;background-color:currentcolor;display:inline-block;min-height:1em;opacity:.25;width:var(--bs-border-width)}.align-baseline{vertical-align:baseline!important}.align-top{vertical-align:top!important}.align-middle{vertical-align:middle!important}.align-bottom{vertical-align:bottom!important}.align-text-bottom{vertical-align:text-bottom!important}.align-text-top{vertical-align:text-top!important}.float-start{float:left!important}.float-end{float:right!important}.float-none{float:none!important}.object-fit-contain{-o-object-fit:contain!important;object-fit:contain!important}.object-fit-cover{-o-object-fit:cover!important;object-fit:cover!important}.object-fit-fill{-o-object-fit:fill!important;object-fit:fill!important}.object-fit-scale{-o-object-fit:scale-down!important;object-fit:scale-down!important}.object-fit-none{-o-object-fit:none!important;object-fit:none!important}.opacity-0{opacity:0!important}.opacity-25{opacity:.25!important}.opacity-50{opacity:.5!important}.opacity-75{opacity:.75!important}.opacity-100{opacity:1!important}.overflow-auto{overflow:auto!important}.overflow-hidden{overflow:hidden!important}.overflow-visible{overflow:visible!important}.overflow-scroll{overflow:scroll!important}.overflow-x-auto{overflow-x:auto!important}.overflow-x-hidden{overflow-x:hidden!important}.overflow-x-visible{overflow-x:visible!important}.overflow-x-scroll{overflow-x:scroll!important}.overflow-y-auto{overflow-y:auto!important}.overflow-y-hidden{overflow-y:hidden!important}.overflow-y-visible{overflow-y:visible!important}.overflow-y-scroll{overflow-y:scroll!important}.d-inline{display:inline!important}.d-inline-block{display:inline-block!important}.d-block{display:block!important}.d-grid{display:grid!important}.d-inline-grid{display:inline-grid!important}.d-table{display:table!important}.d-table-row{display:table-row!important}.d-table-cell{display:table-cell!important}.d-flex{display:flex!important}.d-inline-flex{display:inline-flex!important}.d-none{display:none!important}.shadow{box-shadow:var(--bs-box-shadow)!important}.shadow-sm{box-shadow:var(--bs-box-shadow-sm)!important}.shadow-lg{box-shadow:var(--bs-box-shadow-lg)!important}.shadow-none{box-shadow:none!important}.focus-ring-primary{--bs-focus-ring-color:rgba(var(--bs-primary-rgb),var(--bs-focus-ring-opacity))}.focus-ring-secondary{--bs-focus-ring-color:rgba(var(--bs-secondary-rgb),var(--bs-focus-ring-opacity))}.focus-ring-success{--bs-focus-ring-color:rgba(var(--bs-success-rgb),var(--bs-focus-ring-opacity))}.focus-ring-info{--bs-focus-ring-color:rgba(var(--bs-info-rgb),var(--bs-focus-ring-opacity))}.focus-ring-warning{--bs-focus-ring-color:rgba(var(--bs-warning-rgb),var(--bs-focus-ring-opacity))}.focus-ring-danger{--bs-focus-ring-color:rgba(var(--bs-danger-rgb),var(--bs-focus-ring-opacity))}.focus-ring-light{--bs-focus-ring-color:rgba(var(--bs-light-rgb),var(--bs-focus-ring-opacity))}.focus-ring-dark{--bs-focus-ring-color:rgba(var(--bs-dark-rgb),var(--bs-focus-ring-opacity))}.position-static{position:static!important}.position-relative{position:relative!important}.position-absolute{position:absolute!important}.position-fixed{position:fixed!important}.position-sticky{position:sticky!important}.top-0{top:0!important}.top-50{top:50%!important}.top-100{top:100%!important}.bottom-0{bottom:0!important}.bottom-50{bottom:50%!important}.bottom-100{bottom:100%!important}.start-0{left:0!important}.start-50{left:50%!important}.start-100{left:100%!important}.end-0{right:0!important}.end-50{right:50%!important}.end-100{right:100%!important}.translate-middle{transform:translate(-50%,-50%)!important}.translate-middle-x{transform:translateX(-50%)!important}.translate-middle-y{transform:translateY(-50%)!important}.border{border:var(--bs-border-width) var(--bs-border-style) var(--bs-border-color)!important}.border-0{border:0!important}.border-top{border-top:var(--bs-border-width) var(--bs-border-style) var(--bs-border-color)!important}.border-top-0{border-top:0!important}.border-end{border-right:var(--bs-border-width) var(--bs-border-style) var(--bs-border-color)!important}.border-end-0{border-right:0!important}.border-bottom{border-bottom:var(--bs-border-width) var(--bs-border-style) var(--bs-border-color)!important}.border-bottom-0{border-bottom:0!important}.border-start{border-left:var(--bs-border-width) var(--bs-border-style) var(--bs-border-color)!important}.border-start-0{border-left:0!important}.border-primary{--bs-border-opacity:1;border-color:rgba(var(--bs-primary-rgb),var(--bs-border-opacity))!important}.border-secondary{--bs-border-opacity:1;border-color:rgba(var(--bs-secondary-rgb),var(--bs-border-opacity))!important}.border-success{--bs-border-opacity:1;border-color:rgba(var(--bs-success-rgb),var(--bs-border-opacity))!important}.border-info{--bs-border-opacity:1;border-color:rgba(var(--bs-info-rgb),var(--bs-border-opacity))!important}.border-warning{--bs-border-opacity:1;border-color:rgba(var(--bs-warning-rgb),var(--bs-border-opacity))!important}.border-danger{--bs-border-opacity:1;border-color:rgba(var(--bs-danger-rgb),var(--bs-border-opacity))!important}.border-light{--bs-border-opacity:1;border-color:rgba(var(--bs-light-rgb),var(--bs-border-opacity))!important}.border-dark{--bs-border-opacity:1;border-color:rgba(var(--bs-dark-rgb),var(--bs-border-opacity))!important}.border-black{--bs-border-opacity:1;border-color:rgba(var(--bs-black-rgb),var(--bs-border-opacity))!important}.border-white{--bs-border-opacity:1;border-color:rgba(var(--bs-white-rgb),var(--bs-border-opacity))!important}.border-primary-subtle{border-color:var(--bs-primary-border-subtle)!important}.border-secondary-subtle{border-color:var(--bs-secondary-border-subtle)!important}.border-success-subtle{border-color:var(--bs-success-border-subtle)!important}.border-info-subtle{border-color:var(--bs-info-border-subtle)!important}.border-warning-subtle{border-color:var(--bs-warning-border-subtle)!important}.border-danger-subtle{border-color:var(--bs-danger-border-subtle)!important}.border-light-subtle{border-color:var(--bs-light-border-subtle)!important}.border-dark-subtle{border-color:var(--bs-dark-border-subtle)!important}.border-1{border-width:1px!important}.border-2{border-width:2px!important}.border-3{border-width:3px!important}.border-4{border-width:4px!important}.border-5{border-width:5px!important}.border-opacity-10{--bs-border-opacity:0.1}.border-opacity-25{--bs-border-opacity:0.25}.border-opacity-50{--bs-border-opacity:0.5}.border-opacity-75{--bs-border-opacity:0.75}.border-opacity-100{--bs-border-opacity:1}.w-25{width:25%!important}.w-50{width:50%!important}.w-75{width:75%!important}.w-100{width:100%!important}.w-auto{width:auto!important}.mw-100{max-width:100%!important}.vw-100{width:100vw!important}.min-vw-100{min-width:100vw!important}.h-25{height:25%!important}.h-50{height:50%!important}.h-75{height:75%!important}.h-100{height:100%!important}.h-auto{height:auto!important}.mh-100{max-height:100%!important}.vh-100{height:100vh!important}.min-vh-100{min-height:100vh!important}.flex-fill{flex:1 1 auto!important}.flex-row{flex-direction:row!important}.flex-column{flex-direction:column!important}.flex-row-reverse{flex-direction:row-reverse!important}.flex-column-reverse{flex-direction:column-reverse!important}.flex-grow-0{flex-grow:0!important}.flex-grow-1{flex-grow:1!important}.flex-shrink-0{flex-shrink:0!important}.flex-shrink-1{flex-shrink:1!important}.flex-wrap{flex-wrap:wrap!important}.flex-nowrap{flex-wrap:nowrap!important}.flex-wrap-reverse{flex-wrap:wrap-reverse!important}.justify-content-start{justify-content:flex-start!important}.justify-content-end{justify-content:flex-end!important}.justify-content-center{justify-content:center!important}.justify-content-between{justify-content:space-between!important}.justify-content-around{justify-content:space-around!important}.justify-content-evenly{justify-content:space-evenly!important}.align-items-start{align-items:flex-start!important}.align-items-end{align-items:flex-end!important}.align-items-center{align-items:center!important}.align-items-baseline{align-items:baseline!important}.align-items-stretch{align-items:stretch!important}.align-content-start{align-content:flex-start!important}.align-content-end{align-content:flex-end!important}.align-content-center{align-content:center!important}.align-content-between{align-content:space-between!important}.align-content-around{align-content:space-around!important}.align-content-stretch{align-content:stretch!important}.align-self-auto{align-self:auto!important}.align-self-start{align-self:flex-start!important}.align-self-end{align-self:flex-end!important}.align-self-center{align-self:center!important}.align-self-baseline{align-self:baseline!important}.align-self-stretch{align-self:stretch!important}.order-first{order:-1!important}.order-0{order:0!important}.order-1{order:1!important}.order-2{order:2!important}.order-3{order:3!important}.order-4{order:4!important}.order-5{order:5!important}.order-last{order:6!important}.m-0{margin:0!important}.m-1{margin:.25rem!important}.m-2{margin:.5rem!important}.m-3{margin:1rem!important}.m-4{margin:1.5rem!important}.m-5{margin:3rem!important}.m-auto{margin:auto!important}.mx-0{margin-left:0!important;margin-right:0!important}.mx-1{margin-left:.25rem!important;margin-right:.25rem!important}.mx-2{margin-left:.5rem!important;margin-right:.5rem!important}.mx-3{margin-left:1rem!important;margin-right:1rem!important}.mx-4{margin-left:1.5rem!important;margin-right:1.5rem!important}.mx-5{margin-left:3rem!important;margin-right:3rem!important}.mx-auto{margin-left:auto!important;margin-right:auto!important}.my-0{margin-bottom:0!important;margin-top:0!important}.my-1{margin-bottom:.25rem!important;margin-top:.25rem!important}.my-2{margin-bottom:.5rem!important;margin-top:.5rem!important}.my-3{margin-bottom:1rem!important;margin-top:1rem!important}.my-4{margin-bottom:1.5rem!important;margin-top:1.5rem!important}.my-5{margin-bottom:3rem!important;margin-top:3rem!important}.my-auto{margin-bottom:auto!important;margin-top:auto!important}.mt-0{margin-top:0!important}.mt-1{margin-top:.25rem!important}.mt-2{margin-top:.5rem!important}.mt-3{margin-top:1rem!important}.mt-4{margin-top:1.5rem!important}.mt-5{margin-top:3rem!important}.mt-auto{margin-top:auto!important}.me-0{margin-right:0!important}.me-1{margin-right:.25rem!important}.me-2{margin-right:.5rem!important}.me-3{margin-right:1rem!important}.me-4{margin-right:1.5rem!important}.me-5{margin-right:3rem!important}.me-auto{margin-right:auto!important}.mb-0{margin-bottom:0!important}.mb-1{margin-bottom:.25rem!important}.mb-2{margin-bottom:.5rem!important}.mb-3{margin-bottom:1rem!important}.mb-4{margin-bottom:1.5rem!important}.mb-5{margin-bottom:3rem!important}.mb-auto{margin-bottom:auto!important}.ms-0{margin-left:0!important}.ms-1{margin-left:.25rem!important}.ms-2{margin-left:.5rem!important}.ms-3{margin-left:1rem!important}.ms-4{margin-left:1.5rem!important}.ms-5{margin-left:3rem!important}.ms-auto{margin-left:auto!important}.p-0{padding:0!important}.p-1{padding:.25rem!important}.p-2{padding:.5rem!important}.p-3{padding:1rem!important}.p-4{padding:1.5rem!important}.p-5{padding:3rem!important}.px-0{padding-left:0!important;padding-right:0!important}.px-1{padding-left:.25rem!important;padding-right:.25rem!important}.px-2{padding-left:.5rem!important;padding-right:.5rem!important}.px-3{padding-left:1rem!important;padding-right:1rem!important}.px-4{padding-left:1.5rem!important;padding-right:1.5rem!important}.px-5{padding-left:3rem!important;padding-right:3rem!important}.py-0{padding-bottom:0!important;padding-top:0!important}.py-1{padding-bottom:.25rem!important;padding-top:.25rem!important}.py-2{padding-bottom:.5rem!important;padding-top:.5rem!important}.py-3{padding-bottom:1rem!important;padding-top:1rem!important}.py-4{padding-bottom:1.5rem!important;padding-top:1.5rem!important}.py-5{padding-bottom:3rem!important;padding-top:3rem!important}.pt-0{padding-top:0!important}.pt-1{padding-top:.25rem!important}.pt-2{padding-top:.5rem!important}.pt-3{padding-top:1rem!important}.pt-4{padding-top:1.5rem!important}.pt-5{padding-top:3rem!important}.pe-0{padding-right:0!important}.pe-1{padding-right:.25rem!important}.pe-2{padding-right:.5rem!important}.pe-3{padding-right:1rem!important}.pe-4{padding-right:1.5rem!important}.pe-5{padding-right:3rem!important}.pb-0{padding-bottom:0!important}.pb-1{padding-bottom:.25rem!important}.pb-2{padding-bottom:.5rem!important}.pb-3{padding-bottom:1rem!important}.pb-4{padding-bottom:1.5rem!important}.pb-5{padding-bottom:3rem!important}.ps-0{padding-left:0!important}.ps-1{padding-left:.25rem!important}.ps-2{padding-left:.5rem!important}.ps-3{padding-left:1rem!important}.ps-4{padding-left:1.5rem!important}.ps-5{padding-left:3rem!important}.gap-0{gap:0!important}.gap-1{gap:.25rem!important}.gap-2{gap:.5rem!important}.gap-3{gap:1rem!important}.gap-4{gap:1.5rem!important}.gap-5{gap:3rem!important}.row-gap-0{row-gap:0!important}.row-gap-1{row-gap:.25rem!important}.row-gap-2{row-gap:.5rem!important}.row-gap-3{row-gap:1rem!important}.row-gap-4{row-gap:1.5rem!important}.row-gap-5{row-gap:3rem!important}.column-gap-0{-moz-column-gap:0!important;column-gap:0!important}.column-gap-1{-moz-column-gap:.25rem!important;column-gap:.25rem!important}.column-gap-2{-moz-column-gap:.5rem!important;column-gap:.5rem!important}.column-gap-3{-moz-column-gap:1rem!important;column-gap:1rem!important}.column-gap-4{-moz-column-gap:1.5rem!important;column-gap:1.5rem!important}.column-gap-5{-moz-column-gap:3rem!important;column-gap:3rem!important}.font-monospace{font-family:var(--bs-font-monospace)!important}.fs-1{font-size:calc(1.375rem + 1.5vw)!important}.fs-2{font-size:calc(1.325rem + .9vw)!important}.fs-3{font-size:calc(1.3rem + .6vw)!important}.fs-4{font-size:calc(1.275rem + .3vw)!important}.fs-5{font-size:1.25rem!important}.fs-6{font-size:1rem!important}.fst-italic{font-style:italic!important}.fst-normal{font-style:normal!important}.fw-lighter{font-weight:lighter!important}.fw-light{font-weight:300!important}.fw-normal{font-weight:400!important}.fw-medium{font-weight:500!important}.fw-semibold{font-weight:600!important}.fw-bold{font-weight:700!important}.fw-bolder{font-weight:bolder!important}.lh-1{line-height:1!important}.lh-sm{line-height:1.25!important}.lh-base{line-height:1.5!important}.lh-lg{line-height:2!important}.text-start{text-align:left!important}.text-end{text-align:right!important}.text-center{text-align:center!important}.text-decoration-none{text-decoration:none!important}.text-decoration-underline{text-decoration:underline!important}.text-decoration-line-through{text-decoration:line-through!important}.text-lowercase{text-transform:lowercase!important}.text-uppercase{text-transform:uppercase!important}.text-capitalize{text-transform:capitalize!important}.text-wrap{white-space:normal!important}.text-nowrap{white-space:nowrap!important}.text-break{word-wrap:break-word!important;word-break:break-word!important}.text-primary{--bs-text-opacity:1;color:rgba(var(--bs-primary-rgb),var(--bs-text-opacity))!important}.text-secondary{--bs-text-opacity:1;color:rgba(var(--bs-secondary-rgb),var(--bs-text-opacity))!important}.text-success{--bs-text-opacity:1;color:rgba(var(--bs-success-rgb),var(--bs-text-opacity))!important}.text-info{--bs-text-opacity:1;color:rgba(var(--bs-info-rgb),var(--bs-text-opacity))!important}.text-warning{--bs-text-opacity:1;color:rgba(var(--bs-warning-rgb),var(--bs-text-opacity))!important}.text-danger{--bs-text-opacity:1;color:rgba(var(--bs-danger-rgb),var(--bs-text-opacity))!important}.text-light{--bs-text-opacity:1;color:rgba(var(--bs-light-rgb),var(--bs-text-opacity))!important}.text-dark{--bs-text-opacity:1;color:rgba(var(--bs-dark-rgb),var(--bs-text-opacity))!important}.text-black{--bs-text-opacity:1;color:rgba(var(--bs-black-rgb),var(--bs-text-opacity))!important}.text-white{--bs-text-opacity:1;color:rgba(var(--bs-white-rgb),var(--bs-text-opacity))!important}.text-body{--bs-text-opacity:1;color:rgba(var(--bs-body-color-rgb),var(--bs-text-opacity))!important}.text-muted{--bs-text-opacity:1;color:var(--bs-secondary-color)!important}.text-black-50{--bs-text-opacity:1;color:rgba(0,0,0,.5)!important}.text-white-50{--bs-text-opacity:1;color:hsla(0,0%,100%,.5)!important}.text-body-secondary{--bs-text-opacity:1;color:var(--bs-secondary-color)!important}.text-body-tertiary{--bs-text-opacity:1;color:var(--bs-tertiary-color)!important}.text-body-emphasis{--bs-text-opacity:1;color:var(--bs-emphasis-color)!important}.text-reset{--bs-text-opacity:1;color:inherit!important}.text-opacity-25{--bs-text-opacity:0.25}.text-opacity-50{--bs-text-opacity:0.5}.text-opacity-75{--bs-text-opacity:0.75}.text-opacity-100{--bs-text-opacity:1}.text-primary-emphasis{color:var(--bs-primary-text-emphasis)!important}.text-secondary-emphasis{color:var(--bs-secondary-text-emphasis)!important}.text-success-emphasis{color:var(--bs-success-text-emphasis)!important}.text-info-emphasis{color:var(--bs-info-text-emphasis)!important}.text-warning-emphasis{color:var(--bs-warning-text-emphasis)!important}.text-danger-emphasis{color:var(--bs-danger-text-emphasis)!important}.text-light-emphasis{color:var(--bs-light-text-emphasis)!important}.text-dark-emphasis{color:var(--bs-dark-text-emphasis)!important}.link-opacity-10,.link-opacity-10-hover:hover{--bs-link-opacity:0.1}.link-opacity-25,.link-opacity-25-hover:hover{--bs-link-opacity:0.25}.link-opacity-50,.link-opacity-50-hover:hover{--bs-link-opacity:0.5}.link-opacity-75,.link-opacity-75-hover:hover{--bs-link-opacity:0.75}.link-opacity-100,.link-opacity-100-hover:hover{--bs-link-opacity:1}.link-offset-1,.link-offset-1-hover:hover{text-underline-offset:.125em!important}.link-offset-2,.link-offset-2-hover:hover{text-underline-offset:.25em!important}.link-offset-3,.link-offset-3-hover:hover{text-underline-offset:.375em!important}.link-underline-primary{--bs-link-underline-opacity:1;text-decoration-color:rgba(var(--bs-primary-rgb),var(--bs-link-underline-opacity))!important}.link-underline-secondary{--bs-link-underline-opacity:1;text-decoration-color:rgba(var(--bs-secondary-rgb),var(--bs-link-underline-opacity))!important}.link-underline-success{--bs-link-underline-opacity:1;text-decoration-color:rgba(var(--bs-success-rgb),var(--bs-link-underline-opacity))!important}.link-underline-info{--bs-link-underline-opacity:1;text-decoration-color:rgba(var(--bs-info-rgb),var(--bs-link-underline-opacity))!important}.link-underline-warning{--bs-link-underline-opacity:1;text-decoration-color:rgba(var(--bs-warning-rgb),var(--bs-link-underline-opacity))!important}.link-underline-danger{--bs-link-underline-opacity:1;text-decoration-color:rgba(var(--bs-danger-rgb),var(--bs-link-underline-opacity))!important}.link-underline-light{--bs-link-underline-opacity:1;text-decoration-color:rgba(var(--bs-light-rgb),var(--bs-link-underline-opacity))!important}.link-underline-dark{--bs-link-underline-opacity:1;text-decoration-color:rgba(var(--bs-dark-rgb),var(--bs-link-underline-opacity))!important}.link-underline{--bs-link-underline-opacity:1;text-decoration-color:rgba(var(--bs-link-color-rgb),var(--bs-link-underline-opacity,1))!important}.link-underline-opacity-0,.link-underline-opacity-0-hover:hover{--bs-link-underline-opacity:0}.link-underline-opacity-10,.link-underline-opacity-10-hover:hover{--bs-link-underline-opacity:0.1}.link-underline-opacity-25,.link-underline-opacity-25-hover:hover{--bs-link-underline-opacity:0.25}.link-underline-opacity-50,.link-underline-opacity-50-hover:hover{--bs-link-underline-opacity:0.5}.link-underline-opacity-75,.link-underline-opacity-75-hover:hover{--bs-link-underline-opacity:0.75}.link-underline-opacity-100,.link-underline-opacity-100-hover:hover{--bs-link-underline-opacity:1}.bg-primary{--bs-bg-opacity:1;background-color:rgba(var(--bs-primary-rgb),var(--bs-bg-opacity))!important}.bg-secondary{--bs-bg-opacity:1;background-color:rgba(var(--bs-secondary-rgb),var(--bs-bg-opacity))!important}.bg-success{--bs-bg-opacity:1;background-color:rgba(var(--bs-success-rgb),var(--bs-bg-opacity))!important}.bg-info{--bs-bg-opacity:1;background-color:rgba(var(--bs-info-rgb),var(--bs-bg-opacity))!important}.bg-warning{--bs-bg-opacity:1;background-color:rgba(var(--bs-warning-rgb),var(--bs-bg-opacity))!important}.bg-danger{--bs-bg-opacity:1;background-color:rgba(var(--bs-danger-rgb),var(--bs-bg-opacity))!important}.bg-light{--bs-bg-opacity:1;background-color:rgba(var(--bs-light-rgb),var(--bs-bg-opacity))!important}.bg-dark{--bs-bg-opacity:1;background-color:rgba(var(--bs-dark-rgb),var(--bs-bg-opacity))!important}.bg-black{--bs-bg-opacity:1;background-color:rgba(var(--bs-black-rgb),var(--bs-bg-opacity))!important}.bg-white{--bs-bg-opacity:1;background-color:rgba(var(--bs-white-rgb),var(--bs-bg-opacity))!important}.bg-body{--bs-bg-opacity:1;background-color:rgba(var(--bs-body-bg-rgb),var(--bs-bg-opacity))!important}.bg-transparent{--bs-bg-opacity:1;background-color:transparent!important}.bg-body-secondary{--bs-bg-opacity:1;background-color:rgba(var(--bs-secondary-bg-rgb),var(--bs-bg-opacity))!important}.bg-body-tertiary{--bs-bg-opacity:1;background-color:rgba(var(--bs-tertiary-bg-rgb),var(--bs-bg-opacity))!important}.bg-opacity-10{--bs-bg-opacity:0.1}.bg-opacity-25{--bs-bg-opacity:0.25}.bg-opacity-50{--bs-bg-opacity:0.5}.bg-opacity-75{--bs-bg-opacity:0.75}.bg-opacity-100{--bs-bg-opacity:1}.bg-primary-subtle{background-color:var(--bs-primary-bg-subtle)!important}.bg-secondary-subtle{background-color:var(--bs-secondary-bg-subtle)!important}.bg-success-subtle{background-color:var(--bs-success-bg-subtle)!important}.bg-info-subtle{background-color:var(--bs-info-bg-subtle)!important}.bg-warning-subtle{background-color:var(--bs-warning-bg-subtle)!important}.bg-danger-subtle{background-color:var(--bs-danger-bg-subtle)!important}.bg-light-subtle{background-color:var(--bs-light-bg-subtle)!important}.bg-dark-subtle{background-color:var(--bs-dark-bg-subtle)!important}.bg-gradient{background-image:var(--bs-gradient)!important}.user-select-all{-webkit-user-select:all!important;-moz-user-select:all!important;user-select:all!important}.user-select-auto{-webkit-user-select:auto!important;-moz-user-select:auto!important;user-select:auto!important}.user-select-none{-webkit-user-select:none!important;-moz-user-select:none!important;user-select:none!important}.pe-none{pointer-events:none!important}.pe-auto{pointer-events:auto!important}.rounded{border-radius:var(--bs-border-radius)!important}.rounded-0{border-radius:0!important}.rounded-1{border-radius:var(--bs-border-radius-sm)!important}.rounded-2{border-radius:var(--bs-border-radius)!important}.rounded-3{border-radius:var(--bs-border-radius-lg)!important}.rounded-4{border-radius:var(--bs-border-radius-xl)!important}.rounded-5{border-radius:var(--bs-border-radius-xxl)!important}.rounded-circle{border-radius:50%!important}.rounded-pill{border-radius:var(--bs-border-radius-pill)!important}.rounded-top{border-top-left-radius:var(--bs-border-radius)!important;border-top-right-radius:var(--bs-border-radius)!important}.rounded-top-0{border-top-left-radius:0!important;border-top-right-radius:0!important}.rounded-top-1{border-top-left-radius:var(--bs-border-radius-sm)!important;border-top-right-radius:var(--bs-border-radius-sm)!important}.rounded-top-2{border-top-left-radius:var(--bs-border-radius)!important;border-top-right-radius:var(--bs-border-radius)!important}.rounded-top-3{border-top-left-radius:var(--bs-border-radius-lg)!important;border-top-right-radius:var(--bs-border-radius-lg)!important}.rounded-top-4{border-top-left-radius:var(--bs-border-radius-xl)!important;border-top-right-radius:var(--bs-border-radius-xl)!important}.rounded-top-5{border-top-left-radius:var(--bs-border-radius-xxl)!important;border-top-right-radius:var(--bs-border-radius-xxl)!important}.rounded-top-circle{border-top-left-radius:50%!important;border-top-right-radius:50%!important}.rounded-top-pill{border-top-left-radius:var(--bs-border-radius-pill)!important;border-top-right-radius:var(--bs-border-radius-pill)!important}.rounded-end{border-bottom-right-radius:var(--bs-border-radius)!important;border-top-right-radius:var(--bs-border-radius)!important}.rounded-end-0{border-bottom-right-radius:0!important;border-top-right-radius:0!important}.rounded-end-1{border-bottom-right-radius:var(--bs-border-radius-sm)!important;border-top-right-radius:var(--bs-border-radius-sm)!important}.rounded-end-2{border-bottom-right-radius:var(--bs-border-radius)!important;border-top-right-radius:var(--bs-border-radius)!important}.rounded-end-3{border-bottom-right-radius:var(--bs-border-radius-lg)!important;border-top-right-radius:var(--bs-border-radius-lg)!important}.rounded-end-4{border-bottom-right-radius:var(--bs-border-radius-xl)!important;border-top-right-radius:var(--bs-border-radius-xl)!important}.rounded-end-5{border-bottom-right-radius:var(--bs-border-radius-xxl)!important;border-top-right-radius:var(--bs-border-radius-xxl)!important}.rounded-end-circle{border-bottom-right-radius:50%!important;border-top-right-radius:50%!important}.rounded-end-pill{border-bottom-right-radius:var(--bs-border-radius-pill)!important;border-top-right-radius:var(--bs-border-radius-pill)!important}.rounded-bottom{border-bottom-left-radius:var(--bs-border-radius)!important;border-bottom-right-radius:var(--bs-border-radius)!important}.rounded-bottom-0{border-bottom-left-radius:0!important;border-bottom-right-radius:0!important}.rounded-bottom-1{border-bottom-left-radius:var(--bs-border-radius-sm)!important;border-bottom-right-radius:var(--bs-border-radius-sm)!important}.rounded-bottom-2{border-bottom-left-radius:var(--bs-border-radius)!important;border-bottom-right-radius:var(--bs-border-radius)!important}.rounded-bottom-3{border-bottom-left-radius:var(--bs-border-radius-lg)!important;border-bottom-right-radius:var(--bs-border-radius-lg)!important}.rounded-bottom-4{border-bottom-left-radius:var(--bs-border-radius-xl)!important;border-bottom-right-radius:var(--bs-border-radius-xl)!important}.rounded-bottom-5{border-bottom-left-radius:var(--bs-border-radius-xxl)!important;border-bottom-right-radius:var(--bs-border-radius-xxl)!important}.rounded-bottom-circle{border-bottom-left-radius:50%!important;border-bottom-right-radius:50%!important}.rounded-bottom-pill{border-bottom-left-radius:var(--bs-border-radius-pill)!important;border-bottom-right-radius:var(--bs-border-radius-pill)!important}.rounded-start{border-bottom-left-radius:var(--bs-border-radius)!important;border-top-left-radius:var(--bs-border-radius)!important}.rounded-start-0{border-bottom-left-radius:0!important;border-top-left-radius:0!important}.rounded-start-1{border-bottom-left-radius:var(--bs-border-radius-sm)!important;border-top-left-radius:var(--bs-border-radius-sm)!important}.rounded-start-2{border-bottom-left-radius:var(--bs-border-radius)!important;border-top-left-radius:var(--bs-border-radius)!important}.rounded-start-3{border-bottom-left-radius:var(--bs-border-radius-lg)!important;border-top-left-radius:var(--bs-border-radius-lg)!important}.rounded-start-4{border-bottom-left-radius:var(--bs-border-radius-xl)!important;border-top-left-radius:var(--bs-border-radius-xl)!important}.rounded-start-5{border-bottom-left-radius:var(--bs-border-radius-xxl)!important;border-top-left-radius:var(--bs-border-radius-xxl)!important}.rounded-start-circle{border-bottom-left-radius:50%!important;border-top-left-radius:50%!important}.rounded-start-pill{border-bottom-left-radius:var(--bs-border-radius-pill)!important;border-top-left-radius:var(--bs-border-radius-pill)!important}.visible{visibility:visible!important}.invisible{visibility:hidden!important}.z-n1{z-index:-1!important}.z-0{z-index:0!important}.z-1{z-index:1!important}.z-2{z-index:2!important}.z-3{z-index:3!important}@media (min-width:576px){.float-sm-start{float:left!important}.float-sm-end{float:right!important}.float-sm-none{float:none!important}.object-fit-sm-contain{-o-object-fit:contain!important;object-fit:contain!important}.object-fit-sm-cover{-o-object-fit:cover!important;object-fit:cover!important}.object-fit-sm-fill{-o-object-fit:fill!important;object-fit:fill!important}.object-fit-sm-scale{-o-object-fit:scale-down!important;object-fit:scale-down!important}.object-fit-sm-none{-o-object-fit:none!important;object-fit:none!important}.d-sm-inline{display:inline!important}.d-sm-inline-block{display:inline-block!important}.d-sm-block{display:block!important}.d-sm-grid{display:grid!important}.d-sm-inline-grid{display:inline-grid!important}.d-sm-table{display:table!important}.d-sm-table-row{display:table-row!important}.d-sm-table-cell{display:table-cell!important}.d-sm-flex{display:flex!important}.d-sm-inline-flex{display:inline-flex!important}.d-sm-none{display:none!important}.flex-sm-fill{flex:1 1 auto!important}.flex-sm-row{flex-direction:row!important}.flex-sm-column{flex-direction:column!important}.flex-sm-row-reverse{flex-direction:row-reverse!important}.flex-sm-column-reverse{flex-direction:column-reverse!important}.flex-sm-grow-0{flex-grow:0!important}.flex-sm-grow-1{flex-grow:1!important}.flex-sm-shrink-0{flex-shrink:0!important}.flex-sm-shrink-1{flex-shrink:1!important}.flex-sm-wrap{flex-wrap:wrap!important}.flex-sm-nowrap{flex-wrap:nowrap!important}.flex-sm-wrap-reverse{flex-wrap:wrap-reverse!important}.justify-content-sm-start{justify-content:flex-start!important}.justify-content-sm-end{justify-content:flex-end!important}.justify-content-sm-center{justify-content:center!important}.justify-content-sm-between{justify-content:space-between!important}.justify-content-sm-around{justify-content:space-around!important}.justify-content-sm-evenly{justify-content:space-evenly!important}.align-items-sm-start{align-items:flex-start!important}.align-items-sm-end{align-items:flex-end!important}.align-items-sm-center{align-items:center!important}.align-items-sm-baseline{align-items:baseline!important}.align-items-sm-stretch{align-items:stretch!important}.align-content-sm-start{align-content:flex-start!important}.align-content-sm-end{align-content:flex-end!important}.align-content-sm-center{align-content:center!important}.align-content-sm-between{align-content:space-between!important}.align-content-sm-around{align-content:space-around!important}.align-content-sm-stretch{align-content:stretch!important}.align-self-sm-auto{align-self:auto!important}.align-self-sm-start{align-self:flex-start!important}.align-self-sm-end{align-self:flex-end!important}.align-self-sm-center{align-self:center!important}.align-self-sm-baseline{align-self:baseline!important}.align-self-sm-stretch{align-self:stretch!important}.order-sm-first{order:-1!important}.order-sm-0{order:0!important}.order-sm-1{order:1!important}.order-sm-2{order:2!important}.order-sm-3{order:3!important}.order-sm-4{order:4!important}.order-sm-5{order:5!important}.order-sm-last{order:6!important}.m-sm-0{margin:0!important}.m-sm-1{margin:.25rem!important}.m-sm-2{margin:.5rem!important}.m-sm-3{margin:1rem!important}.m-sm-4{margin:1.5rem!important}.m-sm-5{margin:3rem!important}.m-sm-auto{margin:auto!important}.mx-sm-0{margin-left:0!important;margin-right:0!important}.mx-sm-1{margin-left:.25rem!important;margin-right:.25rem!important}.mx-sm-2{margin-left:.5rem!important;margin-right:.5rem!important}.mx-sm-3{margin-left:1rem!important;margin-right:1rem!important}.mx-sm-4{margin-left:1.5rem!important;margin-right:1.5rem!important}.mx-sm-5{margin-left:3rem!important;margin-right:3rem!important}.mx-sm-auto{margin-left:auto!important;margin-right:auto!important}.my-sm-0{margin-bottom:0!important;margin-top:0!important}.my-sm-1{margin-bottom:.25rem!important;margin-top:.25rem!important}.my-sm-2{margin-bottom:.5rem!important;margin-top:.5rem!important}.my-sm-3{margin-bottom:1rem!important;margin-top:1rem!important}.my-sm-4{margin-bottom:1.5rem!important;margin-top:1.5rem!important}.my-sm-5{margin-bottom:3rem!important;margin-top:3rem!important}.my-sm-auto{margin-bottom:auto!important;margin-top:auto!important}.mt-sm-0{margin-top:0!important}.mt-sm-1{margin-top:.25rem!important}.mt-sm-2{margin-top:.5rem!important}.mt-sm-3{margin-top:1rem!important}.mt-sm-4{margin-top:1.5rem!important}.mt-sm-5{margin-top:3rem!important}.mt-sm-auto{margin-top:auto!important}.me-sm-0{margin-right:0!important}.me-sm-1{margin-right:.25rem!important}.me-sm-2{margin-right:.5rem!important}.me-sm-3{margin-right:1rem!important}.me-sm-4{margin-right:1.5rem!important}.me-sm-5{margin-right:3rem!important}.me-sm-auto{margin-right:auto!important}.mb-sm-0{margin-bottom:0!important}.mb-sm-1{margin-bottom:.25rem!important}.mb-sm-2{margin-bottom:.5rem!important}.mb-sm-3{margin-bottom:1rem!important}.mb-sm-4{margin-bottom:1.5rem!important}.mb-sm-5{margin-bottom:3rem!important}.mb-sm-auto{margin-bottom:auto!important}.ms-sm-0{margin-left:0!important}.ms-sm-1{margin-left:.25rem!important}.ms-sm-2{margin-left:.5rem!important}.ms-sm-3{margin-left:1rem!important}.ms-sm-4{margin-left:1.5rem!important}.ms-sm-5{margin-left:3rem!important}.ms-sm-auto{margin-left:auto!important}.p-sm-0{padding:0!important}.p-sm-1{padding:.25rem!important}.p-sm-2{padding:.5rem!important}.p-sm-3{padding:1rem!important}.p-sm-4{padding:1.5rem!important}.p-sm-5{padding:3rem!important}.px-sm-0{padding-left:0!important;padding-right:0!important}.px-sm-1{padding-left:.25rem!important;padding-right:.25rem!important}.px-sm-2{padding-left:.5rem!important;padding-right:.5rem!important}.px-sm-3{padding-left:1rem!important;padding-right:1rem!important}.px-sm-4{padding-left:1.5rem!important;padding-right:1.5rem!important}.px-sm-5{padding-left:3rem!important;padding-right:3rem!important}.py-sm-0{padding-bottom:0!important;padding-top:0!important}.py-sm-1{padding-bottom:.25rem!important;padding-top:.25rem!important}.py-sm-2{padding-bottom:.5rem!important;padding-top:.5rem!important}.py-sm-3{padding-bottom:1rem!important;padding-top:1rem!important}.py-sm-4{padding-bottom:1.5rem!important;padding-top:1.5rem!important}.py-sm-5{padding-bottom:3rem!important;padding-top:3rem!important}.pt-sm-0{padding-top:0!important}.pt-sm-1{padding-top:.25rem!important}.pt-sm-2{padding-top:.5rem!important}.pt-sm-3{padding-top:1rem!important}.pt-sm-4{padding-top:1.5rem!important}.pt-sm-5{padding-top:3rem!important}.pe-sm-0{padding-right:0!important}.pe-sm-1{padding-right:.25rem!important}.pe-sm-2{padding-right:.5rem!important}.pe-sm-3{padding-right:1rem!important}.pe-sm-4{padding-right:1.5rem!important}.pe-sm-5{padding-right:3rem!important}.pb-sm-0{padding-bottom:0!important}.pb-sm-1{padding-bottom:.25rem!important}.pb-sm-2{padding-bottom:.5rem!important}.pb-sm-3{padding-bottom:1rem!important}.pb-sm-4{padding-bottom:1.5rem!important}.pb-sm-5{padding-bottom:3rem!important}.ps-sm-0{padding-left:0!important}.ps-sm-1{padding-left:.25rem!important}.ps-sm-2{padding-left:.5rem!important}.ps-sm-3{padding-left:1rem!important}.ps-sm-4{padding-left:1.5rem!important}.ps-sm-5{padding-left:3rem!important}.gap-sm-0{gap:0!important}.gap-sm-1{gap:.25rem!important}.gap-sm-2{gap:.5rem!important}.gap-sm-3{gap:1rem!important}.gap-sm-4{gap:1.5rem!important}.gap-sm-5{gap:3rem!important}.row-gap-sm-0{row-gap:0!important}.row-gap-sm-1{row-gap:.25rem!important}.row-gap-sm-2{row-gap:.5rem!important}.row-gap-sm-3{row-gap:1rem!important}.row-gap-sm-4{row-gap:1.5rem!important}.row-gap-sm-5{row-gap:3rem!important}.column-gap-sm-0{-moz-column-gap:0!important;column-gap:0!important}.column-gap-sm-1{-moz-column-gap:.25rem!important;column-gap:.25rem!important}.column-gap-sm-2{-moz-column-gap:.5rem!important;column-gap:.5rem!important}.column-gap-sm-3{-moz-column-gap:1rem!important;column-gap:1rem!important}.column-gap-sm-4{-moz-column-gap:1.5rem!important;column-gap:1.5rem!important}.column-gap-sm-5{-moz-column-gap:3rem!important;column-gap:3rem!important}.text-sm-start{text-align:left!important}.text-sm-end{text-align:right!important}.text-sm-center{text-align:center!important}}@media (min-width:768px){.float-md-start{float:left!important}.float-md-end{float:right!important}.float-md-none{float:none!important}.object-fit-md-contain{-o-object-fit:contain!important;object-fit:contain!important}.object-fit-md-cover{-o-object-fit:cover!important;object-fit:cover!important}.object-fit-md-fill{-o-object-fit:fill!important;object-fit:fill!important}.object-fit-md-scale{-o-object-fit:scale-down!important;object-fit:scale-down!important}.object-fit-md-none{-o-object-fit:none!important;object-fit:none!important}.d-md-inline{display:inline!important}.d-md-inline-block{display:inline-block!important}.d-md-block{display:block!important}.d-md-grid{display:grid!important}.d-md-inline-grid{display:inline-grid!important}.d-md-table{display:table!important}.d-md-table-row{display:table-row!important}.d-md-table-cell{display:table-cell!important}.d-md-flex{display:flex!important}.d-md-inline-flex{display:inline-flex!important}.d-md-none{display:none!important}.flex-md-fill{flex:1 1 auto!important}.flex-md-row{flex-direction:row!important}.flex-md-column{flex-direction:column!important}.flex-md-row-reverse{flex-direction:row-reverse!important}.flex-md-column-reverse{flex-direction:column-reverse!important}.flex-md-grow-0{flex-grow:0!important}.flex-md-grow-1{flex-grow:1!important}.flex-md-shrink-0{flex-shrink:0!important}.flex-md-shrink-1{flex-shrink:1!important}.flex-md-wrap{flex-wrap:wrap!important}.flex-md-nowrap{flex-wrap:nowrap!important}.flex-md-wrap-reverse{flex-wrap:wrap-reverse!important}.justify-content-md-start{justify-content:flex-start!important}.justify-content-md-end{justify-content:flex-end!important}.justify-content-md-center{justify-content:center!important}.justify-content-md-between{justify-content:space-between!important}.justify-content-md-around{justify-content:space-around!important}.justify-content-md-evenly{justify-content:space-evenly!important}.align-items-md-start{align-items:flex-start!important}.align-items-md-end{align-items:flex-end!important}.align-items-md-center{align-items:center!important}.align-items-md-baseline{align-items:baseline!important}.align-items-md-stretch{align-items:stretch!important}.align-content-md-start{align-content:flex-start!important}.align-content-md-end{align-content:flex-end!important}.align-content-md-center{align-content:center!important}.align-content-md-between{align-content:space-between!important}.align-content-md-around{align-content:space-around!important}.align-content-md-stretch{align-content:stretch!important}.align-self-md-auto{align-self:auto!important}.align-self-md-start{align-self:flex-start!important}.align-self-md-end{align-self:flex-end!important}.align-self-md-center{align-self:center!important}.align-self-md-baseline{align-self:baseline!important}.align-self-md-stretch{align-self:stretch!important}.order-md-first{order:-1!important}.order-md-0{order:0!important}.order-md-1{order:1!important}.order-md-2{order:2!important}.order-md-3{order:3!important}.order-md-4{order:4!important}.order-md-5{order:5!important}.order-md-last{order:6!important}.m-md-0{margin:0!important}.m-md-1{margin:.25rem!important}.m-md-2{margin:.5rem!important}.m-md-3{margin:1rem!important}.m-md-4{margin:1.5rem!important}.m-md-5{margin:3rem!important}.m-md-auto{margin:auto!important}.mx-md-0{margin-left:0!important;margin-right:0!important}.mx-md-1{margin-left:.25rem!important;margin-right:.25rem!important}.mx-md-2{margin-left:.5rem!important;margin-right:.5rem!important}.mx-md-3{margin-left:1rem!important;margin-right:1rem!important}.mx-md-4{margin-left:1.5rem!important;margin-right:1.5rem!important}.mx-md-5{margin-left:3rem!important;margin-right:3rem!important}.mx-md-auto{margin-left:auto!important;margin-right:auto!important}.my-md-0{margin-bottom:0!important;margin-top:0!important}.my-md-1{margin-bottom:.25rem!important;margin-top:.25rem!important}.my-md-2{margin-bottom:.5rem!important;margin-top:.5rem!important}.my-md-3{margin-bottom:1rem!important;margin-top:1rem!important}.my-md-4{margin-bottom:1.5rem!important;margin-top:1.5rem!important}.my-md-5{margin-bottom:3rem!important;margin-top:3rem!important}.my-md-auto{margin-bottom:auto!important;margin-top:auto!important}.mt-md-0{margin-top:0!important}.mt-md-1{margin-top:.25rem!important}.mt-md-2{margin-top:.5rem!important}.mt-md-3{margin-top:1rem!important}.mt-md-4{margin-top:1.5rem!important}.mt-md-5{margin-top:3rem!important}.mt-md-auto{margin-top:auto!important}.me-md-0{margin-right:0!important}.me-md-1{margin-right:.25rem!important}.me-md-2{margin-right:.5rem!important}.me-md-3{margin-right:1rem!important}.me-md-4{margin-right:1.5rem!important}.me-md-5{margin-right:3rem!important}.me-md-auto{margin-right:auto!important}.mb-md-0{margin-bottom:0!important}.mb-md-1{margin-bottom:.25rem!important}.mb-md-2{margin-bottom:.5rem!important}.mb-md-3{margin-bottom:1rem!important}.mb-md-4{margin-bottom:1.5rem!important}.mb-md-5{margin-bottom:3rem!important}.mb-md-auto{margin-bottom:auto!important}.ms-md-0{margin-left:0!important}.ms-md-1{margin-left:.25rem!important}.ms-md-2{margin-left:.5rem!important}.ms-md-3{margin-left:1rem!important}.ms-md-4{margin-left:1.5rem!important}.ms-md-5{margin-left:3rem!important}.ms-md-auto{margin-left:auto!important}.p-md-0{padding:0!important}.p-md-1{padding:.25rem!important}.p-md-2{padding:.5rem!important}.p-md-3{padding:1rem!important}.p-md-4{padding:1.5rem!important}.p-md-5{padding:3rem!important}.px-md-0{padding-left:0!important;padding-right:0!important}.px-md-1{padding-left:.25rem!important;padding-right:.25rem!important}.px-md-2{padding-left:.5rem!important;padding-right:.5rem!important}.px-md-3{padding-left:1rem!important;padding-right:1rem!important}.px-md-4{padding-left:1.5rem!important;padding-right:1.5rem!important}.px-md-5{padding-left:3rem!important;padding-right:3rem!important}.py-md-0{padding-bottom:0!important;padding-top:0!important}.py-md-1{padding-bottom:.25rem!important;padding-top:.25rem!important}.py-md-2{padding-bottom:.5rem!important;padding-top:.5rem!important}.py-md-3{padding-bottom:1rem!important;padding-top:1rem!important}.py-md-4{padding-bottom:1.5rem!important;padding-top:1.5rem!important}.py-md-5{padding-bottom:3rem!important;padding-top:3rem!important}.pt-md-0{padding-top:0!important}.pt-md-1{padding-top:.25rem!important}.pt-md-2{padding-top:.5rem!important}.pt-md-3{padding-top:1rem!important}.pt-md-4{padding-top:1.5rem!important}.pt-md-5{padding-top:3rem!important}.pe-md-0{padding-right:0!important}.pe-md-1{padding-right:.25rem!important}.pe-md-2{padding-right:.5rem!important}.pe-md-3{padding-right:1rem!important}.pe-md-4{padding-right:1.5rem!important}.pe-md-5{padding-right:3rem!important}.pb-md-0{padding-bottom:0!important}.pb-md-1{padding-bottom:.25rem!important}.pb-md-2{padding-bottom:.5rem!important}.pb-md-3{padding-bottom:1rem!important}.pb-md-4{padding-bottom:1.5rem!important}.pb-md-5{padding-bottom:3rem!important}.ps-md-0{padding-left:0!important}.ps-md-1{padding-left:.25rem!important}.ps-md-2{padding-left:.5rem!important}.ps-md-3{padding-left:1rem!important}.ps-md-4{padding-left:1.5rem!important}.ps-md-5{padding-left:3rem!important}.gap-md-0{gap:0!important}.gap-md-1{gap:.25rem!important}.gap-md-2{gap:.5rem!important}.gap-md-3{gap:1rem!important}.gap-md-4{gap:1.5rem!important}.gap-md-5{gap:3rem!important}.row-gap-md-0{row-gap:0!important}.row-gap-md-1{row-gap:.25rem!important}.row-gap-md-2{row-gap:.5rem!important}.row-gap-md-3{row-gap:1rem!important}.row-gap-md-4{row-gap:1.5rem!important}.row-gap-md-5{row-gap:3rem!important}.column-gap-md-0{-moz-column-gap:0!important;column-gap:0!important}.column-gap-md-1{-moz-column-gap:.25rem!important;column-gap:.25rem!important}.column-gap-md-2{-moz-column-gap:.5rem!important;column-gap:.5rem!important}.column-gap-md-3{-moz-column-gap:1rem!important;column-gap:1rem!important}.column-gap-md-4{-moz-column-gap:1.5rem!important;column-gap:1.5rem!important}.column-gap-md-5{-moz-column-gap:3rem!important;column-gap:3rem!important}.text-md-start{text-align:left!important}.text-md-end{text-align:right!important}.text-md-center{text-align:center!important}}@media (min-width:992px){.float-lg-start{float:left!important}.float-lg-end{float:right!important}.float-lg-none{float:none!important}.object-fit-lg-contain{-o-object-fit:contain!important;object-fit:contain!important}.object-fit-lg-cover{-o-object-fit:cover!important;object-fit:cover!important}.object-fit-lg-fill{-o-object-fit:fill!important;object-fit:fill!important}.object-fit-lg-scale{-o-object-fit:scale-down!important;object-fit:scale-down!important}.object-fit-lg-none{-o-object-fit:none!important;object-fit:none!important}.d-lg-inline{display:inline!important}.d-lg-inline-block{display:inline-block!important}.d-lg-block{display:block!important}.d-lg-grid{display:grid!important}.d-lg-inline-grid{display:inline-grid!important}.d-lg-table{display:table!important}.d-lg-table-row{display:table-row!important}.d-lg-table-cell{display:table-cell!important}.d-lg-flex{display:flex!important}.d-lg-inline-flex{display:inline-flex!important}.d-lg-none{display:none!important}.flex-lg-fill{flex:1 1 auto!important}.flex-lg-row{flex-direction:row!important}.flex-lg-column{flex-direction:column!important}.flex-lg-row-reverse{flex-direction:row-reverse!important}.flex-lg-column-reverse{flex-direction:column-reverse!important}.flex-lg-grow-0{flex-grow:0!important}.flex-lg-grow-1{flex-grow:1!important}.flex-lg-shrink-0{flex-shrink:0!important}.flex-lg-shrink-1{flex-shrink:1!important}.flex-lg-wrap{flex-wrap:wrap!important}.flex-lg-nowrap{flex-wrap:nowrap!important}.flex-lg-wrap-reverse{flex-wrap:wrap-reverse!important}.justify-content-lg-start{justify-content:flex-start!important}.justify-content-lg-end{justify-content:flex-end!important}.justify-content-lg-center{justify-content:center!important}.justify-content-lg-between{justify-content:space-between!important}.justify-content-lg-around{justify-content:space-around!important}.justify-content-lg-evenly{justify-content:space-evenly!important}.align-items-lg-start{align-items:flex-start!important}.align-items-lg-end{align-items:flex-end!important}.align-items-lg-center{align-items:center!important}.align-items-lg-baseline{align-items:baseline!important}.align-items-lg-stretch{align-items:stretch!important}.align-content-lg-start{align-content:flex-start!important}.align-content-lg-end{align-content:flex-end!important}.align-content-lg-center{align-content:center!important}.align-content-lg-between{align-content:space-between!important}.align-content-lg-around{align-content:space-around!important}.align-content-lg-stretch{align-content:stretch!important}.align-self-lg-auto{align-self:auto!important}.align-self-lg-start{align-self:flex-start!important}.align-self-lg-end{align-self:flex-end!important}.align-self-lg-center{align-self:center!important}.align-self-lg-baseline{align-self:baseline!important}.align-self-lg-stretch{align-self:stretch!important}.order-lg-first{order:-1!important}.order-lg-0{order:0!important}.order-lg-1{order:1!important}.order-lg-2{order:2!important}.order-lg-3{order:3!important}.order-lg-4{order:4!important}.order-lg-5{order:5!important}.order-lg-last{order:6!important}.m-lg-0{margin:0!important}.m-lg-1{margin:.25rem!important}.m-lg-2{margin:.5rem!important}.m-lg-3{margin:1rem!important}.m-lg-4{margin:1.5rem!important}.m-lg-5{margin:3rem!important}.m-lg-auto{margin:auto!important}.mx-lg-0{margin-left:0!important;margin-right:0!important}.mx-lg-1{margin-left:.25rem!important;margin-right:.25rem!important}.mx-lg-2{margin-left:.5rem!important;margin-right:.5rem!important}.mx-lg-3{margin-left:1rem!important;margin-right:1rem!important}.mx-lg-4{margin-left:1.5rem!important;margin-right:1.5rem!important}.mx-lg-5{margin-left:3rem!important;margin-right:3rem!important}.mx-lg-auto{margin-left:auto!important;margin-right:auto!important}.my-lg-0{margin-bottom:0!important;margin-top:0!important}.my-lg-1{margin-bottom:.25rem!important;margin-top:.25rem!important}.my-lg-2{margin-bottom:.5rem!important;margin-top:.5rem!important}.my-lg-3{margin-bottom:1rem!important;margin-top:1rem!important}.my-lg-4{margin-bottom:1.5rem!important;margin-top:1.5rem!important}.my-lg-5{margin-bottom:3rem!important;margin-top:3rem!important}.my-lg-auto{margin-bottom:auto!important;margin-top:auto!important}.mt-lg-0{margin-top:0!important}.mt-lg-1{margin-top:.25rem!important}.mt-lg-2{margin-top:.5rem!important}.mt-lg-3{margin-top:1rem!important}.mt-lg-4{margin-top:1.5rem!important}.mt-lg-5{margin-top:3rem!important}.mt-lg-auto{margin-top:auto!important}.me-lg-0{margin-right:0!important}.me-lg-1{margin-right:.25rem!important}.me-lg-2{margin-right:.5rem!important}.me-lg-3{margin-right:1rem!important}.me-lg-4{margin-right:1.5rem!important}.me-lg-5{margin-right:3rem!important}.me-lg-auto{margin-right:auto!important}.mb-lg-0{margin-bottom:0!important}.mb-lg-1{margin-bottom:.25rem!important}.mb-lg-2{margin-bottom:.5rem!important}.mb-lg-3{margin-bottom:1rem!important}.mb-lg-4{margin-bottom:1.5rem!important}.mb-lg-5{margin-bottom:3rem!important}.mb-lg-auto{margin-bottom:auto!important}.ms-lg-0{margin-left:0!important}.ms-lg-1{margin-left:.25rem!important}.ms-lg-2{margin-left:.5rem!important}.ms-lg-3{margin-left:1rem!important}.ms-lg-4{margin-left:1.5rem!important}.ms-lg-5{margin-left:3rem!important}.ms-lg-auto{margin-left:auto!important}.p-lg-0{padding:0!important}.p-lg-1{padding:.25rem!important}.p-lg-2{padding:.5rem!important}.p-lg-3{padding:1rem!important}.p-lg-4{padding:1.5rem!important}.p-lg-5{padding:3rem!important}.px-lg-0{padding-left:0!important;padding-right:0!important}.px-lg-1{padding-left:.25rem!important;padding-right:.25rem!important}.px-lg-2{padding-left:.5rem!important;padding-right:.5rem!important}.px-lg-3{padding-left:1rem!important;padding-right:1rem!important}.px-lg-4{padding-left:1.5rem!important;padding-right:1.5rem!important}.px-lg-5{padding-left:3rem!important;padding-right:3rem!important}.py-lg-0{padding-bottom:0!important;padding-top:0!important}.py-lg-1{padding-bottom:.25rem!important;padding-top:.25rem!important}.py-lg-2{padding-bottom:.5rem!important;padding-top:.5rem!important}.py-lg-3{padding-bottom:1rem!important;padding-top:1rem!important}.py-lg-4{padding-bottom:1.5rem!important;padding-top:1.5rem!important}.py-lg-5{padding-bottom:3rem!important;padding-top:3rem!important}.pt-lg-0{padding-top:0!important}.pt-lg-1{padding-top:.25rem!important}.pt-lg-2{padding-top:.5rem!important}.pt-lg-3{padding-top:1rem!important}.pt-lg-4{padding-top:1.5rem!important}.pt-lg-5{padding-top:3rem!important}.pe-lg-0{padding-right:0!important}.pe-lg-1{padding-right:.25rem!important}.pe-lg-2{padding-right:.5rem!important}.pe-lg-3{padding-right:1rem!important}.pe-lg-4{padding-right:1.5rem!important}.pe-lg-5{padding-right:3rem!important}.pb-lg-0{padding-bottom:0!important}.pb-lg-1{padding-bottom:.25rem!important}.pb-lg-2{padding-bottom:.5rem!important}.pb-lg-3{padding-bottom:1rem!important}.pb-lg-4{padding-bottom:1.5rem!important}.pb-lg-5{padding-bottom:3rem!important}.ps-lg-0{padding-left:0!important}.ps-lg-1{padding-left:.25rem!important}.ps-lg-2{padding-left:.5rem!important}.ps-lg-3{padding-left:1rem!important}.ps-lg-4{padding-left:1.5rem!important}.ps-lg-5{padding-left:3rem!important}.gap-lg-0{gap:0!important}.gap-lg-1{gap:.25rem!important}.gap-lg-2{gap:.5rem!important}.gap-lg-3{gap:1rem!important}.gap-lg-4{gap:1.5rem!important}.gap-lg-5{gap:3rem!important}.row-gap-lg-0{row-gap:0!important}.row-gap-lg-1{row-gap:.25rem!important}.row-gap-lg-2{row-gap:.5rem!important}.row-gap-lg-3{row-gap:1rem!important}.row-gap-lg-4{row-gap:1.5rem!important}.row-gap-lg-5{row-gap:3rem!important}.column-gap-lg-0{-moz-column-gap:0!important;column-gap:0!important}.column-gap-lg-1{-moz-column-gap:.25rem!important;column-gap:.25rem!important}.column-gap-lg-2{-moz-column-gap:.5rem!important;column-gap:.5rem!important}.column-gap-lg-3{-moz-column-gap:1rem!important;column-gap:1rem!important}.column-gap-lg-4{-moz-column-gap:1.5rem!important;column-gap:1.5rem!important}.column-gap-lg-5{-moz-column-gap:3rem!important;column-gap:3rem!important}.text-lg-start{text-align:left!important}.text-lg-end{text-align:right!important}.text-lg-center{text-align:center!important}}@media (min-width:1200px){.float-xl-start{float:left!important}.float-xl-end{float:right!important}.float-xl-none{float:none!important}.object-fit-xl-contain{-o-object-fit:contain!important;object-fit:contain!important}.object-fit-xl-cover{-o-object-fit:cover!important;object-fit:cover!important}.object-fit-xl-fill{-o-object-fit:fill!important;object-fit:fill!important}.object-fit-xl-scale{-o-object-fit:scale-down!important;object-fit:scale-down!important}.object-fit-xl-none{-o-object-fit:none!important;object-fit:none!important}.d-xl-inline{display:inline!important}.d-xl-inline-block{display:inline-block!important}.d-xl-block{display:block!important}.d-xl-grid{display:grid!important}.d-xl-inline-grid{display:inline-grid!important}.d-xl-table{display:table!important}.d-xl-table-row{display:table-row!important}.d-xl-table-cell{display:table-cell!important}.d-xl-flex{display:flex!important}.d-xl-inline-flex{display:inline-flex!important}.d-xl-none{display:none!important}.flex-xl-fill{flex:1 1 auto!important}.flex-xl-row{flex-direction:row!important}.flex-xl-column{flex-direction:column!important}.flex-xl-row-reverse{flex-direction:row-reverse!important}.flex-xl-column-reverse{flex-direction:column-reverse!important}.flex-xl-grow-0{flex-grow:0!important}.flex-xl-grow-1{flex-grow:1!important}.flex-xl-shrink-0{flex-shrink:0!important}.flex-xl-shrink-1{flex-shrink:1!important}.flex-xl-wrap{flex-wrap:wrap!important}.flex-xl-nowrap{flex-wrap:nowrap!important}.flex-xl-wrap-reverse{flex-wrap:wrap-reverse!important}.justify-content-xl-start{justify-content:flex-start!important}.justify-content-xl-end{justify-content:flex-end!important}.justify-content-xl-center{justify-content:center!important}.justify-content-xl-between{justify-content:space-between!important}.justify-content-xl-around{justify-content:space-around!important}.justify-content-xl-evenly{justify-content:space-evenly!important}.align-items-xl-start{align-items:flex-start!important}.align-items-xl-end{align-items:flex-end!important}.align-items-xl-center{align-items:center!important}.align-items-xl-baseline{align-items:baseline!important}.align-items-xl-stretch{align-items:stretch!important}.align-content-xl-start{align-content:flex-start!important}.align-content-xl-end{align-content:flex-end!important}.align-content-xl-center{align-content:center!important}.align-content-xl-between{align-content:space-between!important}.align-content-xl-around{align-content:space-around!important}.align-content-xl-stretch{align-content:stretch!important}.align-self-xl-auto{align-self:auto!important}.align-self-xl-start{align-self:flex-start!important}.align-self-xl-end{align-self:flex-end!important}.align-self-xl-center{align-self:center!important}.align-self-xl-baseline{align-self:baseline!important}.align-self-xl-stretch{align-self:stretch!important}.order-xl-first{order:-1!important}.order-xl-0{order:0!important}.order-xl-1{order:1!important}.order-xl-2{order:2!important}.order-xl-3{order:3!important}.order-xl-4{order:4!important}.order-xl-5{order:5!important}.order-xl-last{order:6!important}.m-xl-0{margin:0!important}.m-xl-1{margin:.25rem!important}.m-xl-2{margin:.5rem!important}.m-xl-3{margin:1rem!important}.m-xl-4{margin:1.5rem!important}.m-xl-5{margin:3rem!important}.m-xl-auto{margin:auto!important}.mx-xl-0{margin-left:0!important;margin-right:0!important}.mx-xl-1{margin-left:.25rem!important;margin-right:.25rem!important}.mx-xl-2{margin-left:.5rem!important;margin-right:.5rem!important}.mx-xl-3{margin-left:1rem!important;margin-right:1rem!important}.mx-xl-4{margin-left:1.5rem!important;margin-right:1.5rem!important}.mx-xl-5{margin-left:3rem!important;margin-right:3rem!important}.mx-xl-auto{margin-left:auto!important;margin-right:auto!important}.my-xl-0{margin-bottom:0!important;margin-top:0!important}.my-xl-1{margin-bottom:.25rem!important;margin-top:.25rem!important}.my-xl-2{margin-bottom:.5rem!important;margin-top:.5rem!important}.my-xl-3{margin-bottom:1rem!important;margin-top:1rem!important}.my-xl-4{margin-bottom:1.5rem!important;margin-top:1.5rem!important}.my-xl-5{margin-bottom:3rem!important;margin-top:3rem!important}.my-xl-auto{margin-bottom:auto!important;margin-top:auto!important}.mt-xl-0{margin-top:0!important}.mt-xl-1{margin-top:.25rem!important}.mt-xl-2{margin-top:.5rem!important}.mt-xl-3{margin-top:1rem!important}.mt-xl-4{margin-top:1.5rem!important}.mt-xl-5{margin-top:3rem!important}.mt-xl-auto{margin-top:auto!important}.me-xl-0{margin-right:0!important}.me-xl-1{margin-right:.25rem!important}.me-xl-2{margin-right:.5rem!important}.me-xl-3{margin-right:1rem!important}.me-xl-4{margin-right:1.5rem!important}.me-xl-5{margin-right:3rem!important}.me-xl-auto{margin-right:auto!important}.mb-xl-0{margin-bottom:0!important}.mb-xl-1{margin-bottom:.25rem!important}.mb-xl-2{margin-bottom:.5rem!important}.mb-xl-3{margin-bottom:1rem!important}.mb-xl-4{margin-bottom:1.5rem!important}.mb-xl-5{margin-bottom:3rem!important}.mb-xl-auto{margin-bottom:auto!important}.ms-xl-0{margin-left:0!important}.ms-xl-1{margin-left:.25rem!important}.ms-xl-2{margin-left:.5rem!important}.ms-xl-3{margin-left:1rem!important}.ms-xl-4{margin-left:1.5rem!important}.ms-xl-5{margin-left:3rem!important}.ms-xl-auto{margin-left:auto!important}.p-xl-0{padding:0!important}.p-xl-1{padding:.25rem!important}.p-xl-2{padding:.5rem!important}.p-xl-3{padding:1rem!important}.p-xl-4{padding:1.5rem!important}.p-xl-5{padding:3rem!important}.px-xl-0{padding-left:0!important;padding-right:0!important}.px-xl-1{padding-left:.25rem!important;padding-right:.25rem!important}.px-xl-2{padding-left:.5rem!important;padding-right:.5rem!important}.px-xl-3{padding-left:1rem!important;padding-right:1rem!important}.px-xl-4{padding-left:1.5rem!important;padding-right:1.5rem!important}.px-xl-5{padding-left:3rem!important;padding-right:3rem!important}.py-xl-0{padding-bottom:0!important;padding-top:0!important}.py-xl-1{padding-bottom:.25rem!important;padding-top:.25rem!important}.py-xl-2{padding-bottom:.5rem!important;padding-top:.5rem!important}.py-xl-3{padding-bottom:1rem!important;padding-top:1rem!important}.py-xl-4{padding-bottom:1.5rem!important;padding-top:1.5rem!important}.py-xl-5{padding-bottom:3rem!important;padding-top:3rem!important}.pt-xl-0{padding-top:0!important}.pt-xl-1{padding-top:.25rem!important}.pt-xl-2{padding-top:.5rem!important}.pt-xl-3{padding-top:1rem!important}.pt-xl-4{padding-top:1.5rem!important}.pt-xl-5{padding-top:3rem!important}.pe-xl-0{padding-right:0!important}.pe-xl-1{padding-right:.25rem!important}.pe-xl-2{padding-right:.5rem!important}.pe-xl-3{padding-right:1rem!important}.pe-xl-4{padding-right:1.5rem!important}.pe-xl-5{padding-right:3rem!important}.pb-xl-0{padding-bottom:0!important}.pb-xl-1{padding-bottom:.25rem!important}.pb-xl-2{padding-bottom:.5rem!important}.pb-xl-3{padding-bottom:1rem!important}.pb-xl-4{padding-bottom:1.5rem!important}.pb-xl-5{padding-bottom:3rem!important}.ps-xl-0{padding-left:0!important}.ps-xl-1{padding-left:.25rem!important}.ps-xl-2{padding-left:.5rem!important}.ps-xl-3{padding-left:1rem!important}.ps-xl-4{padding-left:1.5rem!important}.ps-xl-5{padding-left:3rem!important}.gap-xl-0{gap:0!important}.gap-xl-1{gap:.25rem!important}.gap-xl-2{gap:.5rem!important}.gap-xl-3{gap:1rem!important}.gap-xl-4{gap:1.5rem!important}.gap-xl-5{gap:3rem!important}.row-gap-xl-0{row-gap:0!important}.row-gap-xl-1{row-gap:.25rem!important}.row-gap-xl-2{row-gap:.5rem!important}.row-gap-xl-3{row-gap:1rem!important}.row-gap-xl-4{row-gap:1.5rem!important}.row-gap-xl-5{row-gap:3rem!important}.column-gap-xl-0{-moz-column-gap:0!important;column-gap:0!important}.column-gap-xl-1{-moz-column-gap:.25rem!important;column-gap:.25rem!important}.column-gap-xl-2{-moz-column-gap:.5rem!important;column-gap:.5rem!important}.column-gap-xl-3{-moz-column-gap:1rem!important;column-gap:1rem!important}.column-gap-xl-4{-moz-column-gap:1.5rem!important;column-gap:1.5rem!important}.column-gap-xl-5{-moz-column-gap:3rem!important;column-gap:3rem!important}.text-xl-start{text-align:left!important}.text-xl-end{text-align:right!important}.text-xl-center{text-align:center!important}}@media (min-width:1400px){.float-xxl-start{float:left!important}.float-xxl-end{float:right!important}.float-xxl-none{float:none!important}.object-fit-xxl-contain{-o-object-fit:contain!important;object-fit:contain!important}.object-fit-xxl-cover{-o-object-fit:cover!important;object-fit:cover!important}.object-fit-xxl-fill{-o-object-fit:fill!important;object-fit:fill!important}.object-fit-xxl-scale{-o-object-fit:scale-down!important;object-fit:scale-down!important}.object-fit-xxl-none{-o-object-fit:none!important;object-fit:none!important}.d-xxl-inline{display:inline!important}.d-xxl-inline-block{display:inline-block!important}.d-xxl-block{display:block!important}.d-xxl-grid{display:grid!important}.d-xxl-inline-grid{display:inline-grid!important}.d-xxl-table{display:table!important}.d-xxl-table-row{display:table-row!important}.d-xxl-table-cell{display:table-cell!important}.d-xxl-flex{display:flex!important}.d-xxl-inline-flex{display:inline-flex!important}.d-xxl-none{display:none!important}.flex-xxl-fill{flex:1 1 auto!important}.flex-xxl-row{flex-direction:row!important}.flex-xxl-column{flex-direction:column!important}.flex-xxl-row-reverse{flex-direction:row-reverse!important}.flex-xxl-column-reverse{flex-direction:column-reverse!important}.flex-xxl-grow-0{flex-grow:0!important}.flex-xxl-grow-1{flex-grow:1!important}.flex-xxl-shrink-0{flex-shrink:0!important}.flex-xxl-shrink-1{flex-shrink:1!important}.flex-xxl-wrap{flex-wrap:wrap!important}.flex-xxl-nowrap{flex-wrap:nowrap!important}.flex-xxl-wrap-reverse{flex-wrap:wrap-reverse!important}.justify-content-xxl-start{justify-content:flex-start!important}.justify-content-xxl-end{justify-content:flex-end!important}.justify-content-xxl-center{justify-content:center!important}.justify-content-xxl-between{justify-content:space-between!important}.justify-content-xxl-around{justify-content:space-around!important}.justify-content-xxl-evenly{justify-content:space-evenly!important}.align-items-xxl-start{align-items:flex-start!important}.align-items-xxl-end{align-items:flex-end!important}.align-items-xxl-center{align-items:center!important}.align-items-xxl-baseline{align-items:baseline!important}.align-items-xxl-stretch{align-items:stretch!important}.align-content-xxl-start{align-content:flex-start!important}.align-content-xxl-end{align-content:flex-end!important}.align-content-xxl-center{align-content:center!important}.align-content-xxl-between{align-content:space-between!important}.align-content-xxl-around{align-content:space-around!important}.align-content-xxl-stretch{align-content:stretch!important}.align-self-xxl-auto{align-self:auto!important}.align-self-xxl-start{align-self:flex-start!important}.align-self-xxl-end{align-self:flex-end!important}.align-self-xxl-center{align-self:center!important}.align-self-xxl-baseline{align-self:baseline!important}.align-self-xxl-stretch{align-self:stretch!important}.order-xxl-first{order:-1!important}.order-xxl-0{order:0!important}.order-xxl-1{order:1!important}.order-xxl-2{order:2!important}.order-xxl-3{order:3!important}.order-xxl-4{order:4!important}.order-xxl-5{order:5!important}.order-xxl-last{order:6!important}.m-xxl-0{margin:0!important}.m-xxl-1{margin:.25rem!important}.m-xxl-2{margin:.5rem!important}.m-xxl-3{margin:1rem!important}.m-xxl-4{margin:1.5rem!important}.m-xxl-5{margin:3rem!important}.m-xxl-auto{margin:auto!important}.mx-xxl-0{margin-left:0!important;margin-right:0!important}.mx-xxl-1{margin-left:.25rem!important;margin-right:.25rem!important}.mx-xxl-2{margin-left:.5rem!important;margin-right:.5rem!important}.mx-xxl-3{margin-left:1rem!important;margin-right:1rem!important}.mx-xxl-4{margin-left:1.5rem!important;margin-right:1.5rem!important}.mx-xxl-5{margin-left:3rem!important;margin-right:3rem!important}.mx-xxl-auto{margin-left:auto!important;margin-right:auto!important}.my-xxl-0{margin-bottom:0!important;margin-top:0!important}.my-xxl-1{margin-bottom:.25rem!important;margin-top:.25rem!important}.my-xxl-2{margin-bottom:.5rem!important;margin-top:.5rem!important}.my-xxl-3{margin-bottom:1rem!important;margin-top:1rem!important}.my-xxl-4{margin-bottom:1.5rem!important;margin-top:1.5rem!important}.my-xxl-5{margin-bottom:3rem!important;margin-top:3rem!important}.my-xxl-auto{margin-bottom:auto!important;margin-top:auto!important}.mt-xxl-0{margin-top:0!important}.mt-xxl-1{margin-top:.25rem!important}.mt-xxl-2{margin-top:.5rem!important}.mt-xxl-3{margin-top:1rem!important}.mt-xxl-4{margin-top:1.5rem!important}.mt-xxl-5{margin-top:3rem!important}.mt-xxl-auto{margin-top:auto!important}.me-xxl-0{margin-right:0!important}.me-xxl-1{margin-right:.25rem!important}.me-xxl-2{margin-right:.5rem!important}.me-xxl-3{margin-right:1rem!important}.me-xxl-4{margin-right:1.5rem!important}.me-xxl-5{margin-right:3rem!important}.me-xxl-auto{margin-right:auto!important}.mb-xxl-0{margin-bottom:0!important}.mb-xxl-1{margin-bottom:.25rem!important}.mb-xxl-2{margin-bottom:.5rem!important}.mb-xxl-3{margin-bottom:1rem!important}.mb-xxl-4{margin-bottom:1.5rem!important}.mb-xxl-5{margin-bottom:3rem!important}.mb-xxl-auto{margin-bottom:auto!important}.ms-xxl-0{margin-left:0!important}.ms-xxl-1{margin-left:.25rem!important}.ms-xxl-2{margin-left:.5rem!important}.ms-xxl-3{margin-left:1rem!important}.ms-xxl-4{margin-left:1.5rem!important}.ms-xxl-5{margin-left:3rem!important}.ms-xxl-auto{margin-left:auto!important}.p-xxl-0{padding:0!important}.p-xxl-1{padding:.25rem!important}.p-xxl-2{padding:.5rem!important}.p-xxl-3{padding:1rem!important}.p-xxl-4{padding:1.5rem!important}.p-xxl-5{padding:3rem!important}.px-xxl-0{padding-left:0!important;padding-right:0!important}.px-xxl-1{padding-left:.25rem!important;padding-right:.25rem!important}.px-xxl-2{padding-left:.5rem!important;padding-right:.5rem!important}.px-xxl-3{padding-left:1rem!important;padding-right:1rem!important}.px-xxl-4{padding-left:1.5rem!important;padding-right:1.5rem!important}.px-xxl-5{padding-left:3rem!important;padding-right:3rem!important}.py-xxl-0{padding-bottom:0!important;padding-top:0!important}.py-xxl-1{padding-bottom:.25rem!important;padding-top:.25rem!important}.py-xxl-2{padding-bottom:.5rem!important;padding-top:.5rem!important}.py-xxl-3{padding-bottom:1rem!important;padding-top:1rem!important}.py-xxl-4{padding-bottom:1.5rem!important;padding-top:1.5rem!important}.py-xxl-5{padding-bottom:3rem!important;padding-top:3rem!important}.pt-xxl-0{padding-top:0!important}.pt-xxl-1{padding-top:.25rem!important}.pt-xxl-2{padding-top:.5rem!important}.pt-xxl-3{padding-top:1rem!important}.pt-xxl-4{padding-top:1.5rem!important}.pt-xxl-5{padding-top:3rem!important}.pe-xxl-0{padding-right:0!important}.pe-xxl-1{padding-right:.25rem!important}.pe-xxl-2{padding-right:.5rem!important}.pe-xxl-3{padding-right:1rem!important}.pe-xxl-4{padding-right:1.5rem!important}.pe-xxl-5{padding-right:3rem!important}.pb-xxl-0{padding-bottom:0!important}.pb-xxl-1{padding-bottom:.25rem!important}.pb-xxl-2{padding-bottom:.5rem!important}.pb-xxl-3{padding-bottom:1rem!important}.pb-xxl-4{padding-bottom:1.5rem!important}.pb-xxl-5{padding-bottom:3rem!important}.ps-xxl-0{padding-left:0!important}.ps-xxl-1{padding-left:.25rem!important}.ps-xxl-2{padding-left:.5rem!important}.ps-xxl-3{padding-left:1rem!important}.ps-xxl-4{padding-left:1.5rem!important}.ps-xxl-5{padding-left:3rem!important}.gap-xxl-0{gap:0!important}.gap-xxl-1{gap:.25rem!important}.gap-xxl-2{gap:.5rem!important}.gap-xxl-3{gap:1rem!important}.gap-xxl-4{gap:1.5rem!important}.gap-xxl-5{gap:3rem!important}.row-gap-xxl-0{row-gap:0!important}.row-gap-xxl-1{row-gap:.25rem!important}.row-gap-xxl-2{row-gap:.5rem!important}.row-gap-xxl-3{row-gap:1rem!important}.row-gap-xxl-4{row-gap:1.5rem!important}.row-gap-xxl-5{row-gap:3rem!important}.column-gap-xxl-0{-moz-column-gap:0!important;column-gap:0!important}.column-gap-xxl-1{-moz-column-gap:.25rem!important;column-gap:.25rem!important}.column-gap-xxl-2{-moz-column-gap:.5rem!important;column-gap:.5rem!important}.column-gap-xxl-3{-moz-column-gap:1rem!important;column-gap:1rem!important}.column-gap-xxl-4{-moz-column-gap:1.5rem!important;column-gap:1.5rem!important}.column-gap-xxl-5{-moz-column-gap:3rem!important;column-gap:3rem!important}.text-xxl-start{text-align:left!important}.text-xxl-end{text-align:right!important}.text-xxl-center{text-align:center!important}}@media (min-width:1200px){.fs-1{font-size:2.5rem!important}.fs-2{font-size:2rem!important}.fs-3{font-size:1.75rem!important}.fs-4{font-size:1.5rem!important}}@media print{.d-print-inline{display:inline!important}.d-print-inline-block{display:inline-block!important}.d-print-block{display:block!important}.d-print-grid{display:grid!important}.d-print-inline-grid{display:inline-grid!important}.d-print-table{display:table!important}.d-print-table-row{display:table-row!important}.d-print-table-cell{display:table-cell!important}.d-print-flex{display:flex!important}.d-print-inline-flex{display:inline-flex!important}.d-print-none{display:none!important}}.btn-primary:hover{background-color:#3c83eb;border-color:#3c83eb}.btn:disabled{cursor:not-allowed;opacity:.3}.home-bg{color:#fff;height:100vh;position:fixed}.home-bg:before{background-position:50%;background-repeat:no-repeat;background-size:cover;content:"";height:100%;opacity:.4;position:absolute;width:100%;z-index:-1}@media screen and (max-width:400px){.home-bg{height:auto}}.home-bg .home-content{color:#000;padding:2rem 5rem}.home-bg .home-content .view-this-page-text{cursor:pointer}.home-bg .home-content .view-this-page-text:hover{text-decoration:underline}.home-bg .home-content .img-view-page-box{cursor:pointer;max-width:350px}.home-bg .home-content .img-view-page-box .img-view-page{filter:blur(.6px);width:100%}.modal-show{background-color:rgba(0,0,0,.5);display:block;z-index:99999}.modal-show-error{background-color:rgba(0,0,0,.6);display:block;z-index:999999}.modal-header{border-bottom:none!important}.top-header{position:sticky;top:0;z-index:999}`;
    entryStyles_B5NIiaim = [index2];
  }
});

// .netlify/functions-internal/server/chunks/build/index-styles-1.mjs-3MMpyLWU.mjs
var index_vue_vue_type_style_index_0_scoped_fe77d168_lang;
var init_index_styles_1_mjs_3MMpyLWU = __esm({
  ".netlify/functions-internal/server/chunks/build/index-styles-1.mjs-3MMpyLWU.mjs"() {
    "use strict";
    index_vue_vue_type_style_index_0_scoped_fe77d168_lang = ".el-carousel__item h3[data-v-fe77d168]{color:#475669;line-height:200px;margin:0;opacity:.75;text-align:center}.el-carousel__item[data-v-fe77d168]:nth-child(2n){background-color:#99a9bf}.el-carousel__item[data-v-fe77d168]:nth-child(odd){background-color:#d3dce6}";
  }
});

// .netlify/functions-internal/server/chunks/build/index-styles.CjlDxf47.mjs
var index_styles_CjlDxf47_exports = {};
__export(index_styles_CjlDxf47_exports, {
  default: () => indexStyles_CjlDxf47
});
var indexStyles_CjlDxf47;
var init_index_styles_CjlDxf47 = __esm({
  ".netlify/functions-internal/server/chunks/build/index-styles.CjlDxf47.mjs"() {
    "use strict";
    init_index_styles_1_mjs_3MMpyLWU();
    indexStyles_CjlDxf47 = [index_vue_vue_type_style_index_0_scoped_fe77d168_lang, index_vue_vue_type_style_index_0_scoped_fe77d168_lang];
  }
});

// .netlify/functions-internal/server/chunks/build/index-styles.hzMBf7ql.mjs
var index_styles_hzMBf7ql_exports = {};
__export(index_styles_hzMBf7ql_exports, {
  default: () => indexStyles_hzMBf7ql
});
var indexStyles_hzMBf7ql;
var init_index_styles_hzMBf7ql = __esm({
  ".netlify/functions-internal/server/chunks/build/index-styles.hzMBf7ql.mjs"() {
    "use strict";
    init_index_styles_1_mjs_3MMpyLWU();
    indexStyles_hzMBf7ql = [index_vue_vue_type_style_index_0_scoped_fe77d168_lang];
  }
});

// .netlify/functions-internal/server/chunks/build/error-404-styles-1.mjs-D8Sw_W7I.mjs
var error404_vue_vue_type_style_index_0_scoped_00b6b518_lang;
var init_error_404_styles_1_mjs_D8Sw_W7I = __esm({
  ".netlify/functions-internal/server/chunks/build/error-404-styles-1.mjs-D8Sw_W7I.mjs"() {
    "use strict";
    error404_vue_vue_type_style_index_0_scoped_00b6b518_lang = '.spotlight[data-v-00b6b518]{background:linear-gradient(45deg,#00dc82,#36e4da 50%,#0047e1);bottom:-30vh;filter:blur(20vh);height:40vh}.gradient-border[data-v-00b6b518]{-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px);border-radius:.5rem;position:relative}@media (prefers-color-scheme:light){.gradient-border[data-v-00b6b518]{background-color:hsla(0,0%,100%,.3)}.gradient-border[data-v-00b6b518]:before{background:linear-gradient(90deg,#e2e2e2,#e2e2e2 25%,#00dc82 50%,#36e4da 75%,#0047e1)}}@media (prefers-color-scheme:dark){.gradient-border[data-v-00b6b518]{background-color:hsla(0,0%,8%,.3)}.gradient-border[data-v-00b6b518]:before{background:linear-gradient(90deg,#303030,#303030 25%,#00dc82 50%,#36e4da 75%,#0047e1)}}.gradient-border[data-v-00b6b518]:before{background-size:400% auto;border-radius:.5rem;bottom:0;content:"";left:0;-webkit-mask:linear-gradient(#fff 0 0) content-box,linear-gradient(#fff 0 0);mask:linear-gradient(#fff 0 0) content-box,linear-gradient(#fff 0 0);-webkit-mask-composite:xor;mask-composite:exclude;opacity:.5;padding:2px;position:absolute;right:0;top:0;transition:background-position .3s ease-in-out,opacity .2s ease-in-out;width:100%}.gradient-border[data-v-00b6b518]:hover:before{background-position:-50% 0;opacity:1}.fixed[data-v-00b6b518]{position:fixed}.left-0[data-v-00b6b518]{left:0}.right-0[data-v-00b6b518]{right:0}.z-10[data-v-00b6b518]{z-index:10}.z-20[data-v-00b6b518]{z-index:20}.grid[data-v-00b6b518]{display:grid}.mb-16[data-v-00b6b518]{margin-bottom:4rem}.mb-8[data-v-00b6b518]{margin-bottom:2rem}.max-w-520px[data-v-00b6b518]{max-width:520px}.min-h-screen[data-v-00b6b518]{min-height:100vh}.w-full[data-v-00b6b518]{width:100%}.flex[data-v-00b6b518]{display:flex}.cursor-pointer[data-v-00b6b518]{cursor:pointer}.place-content-center[data-v-00b6b518]{place-content:center}.items-center[data-v-00b6b518]{align-items:center}.justify-center[data-v-00b6b518]{justify-content:center}.overflow-hidden[data-v-00b6b518]{overflow:hidden}.bg-white[data-v-00b6b518]{--un-bg-opacity:1;background-color:rgb(255 255 255/var(--un-bg-opacity))}.px-4[data-v-00b6b518]{padding-left:1rem;padding-right:1rem}.px-8[data-v-00b6b518]{padding-left:2rem;padding-right:2rem}.py-2[data-v-00b6b518]{padding-bottom:.5rem;padding-top:.5rem}.text-center[data-v-00b6b518]{text-align:center}.text-8xl[data-v-00b6b518]{font-size:6rem;line-height:1}.text-xl[data-v-00b6b518]{font-size:1.25rem;line-height:1.75rem}.text-black[data-v-00b6b518]{--un-text-opacity:1;color:rgb(0 0 0/var(--un-text-opacity))}.font-light[data-v-00b6b518]{font-weight:300}.font-medium[data-v-00b6b518]{font-weight:500}.leading-tight[data-v-00b6b518]{line-height:1.25}.font-sans[data-v-00b6b518]{font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol,Noto Color Emoji}.antialiased[data-v-00b6b518]{-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}@media (prefers-color-scheme:dark){.dark\\:bg-black[data-v-00b6b518]{--un-bg-opacity:1;background-color:rgb(0 0 0/var(--un-bg-opacity))}.dark\\:text-white[data-v-00b6b518]{--un-text-opacity:1;color:rgb(255 255 255/var(--un-text-opacity))}}@media (min-width:640px){.sm\\:px-0[data-v-00b6b518]{padding-left:0;padding-right:0}.sm\\:px-6[data-v-00b6b518]{padding-left:1.5rem;padding-right:1.5rem}.sm\\:py-3[data-v-00b6b518]{padding-bottom:.75rem;padding-top:.75rem}.sm\\:text-4xl[data-v-00b6b518]{font-size:2.25rem;line-height:2.5rem}.sm\\:text-xl[data-v-00b6b518]{font-size:1.25rem;line-height:1.75rem}}';
  }
});

// .netlify/functions-internal/server/chunks/build/error-404-styles.BcoFjqgl.mjs
var error_404_styles_BcoFjqgl_exports = {};
__export(error_404_styles_BcoFjqgl_exports, {
  default: () => error404Styles_BcoFjqgl
});
var error404Styles_BcoFjqgl;
var init_error_404_styles_BcoFjqgl = __esm({
  ".netlify/functions-internal/server/chunks/build/error-404-styles.BcoFjqgl.mjs"() {
    "use strict";
    init_error_404_styles_1_mjs_D8Sw_W7I();
    error404Styles_BcoFjqgl = [error404_vue_vue_type_style_index_0_scoped_00b6b518_lang, error404_vue_vue_type_style_index_0_scoped_00b6b518_lang];
  }
});

// .netlify/functions-internal/server/chunks/build/error-500-styles-1.mjs-DiWYPNRc.mjs
var error500_vue_vue_type_style_index_0_scoped_f7ad9679_lang;
var init_error_500_styles_1_mjs_DiWYPNRc = __esm({
  ".netlify/functions-internal/server/chunks/build/error-500-styles-1.mjs-DiWYPNRc.mjs"() {
    "use strict";
    error500_vue_vue_type_style_index_0_scoped_f7ad9679_lang = ".spotlight[data-v-f7ad9679]{background:linear-gradient(45deg,#00dc82,#36e4da 50%,#0047e1);filter:blur(20vh)}.fixed[data-v-f7ad9679]{position:fixed}.-bottom-1\\/2[data-v-f7ad9679]{bottom:-50%}.left-0[data-v-f7ad9679]{left:0}.right-0[data-v-f7ad9679]{right:0}.grid[data-v-f7ad9679]{display:grid}.mb-16[data-v-f7ad9679]{margin-bottom:4rem}.mb-8[data-v-f7ad9679]{margin-bottom:2rem}.h-1\\/2[data-v-f7ad9679]{height:50%}.max-w-520px[data-v-f7ad9679]{max-width:520px}.min-h-screen[data-v-f7ad9679]{min-height:100vh}.place-content-center[data-v-f7ad9679]{place-content:center}.overflow-hidden[data-v-f7ad9679]{overflow:hidden}.bg-white[data-v-f7ad9679]{--un-bg-opacity:1;background-color:rgb(255 255 255/var(--un-bg-opacity))}.px-8[data-v-f7ad9679]{padding-left:2rem;padding-right:2rem}.text-center[data-v-f7ad9679]{text-align:center}.text-8xl[data-v-f7ad9679]{font-size:6rem;line-height:1}.text-xl[data-v-f7ad9679]{font-size:1.25rem;line-height:1.75rem}.text-black[data-v-f7ad9679]{--un-text-opacity:1;color:rgb(0 0 0/var(--un-text-opacity))}.font-light[data-v-f7ad9679]{font-weight:300}.font-medium[data-v-f7ad9679]{font-weight:500}.leading-tight[data-v-f7ad9679]{line-height:1.25}.font-sans[data-v-f7ad9679]{font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol,Noto Color Emoji}.antialiased[data-v-f7ad9679]{-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}@media (prefers-color-scheme:dark){.dark\\:bg-black[data-v-f7ad9679]{--un-bg-opacity:1;background-color:rgb(0 0 0/var(--un-bg-opacity))}.dark\\:text-white[data-v-f7ad9679]{--un-text-opacity:1;color:rgb(255 255 255/var(--un-text-opacity))}}@media (min-width:640px){.sm\\:px-0[data-v-f7ad9679]{padding-left:0;padding-right:0}.sm\\:text-4xl[data-v-f7ad9679]{font-size:2.25rem;line-height:2.5rem}}";
  }
});

// .netlify/functions-internal/server/chunks/build/error-500-styles.DPP87-Dp.mjs
var error_500_styles_DPP87_Dp_exports = {};
__export(error_500_styles_DPP87_Dp_exports, {
  default: () => error500Styles_DPP87Dp
});
var error500Styles_DPP87Dp;
var init_error_500_styles_DPP87_Dp = __esm({
  ".netlify/functions-internal/server/chunks/build/error-500-styles.DPP87-Dp.mjs"() {
    "use strict";
    init_error_500_styles_1_mjs_DiWYPNRc();
    error500Styles_DPP87Dp = [error500_vue_vue_type_style_index_0_scoped_f7ad9679_lang, error500_vue_vue_type_style_index_0_scoped_f7ad9679_lang];
  }
});

// .netlify/functions-internal/server/chunks/build/Title-styles-1.mjs-CzS9zq8t.mjs
var Title_vue_vue_type_style_index_0_lang;
var init_Title_styles_1_mjs_CzS9zq8t = __esm({
  ".netlify/functions-internal/server/chunks/build/Title-styles-1.mjs-CzS9zq8t.mjs"() {
    "use strict";
    Title_vue_vue_type_style_index_0_lang = ".active-text{color:red}";
  }
});

// .netlify/functions-internal/server/chunks/build/Title-styles.CYxh8bsA.mjs
var Title_styles_CYxh8bsA_exports = {};
__export(Title_styles_CYxh8bsA_exports, {
  default: () => TitleStyles_CYxh8bsA
});
var TitleStyles_CYxh8bsA;
var init_Title_styles_CYxh8bsA = __esm({
  ".netlify/functions-internal/server/chunks/build/Title-styles.CYxh8bsA.mjs"() {
    "use strict";
    init_Title_styles_1_mjs_CzS9zq8t();
    TitleStyles_CYxh8bsA = [Title_vue_vue_type_style_index_0_lang, Title_vue_vue_type_style_index_0_lang];
  }
});

// .netlify/functions-internal/server/chunks/build/error-500-styles.DqmriZ_b.mjs
var error_500_styles_DqmriZ_b_exports = {};
__export(error_500_styles_DqmriZ_b_exports, {
  default: () => error500Styles_DqmriZ_b
});
var error500Styles_DqmriZ_b;
var init_error_500_styles_DqmriZ_b = __esm({
  ".netlify/functions-internal/server/chunks/build/error-500-styles.DqmriZ_b.mjs"() {
    "use strict";
    init_error_500_styles_1_mjs_DiWYPNRc();
    error500Styles_DqmriZ_b = [error500_vue_vue_type_style_index_0_scoped_f7ad9679_lang];
  }
});

// .netlify/functions-internal/server/chunks/build/error-404-styles.DRLC0U6S.mjs
var error_404_styles_DRLC0U6S_exports = {};
__export(error_404_styles_DRLC0U6S_exports, {
  default: () => error404Styles_DRLC0U6S
});
var error404Styles_DRLC0U6S;
var init_error_404_styles_DRLC0U6S = __esm({
  ".netlify/functions-internal/server/chunks/build/error-404-styles.DRLC0U6S.mjs"() {
    "use strict";
    init_error_404_styles_1_mjs_D8Sw_W7I();
    error404Styles_DRLC0U6S = [error404_vue_vue_type_style_index_0_scoped_00b6b518_lang];
  }
});

// .netlify/functions-internal/server/chunks/build/Title-styles.B4CI-PoO.mjs
var Title_styles_B4CI_PoO_exports = {};
__export(Title_styles_B4CI_PoO_exports, {
  default: () => TitleStyles_B4CIPoO
});
var TitleStyles_B4CIPoO;
var init_Title_styles_B4CI_PoO = __esm({
  ".netlify/functions-internal/server/chunks/build/Title-styles.B4CI-PoO.mjs"() {
    "use strict";
    init_Title_styles_1_mjs_CzS9zq8t();
    TitleStyles_B4CIPoO = [Title_vue_vue_type_style_index_0_lang];
  }
});

// .netlify/functions-internal/server/chunks/build/Square-styles-1.mjs-DXAh3SLy.mjs
var Square_vue_vue_type_style_index_0_scoped_c893ce81_lang;
var init_Square_styles_1_mjs_DXAh3SLy = __esm({
  ".netlify/functions-internal/server/chunks/build/Square-styles-1.mjs-DXAh3SLy.mjs"() {
    "use strict";
    Square_vue_vue_type_style_index_0_scoped_c893ce81_lang = ".logo-img[data-v-c893ce81]{cursor:pointer}.img-thumbnail[data-v-c893ce81]{border:none!important}";
  }
});

// .netlify/functions-internal/server/chunks/build/Square-styles.BX2xYXyD.mjs
var Square_styles_BX2xYXyD_exports = {};
__export(Square_styles_BX2xYXyD_exports, {
  default: () => SquareStyles_BX2xYXyD
});
var SquareStyles_BX2xYXyD;
var init_Square_styles_BX2xYXyD = __esm({
  ".netlify/functions-internal/server/chunks/build/Square-styles.BX2xYXyD.mjs"() {
    "use strict";
    init_Square_styles_1_mjs_DXAh3SLy();
    SquareStyles_BX2xYXyD = [Square_vue_vue_type_style_index_0_scoped_c893ce81_lang, Square_vue_vue_type_style_index_0_scoped_c893ce81_lang];
  }
});

// .netlify/functions-internal/server/chunks/build/Square-styles.OuKwtfde.mjs
var Square_styles_OuKwtfde_exports = {};
__export(Square_styles_OuKwtfde_exports, {
  default: () => SquareStyles_OuKwtfde
});
var SquareStyles_OuKwtfde;
var init_Square_styles_OuKwtfde = __esm({
  ".netlify/functions-internal/server/chunks/build/Square-styles.OuKwtfde.mjs"() {
    "use strict";
    init_Square_styles_1_mjs_DXAh3SLy();
    SquareStyles_OuKwtfde = [Square_vue_vue_type_style_index_0_scoped_c893ce81_lang];
  }
});

// .netlify/functions-internal/server/chunks/build/index-styles-1.mjs-diveWXvx.mjs
var index_vue_vue_type_style_index_0_scoped_ff1b7767_lang;
var init_index_styles_1_mjs_diveWXvx = __esm({
  ".netlify/functions-internal/server/chunks/build/index-styles-1.mjs-diveWXvx.mjs"() {
    "use strict";
    index_vue_vue_type_style_index_0_scoped_ff1b7767_lang = ".page-loading[data-v-ff1b7767]{z-index:999999999999}.page-loading .overlay[data-v-ff1b7767]{background-color:rgba(0,0,0,.5);bottom:0;left:0;position:absolute;right:0;top:0;z-index:1}";
  }
});

// .netlify/functions-internal/server/chunks/build/index-styles.BufNlWou.mjs
var index_styles_BufNlWou_exports = {};
__export(index_styles_BufNlWou_exports, {
  default: () => indexStyles_BufNlWou
});
var indexStyles_BufNlWou;
var init_index_styles_BufNlWou = __esm({
  ".netlify/functions-internal/server/chunks/build/index-styles.BufNlWou.mjs"() {
    "use strict";
    init_index_styles_1_mjs_diveWXvx();
    indexStyles_BufNlWou = [index_vue_vue_type_style_index_0_scoped_ff1b7767_lang, index_vue_vue_type_style_index_0_scoped_ff1b7767_lang];
  }
});

// .netlify/functions-internal/server/chunks/build/index-styles-1.mjs-MLpuLoOF.mjs
var index_vue_vue_type_style_index_0_scoped_c1972f50_lang;
var init_index_styles_1_mjs_MLpuLoOF = __esm({
  ".netlify/functions-internal/server/chunks/build/index-styles-1.mjs-MLpuLoOF.mjs"() {
    "use strict";
    index_vue_vue_type_style_index_0_scoped_c1972f50_lang = ".profile-img[data-v-c1972f50]{cursor:pointer}";
  }
});

// .netlify/functions-internal/server/chunks/build/index-styles.CqzRHDfQ.mjs
var index_styles_CqzRHDfQ_exports = {};
__export(index_styles_CqzRHDfQ_exports, {
  default: () => indexStyles_CqzRHDfQ
});
var indexStyles_CqzRHDfQ;
var init_index_styles_CqzRHDfQ = __esm({
  ".netlify/functions-internal/server/chunks/build/index-styles.CqzRHDfQ.mjs"() {
    "use strict";
    init_index_styles_1_mjs_MLpuLoOF();
    indexStyles_CqzRHDfQ = [index_vue_vue_type_style_index_0_scoped_c1972f50_lang, index_vue_vue_type_style_index_0_scoped_c1972f50_lang];
  }
});

// .netlify/functions-internal/server/chunks/build/index-styles.BW6hQb71.mjs
var index_styles_BW6hQb71_exports = {};
__export(index_styles_BW6hQb71_exports, {
  default: () => indexStyles_BW6hQb71
});
var indexStyles_BW6hQb71;
var init_index_styles_BW6hQb71 = __esm({
  ".netlify/functions-internal/server/chunks/build/index-styles.BW6hQb71.mjs"() {
    "use strict";
    init_index_styles_1_mjs_MLpuLoOF();
    indexStyles_BW6hQb71 = [index_vue_vue_type_style_index_0_scoped_c1972f50_lang];
  }
});

// .netlify/functions-internal/server/chunks/build/index-styles.CIKDWvyR.mjs
var index_styles_CIKDWvyR_exports = {};
__export(index_styles_CIKDWvyR_exports, {
  default: () => indexStyles_CIKDWvyR
});
var indexStyles_CIKDWvyR;
var init_index_styles_CIKDWvyR = __esm({
  ".netlify/functions-internal/server/chunks/build/index-styles.CIKDWvyR.mjs"() {
    "use strict";
    init_index_styles_1_mjs_diveWXvx();
    indexStyles_CIKDWvyR = [index_vue_vue_type_style_index_0_scoped_ff1b7767_lang];
  }
});

// .netlify/functions-internal/server/chunks/build/styles.mjs
var styles_exports = {};
__export(styles_exports, {
  default: () => styles
});
var interopDefault, styles;
var init_styles = __esm({
  ".netlify/functions-internal/server/chunks/build/styles.mjs"() {
    "use strict";
    interopDefault = (r) => r.default || r || [];
    styles = {
      "node_modules/nuxt/dist/app/entry.js": () => Promise.resolve().then(() => (init_entry_styles_B5NIiaim(), entry_styles_B5NIiaim_exports)).then(interopDefault),
      "pages/index.vue": () => Promise.resolve().then(() => (init_index_styles_CjlDxf47(), index_styles_CjlDxf47_exports)).then(interopDefault),
      "pages/index.vue?vue&type=style&index=0&scoped=fe77d168&lang.css": () => Promise.resolve().then(() => (init_index_styles_hzMBf7ql(), index_styles_hzMBf7ql_exports)).then(interopDefault),
      "node_modules/nuxt/dist/app/components/error-404.vue": () => Promise.resolve().then(() => (init_error_404_styles_BcoFjqgl(), error_404_styles_BcoFjqgl_exports)).then(interopDefault),
      "node_modules/nuxt/dist/app/components/error-500.vue": () => Promise.resolve().then(() => (init_error_500_styles_DPP87_Dp(), error_500_styles_DPP87_Dp_exports)).then(interopDefault),
      "components/Site/Title.vue": () => Promise.resolve().then(() => (init_Title_styles_CYxh8bsA(), Title_styles_CYxh8bsA_exports)).then(interopDefault),
      "node_modules/nuxt/dist/app/components/error-500.vue?vue&type=style&index=0&scoped=f7ad9679&lang.css": () => Promise.resolve().then(() => (init_error_500_styles_DqmriZ_b(), error_500_styles_DqmriZ_b_exports)).then(interopDefault),
      "node_modules/nuxt/dist/app/components/error-404.vue?vue&type=style&index=0&scoped=00b6b518&lang.css": () => Promise.resolve().then(() => (init_error_404_styles_DRLC0U6S(), error_404_styles_DRLC0U6S_exports)).then(interopDefault),
      "components/Site/Title.vue?vue&type=style&index=0&lang.scss": () => Promise.resolve().then(() => (init_Title_styles_B4CI_PoO(), Title_styles_B4CI_PoO_exports)).then(interopDefault),
      "components/Site/Logo/Square.vue": () => Promise.resolve().then(() => (init_Square_styles_BX2xYXyD(), Square_styles_BX2xYXyD_exports)).then(interopDefault),
      "components/Site/Logo/Square.vue?vue&type=style&index=0&scoped=c893ce81&lang.css": () => Promise.resolve().then(() => (init_Square_styles_OuKwtfde(), Square_styles_OuKwtfde_exports)).then(interopDefault),
      "components/Loading/index.vue": () => Promise.resolve().then(() => (init_index_styles_BufNlWou(), index_styles_BufNlWou_exports)).then(interopDefault),
      "components/Page/Header/index.vue": () => Promise.resolve().then(() => (init_index_styles_CqzRHDfQ(), index_styles_CqzRHDfQ_exports)).then(interopDefault),
      "components/Page/Header/index.vue?vue&type=style&index=0&scoped=c1972f50&lang.scss": () => Promise.resolve().then(() => (init_index_styles_BW6hQb71(), index_styles_BW6hQb71_exports)).then(interopDefault),
      "components/Loading/index.vue?vue&type=style&index=0&scoped=ff1b7767&lang.scss": () => Promise.resolve().then(() => (init_index_styles_CIKDWvyR(), index_styles_CIKDWvyR_exports)).then(interopDefault)
    };
  }
});

// .netlify/functions-internal/server/chunks/virtual/_virtual_spa-template.mjs
var virtual_spa_template_exports = {};
__export(virtual_spa_template_exports, {
  template: () => template2
});
var template2;
var init_virtual_spa_template = __esm({
  ".netlify/functions-internal/server/chunks/virtual/_virtual_spa-template.mjs"() {
    "use strict";
    template2 = "";
  }
});

// .netlify/functions-internal/server/chunks/routes/renderer.mjs
var renderer_exports = {};
__export(renderer_exports, {
  default: () => renderer
});
import process from "node:process";
import { getRequestDependencies, getPreloadLinks, getPrefetchLinks, createRenderer } from "vue-bundle-renderer/runtime";
import { stringify, uneval } from "devalue";
import { renderToString } from "vue/server-renderer";
import { propsToString, renderSSRHead } from "@unhead/ssr";
import { createServerHead as createServerHead$1, CapoPlugin as CapoPlugin2 } from "unhead";
import { version as version2, unref as unref5 } from "vue";
import { defineHeadPlugin as defineHeadPlugin2 } from "@unhead/shared";
import "consola/core";
function resolveUnref2(r) {
  return typeof r === "function" ? r() : unref5(r);
}
function resolveUnrefHeadInput2(ref8) {
  if (ref8 instanceof Promise || ref8 instanceof Date || ref8 instanceof RegExp)
    return ref8;
  const root = resolveUnref2(ref8);
  if (!ref8 || !root)
    return root;
  if (Array.isArray(root))
    return root.map((r) => resolveUnrefHeadInput2(r));
  if (typeof root === "object") {
    const resolved = {};
    for (const k in root) {
      if (!Object.prototype.hasOwnProperty.call(root, k)) {
        continue;
      }
      if (k === "titleTemplate" || k[0] === "o" && k[1] === "n") {
        resolved[k] = unref5(root[k]);
        continue;
      }
      resolved[k] = resolveUnrefHeadInput2(root[k]);
    }
    return resolved;
  }
  return root;
}
function vueInstall(head) {
  const plugin2 = {
    install(app) {
      if (Vue3) {
        app.config.globalProperties.$unhead = head;
        app.config.globalProperties.$head = head;
        app.provide(headSymbol2, head);
      }
    }
  };
  return plugin2.install;
}
function createServerHead(options = {}) {
  const head = createServerHead$1(options);
  head.use(VueReactivityPlugin);
  head.install = vueInstall(head);
  return head;
}
function lazyCachedFunction(fn) {
  let res = null;
  return () => {
    if (res === null) {
      res = fn().catch((err) => {
        res = null;
        throw err;
      });
    }
    return res;
  };
}
function normalizeChunks(chunks) {
  return chunks.filter(Boolean).map((i2) => i2.trim());
}
function joinTags(tags) {
  return tags.join("");
}
function joinAttrs(chunks) {
  if (chunks.length === 0) {
    return "";
  }
  return " " + chunks.join(" ");
}
function renderHTMLDocument(html) {
  return `<!DOCTYPE html><html${joinAttrs(html.htmlAttrs)}><head>${joinTags(html.head)}</head><body${joinAttrs(html.bodyAttrs)}>${joinTags(html.bodyPrepend)}${joinTags(html.body)}${joinTags(html.bodyAppend)}</body></html>`;
}
async function renderInlineStyles(usedModules) {
  const styleMap = await getSSRStyles();
  const inlinedStyles = /* @__PURE__ */ new Set();
  for (const mod of usedModules) {
    if (mod in styleMap && styleMap[mod]) {
      for (const style of await styleMap[mod]()) {
        inlinedStyles.add(style);
      }
    }
  }
  return Array.from(inlinedStyles).map((style) => ({ innerHTML: style }));
}
function renderPayloadResponse(ssrContext) {
  return {
    body: stringify(splitPayload(ssrContext).payload, ssrContext._payloadReducers),
    statusCode: getResponseStatus(ssrContext.event),
    statusMessage: getResponseStatusText(ssrContext.event),
    headers: {
      "content-type": "application/json;charset=utf-8",
      "x-powered-by": "Nuxt"
    }
  };
}
function renderPayloadJsonScript(opts) {
  const contents = opts.data ? stringify(opts.data, opts.ssrContext._payloadReducers) : "";
  const payload2 = {
    "type": "application/json",
    "innerHTML": contents,
    "data-nuxt-data": appId2,
    "data-ssr": !opts.ssrContext.noSSR
  };
  {
    payload2.id = "__NUXT_DATA__";
  }
  if (opts.src) {
    payload2["data-src"] = opts.src;
  }
  const config3 = uneval(opts.ssrContext.config);
  return [
    payload2,
    {
      innerHTML: `window.__NUXT__={};window.__NUXT__.config=${config3}`
    }
  ];
}
function splitPayload(ssrContext) {
  const { data, prerenderedAt, ...initial } = ssrContext.payload;
  return {
    initial: { ...initial, prerenderedAt },
    payload: { data, prerenderedAt }
  };
}
var Vue3, VueReactivityPlugin, headSymbol2, unheadPlugins, renderSSRHeadOptions, appHead, appRootTag, appRootAttrs, appTeleportTag, appTeleportAttrs, componentIslands, appId2, getClientManifest, getEntryIds, getServerEntry, getSSRStyles, getSSRRenderer, getSPARenderer, HAS_APP_TELEPORTS, APP_TELEPORT_OPEN_TAG, APP_TELEPORT_CLOSE_TAG, APP_ROOT_OPEN_TAG, APP_ROOT_CLOSE_TAG, PAYLOAD_URL_RE, renderer;
var init_renderer = __esm({
  ".netlify/functions-internal/server/chunks/routes/renderer.mjs"() {
    "use strict";
    init_nitro();
    globalThis._importMeta_ = globalThis._importMeta_ || { url: "file:///_entry.js", env: process.env };
    Vue3 = version2[0] === "3";
    VueReactivityPlugin = defineHeadPlugin2({
      hooks: {
        "entries:resolve": (ctx) => {
          for (const entry2 of ctx.entries)
            entry2.resolvedInput = resolveUnrefHeadInput2(entry2.input);
        }
      }
    });
    headSymbol2 = "usehead";
    unheadPlugins = true ? [CapoPlugin2({ track: true })] : [];
    renderSSRHeadOptions = { "omitLineBreaks": false };
    appHead = { "meta": [{ "name": "viewport", "content": "width=device-width, initial-scale=1" }, { "charset": "utf-8" }], "link": [], "style": [], "script": [], "noscript": [], "title": "ITE" };
    appRootTag = "div";
    appRootAttrs = { "id": "__nuxt" };
    appTeleportTag = "div";
    appTeleportAttrs = { "id": "teleports" };
    componentIslands = false;
    appId2 = "nuxt-app";
    globalThis.__buildAssetsURL = buildAssetsURL;
    globalThis.__publicAssetsURL = publicAssetsURL;
    getClientManifest = () => Promise.resolve().then(() => (init_client_manifest(), client_manifest_exports)).then((r) => r.default || r).then((r) => typeof r === "function" ? r() : r);
    getEntryIds = () => getClientManifest().then((r) => Object.values(r).filter(
      (r2) => (
        // @ts-expect-error internal key set by CSS inlining configuration
        r2._globalCSS
      )
    ).map((r2) => r2.src));
    getServerEntry = () => Promise.resolve().then(() => (init_server(), server_exports)).then((r) => r.default || r);
    getSSRStyles = lazyCachedFunction(() => Promise.resolve().then(() => (init_styles(), styles_exports)).then((r) => r.default || r));
    getSSRRenderer = lazyCachedFunction(async () => {
      const manifest = await getClientManifest();
      if (!manifest) {
        throw new Error("client.manifest is not available");
      }
      const createSSRApp = await getServerEntry();
      if (!createSSRApp) {
        throw new Error("Server bundle is not available");
      }
      const options = {
        manifest,
        renderToString: renderToString$1,
        buildAssetsURL
      };
      const renderer2 = createRenderer(createSSRApp, options);
      async function renderToString$1(input, context) {
        const html = await renderToString(input, context);
        return APP_ROOT_OPEN_TAG + html + APP_ROOT_CLOSE_TAG;
      }
      return renderer2;
    });
    getSPARenderer = lazyCachedFunction(async () => {
      const manifest = await getClientManifest();
      const spaTemplate = await Promise.resolve().then(() => (init_virtual_spa_template(), virtual_spa_template_exports)).then((r) => r.template).catch(() => "").then((r) => APP_ROOT_OPEN_TAG + r + APP_ROOT_CLOSE_TAG);
      const options = {
        manifest,
        renderToString: () => spaTemplate,
        buildAssetsURL
      };
      const renderer2 = createRenderer(() => () => {
      }, options);
      const result = await renderer2.renderToString({});
      const renderToString2 = (ssrContext) => {
        const config3 = useRuntimeConfig2(ssrContext.event);
        ssrContext.modules = ssrContext.modules || /* @__PURE__ */ new Set();
        ssrContext.payload.serverRendered = false;
        ssrContext.config = {
          public: config3.public,
          app: config3.app
        };
        return Promise.resolve(result);
      };
      return {
        rendererContext: renderer2.rendererContext,
        renderToString: renderToString2
      };
    });
    HAS_APP_TELEPORTS = !!appTeleportAttrs.id;
    APP_TELEPORT_OPEN_TAG = HAS_APP_TELEPORTS ? `<${appTeleportTag}${propsToString(appTeleportAttrs)}>` : "";
    APP_TELEPORT_CLOSE_TAG = HAS_APP_TELEPORTS ? `</${appTeleportTag}>` : "";
    APP_ROOT_OPEN_TAG = `<${appRootTag}${propsToString(appRootAttrs)}>`;
    APP_ROOT_CLOSE_TAG = `</${appRootTag}>`;
    PAYLOAD_URL_RE = /\/_payload.json(\?.*)?$/;
    renderer = defineRenderHandler(async (event) => {
      const nitroApp3 = useNitroApp();
      const ssrError = event.path.startsWith("/__nuxt_error") ? getQuery(event) : null;
      if (ssrError && ssrError.statusCode) {
        ssrError.statusCode = Number.parseInt(ssrError.statusCode);
      }
      if (ssrError && !("__unenv__" in event.node.req)) {
        throw createError$1({
          statusCode: 404,
          statusMessage: "Page Not Found: /__nuxt_error"
        });
      }
      const isRenderingIsland = componentIslands;
      const islandContext = void 0;
      let url = ssrError?.url || islandContext?.url || event.path;
      const isRenderingPayload = PAYLOAD_URL_RE.test(url) && !isRenderingIsland;
      if (isRenderingPayload) {
        url = url.substring(0, url.lastIndexOf("/")) || "/";
        event._path = url;
        event.node.req.url = url;
      }
      const routeOptions = getRouteRules2(event);
      const head = createServerHead({
        plugins: unheadPlugins
      });
      const headEntryOptions = { mode: "server" };
      {
        head.push(appHead, headEntryOptions);
      }
      const ssrContext = {
        url,
        event,
        runtimeConfig: useRuntimeConfig2(event),
        noSSR: event.context.nuxt?.noSSR || routeOptions.ssr === false && !isRenderingIsland || false,
        head,
        error: !!ssrError,
        nuxt: void 0,
        /* NuxtApp */
        payload: ssrError ? { error: ssrError } : {},
        _payloadReducers: /* @__PURE__ */ Object.create(null),
        modules: /* @__PURE__ */ new Set(),
        islandContext
      };
      const renderer2 = ssrContext.noSSR ? await getSPARenderer() : await getSSRRenderer();
      {
        for (const id of await getEntryIds()) {
          ssrContext.modules.add(id);
        }
      }
      const _rendered = await renderer2.renderToString(ssrContext).catch(async (error2) => {
        if (ssrContext._renderResponse && error2.message === "skipping render") {
          return {};
        }
        const _err = !ssrError && ssrContext.payload?.error || error2;
        await ssrContext.nuxt?.hooks.callHook("app:error", _err);
        throw _err;
      });
      await ssrContext.nuxt?.hooks.callHook("app:rendered", { ssrContext, renderResult: _rendered });
      if (ssrContext._renderResponse) {
        return ssrContext._renderResponse;
      }
      if (ssrContext.payload?.error && !ssrError) {
        throw ssrContext.payload.error;
      }
      if (isRenderingPayload) {
        const response2 = renderPayloadResponse(ssrContext);
        return response2;
      }
      const inlinedStyles = await renderInlineStyles(ssrContext.modules ?? []);
      const NO_SCRIPTS = routeOptions.experimentalNoScripts;
      const { styles: styles2, scripts } = getRequestDependencies(ssrContext, renderer2.rendererContext);
      if (inlinedStyles.length) {
        head.push({ style: inlinedStyles });
      }
      {
        const link = [];
        for (const resource of Object.values(styles2)) {
          {
            link.push({ rel: "stylesheet", href: renderer2.rendererContext.buildAssetsURL(resource.file), crossorigin: "" });
          }
        }
        if (link.length) {
          head.push({ link }, headEntryOptions);
        }
      }
      if (!NO_SCRIPTS && !isRenderingIsland) {
        head.push({
          link: getPreloadLinks(ssrContext, renderer2.rendererContext)
        }, headEntryOptions);
        head.push({
          link: getPrefetchLinks(ssrContext, renderer2.rendererContext)
        }, headEntryOptions);
        head.push({
          script: renderPayloadJsonScript({ ssrContext, data: ssrContext.payload })
        }, {
          ...headEntryOptions,
          // this should come before another end of body scripts
          tagPosition: "bodyClose",
          tagPriority: "high"
        });
      }
      if (!routeOptions.experimentalNoScripts && !isRenderingIsland) {
        head.push({
          script: Object.values(scripts).map((resource) => ({
            type: resource.module ? "module" : null,
            src: renderer2.rendererContext.buildAssetsURL(resource.file),
            defer: resource.module ? null : true,
            // if we are rendering script tag payloads that import an async payload
            // we need to ensure this resolves before executing the Nuxt entry
            tagPosition: "head",
            crossorigin: ""
          }))
        }, headEntryOptions);
      }
      const { headTags, bodyTags, bodyTagsOpen, htmlAttrs, bodyAttrs } = await renderSSRHead(head, renderSSRHeadOptions);
      const htmlContext = {
        island: isRenderingIsland,
        htmlAttrs: htmlAttrs ? [htmlAttrs] : [],
        head: normalizeChunks([headTags]),
        bodyAttrs: bodyAttrs ? [bodyAttrs] : [],
        bodyPrepend: normalizeChunks([bodyTagsOpen, ssrContext.teleports?.body]),
        body: [
          _rendered.html,
          APP_TELEPORT_OPEN_TAG + (HAS_APP_TELEPORTS ? joinTags([ssrContext.teleports?.[`#${appTeleportAttrs.id}`]]) : "") + APP_TELEPORT_CLOSE_TAG
        ],
        bodyAppend: [bodyTags]
      };
      await nitroApp3.hooks.callHook("render:html", htmlContext, { event });
      const response = {
        body: renderHTMLDocument(htmlContext),
        statusCode: getResponseStatus(event),
        statusMessage: getResponseStatusText(event),
        headers: {
          "content-type": "text/html;charset=utf-8",
          "x-powered-by": "Nuxt"
        }
      };
      return response;
    });
  }
});

// .netlify/functions-internal/server/chunks/_/nitro.mjs
import process2 from "node:process";
import http from "node:http";
import https from "node:https";
import { toValue as toValue2 } from "vue";
import { createConsola as createConsola$1 } from "consola/core";
import { promises, existsSync } from "node:fs";
import { dirname, resolve as resolve$1, join } from "node:path";
function jsonParseTransform(key, value) {
  if (key === "__proto__" || key === "constructor" && value && typeof value === "object" && "prototype" in value) {
    warnKeyDropped(key);
    return;
  }
  return value;
}
function warnKeyDropped(key) {
  console.warn(`[destr] Dropping "${key}" key to prevent prototype pollution.`);
}
function destr(value, options = {}) {
  if (typeof value !== "string") {
    return value;
  }
  const _value = value.trim();
  if (
    // eslint-disable-next-line unicorn/prefer-at
    value[0] === '"' && value.endsWith('"') && !value.includes("\\")
  ) {
    return _value.slice(1, -1);
  }
  if (_value.length <= 9) {
    const _lval = _value.toLowerCase();
    if (_lval === "true") {
      return true;
    }
    if (_lval === "false") {
      return false;
    }
    if (_lval === "undefined") {
      return void 0;
    }
    if (_lval === "null") {
      return null;
    }
    if (_lval === "nan") {
      return Number.NaN;
    }
    if (_lval === "infinity") {
      return Number.POSITIVE_INFINITY;
    }
    if (_lval === "-infinity") {
      return Number.NEGATIVE_INFINITY;
    }
  }
  if (!JsonSigRx.test(value)) {
    if (options.strict) {
      throw new SyntaxError("[destr] Invalid JSON");
    }
    return value;
  }
  try {
    if (suspectProtoRx.test(value) || suspectConstructorRx.test(value)) {
      if (options.strict) {
        throw new Error("[destr] Possible prototype pollution");
      }
      return JSON.parse(value, jsonParseTransform);
    }
    return JSON.parse(value);
  } catch (error2) {
    if (options.strict) {
      throw error2;
    }
    return value;
  }
}
function encode(text) {
  return encodeURI("" + text).replace(ENC_PIPE_RE, "|");
}
function encodeQueryValue(input) {
  return encode(typeof input === "string" ? input : JSON.stringify(input)).replace(PLUS_RE, "%2B").replace(ENC_SPACE_RE, "+").replace(HASH_RE, "%23").replace(AMPERSAND_RE, "%26").replace(ENC_BACKTICK_RE, "`").replace(ENC_CARET_RE, "^").replace(SLASH_RE, "%2F");
}
function encodeQueryKey(text) {
  return encodeQueryValue(text).replace(EQUAL_RE, "%3D");
}
function encodePath(text) {
  return encode(text).replace(HASH_RE, "%23").replace(IM_RE, "%3F").replace(ENC_ENC_SLASH_RE, "%2F").replace(AMPERSAND_RE, "%26").replace(PLUS_RE, "%2B");
}
function decode$1(text = "") {
  try {
    return decodeURIComponent("" + text);
  } catch {
    return "" + text;
  }
}
function decodeQueryKey(text) {
  return decode$1(text.replace(PLUS_RE, " "));
}
function decodeQueryValue(text) {
  return decode$1(text.replace(PLUS_RE, " "));
}
function parseQuery(parametersString = "") {
  const object = {};
  if (parametersString[0] === "?") {
    parametersString = parametersString.slice(1);
  }
  for (const parameter of parametersString.split("&")) {
    const s2 = parameter.match(/([^=]+)=?(.*)/) || [];
    if (s2.length < 2) {
      continue;
    }
    const key = decodeQueryKey(s2[1]);
    if (key === "__proto__" || key === "constructor") {
      continue;
    }
    const value = decodeQueryValue(s2[2] || "");
    if (object[key] === void 0) {
      object[key] = value;
    } else if (Array.isArray(object[key])) {
      object[key].push(value);
    } else {
      object[key] = [object[key], value];
    }
  }
  return object;
}
function encodeQueryItem(key, value) {
  if (typeof value === "number" || typeof value === "boolean") {
    value = String(value);
  }
  if (!value) {
    return encodeQueryKey(key);
  }
  if (Array.isArray(value)) {
    return value.map((_value) => `${encodeQueryKey(key)}=${encodeQueryValue(_value)}`).join("&");
  }
  return `${encodeQueryKey(key)}=${encodeQueryValue(value)}`;
}
function stringifyQuery(query) {
  return Object.keys(query).filter((k) => query[k] !== void 0).map((k) => encodeQueryItem(k, query[k])).filter(Boolean).join("&");
}
function hasProtocol(inputString, opts = {}) {
  if (typeof opts === "boolean") {
    opts = { acceptRelative: opts };
  }
  if (opts.strict) {
    return PROTOCOL_STRICT_REGEX.test(inputString);
  }
  return PROTOCOL_REGEX.test(inputString) || (opts.acceptRelative ? PROTOCOL_RELATIVE_REGEX.test(inputString) : false);
}
function isScriptProtocol(protocol) {
  return !!protocol && PROTOCOL_SCRIPT_RE.test(protocol);
}
function hasTrailingSlash(input = "", respectQueryAndFragment) {
  if (!respectQueryAndFragment) {
    return input.endsWith("/");
  }
  return TRAILING_SLASH_RE.test(input);
}
function withoutTrailingSlash(input = "", respectQueryAndFragment) {
  if (!respectQueryAndFragment) {
    return (hasTrailingSlash(input) ? input.slice(0, -1) : input) || "/";
  }
  if (!hasTrailingSlash(input, true)) {
    return input || "/";
  }
  let path = input;
  let fragment = "";
  const fragmentIndex = input.indexOf("#");
  if (fragmentIndex >= 0) {
    path = input.slice(0, fragmentIndex);
    fragment = input.slice(fragmentIndex);
  }
  const [s0, ...s2] = path.split("?");
  const cleanPath = s0.endsWith("/") ? s0.slice(0, -1) : s0;
  return (cleanPath || "/") + (s2.length > 0 ? `?${s2.join("?")}` : "") + fragment;
}
function withTrailingSlash(input = "", respectQueryAndFragment) {
  if (!respectQueryAndFragment) {
    return input.endsWith("/") ? input : input + "/";
  }
  if (hasTrailingSlash(input, true)) {
    return input || "/";
  }
  let path = input;
  let fragment = "";
  const fragmentIndex = input.indexOf("#");
  if (fragmentIndex >= 0) {
    path = input.slice(0, fragmentIndex);
    fragment = input.slice(fragmentIndex);
    if (!path) {
      return fragment;
    }
  }
  const [s0, ...s2] = path.split("?");
  return s0 + "/" + (s2.length > 0 ? `?${s2.join("?")}` : "") + fragment;
}
function hasLeadingSlash(input = "") {
  return input.startsWith("/");
}
function withLeadingSlash(input = "") {
  return hasLeadingSlash(input) ? input : "/" + input;
}
function withBase(input, base) {
  if (isEmptyURL(base) || hasProtocol(input)) {
    return input;
  }
  const _base = withoutTrailingSlash(base);
  if (input.startsWith(_base)) {
    return input;
  }
  return joinURL(_base, input);
}
function withoutBase(input, base) {
  if (isEmptyURL(base)) {
    return input;
  }
  const _base = withoutTrailingSlash(base);
  if (!input.startsWith(_base)) {
    return input;
  }
  const trimmed = input.slice(_base.length);
  return trimmed[0] === "/" ? trimmed : "/" + trimmed;
}
function withQuery(input, query) {
  const parsed = parseURL(input);
  const mergedQuery = { ...parseQuery(parsed.search), ...query };
  parsed.search = stringifyQuery(mergedQuery);
  return stringifyParsedURL(parsed);
}
function getQuery$1(input) {
  return parseQuery(parseURL(input).search);
}
function isEmptyURL(url) {
  return !url || url === "/";
}
function isNonEmptyURL(url) {
  return url && url !== "/";
}
function joinURL(base, ...input) {
  let url = base || "";
  for (const segment of input.filter((url2) => isNonEmptyURL(url2))) {
    if (url) {
      const _segment = segment.replace(JOIN_LEADING_SLASH_RE, "");
      url = withTrailingSlash(url) + _segment;
    } else {
      url = segment;
    }
  }
  return url;
}
function joinRelativeURL(..._input) {
  const JOIN_SEGMENT_SPLIT_RE = /\/(?!\/)/;
  const input = _input.filter(Boolean);
  const segments = [];
  let segmentsDepth = 0;
  for (const i2 of input) {
    if (!i2 || i2 === "/") {
      continue;
    }
    for (const [sindex, s2] of i2.split(JOIN_SEGMENT_SPLIT_RE).entries()) {
      if (!s2 || s2 === ".") {
        continue;
      }
      if (s2 === "..") {
        if (segments.length === 1 && hasProtocol(segments[0])) {
          continue;
        }
        segments.pop();
        segmentsDepth--;
        continue;
      }
      if (sindex === 1 && segments[segments.length - 1]?.endsWith(":/")) {
        segments[segments.length - 1] += "/" + s2;
        continue;
      }
      segments.push(s2);
      segmentsDepth++;
    }
  }
  let url = segments.join("/");
  if (segmentsDepth >= 0) {
    if (input[0]?.startsWith("/") && !url.startsWith("/")) {
      url = "/" + url;
    } else if (input[0]?.startsWith("./") && !url.startsWith("./")) {
      url = "./" + url;
    }
  } else {
    url = "../".repeat(-1 * segmentsDepth) + url;
  }
  if (input[input.length - 1]?.endsWith("/") && !url.endsWith("/")) {
    url += "/";
  }
  return url;
}
function withHttps(input) {
  return withProtocol(input, "https://");
}
function withProtocol(input, protocol) {
  let match = input.match(PROTOCOL_REGEX);
  if (!match) {
    match = input.match(/^\/{2,}/);
  }
  if (!match) {
    return protocol + input;
  }
  return protocol + input.slice(match[0].length);
}
function parseURL(input = "", defaultProto) {
  const _specialProtoMatch = input.match(
    /^[\s\0]*(blob:|data:|javascript:|vbscript:)(.*)/i
  );
  if (_specialProtoMatch) {
    const [, _proto, _pathname = ""] = _specialProtoMatch;
    return {
      protocol: _proto.toLowerCase(),
      pathname: _pathname,
      href: _proto + _pathname,
      auth: "",
      host: "",
      search: "",
      hash: ""
    };
  }
  if (!hasProtocol(input, { acceptRelative: true })) {
    return defaultProto ? parseURL(defaultProto + input) : parsePath(input);
  }
  const [, protocol = "", auth2, hostAndPath = ""] = input.replace(/\\/g, "/").match(/^[\s\0]*([\w+.-]{2,}:)?\/\/([^/@]+@)?(.*)/) || [];
  let [, host = "", path = ""] = hostAndPath.match(/([^#/?]*)(.*)?/) || [];
  if (protocol === "file:") {
    path = path.replace(/\/(?=[A-Za-z]:)/, "");
  }
  const { pathname, search, hash: hash2 } = parsePath(path);
  return {
    protocol: protocol.toLowerCase(),
    auth: auth2 ? auth2.slice(0, Math.max(0, auth2.length - 1)) : "",
    host,
    pathname,
    search,
    hash: hash2,
    [protocolRelative]: !protocol
  };
}
function parsePath(input = "") {
  const [pathname = "", search = "", hash2 = ""] = (input.match(/([^#?]*)(\?[^#]*)?(#.*)?/) || []).splice(1);
  return {
    pathname,
    search,
    hash: hash2
  };
}
function stringifyParsedURL(parsed) {
  const pathname = parsed.pathname || "";
  const search = parsed.search ? (parsed.search.startsWith("?") ? "" : "?") + parsed.search : "";
  const hash2 = parsed.hash || "";
  const auth2 = parsed.auth ? parsed.auth + "@" : "";
  const host = parsed.host || "";
  const proto = parsed.protocol || parsed[protocolRelative] ? (parsed.protocol || "") + "//" : "";
  return proto + auth2 + host + pathname + search + hash2;
}
function parse(str, options) {
  if (typeof str !== "string") {
    throw new TypeError("argument str must be a string");
  }
  const obj = {};
  const opt = options || {};
  const dec = opt.decode || decode;
  let index3 = 0;
  while (index3 < str.length) {
    const eqIdx = str.indexOf("=", index3);
    if (eqIdx === -1) {
      break;
    }
    let endIdx = str.indexOf(";", index3);
    if (endIdx === -1) {
      endIdx = str.length;
    } else if (endIdx < eqIdx) {
      index3 = str.lastIndexOf(";", eqIdx - 1) + 1;
      continue;
    }
    const key = str.slice(index3, eqIdx).trim();
    if (opt?.filter && !opt?.filter(key)) {
      index3 = endIdx + 1;
      continue;
    }
    if (void 0 === obj[key]) {
      let val = str.slice(eqIdx + 1, endIdx).trim();
      if (val.codePointAt(0) === 34) {
        val = val.slice(1, -1);
      }
      obj[key] = tryDecode(val, dec);
    }
    index3 = endIdx + 1;
  }
  return obj;
}
function decode(str) {
  return str.includes("%") ? decodeURIComponent(str) : str;
}
function tryDecode(str, decode2) {
  try {
    return decode2(str);
  } catch {
    return str;
  }
}
function serialize(name, value, options) {
  const opt = options || {};
  const enc = opt.encode || encodeURIComponent;
  if (typeof enc !== "function") {
    throw new TypeError("option encode is invalid");
  }
  if (!fieldContentRegExp.test(name)) {
    throw new TypeError("argument name is invalid");
  }
  const encodedValue = enc(value);
  if (encodedValue && !fieldContentRegExp.test(encodedValue)) {
    throw new TypeError("argument val is invalid");
  }
  let str = name + "=" + encodedValue;
  if (void 0 !== opt.maxAge && opt.maxAge !== null) {
    const maxAge = opt.maxAge - 0;
    if (Number.isNaN(maxAge) || !Number.isFinite(maxAge)) {
      throw new TypeError("option maxAge is invalid");
    }
    str += "; Max-Age=" + Math.floor(maxAge);
  }
  if (opt.domain) {
    if (!fieldContentRegExp.test(opt.domain)) {
      throw new TypeError("option domain is invalid");
    }
    str += "; Domain=" + opt.domain;
  }
  if (opt.path) {
    if (!fieldContentRegExp.test(opt.path)) {
      throw new TypeError("option path is invalid");
    }
    str += "; Path=" + opt.path;
  }
  if (opt.expires) {
    if (!isDate(opt.expires) || Number.isNaN(opt.expires.valueOf())) {
      throw new TypeError("option expires is invalid");
    }
    str += "; Expires=" + opt.expires.toUTCString();
  }
  if (opt.httpOnly) {
    str += "; HttpOnly";
  }
  if (opt.secure) {
    str += "; Secure";
  }
  if (opt.priority) {
    const priority = typeof opt.priority === "string" ? opt.priority.toLowerCase() : opt.priority;
    switch (priority) {
      case "low": {
        str += "; Priority=Low";
        break;
      }
      case "medium": {
        str += "; Priority=Medium";
        break;
      }
      case "high": {
        str += "; Priority=High";
        break;
      }
      default: {
        throw new TypeError("option priority is invalid");
      }
    }
  }
  if (opt.sameSite) {
    const sameSite = typeof opt.sameSite === "string" ? opt.sameSite.toLowerCase() : opt.sameSite;
    switch (sameSite) {
      case true: {
        str += "; SameSite=Strict";
        break;
      }
      case "lax": {
        str += "; SameSite=Lax";
        break;
      }
      case "strict": {
        str += "; SameSite=Strict";
        break;
      }
      case "none": {
        str += "; SameSite=None";
        break;
      }
      default: {
        throw new TypeError("option sameSite is invalid");
      }
    }
  }
  if (opt.partitioned) {
    str += "; Partitioned";
  }
  return str;
}
function isDate(val) {
  return Object.prototype.toString.call(val) === "[object Date]" || val instanceof Date;
}
function objectHash(object, options) {
  if (options) {
    options = { ...defaults, ...options };
  } else {
    options = defaults;
  }
  const hasher = createHasher(options);
  hasher.dispatch(object);
  return hasher.toString();
}
function createHasher(options) {
  let buff = "";
  let context = /* @__PURE__ */ new Map();
  const write = (str) => {
    buff += str;
  };
  return {
    toString() {
      return buff;
    },
    getContext() {
      return context;
    },
    dispatch(value) {
      if (options.replacer) {
        value = options.replacer(value);
      }
      const type = value === null ? "null" : typeof value;
      return this[type](value);
    },
    object(object) {
      if (object && typeof object.toJSON === "function") {
        return this.object(object.toJSON());
      }
      const objString = Object.prototype.toString.call(object);
      let objType = "";
      const objectLength = objString.length;
      if (objectLength < 10) {
        objType = "unknown:[" + objString + "]";
      } else {
        objType = objString.slice(8, objectLength - 1);
      }
      objType = objType.toLowerCase();
      let objectNumber = null;
      if ((objectNumber = context.get(object)) === void 0) {
        context.set(object, context.size);
      } else {
        return this.dispatch("[CIRCULAR:" + objectNumber + "]");
      }
      if (typeof Buffer !== "undefined" && Buffer.isBuffer && Buffer.isBuffer(object)) {
        write("buffer:");
        return write(object.toString("utf8"));
      }
      if (objType !== "object" && objType !== "function" && objType !== "asyncfunction") {
        if (this[objType]) {
          this[objType](object);
        } else if (!options.ignoreUnknown) {
          this.unkown(object, objType);
        }
      } else {
        let keys = Object.keys(object);
        if (options.unorderedObjects) {
          keys = keys.sort();
        }
        let extraKeys = [];
        if (options.respectType !== false && !isNativeFunction(object)) {
          extraKeys = defaultPrototypesKeys;
        }
        if (options.excludeKeys) {
          keys = keys.filter((key) => {
            return !options.excludeKeys(key);
          });
          extraKeys = extraKeys.filter((key) => {
            return !options.excludeKeys(key);
          });
        }
        write("object:" + (keys.length + extraKeys.length) + ":");
        const dispatchForKey = (key) => {
          this.dispatch(key);
          write(":");
          if (!options.excludeValues) {
            this.dispatch(object[key]);
          }
          write(",");
        };
        for (const key of keys) {
          dispatchForKey(key);
        }
        for (const key of extraKeys) {
          dispatchForKey(key);
        }
      }
    },
    array(arr, unordered) {
      unordered = unordered === void 0 ? options.unorderedArrays !== false : unordered;
      write("array:" + arr.length + ":");
      if (!unordered || arr.length <= 1) {
        for (const entry2 of arr) {
          this.dispatch(entry2);
        }
        return;
      }
      const contextAdditions = /* @__PURE__ */ new Map();
      const entries = arr.map((entry2) => {
        const hasher = createHasher(options);
        hasher.dispatch(entry2);
        for (const [key, value] of hasher.getContext()) {
          contextAdditions.set(key, value);
        }
        return hasher.toString();
      });
      context = contextAdditions;
      entries.sort();
      return this.array(entries, false);
    },
    date(date) {
      return write("date:" + date.toJSON());
    },
    symbol(sym) {
      return write("symbol:" + sym.toString());
    },
    unkown(value, type) {
      write(type);
      if (!value) {
        return;
      }
      write(":");
      if (value && typeof value.entries === "function") {
        return this.array(
          Array.from(value.entries()),
          true
          /* ordered */
        );
      }
    },
    error(err) {
      return write("error:" + err.toString());
    },
    boolean(bool) {
      return write("bool:" + bool);
    },
    string(string) {
      write("string:" + string.length + ":");
      write(string);
    },
    function(fn) {
      write("fn:");
      if (isNativeFunction(fn)) {
        this.dispatch("[native]");
      } else {
        this.dispatch(fn.toString());
      }
      if (options.respectFunctionNames !== false) {
        this.dispatch("function-name:" + String(fn.name));
      }
      if (options.respectFunctionProperties) {
        this.object(fn);
      }
    },
    number(number) {
      return write("number:" + number);
    },
    xml(xml) {
      return write("xml:" + xml.toString());
    },
    null() {
      return write("Null");
    },
    undefined() {
      return write("Undefined");
    },
    regexp(regex) {
      return write("regex:" + regex.toString());
    },
    uint8array(arr) {
      write("uint8array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    uint8clampedarray(arr) {
      write("uint8clampedarray:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    int8array(arr) {
      write("int8array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    uint16array(arr) {
      write("uint16array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    int16array(arr) {
      write("int16array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    uint32array(arr) {
      write("uint32array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    int32array(arr) {
      write("int32array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    float32array(arr) {
      write("float32array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    float64array(arr) {
      write("float64array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    arraybuffer(arr) {
      write("arraybuffer:");
      return this.dispatch(new Uint8Array(arr));
    },
    url(url) {
      return write("url:" + url.toString());
    },
    map(map) {
      write("map:");
      const arr = [...map];
      return this.array(arr, options.unorderedSets !== false);
    },
    set(set) {
      write("set:");
      const arr = [...set];
      return this.array(arr, options.unorderedSets !== false);
    },
    file(file) {
      write("file:");
      return this.dispatch([file.name, file.size, file.type, file.lastModfied]);
    },
    blob() {
      if (options.ignoreUnknown) {
        return write("[blob]");
      }
      throw new Error(
        'Hashing Blob objects is currently not supported\nUse "options.replacer" or "options.ignoreUnknown"\n'
      );
    },
    domwindow() {
      return write("domwindow");
    },
    bigint(number) {
      return write("bigint:" + number.toString());
    },
    /* Node.js standard native objects */
    process() {
      return write("process");
    },
    timer() {
      return write("timer");
    },
    pipe() {
      return write("pipe");
    },
    tcp() {
      return write("tcp");
    },
    udp() {
      return write("udp");
    },
    tty() {
      return write("tty");
    },
    statwatcher() {
      return write("statwatcher");
    },
    securecontext() {
      return write("securecontext");
    },
    connection() {
      return write("connection");
    },
    zlib() {
      return write("zlib");
    },
    context() {
      return write("context");
    },
    nodescript() {
      return write("nodescript");
    },
    httpparser() {
      return write("httpparser");
    },
    dataview() {
      return write("dataview");
    },
    signal() {
      return write("signal");
    },
    fsevent() {
      return write("fsevent");
    },
    tlswrap() {
      return write("tlswrap");
    }
  };
}
function isNativeFunction(f) {
  if (typeof f !== "function") {
    return false;
  }
  return Function.prototype.toString.call(f).slice(-nativeFuncLength) === nativeFunc;
}
function sha256base64(message2) {
  return new SHA256().finalize(message2).toString(Base64);
}
function hash(object, options = {}) {
  const hashed = typeof object === "string" ? object : objectHash(object, options);
  return sha256base64(hashed).slice(0, 10);
}
function isEqual(object1, object2, hashOptions = {}) {
  if (object1 === object2) {
    return true;
  }
  if (objectHash(object1, hashOptions) === objectHash(object2, hashOptions)) {
    return true;
  }
  return false;
}
function createRouter$1(options = {}) {
  const ctx = {
    options,
    rootNode: createRadixNode(),
    staticRoutesMap: {}
  };
  const normalizeTrailingSlash = (p) => options.strictTrailingSlash ? p : p.replace(/\/$/, "") || "/";
  if (options.routes) {
    for (const path in options.routes) {
      insert(ctx, normalizeTrailingSlash(path), options.routes[path]);
    }
  }
  return {
    ctx,
    lookup: (path) => lookup(ctx, normalizeTrailingSlash(path)),
    insert: (path, data) => insert(ctx, normalizeTrailingSlash(path), data),
    remove: (path) => remove(ctx, normalizeTrailingSlash(path))
  };
}
function lookup(ctx, path) {
  const staticPathNode = ctx.staticRoutesMap[path];
  if (staticPathNode) {
    return staticPathNode.data;
  }
  const sections = path.split("/");
  const params = {};
  let paramsFound = false;
  let wildcardNode = null;
  let node = ctx.rootNode;
  let wildCardParam = null;
  for (let i2 = 0; i2 < sections.length; i2++) {
    const section = sections[i2];
    if (node.wildcardChildNode !== null) {
      wildcardNode = node.wildcardChildNode;
      wildCardParam = sections.slice(i2).join("/");
    }
    const nextNode = node.children.get(section);
    if (nextNode === void 0) {
      if (node && node.placeholderChildren.length > 1) {
        const remaining = sections.length - i2;
        node = node.placeholderChildren.find((c) => c.maxDepth === remaining) || null;
      } else {
        node = node.placeholderChildren[0] || null;
      }
      if (!node) {
        break;
      }
      if (node.paramName) {
        params[node.paramName] = section;
      }
      paramsFound = true;
    } else {
      node = nextNode;
    }
  }
  if ((node === null || node.data === null) && wildcardNode !== null) {
    node = wildcardNode;
    params[node.paramName || "_"] = wildCardParam;
    paramsFound = true;
  }
  if (!node) {
    return null;
  }
  if (paramsFound) {
    return {
      ...node.data,
      params: paramsFound ? params : void 0
    };
  }
  return node.data;
}
function insert(ctx, path, data) {
  let isStaticRoute = true;
  const sections = path.split("/");
  let node = ctx.rootNode;
  let _unnamedPlaceholderCtr = 0;
  const matchedNodes = [node];
  for (const section of sections) {
    let childNode;
    if (childNode = node.children.get(section)) {
      node = childNode;
    } else {
      const type = getNodeType(section);
      childNode = createRadixNode({ type, parent: node });
      node.children.set(section, childNode);
      if (type === NODE_TYPES.PLACEHOLDER) {
        childNode.paramName = section === "*" ? `_${_unnamedPlaceholderCtr++}` : section.slice(1);
        node.placeholderChildren.push(childNode);
        isStaticRoute = false;
      } else if (type === NODE_TYPES.WILDCARD) {
        node.wildcardChildNode = childNode;
        childNode.paramName = section.slice(
          3
          /* "**:" */
        ) || "_";
        isStaticRoute = false;
      }
      matchedNodes.push(childNode);
      node = childNode;
    }
  }
  for (const [depth, node2] of matchedNodes.entries()) {
    node2.maxDepth = Math.max(matchedNodes.length - depth, node2.maxDepth || 0);
  }
  node.data = data;
  if (isStaticRoute === true) {
    ctx.staticRoutesMap[path] = node;
  }
  return node;
}
function remove(ctx, path) {
  let success = false;
  const sections = path.split("/");
  let node = ctx.rootNode;
  for (const section of sections) {
    node = node.children.get(section);
    if (!node) {
      return success;
    }
  }
  if (node.data) {
    const lastSection = sections.at(-1) || "";
    node.data = null;
    if (Object.keys(node.children).length === 0 && node.parent) {
      node.parent.children.delete(lastSection);
      node.parent.wildcardChildNode = null;
      node.parent.placeholderChildren = [];
    }
    success = true;
  }
  return success;
}
function createRadixNode(options = {}) {
  return {
    type: options.type || NODE_TYPES.NORMAL,
    maxDepth: 0,
    parent: options.parent || null,
    children: /* @__PURE__ */ new Map(),
    data: options.data || null,
    paramName: options.paramName || null,
    wildcardChildNode: null,
    placeholderChildren: []
  };
}
function getNodeType(str) {
  if (str.startsWith("**")) {
    return NODE_TYPES.WILDCARD;
  }
  if (str[0] === ":" || str === "*") {
    return NODE_TYPES.PLACEHOLDER;
  }
  return NODE_TYPES.NORMAL;
}
function toRouteMatcher(router) {
  const table = _routerNodeToTable("", router.ctx.rootNode);
  return _createMatcher(table, router.ctx.options.strictTrailingSlash);
}
function _createMatcher(table, strictTrailingSlash) {
  return {
    ctx: { table },
    matchAll: (path) => _matchRoutes(path, table, strictTrailingSlash)
  };
}
function _createRouteTable() {
  return {
    static: /* @__PURE__ */ new Map(),
    wildcard: /* @__PURE__ */ new Map(),
    dynamic: /* @__PURE__ */ new Map()
  };
}
function _matchRoutes(path, table, strictTrailingSlash) {
  if (strictTrailingSlash !== true && path.endsWith("/")) {
    path = path.slice(0, -1) || "/";
  }
  const matches = [];
  for (const [key, value] of _sortRoutesMap(table.wildcard)) {
    if (path === key || path.startsWith(key + "/")) {
      matches.push(value);
    }
  }
  for (const [key, value] of _sortRoutesMap(table.dynamic)) {
    if (path.startsWith(key + "/")) {
      const subPath = "/" + path.slice(key.length).split("/").splice(2).join("/");
      matches.push(..._matchRoutes(subPath, value));
    }
  }
  const staticMatch = table.static.get(path);
  if (staticMatch) {
    matches.push(staticMatch);
  }
  return matches.filter(Boolean);
}
function _sortRoutesMap(m) {
  return [...m.entries()].sort((a, b) => a[0].length - b[0].length);
}
function _routerNodeToTable(initialPath, initialNode) {
  const table = _createRouteTable();
  function _addNode(path, node) {
    if (path) {
      if (node.type === NODE_TYPES.NORMAL && !(path.includes("*") || path.includes(":"))) {
        if (node.data) {
          table.static.set(path, node.data);
        }
      } else if (node.type === NODE_TYPES.WILDCARD) {
        table.wildcard.set(path.replace("/**", ""), node.data);
      } else if (node.type === NODE_TYPES.PLACEHOLDER) {
        const subTable = _routerNodeToTable("", node);
        if (node.data) {
          subTable.static.set("/", node.data);
        }
        table.dynamic.set(path.replace(/\/\*|\/:\w+/, ""), subTable);
        return;
      }
    }
    for (const [childPath, child] of node.children.entries()) {
      _addNode(`${path}/${childPath}`.replace("//", "/"), child);
    }
  }
  _addNode(initialPath, initialNode);
  return table;
}
function isPlainObject2(value) {
  if (value === null || typeof value !== "object") {
    return false;
  }
  const prototype = Object.getPrototypeOf(value);
  if (prototype !== null && prototype !== Object.prototype && Object.getPrototypeOf(prototype) !== null) {
    return false;
  }
  if (Symbol.iterator in value) {
    return false;
  }
  if (Symbol.toStringTag in value) {
    return Object.prototype.toString.call(value) === "[object Module]";
  }
  return true;
}
function _defu(baseObject, defaults2, namespace = ".", merger2) {
  if (!isPlainObject2(defaults2)) {
    return _defu(baseObject, {}, namespace, merger2);
  }
  const object = Object.assign({}, defaults2);
  for (const key in baseObject) {
    if (key === "__proto__" || key === "constructor") {
      continue;
    }
    const value = baseObject[key];
    if (value === null || value === void 0) {
      continue;
    }
    if (merger2 && merger2(object, key, value, namespace)) {
      continue;
    }
    if (Array.isArray(value) && Array.isArray(object[key])) {
      object[key] = [...value, ...object[key]];
    } else if (isPlainObject2(value) && isPlainObject2(object[key])) {
      object[key] = _defu(
        value,
        object[key],
        (namespace ? `${namespace}.` : "") + key.toString(),
        merger2
      );
    } else {
      object[key] = value;
    }
  }
  return object;
}
function createDefu(merger2) {
  return (...arguments_) => (
    // eslint-disable-next-line unicorn/no-array-reduce
    arguments_.reduce((p, c) => _defu(p, c, "", merger2), {})
  );
}
function rawHeaders(headers) {
  const rawHeaders2 = [];
  for (const key in headers) {
    if (Array.isArray(headers[key])) {
      for (const h3 of headers[key]) {
        rawHeaders2.push(key, h3);
      }
    } else {
      rawHeaders2.push(key, headers[key]);
    }
  }
  return rawHeaders2;
}
function mergeFns(...functions) {
  return function(...args) {
    for (const fn of functions) {
      fn(...args);
    }
  };
}
function createNotImplementedError(name) {
  throw new Error(`[unenv] ${name} is not implemented yet!`);
}
function _addListener(target, type, listener, prepend) {
  _checkListener(listener);
  if (target._events.newListener !== void 0) {
    target.emit("newListener", type, listener.listener || listener);
  }
  if (!target._events[type]) {
    target._events[type] = [];
  }
  if (prepend) {
    target._events[type].unshift(listener);
  } else {
    target._events[type].push(listener);
  }
  const maxListeners = _getMaxListeners(target);
  if (maxListeners > 0 && target._events[type].length > maxListeners && !target._events[type].warned) {
    target._events[type].warned = true;
    const warning = new Error(
      `[unenv] Possible EventEmitter memory leak detected. ${target._events[type].length} ${type} listeners added. Use emitter.setMaxListeners() to increase limit`
    );
    warning.name = "MaxListenersExceededWarning";
    warning.emitter = target;
    warning.type = type;
    warning.count = target._events[type]?.length;
    console.warn(warning);
  }
  return target;
}
function _removeListener(target, type, listener) {
  _checkListener(listener);
  if (!target._events[type] || target._events[type].length === 0) {
    return target;
  }
  const lenBeforeFilter = target._events[type].length;
  target._events[type] = target._events[type].filter((fn) => fn !== listener);
  if (lenBeforeFilter === target._events[type].length) {
    return target;
  }
  if (target._events.removeListener) {
    target.emit("removeListener", type, listener.listener || listener);
  }
  if (target._events[type].length === 0) {
    delete target._events[type];
  }
  return target;
}
function _removeAllListeners(target, type) {
  if (!target._events[type] || target._events[type].length === 0) {
    return target;
  }
  if (target._events.removeListener) {
    for (const _listener of target._events[type]) {
      target.emit("removeListener", type, _listener.listener || _listener);
    }
  }
  delete target._events[type];
  return target;
}
function _wrapOnce(target, type, listener) {
  let fired = false;
  const wrapper = (...args) => {
    if (fired) {
      return;
    }
    target.removeListener(type, wrapper);
    fired = true;
    return args.length === 0 ? listener.call(target) : listener.apply(target, args);
  };
  wrapper.listener = listener;
  return wrapper;
}
function _getMaxListeners(target) {
  return target._maxListeners ?? EventEmitter$1.defaultMaxListeners;
}
function _listeners(target, type, unwrap) {
  let listeners = target._events[type];
  if (typeof listeners === "function") {
    listeners = [listeners];
  }
  return unwrap ? listeners.map((l2) => l2.listener || l2) : listeners;
}
function _checkListener(listener) {
  if (typeof listener !== "function") {
    throw new TypeError(
      'The "listener" argument must be of type Function. Received type ' + typeof listener
    );
  }
}
function getDuplex() {
  Object.assign(__Duplex.prototype, Readable.prototype);
  Object.assign(__Duplex.prototype, Writable.prototype);
  return __Duplex;
}
function _distinct(obj) {
  const d = {};
  for (const [key, value] of Object.entries(obj)) {
    if (key) {
      d[key] = (Array.isArray(value) ? value : [value]).filter(
        Boolean
      );
    }
  }
  return d;
}
function hasProp(obj, prop) {
  try {
    return prop in obj;
  } catch {
    return false;
  }
}
function createError$1(input) {
  if (typeof input === "string") {
    return new H3Error(input);
  }
  if (isError(input)) {
    return input;
  }
  const err = new H3Error(input.message ?? input.statusMessage ?? "", {
    cause: input.cause || input
  });
  if (hasProp(input, "stack")) {
    try {
      Object.defineProperty(err, "stack", {
        get() {
          return input.stack;
        }
      });
    } catch {
      try {
        err.stack = input.stack;
      } catch {
      }
    }
  }
  if (input.data) {
    err.data = input.data;
  }
  if (input.statusCode) {
    err.statusCode = sanitizeStatusCode(input.statusCode, err.statusCode);
  } else if (input.status) {
    err.statusCode = sanitizeStatusCode(input.status, err.statusCode);
  }
  if (input.statusMessage) {
    err.statusMessage = input.statusMessage;
  } else if (input.statusText) {
    err.statusMessage = input.statusText;
  }
  if (err.statusMessage) {
    const originalMessage = err.statusMessage;
    const sanitizedMessage = sanitizeStatusMessage(err.statusMessage);
    if (sanitizedMessage !== originalMessage) {
      console.warn(
        "[h3] Please prefer using `message` for longer error messages instead of `statusMessage`. In the future, `statusMessage` will be sanitized by default."
      );
    }
  }
  if (input.fatal !== void 0) {
    err.fatal = input.fatal;
  }
  if (input.unhandled !== void 0) {
    err.unhandled = input.unhandled;
  }
  return err;
}
function sendError(event, error2, debug) {
  if (event.handled) {
    return;
  }
  const h3Error = isError(error2) ? error2 : createError$1(error2);
  const responseBody = {
    statusCode: h3Error.statusCode,
    statusMessage: h3Error.statusMessage,
    stack: [],
    data: h3Error.data
  };
  if (debug) {
    responseBody.stack = (h3Error.stack || "").split("\n").map((l2) => l2.trim());
  }
  if (event.handled) {
    return;
  }
  const _code = Number.parseInt(h3Error.statusCode);
  setResponseStatus(event, _code, h3Error.statusMessage);
  event.node.res.setHeader("content-type", MIMES.json);
  event.node.res.end(JSON.stringify(responseBody, void 0, 2));
}
function isError(input) {
  return input?.constructor?.__h3_error__ === true;
}
function getQuery(event) {
  return getQuery$1(event.path || "");
}
function isMethod(event, expected, allowHead) {
  if (typeof expected === "string") {
    if (event.method === expected) {
      return true;
    }
  } else if (expected.includes(event.method)) {
    return true;
  }
  return false;
}
function assertMethod(event, expected, allowHead) {
  if (!isMethod(event, expected)) {
    throw createError$1({
      statusCode: 405,
      statusMessage: "HTTP method is not allowed."
    });
  }
}
function getRequestHeaders(event) {
  const _headers = {};
  for (const key in event.node.req.headers) {
    const val = event.node.req.headers[key];
    _headers[key] = Array.isArray(val) ? val.filter(Boolean).join(", ") : val;
  }
  return _headers;
}
function getRequestHeader(event, name) {
  const headers = getRequestHeaders(event);
  const value = headers[name.toLowerCase()];
  return value;
}
function getRequestHost(event, opts = {}) {
  if (opts.xForwardedHost) {
    const xForwardedHost = event.node.req.headers["x-forwarded-host"];
    if (xForwardedHost) {
      return xForwardedHost;
    }
  }
  return event.node.req.headers.host || "localhost";
}
function getRequestProtocol(event, opts = {}) {
  if (opts.xForwardedProto !== false && event.node.req.headers["x-forwarded-proto"] === "https") {
    return "https";
  }
  return event.node.req.connection?.encrypted ? "https" : "http";
}
function readRawBody(event, encoding = "utf8") {
  assertMethod(event, PayloadMethods$1);
  const _rawBody = event._requestBody || event.web?.request?.body || event.node.req[RawBodySymbol] || event.node.req.rawBody || event.node.req.body;
  if (_rawBody) {
    const promise2 = Promise.resolve(_rawBody).then((_resolved) => {
      if (Buffer.isBuffer(_resolved)) {
        return _resolved;
      }
      if (typeof _resolved.pipeTo === "function") {
        return new Promise((resolve2, reject) => {
          const chunks = [];
          _resolved.pipeTo(
            new WritableStream({
              write(chunk) {
                chunks.push(chunk);
              },
              close() {
                resolve2(Buffer.concat(chunks));
              },
              abort(reason) {
                reject(reason);
              }
            })
          ).catch(reject);
        });
      } else if (typeof _resolved.pipe === "function") {
        return new Promise((resolve2, reject) => {
          const chunks = [];
          _resolved.on("data", (chunk) => {
            chunks.push(chunk);
          }).on("end", () => {
            resolve2(Buffer.concat(chunks));
          }).on("error", reject);
        });
      }
      if (_resolved.constructor === Object) {
        return Buffer.from(JSON.stringify(_resolved));
      }
      if (_resolved instanceof URLSearchParams) {
        return Buffer.from(_resolved.toString());
      }
      return Buffer.from(_resolved);
    });
    return encoding ? promise2.then((buff) => buff.toString(encoding)) : promise2;
  }
  if (!Number.parseInt(event.node.req.headers["content-length"] || "") && !String(event.node.req.headers["transfer-encoding"] ?? "").split(",").map((e) => e.trim()).filter(Boolean).includes("chunked")) {
    return Promise.resolve(void 0);
  }
  const promise = event.node.req[RawBodySymbol] = new Promise(
    (resolve2, reject) => {
      const bodyData = [];
      event.node.req.on("error", (err) => {
        reject(err);
      }).on("data", (chunk) => {
        bodyData.push(chunk);
      }).on("end", () => {
        resolve2(Buffer.concat(bodyData));
      });
    }
  );
  const result = encoding ? promise.then((buff) => buff.toString(encoding)) : promise;
  return result;
}
function getRequestWebStream(event) {
  if (!PayloadMethods$1.includes(event.method)) {
    return;
  }
  const bodyStream = event.web?.request?.body || event._requestBody;
  if (bodyStream) {
    return bodyStream;
  }
  const _hasRawBody = RawBodySymbol in event.node.req || "rawBody" in event.node.req || "body" in event.node.req || "__unenv__" in event.node.req;
  if (_hasRawBody) {
    return new ReadableStream({
      async start(controller) {
        const _rawBody = await readRawBody(event, false);
        if (_rawBody) {
          controller.enqueue(_rawBody);
        }
        controller.close();
      }
    });
  }
  return new ReadableStream({
    start: (controller) => {
      event.node.req.on("data", (chunk) => {
        controller.enqueue(chunk);
      });
      event.node.req.on("end", () => {
        controller.close();
      });
      event.node.req.on("error", (err) => {
        controller.error(err);
      });
    }
  });
}
function handleCacheHeaders(event, opts) {
  const cacheControls = ["public", ...opts.cacheControls || []];
  let cacheMatched = false;
  if (opts.maxAge !== void 0) {
    cacheControls.push(`max-age=${+opts.maxAge}`, `s-maxage=${+opts.maxAge}`);
  }
  if (opts.modifiedTime) {
    const modifiedTime = new Date(opts.modifiedTime);
    const ifModifiedSince = event.node.req.headers["if-modified-since"];
    event.node.res.setHeader("last-modified", modifiedTime.toUTCString());
    if (ifModifiedSince && new Date(ifModifiedSince) >= opts.modifiedTime) {
      cacheMatched = true;
    }
  }
  if (opts.etag) {
    event.node.res.setHeader("etag", opts.etag);
    const ifNonMatch = event.node.req.headers["if-none-match"];
    if (ifNonMatch === opts.etag) {
      cacheMatched = true;
    }
  }
  event.node.res.setHeader("cache-control", cacheControls.join(", "));
  if (cacheMatched) {
    event.node.res.statusCode = 304;
    if (!event.handled) {
      event.node.res.end();
    }
    return true;
  }
  return false;
}
function sanitizeStatusMessage(statusMessage = "") {
  return statusMessage.replace(DISALLOWED_STATUS_CHARS, "");
}
function sanitizeStatusCode(statusCode, defaultStatusCode = 200) {
  if (!statusCode) {
    return defaultStatusCode;
  }
  if (typeof statusCode === "string") {
    statusCode = Number.parseInt(statusCode, 10);
  }
  if (statusCode < 100 || statusCode > 999) {
    return defaultStatusCode;
  }
  return statusCode;
}
function parseCookies(event) {
  return parse(event.node.req.headers.cookie || "");
}
function getCookie(event, name) {
  return parseCookies(event)[name];
}
function setCookie(event, name, value, serializeOptions) {
  serializeOptions = { path: "/", ...serializeOptions };
  const cookieStr = serialize(name, value, serializeOptions);
  let setCookies = event.node.res.getHeader("set-cookie");
  if (!Array.isArray(setCookies)) {
    setCookies = [setCookies];
  }
  const _optionsHash = objectHash(serializeOptions);
  setCookies = setCookies.filter((cookieValue) => {
    return cookieValue && _optionsHash !== objectHash(parse(cookieValue));
  });
  event.node.res.setHeader("set-cookie", [...setCookies, cookieStr]);
}
function deleteCookie(event, name, serializeOptions) {
  setCookie(event, name, "", {
    ...serializeOptions,
    maxAge: 0
  });
}
function splitCookiesString(cookiesString) {
  if (Array.isArray(cookiesString)) {
    return cookiesString.flatMap((c) => splitCookiesString(c));
  }
  if (typeof cookiesString !== "string") {
    return [];
  }
  const cookiesStrings = [];
  let pos = 0;
  let start;
  let ch;
  let lastComma;
  let nextStart;
  let cookiesSeparatorFound;
  const skipWhitespace = () => {
    while (pos < cookiesString.length && /\s/.test(cookiesString.charAt(pos))) {
      pos += 1;
    }
    return pos < cookiesString.length;
  };
  const notSpecialChar = () => {
    ch = cookiesString.charAt(pos);
    return ch !== "=" && ch !== ";" && ch !== ",";
  };
  while (pos < cookiesString.length) {
    start = pos;
    cookiesSeparatorFound = false;
    while (skipWhitespace()) {
      ch = cookiesString.charAt(pos);
      if (ch === ",") {
        lastComma = pos;
        pos += 1;
        skipWhitespace();
        nextStart = pos;
        while (pos < cookiesString.length && notSpecialChar()) {
          pos += 1;
        }
        if (pos < cookiesString.length && cookiesString.charAt(pos) === "=") {
          cookiesSeparatorFound = true;
          pos = nextStart;
          cookiesStrings.push(cookiesString.slice(start, lastComma));
          start = pos;
        } else {
          pos = lastComma + 1;
        }
      } else {
        pos += 1;
      }
    }
    if (!cookiesSeparatorFound || pos >= cookiesString.length) {
      cookiesStrings.push(cookiesString.slice(start));
    }
  }
  return cookiesStrings;
}
function send(event, data, type) {
  if (type) {
    defaultContentType(event, type);
  }
  return new Promise((resolve2) => {
    defer(() => {
      if (!event.handled) {
        event.node.res.end(data);
      }
      resolve2();
    });
  });
}
function sendNoContent(event, code) {
  if (event.handled) {
    return;
  }
  if (!code && event.node.res.statusCode !== 200) {
    code = event.node.res.statusCode;
  }
  const _code = sanitizeStatusCode(code, 204);
  if (_code === 204) {
    event.node.res.removeHeader("content-length");
  }
  event.node.res.writeHead(_code);
  event.node.res.end();
}
function setResponseStatus(event, code, text) {
  if (code) {
    event.node.res.statusCode = sanitizeStatusCode(
      code,
      event.node.res.statusCode
    );
  }
  if (text) {
    event.node.res.statusMessage = sanitizeStatusMessage(text);
  }
}
function getResponseStatus(event) {
  return event.node.res.statusCode;
}
function getResponseStatusText(event) {
  return event.node.res.statusMessage;
}
function defaultContentType(event, type) {
  if (type && event.node.res.statusCode !== 304 && !event.node.res.getHeader("content-type")) {
    event.node.res.setHeader("content-type", type);
  }
}
function sendRedirect(event, location, code = 302) {
  event.node.res.statusCode = sanitizeStatusCode(
    code,
    event.node.res.statusCode
  );
  event.node.res.setHeader("location", location);
  const encodedLoc = location.replace(/"/g, "%22");
  const html = `<!DOCTYPE html><html><head><meta http-equiv="refresh" content="0; url=${encodedLoc}"></head></html>`;
  return send(event, html, MIMES.html);
}
function setResponseHeaders(event, headers) {
  for (const [name, value] of Object.entries(headers)) {
    event.node.res.setHeader(
      name,
      value
    );
  }
}
function setResponseHeader(event, name, value) {
  event.node.res.setHeader(name, value);
}
function isStream(data) {
  if (!data || typeof data !== "object") {
    return false;
  }
  if (typeof data.pipe === "function") {
    if (typeof data._read === "function") {
      return true;
    }
    if (typeof data.abort === "function") {
      return true;
    }
  }
  if (typeof data.pipeTo === "function") {
    return true;
  }
  return false;
}
function isWebResponse(data) {
  return typeof Response !== "undefined" && data instanceof Response;
}
function sendStream(event, stream) {
  if (!stream || typeof stream !== "object") {
    throw new Error("[h3] Invalid stream provided.");
  }
  event.node.res._data = stream;
  if (!event.node.res.socket) {
    event._handled = true;
    return Promise.resolve();
  }
  if (hasProp(stream, "pipeTo") && typeof stream.pipeTo === "function") {
    return stream.pipeTo(
      new WritableStream({
        write(chunk) {
          event.node.res.write(chunk);
        }
      })
    ).then(() => {
      event.node.res.end();
    });
  }
  if (hasProp(stream, "pipe") && typeof stream.pipe === "function") {
    return new Promise((resolve2, reject) => {
      stream.pipe(event.node.res);
      if (stream.on) {
        stream.on("end", () => {
          event.node.res.end();
          resolve2();
        });
        stream.on("error", (error2) => {
          reject(error2);
        });
      }
      event.node.res.on("close", () => {
        if (stream.abort) {
          stream.abort();
        }
      });
    });
  }
  throw new Error("[h3] Invalid or incompatible stream provided.");
}
function sendWebResponse(event, response) {
  for (const [key, value] of response.headers) {
    if (key === "set-cookie") {
      event.node.res.appendHeader(key, splitCookiesString(value));
    } else {
      event.node.res.setHeader(key, value);
    }
  }
  if (response.status) {
    event.node.res.statusCode = sanitizeStatusCode(
      response.status,
      event.node.res.statusCode
    );
  }
  if (response.statusText) {
    event.node.res.statusMessage = sanitizeStatusMessage(response.statusText);
  }
  if (response.redirected) {
    event.node.res.setHeader("location", response.url);
  }
  if (!response.body) {
    event.node.res.end();
    return;
  }
  return sendStream(event, response.body);
}
async function proxyRequest(event, target, opts = {}) {
  let body;
  let duplex;
  if (PayloadMethods.has(event.method)) {
    if (opts.streamRequest) {
      body = getRequestWebStream(event);
      duplex = "half";
    } else {
      body = await readRawBody(event, false).catch(() => void 0);
    }
  }
  const method = opts.fetchOptions?.method || event.method;
  const fetchHeaders = mergeHeaders$1(
    getProxyRequestHeaders(event),
    opts.fetchOptions?.headers,
    opts.headers
  );
  return sendProxy(event, target, {
    ...opts,
    fetchOptions: {
      method,
      body,
      duplex,
      ...opts.fetchOptions,
      headers: fetchHeaders
    }
  });
}
async function sendProxy(event, target, opts = {}) {
  let response;
  try {
    response = await _getFetch(opts.fetch)(target, {
      headers: opts.headers,
      ignoreResponseError: true,
      // make $ofetch.raw transparent
      ...opts.fetchOptions
    });
  } catch (error2) {
    throw createError$1({
      status: 502,
      statusMessage: "Bad Gateway",
      cause: error2
    });
  }
  event.node.res.statusCode = sanitizeStatusCode(
    response.status,
    event.node.res.statusCode
  );
  event.node.res.statusMessage = sanitizeStatusMessage(response.statusText);
  const cookies = [];
  for (const [key, value] of response.headers.entries()) {
    if (key === "content-encoding") {
      continue;
    }
    if (key === "content-length") {
      continue;
    }
    if (key === "set-cookie") {
      cookies.push(...splitCookiesString(value));
      continue;
    }
    event.node.res.setHeader(key, value);
  }
  if (cookies.length > 0) {
    event.node.res.setHeader(
      "set-cookie",
      cookies.map((cookie) => {
        if (opts.cookieDomainRewrite) {
          cookie = rewriteCookieProperty(
            cookie,
            opts.cookieDomainRewrite,
            "domain"
          );
        }
        if (opts.cookiePathRewrite) {
          cookie = rewriteCookieProperty(
            cookie,
            opts.cookiePathRewrite,
            "path"
          );
        }
        return cookie;
      })
    );
  }
  if (opts.onResponse) {
    await opts.onResponse(event, response);
  }
  if (response._data !== void 0) {
    return response._data;
  }
  if (event.handled) {
    return;
  }
  if (opts.sendStream === false) {
    const data = new Uint8Array(await response.arrayBuffer());
    return event.node.res.end(data);
  }
  if (response.body) {
    for await (const chunk of response.body) {
      event.node.res.write(chunk);
    }
  }
  return event.node.res.end();
}
function getProxyRequestHeaders(event) {
  const headers = /* @__PURE__ */ Object.create(null);
  const reqHeaders = getRequestHeaders(event);
  for (const name in reqHeaders) {
    if (!ignoredHeaders.has(name)) {
      headers[name] = reqHeaders[name];
    }
  }
  return headers;
}
function fetchWithEvent(event, req, init, options) {
  return _getFetch(options?.fetch)(req, {
    ...init,
    context: init?.context || event.context,
    headers: {
      ...getProxyRequestHeaders(event),
      ...init?.headers
    }
  });
}
function _getFetch(_fetch) {
  if (_fetch) {
    return _fetch;
  }
  if (globalThis.fetch) {
    return globalThis.fetch;
  }
  throw new Error(
    "fetch is not available. Try importing `node-fetch-native/polyfill` for Node.js."
  );
}
function rewriteCookieProperty(header, map, property) {
  const _map = typeof map === "string" ? { "*": map } : map;
  return header.replace(
    new RegExp(`(;\\s*${property}=)([^;]+)`, "gi"),
    (match, prefix, previousValue) => {
      let newValue;
      if (previousValue in _map) {
        newValue = _map[previousValue];
      } else if ("*" in _map) {
        newValue = _map["*"];
      } else {
        return match;
      }
      return newValue ? prefix + newValue : "";
    }
  );
}
function mergeHeaders$1(defaults2, ...inputs) {
  const _inputs = inputs.filter(Boolean);
  if (_inputs.length === 0) {
    return defaults2;
  }
  const merged = new Headers(defaults2);
  for (const input of _inputs) {
    for (const [key, value] of Object.entries(input)) {
      if (value !== void 0) {
        merged.set(key, value);
      }
    }
  }
  return merged;
}
function isEvent(input) {
  return hasProp(input, "__is_event__");
}
function createEvent(req, res) {
  return new H3Event(req, res);
}
function _normalizeNodeHeaders(nodeHeaders) {
  const headers = new Headers();
  for (const [name, value] of Object.entries(nodeHeaders)) {
    if (Array.isArray(value)) {
      for (const item of value) {
        headers.append(name, item);
      }
    } else if (value) {
      headers.set(name, value);
    }
  }
  return headers;
}
function defineEventHandler(handler2) {
  if (typeof handler2 === "function") {
    handler2.__is_handler__ = true;
    return handler2;
  }
  const _hooks = {
    onRequest: _normalizeArray(handler2.onRequest),
    onBeforeResponse: _normalizeArray(handler2.onBeforeResponse)
  };
  const _handler = (event) => {
    return _callHandler(event, handler2.handler, _hooks);
  };
  _handler.__is_handler__ = true;
  _handler.__resolve__ = handler2.handler.__resolve__;
  _handler.__websocket__ = handler2.websocket;
  return _handler;
}
function _normalizeArray(input) {
  return input ? Array.isArray(input) ? input : [input] : void 0;
}
async function _callHandler(event, handler2, hooks) {
  if (hooks.onRequest) {
    for (const hook of hooks.onRequest) {
      await hook(event);
      if (event.handled) {
        return;
      }
    }
  }
  const body = await handler2(event);
  const response = { body };
  if (hooks.onBeforeResponse) {
    for (const hook of hooks.onBeforeResponse) {
      await hook(event, response);
    }
  }
  return response.body;
}
function isEventHandler(input) {
  return hasProp(input, "__is_handler__");
}
function toEventHandler(input, _, _route) {
  if (!isEventHandler(input)) {
    console.warn(
      "[h3] Implicit event handler conversion is deprecated. Use `eventHandler()` or `fromNodeMiddleware()` to define event handlers.",
      _route && _route !== "/" ? `
     Route: ${_route}` : "",
      `
     Handler: ${input}`
    );
  }
  return input;
}
function defineLazyEventHandler(factory) {
  let _promise;
  let _resolved;
  const resolveHandler = () => {
    if (_resolved) {
      return Promise.resolve(_resolved);
    }
    if (!_promise) {
      _promise = Promise.resolve(factory()).then((r) => {
        const handler22 = r.default || r;
        if (typeof handler22 !== "function") {
          throw new TypeError(
            "Invalid lazy handler result. It should be a function:",
            handler22
          );
        }
        _resolved = { handler: toEventHandler(r.default || r) };
        return _resolved;
      });
    }
    return _promise;
  };
  const handler2 = eventHandler((event) => {
    if (_resolved) {
      return _resolved.handler(event);
    }
    return resolveHandler().then((r) => r.handler(event));
  });
  handler2.__resolve__ = resolveHandler;
  return handler2;
}
function createApp2(options = {}) {
  const stack = [];
  const handler2 = createAppEventHandler(stack, options);
  const resolve2 = createResolver(stack);
  handler2.__resolve__ = resolve2;
  const getWebsocket = cachedFn(() => websocketOptions(resolve2, options));
  const app = {
    // @ts-expect-error
    use: (arg1, arg2, arg3) => use(app, arg1, arg2, arg3),
    resolve: resolve2,
    handler: handler2,
    stack,
    options,
    get websocket() {
      return getWebsocket();
    }
  };
  return app;
}
function use(app, arg1, arg2, arg3) {
  if (Array.isArray(arg1)) {
    for (const i2 of arg1) {
      use(app, i2, arg2, arg3);
    }
  } else if (Array.isArray(arg2)) {
    for (const i2 of arg2) {
      use(app, arg1, i2, arg3);
    }
  } else if (typeof arg1 === "string") {
    app.stack.push(
      normalizeLayer({ ...arg3, route: arg1, handler: arg2 })
    );
  } else if (typeof arg1 === "function") {
    app.stack.push(normalizeLayer({ ...arg2, handler: arg1 }));
  } else {
    app.stack.push(normalizeLayer({ ...arg1 }));
  }
  return app;
}
function createAppEventHandler(stack, options) {
  const spacing = options.debug ? 2 : void 0;
  return eventHandler(async (event) => {
    event.node.req.originalUrl = event.node.req.originalUrl || event.node.req.url || "/";
    const _reqPath = event._path || event.node.req.url || "/";
    let _layerPath;
    if (options.onRequest) {
      await options.onRequest(event);
    }
    for (const layer of stack) {
      if (layer.route.length > 1) {
        if (!_reqPath.startsWith(layer.route)) {
          continue;
        }
        _layerPath = _reqPath.slice(layer.route.length) || "/";
      } else {
        _layerPath = _reqPath;
      }
      if (layer.match && !layer.match(_layerPath, event)) {
        continue;
      }
      event._path = _layerPath;
      event.node.req.url = _layerPath;
      const val = await layer.handler(event);
      const _body = val === void 0 ? void 0 : await val;
      if (_body !== void 0) {
        const _response = { body: _body };
        if (options.onBeforeResponse) {
          event._onBeforeResponseCalled = true;
          await options.onBeforeResponse(event, _response);
        }
        await handleHandlerResponse(event, _response.body, spacing);
        if (options.onAfterResponse) {
          event._onAfterResponseCalled = true;
          await options.onAfterResponse(event, _response);
        }
        return;
      }
      if (event.handled) {
        if (options.onAfterResponse) {
          event._onAfterResponseCalled = true;
          await options.onAfterResponse(event, void 0);
        }
        return;
      }
    }
    if (!event.handled) {
      throw createError$1({
        statusCode: 404,
        statusMessage: `Cannot find any path matching ${event.path || "/"}.`
      });
    }
    if (options.onAfterResponse) {
      event._onAfterResponseCalled = true;
      await options.onAfterResponse(event, void 0);
    }
  });
}
function createResolver(stack) {
  return async (path) => {
    let _layerPath;
    for (const layer of stack) {
      if (layer.route === "/" && !layer.handler.__resolve__) {
        continue;
      }
      if (!path.startsWith(layer.route)) {
        continue;
      }
      _layerPath = path.slice(layer.route.length) || "/";
      if (layer.match && !layer.match(_layerPath, void 0)) {
        continue;
      }
      let res = { route: layer.route, handler: layer.handler };
      if (res.handler.__resolve__) {
        const _res = await res.handler.__resolve__(_layerPath);
        if (!_res) {
          continue;
        }
        res = {
          ...res,
          ..._res,
          route: joinURL(res.route || "/", _res.route || "/")
        };
      }
      return res;
    }
  };
}
function normalizeLayer(input) {
  let handler2 = input.handler;
  if (handler2.handler) {
    handler2 = handler2.handler;
  }
  if (input.lazy) {
    handler2 = lazyEventHandler(handler2);
  } else if (!isEventHandler(handler2)) {
    handler2 = toEventHandler(handler2, void 0, input.route);
  }
  return {
    route: withoutTrailingSlash(input.route),
    match: input.match,
    handler: handler2
  };
}
function handleHandlerResponse(event, val, jsonSpace) {
  if (val === null) {
    return sendNoContent(event);
  }
  if (val) {
    if (isWebResponse(val)) {
      return sendWebResponse(event, val);
    }
    if (isStream(val)) {
      return sendStream(event, val);
    }
    if (val.buffer) {
      return send(event, val);
    }
    if (val.arrayBuffer && typeof val.arrayBuffer === "function") {
      return val.arrayBuffer().then((arrayBuffer) => {
        return send(event, Buffer.from(arrayBuffer), val.type);
      });
    }
    if (val instanceof Error) {
      throw createError$1(val);
    }
    if (typeof val.end === "function") {
      return true;
    }
  }
  const valType = typeof val;
  if (valType === "string") {
    return send(event, val, MIMES.html);
  }
  if (valType === "object" || valType === "boolean" || valType === "number") {
    return send(event, JSON.stringify(val, void 0, jsonSpace), MIMES.json);
  }
  if (valType === "bigint") {
    return send(event, val.toString(), MIMES.json);
  }
  throw createError$1({
    statusCode: 500,
    statusMessage: `[h3] Cannot send ${valType} as response.`
  });
}
function cachedFn(fn) {
  let cache;
  return () => {
    if (!cache) {
      cache = fn();
    }
    return cache;
  };
}
function websocketOptions(evResolver, appOptions) {
  return {
    ...appOptions.websocket,
    async resolve(info) {
      const url = info.request?.url || info.url || "/";
      const { pathname } = typeof url === "string" ? parseURL(url) : url;
      const resolved = await evResolver(pathname);
      return resolved?.handler?.__websocket__ || {};
    }
  };
}
function createRouter2(opts = {}) {
  const _router = createRouter$1({});
  const routes = {};
  let _matcher;
  const router = {};
  const addRoute = (path, handler2, method) => {
    let route = routes[path];
    if (!route) {
      routes[path] = route = { path, handlers: {} };
      _router.insert(path, route);
    }
    if (Array.isArray(method)) {
      for (const m of method) {
        addRoute(path, handler2, m);
      }
    } else {
      route.handlers[method] = toEventHandler(handler2, void 0, path);
    }
    return router;
  };
  router.use = router.add = (path, handler2, method) => addRoute(path, handler2, method || "all");
  for (const method of RouterMethods) {
    router[method] = (path, handle) => router.add(path, handle, method);
  }
  const matchHandler = (path = "/", method = "get") => {
    const qIndex = path.indexOf("?");
    if (qIndex !== -1) {
      path = path.slice(0, Math.max(0, qIndex));
    }
    const matched = _router.lookup(path);
    if (!matched || !matched.handlers) {
      return {
        error: createError$1({
          statusCode: 404,
          name: "Not Found",
          statusMessage: `Cannot find any route matching ${path || "/"}.`
        })
      };
    }
    let handler2 = matched.handlers[method] || matched.handlers.all;
    if (!handler2) {
      if (!_matcher) {
        _matcher = toRouteMatcher(_router);
      }
      const _matches = _matcher.matchAll(path).reverse();
      for (const _match of _matches) {
        if (_match.handlers[method]) {
          handler2 = _match.handlers[method];
          matched.handlers[method] = matched.handlers[method] || handler2;
          break;
        }
        if (_match.handlers.all) {
          handler2 = _match.handlers.all;
          matched.handlers.all = matched.handlers.all || handler2;
          break;
        }
      }
    }
    if (!handler2) {
      return {
        error: createError$1({
          statusCode: 405,
          name: "Method Not Allowed",
          statusMessage: `Method ${method} is not allowed on this route.`
        })
      };
    }
    return { matched, handler: handler2 };
  };
  const isPreemptive = opts.preemptive || opts.preemtive;
  router.handler = eventHandler((event) => {
    const match = matchHandler(
      event.path,
      event.method.toLowerCase()
    );
    if ("error" in match) {
      if (isPreemptive) {
        throw match.error;
      } else {
        return;
      }
    }
    event.context.matchedRoute = match.matched;
    const params = match.matched.params || {};
    event.context.params = params;
    return Promise.resolve(match.handler(event)).then((res) => {
      if (res === void 0 && isPreemptive) {
        return null;
      }
      return res;
    });
  });
  router.handler.__resolve__ = async (path) => {
    path = withLeadingSlash(path);
    const match = matchHandler(path);
    if ("error" in match) {
      return;
    }
    let res = {
      route: match.matched.path,
      handler: match.handler
    };
    if (match.handler.__resolve__) {
      const _res = await match.handler.__resolve__(path);
      if (!_res) {
        return;
      }
      res = { ...res, ..._res };
    }
    return res;
  };
  return router;
}
function toNodeListener(app) {
  const toNodeHandle = async function(req, res) {
    const event = createEvent(req, res);
    try {
      await app.handler(event);
    } catch (_error) {
      const error2 = createError$1(_error);
      if (!isError(_error)) {
        error2.unhandled = true;
      }
      setResponseStatus(event, error2.statusCode, error2.statusMessage);
      if (app.options.onError) {
        await app.options.onError(error2, event);
      }
      if (event.handled) {
        return;
      }
      if (error2.unhandled || error2.fatal) {
        console.error("[h3]", error2.fatal ? "[fatal]" : "[unhandled]", error2);
      }
      if (app.options.onBeforeResponse && !event._onBeforeResponseCalled) {
        await app.options.onBeforeResponse(event, { body: error2 });
      }
      await sendError(event, error2, !!app.options.debug);
      if (app.options.onAfterResponse && !event._onAfterResponseCalled) {
        await app.options.onAfterResponse(event, { body: error2 });
      }
    }
  };
  return toNodeHandle;
}
function flatHooks(configHooks, hooks = {}, parentName) {
  for (const key in configHooks) {
    const subHook = configHooks[key];
    const name = parentName ? `${parentName}:${key}` : key;
    if (typeof subHook === "object" && subHook !== null) {
      flatHooks(subHook, hooks, name);
    } else if (typeof subHook === "function") {
      hooks[name] = subHook;
    }
  }
  return hooks;
}
function serialTaskCaller(hooks, args) {
  const name = args.shift();
  const task = createTask(name);
  return hooks.reduce(
    (promise, hookFunction) => promise.then(() => task.run(() => hookFunction(...args))),
    Promise.resolve()
  );
}
function parallelTaskCaller(hooks, args) {
  const name = args.shift();
  const task = createTask(name);
  return Promise.all(hooks.map((hook) => task.run(() => hook(...args))));
}
function callEachWith(callbacks, arg0) {
  for (const callback of [...callbacks]) {
    callback(arg0);
  }
}
function createHooks() {
  return new Hookable();
}
function createFetchError(ctx) {
  const errorMessage = ctx.error?.message || ctx.error?.toString() || "";
  const method = ctx.request?.method || ctx.options?.method || "GET";
  const url = ctx.request?.url || String(ctx.request) || "/";
  const requestStr = `[${method}] ${JSON.stringify(url)}`;
  const statusStr = ctx.response ? `${ctx.response.status} ${ctx.response.statusText}` : "<no response>";
  const message2 = `${requestStr}: ${statusStr}${errorMessage ? ` ${errorMessage}` : ""}`;
  const fetchError = new FetchError(
    message2,
    ctx.error ? { cause: ctx.error } : void 0
  );
  for (const key of ["request", "options", "response"]) {
    Object.defineProperty(fetchError, key, {
      get() {
        return ctx[key];
      }
    });
  }
  for (const [key, refKey] of [
    ["data", "_data"],
    ["status", "status"],
    ["statusCode", "status"],
    ["statusText", "statusText"],
    ["statusMessage", "statusText"]
  ]) {
    Object.defineProperty(fetchError, key, {
      get() {
        return ctx.response && ctx.response[refKey];
      }
    });
  }
  return fetchError;
}
function isPayloadMethod(method = "GET") {
  return payloadMethods.has(method.toUpperCase());
}
function isJSONSerializable(value) {
  if (value === void 0) {
    return false;
  }
  const t = typeof value;
  if (t === "string" || t === "number" || t === "boolean" || t === null) {
    return true;
  }
  if (t !== "object") {
    return false;
  }
  if (Array.isArray(value)) {
    return true;
  }
  if (value.buffer) {
    return false;
  }
  return value.constructor && value.constructor.name === "Object" || typeof value.toJSON === "function";
}
function detectResponseType(_contentType = "") {
  if (!_contentType) {
    return "json";
  }
  const contentType = _contentType.split(";").shift() || "";
  if (JSON_RE.test(contentType)) {
    return "json";
  }
  if (textTypes.has(contentType) || contentType.startsWith("text/")) {
    return "text";
  }
  return "blob";
}
function resolveFetchOptions(request, input, defaults2, Headers2) {
  const headers = mergeHeaders(
    input?.headers ?? request?.headers,
    defaults2?.headers,
    Headers2
  );
  let query;
  if (defaults2?.query || defaults2?.params || input?.params || input?.query) {
    query = {
      ...defaults2?.params,
      ...defaults2?.query,
      ...input?.params,
      ...input?.query
    };
  }
  return {
    ...defaults2,
    ...input,
    query,
    params: query,
    headers
  };
}
function mergeHeaders(input, defaults2, Headers2) {
  if (!defaults2) {
    return new Headers2(input);
  }
  const headers = new Headers2(defaults2);
  if (input) {
    for (const [key, value] of Symbol.iterator in input || Array.isArray(input) ? input : new Headers2(input)) {
      headers.set(key, value);
    }
  }
  return headers;
}
async function callHooks(context, hooks) {
  if (hooks) {
    if (Array.isArray(hooks)) {
      for (const hook of hooks) {
        await hook(context);
      }
    } else {
      await hooks(context);
    }
  }
}
function createFetch$1(globalOptions = {}) {
  const {
    fetch: fetch2 = globalThis.fetch,
    Headers: Headers2 = globalThis.Headers,
    AbortController: AbortController2 = globalThis.AbortController
  } = globalOptions;
  async function onError(context) {
    const isAbort = context.error && context.error.name === "AbortError" && !context.options.timeout || false;
    if (context.options.retry !== false && !isAbort) {
      let retries;
      if (typeof context.options.retry === "number") {
        retries = context.options.retry;
      } else {
        retries = isPayloadMethod(context.options.method) ? 0 : 1;
      }
      const responseCode = context.response && context.response.status || 500;
      if (retries > 0 && (Array.isArray(context.options.retryStatusCodes) ? context.options.retryStatusCodes.includes(responseCode) : retryStatusCodes.has(responseCode))) {
        const retryDelay = typeof context.options.retryDelay === "function" ? context.options.retryDelay(context) : context.options.retryDelay || 0;
        if (retryDelay > 0) {
          await new Promise((resolve2) => setTimeout(resolve2, retryDelay));
        }
        return $fetchRaw(context.request, {
          ...context.options,
          retry: retries - 1
        });
      }
    }
    const error2 = createFetchError(context);
    if (Error.captureStackTrace) {
      Error.captureStackTrace(error2, $fetchRaw);
    }
    throw error2;
  }
  const $fetchRaw = async function $fetchRaw2(_request, _options = {}) {
    const context = {
      request: _request,
      options: resolveFetchOptions(
        _request,
        _options,
        globalOptions.defaults,
        Headers2
      ),
      response: void 0,
      error: void 0
    };
    if (context.options.method) {
      context.options.method = context.options.method.toUpperCase();
    }
    if (context.options.onRequest) {
      await callHooks(context, context.options.onRequest);
    }
    if (typeof context.request === "string") {
      if (context.options.baseURL) {
        context.request = withBase(context.request, context.options.baseURL);
      }
      if (context.options.query) {
        context.request = withQuery(context.request, context.options.query);
        delete context.options.query;
      }
      if ("query" in context.options) {
        delete context.options.query;
      }
      if ("params" in context.options) {
        delete context.options.params;
      }
    }
    if (context.options.body && isPayloadMethod(context.options.method)) {
      if (isJSONSerializable(context.options.body)) {
        context.options.body = typeof context.options.body === "string" ? context.options.body : JSON.stringify(context.options.body);
        context.options.headers = new Headers2(context.options.headers || {});
        if (!context.options.headers.has("content-type")) {
          context.options.headers.set("content-type", "application/json");
        }
        if (!context.options.headers.has("accept")) {
          context.options.headers.set("accept", "application/json");
        }
      } else if (
        // ReadableStream Body
        "pipeTo" in context.options.body && typeof context.options.body.pipeTo === "function" || // Node.js Stream Body
        typeof context.options.body.pipe === "function"
      ) {
        if (!("duplex" in context.options)) {
          context.options.duplex = "half";
        }
      }
    }
    let abortTimeout;
    if (!context.options.signal && context.options.timeout) {
      const controller = new AbortController2();
      abortTimeout = setTimeout(() => {
        const error2 = new Error(
          "[TimeoutError]: The operation was aborted due to timeout"
        );
        error2.name = "TimeoutError";
        error2.code = 23;
        controller.abort(error2);
      }, context.options.timeout);
      context.options.signal = controller.signal;
    }
    try {
      context.response = await fetch2(
        context.request,
        context.options
      );
    } catch (error2) {
      context.error = error2;
      if (context.options.onRequestError) {
        await callHooks(
          context,
          context.options.onRequestError
        );
      }
      return await onError(context);
    } finally {
      if (abortTimeout) {
        clearTimeout(abortTimeout);
      }
    }
    const hasBody = (context.response.body || // https://github.com/unjs/ofetch/issues/324
    // https://github.com/unjs/ofetch/issues/294
    // https://github.com/JakeChampion/fetch/issues/1454
    context.response._bodyInit) && !nullBodyResponses$1.has(context.response.status) && context.options.method !== "HEAD";
    if (hasBody) {
      const responseType = (context.options.parseResponse ? "json" : context.options.responseType) || detectResponseType(context.response.headers.get("content-type") || "");
      switch (responseType) {
        case "json": {
          const data = await context.response.text();
          const parseFunction = context.options.parseResponse || destr;
          context.response._data = parseFunction(data);
          break;
        }
        case "stream": {
          context.response._data = context.response.body || context.response._bodyInit;
          break;
        }
        default: {
          context.response._data = await context.response[responseType]();
        }
      }
    }
    if (context.options.onResponse) {
      await callHooks(
        context,
        context.options.onResponse
      );
    }
    if (!context.options.ignoreResponseError && context.response.status >= 400 && context.response.status < 600) {
      if (context.options.onResponseError) {
        await callHooks(
          context,
          context.options.onResponseError
        );
      }
      return await onError(context);
    }
    return context.response;
  };
  const $fetch2 = async function $fetch22(request, options) {
    const r = await $fetchRaw(request, options);
    return r._data;
  };
  $fetch2.raw = $fetchRaw;
  $fetch2.native = (...args) => fetch2(...args);
  $fetch2.create = (defaultOptions = {}, customGlobalOptions = {}) => createFetch$1({
    ...globalOptions,
    ...customGlobalOptions,
    defaults: {
      ...globalOptions.defaults,
      ...customGlobalOptions.defaults,
      ...defaultOptions
    }
  });
  return $fetch2;
}
function createNodeFetch() {
  const useKeepAlive = JSON.parse(process2.env.FETCH_KEEP_ALIVE || "false");
  if (!useKeepAlive) {
    return l;
  }
  const agentOptions = { keepAlive: true };
  const httpAgent = new http.Agent(agentOptions);
  const httpsAgent = new https.Agent(agentOptions);
  const nodeFetchOptions = {
    agent(parsedURL) {
      return parsedURL.protocol === "http:" ? httpAgent : httpsAgent;
    }
  };
  return function nodeFetchWithKeepAlive(input, init) {
    return l(input, { ...nodeFetchOptions, ...init });
  };
}
function createCall(handle) {
  return function callHandle(context) {
    const req = new IncomingMessage();
    const res = new ServerResponse(req);
    req.url = context.url || "/";
    req.method = context.method || "GET";
    req.headers = {};
    if (context.headers) {
      const headerEntries = typeof context.headers.entries === "function" ? context.headers.entries() : Object.entries(context.headers);
      for (const [name, value] of headerEntries) {
        if (!value) {
          continue;
        }
        req.headers[name.toLowerCase()] = value;
      }
    }
    req.headers.host = req.headers.host || context.host || "localhost";
    req.connection.encrypted = // @ts-ignore
    req.connection.encrypted || context.protocol === "https";
    req.body = context.body || null;
    req.__unenv__ = context.context;
    return handle(req, res).then(() => {
      let body = res._data;
      if (nullBodyResponses.has(res.statusCode) || req.method.toUpperCase() === "HEAD") {
        body = null;
        delete res._headers["content-length"];
      }
      const r = {
        body,
        headers: res._headers,
        status: res.statusCode,
        statusText: res.statusMessage
      };
      req.destroy();
      res.destroy();
      return r;
    });
  };
}
function createFetch(call, _fetch = global.fetch) {
  return async function ufetch(input, init) {
    const url = input.toString();
    if (!url.startsWith("/")) {
      return _fetch(url, init);
    }
    try {
      const r = await call({ url, ...init });
      return new Response(r.body, {
        status: r.status,
        statusText: r.statusText,
        headers: Object.fromEntries(
          Object.entries(r.headers).map(([name, value]) => [
            name,
            Array.isArray(value) ? value.join(",") : String(value) || ""
          ])
        )
      });
    } catch (error2) {
      return new Response(error2.toString(), {
        status: Number.parseInt(error2.statusCode || error2.code) || 500,
        statusText: error2.statusText
      });
    }
  };
}
function hasReqHeader(event, name, includes) {
  const value = getRequestHeader(event, name);
  return value && typeof value === "string" && value.toLowerCase().includes(includes);
}
function isJsonRequest(event) {
  if (hasReqHeader(event, "accept", "text/html")) {
    return false;
  }
  return hasReqHeader(event, "accept", "application/json") || hasReqHeader(event, "user-agent", "curl/") || hasReqHeader(event, "user-agent", "httpie/") || hasReqHeader(event, "sec-fetch-mode", "cors") || event.path.startsWith("/api/") || event.path.endsWith(".json");
}
function normalizeError(error2, isDev) {
  const cwd = typeof process2.cwd === "function" ? process2.cwd() : "/";
  const stack = error2.unhandled || error2.fatal ? [] : (error2.stack || "").split("\n").splice(1).filter((line) => line.includes("at ")).map((line) => {
    const text = line.replace(cwd + "/", "./").replace("webpack:/", "").replace("file://", "").trim();
    return {
      text,
      internal: line.includes("node_modules") && !line.includes(".cache") || line.includes("internal") || line.includes("new Promise")
    };
  });
  const statusCode = error2.statusCode || 500;
  const statusMessage = error2.statusMessage ?? (statusCode === 404 ? "Not Found" : "");
  const message2 = error2.unhandled ? "internal server error" : error2.message || error2.toString();
  return {
    stack,
    statusCode,
    statusMessage,
    message: message2
  };
}
function joinHeaders(value) {
  return Array.isArray(value) ? value.join(", ") : String(value);
}
function normalizeFetchResponse(response) {
  if (!response.headers.has("set-cookie")) {
    return response;
  }
  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers: normalizeCookieHeaders(response.headers)
  });
}
function normalizeCookieHeader(header = "") {
  return splitCookiesString(joinHeaders(header));
}
function normalizeCookieHeaders(headers) {
  const outgoingHeaders = new Headers();
  for (const [name, header] of headers) {
    if (name === "set-cookie") {
      for (const cookie of normalizeCookieHeader(header)) {
        outgoingHeaders.append("set-cookie", cookie);
      }
    } else {
      outgoingHeaders.set(name, joinHeaders(header));
    }
  }
  return outgoingHeaders;
}
function klona(x) {
  if (typeof x !== "object")
    return x;
  var k, tmp, str = Object.prototype.toString.call(x);
  if (str === "[object Object]") {
    if (x.constructor !== Object && typeof x.constructor === "function") {
      tmp = new x.constructor();
      for (k in x) {
        if (x.hasOwnProperty(k) && tmp[k] !== x[k]) {
          tmp[k] = klona(x[k]);
        }
      }
    } else {
      tmp = {};
      for (k in x) {
        if (k === "__proto__") {
          Object.defineProperty(tmp, k, {
            value: klona(x[k]),
            configurable: true,
            enumerable: true,
            writable: true
          });
        } else {
          tmp[k] = klona(x[k]);
        }
      }
    }
    return tmp;
  }
  if (str === "[object Array]") {
    k = x.length;
    for (tmp = Array(k); k--; ) {
      tmp[k] = klona(x[k]);
    }
    return tmp;
  }
  if (str === "[object Set]") {
    tmp = /* @__PURE__ */ new Set();
    x.forEach(function(val) {
      tmp.add(klona(val));
    });
    return tmp;
  }
  if (str === "[object Map]") {
    tmp = /* @__PURE__ */ new Map();
    x.forEach(function(val, key) {
      tmp.set(klona(key), klona(val));
    });
    return tmp;
  }
  if (str === "[object Date]") {
    return /* @__PURE__ */ new Date(+x);
  }
  if (str === "[object RegExp]") {
    tmp = new RegExp(x.source, x.flags);
    tmp.lastIndex = x.lastIndex;
    return tmp;
  }
  if (str === "[object DataView]") {
    return new x.constructor(klona(x.buffer));
  }
  if (str === "[object ArrayBuffer]") {
    return x.slice(0);
  }
  if (str.slice(-6) === "Array]") {
    return new x.constructor(x);
  }
  return x;
}
function isUppercase(char = "") {
  if (NUMBER_CHAR_RE.test(char)) {
    return void 0;
  }
  return char !== char.toLowerCase();
}
function splitByCase(str, separators) {
  const splitters = STR_SPLITTERS;
  const parts = [];
  if (!str || typeof str !== "string") {
    return parts;
  }
  let buff = "";
  let previousUpper;
  let previousSplitter;
  for (const char of str) {
    const isSplitter = splitters.includes(char);
    if (isSplitter === true) {
      parts.push(buff);
      buff = "";
      previousUpper = void 0;
      continue;
    }
    const isUpper = isUppercase(char);
    if (previousSplitter === false) {
      if (previousUpper === false && isUpper === true) {
        parts.push(buff);
        buff = char;
        previousUpper = isUpper;
        continue;
      }
      if (previousUpper === true && isUpper === false && buff.length > 1) {
        const lastChar = buff.at(-1);
        parts.push(buff.slice(0, Math.max(0, buff.length - 1)));
        buff = lastChar + char;
        previousUpper = isUpper;
        continue;
      }
    }
    buff += char;
    previousUpper = isUpper;
    previousSplitter = isSplitter;
  }
  parts.push(buff);
  return parts;
}
function kebabCase(str, joiner) {
  return str ? (Array.isArray(str) ? str : splitByCase(str)).map((p) => p.toLowerCase()).join(joiner) : "";
}
function snakeCase(str) {
  return kebabCase(str || "", "_");
}
function getEnv(key, opts) {
  const envKey = snakeCase(key).toUpperCase();
  return destr(
    process2.env[opts.prefix + envKey] ?? process2.env[opts.altPrefix + envKey]
  );
}
function _isObject(input) {
  return typeof input === "object" && !Array.isArray(input);
}
function applyEnv(obj, opts, parentKey = "") {
  for (const key in obj) {
    const subKey = parentKey ? `${parentKey}_${key}` : key;
    const envValue = getEnv(subKey, opts);
    if (_isObject(obj[key])) {
      if (_isObject(envValue)) {
        obj[key] = { ...obj[key], ...envValue };
        applyEnv(obj[key], opts, subKey);
      } else if (envValue === void 0) {
        applyEnv(obj[key], opts, subKey);
      } else {
        obj[key] = envValue ?? obj[key];
      }
    } else {
      obj[key] = envValue ?? obj[key];
    }
    if (opts.envExpansion && typeof obj[key] === "string") {
      obj[key] = _expandFromEnv(obj[key]);
    }
  }
  return obj;
}
function _expandFromEnv(value) {
  return value.replace(envExpandRx, (match, key) => {
    return process2.env[key] || match;
  });
}
function useRuntimeConfig2(event) {
  if (!event) {
    return _sharedRuntimeConfig;
  }
  if (event.context.nitro.runtimeConfig) {
    return event.context.nitro.runtimeConfig;
  }
  const runtimeConfig = klona(_inlineRuntimeConfig);
  applyEnv(runtimeConfig, envOptions);
  event.context.nitro.runtimeConfig = runtimeConfig;
  return runtimeConfig;
}
function useAppConfig(event) {
  if (!event) {
    return _sharedAppConfig;
  }
  if (event.context.nitro.appConfig) {
    return event.context.nitro.appConfig;
  }
  const appConfig$1 = klona(appConfig);
  event.context.nitro.appConfig = appConfig$1;
  return appConfig$1;
}
function _deepFreeze(object) {
  const propNames = Object.getOwnPropertyNames(object);
  for (const name of propNames) {
    const value = object[name];
    if (value && typeof value === "object") {
      _deepFreeze(value);
    }
  }
  return Object.freeze(object);
}
function defineNitroPlugin(def) {
  return def;
}
function wrapToPromise(value) {
  if (!value || typeof value.then !== "function") {
    return Promise.resolve(value);
  }
  return value;
}
function asyncCall(function_, ...arguments_) {
  try {
    return wrapToPromise(function_(...arguments_));
  } catch (error2) {
    return Promise.reject(error2);
  }
}
function isPrimitive$1(value) {
  const type = typeof value;
  return value === null || type !== "object" && type !== "function";
}
function isPureObject(value) {
  const proto = Object.getPrototypeOf(value);
  return !proto || proto.isPrototypeOf(Object);
}
function stringify2(value) {
  if (isPrimitive$1(value)) {
    return String(value);
  }
  if (isPureObject(value) || Array.isArray(value)) {
    return JSON.stringify(value);
  }
  if (typeof value.toJSON === "function") {
    return stringify2(value.toJSON());
  }
  throw new Error("[unstorage] Cannot stringify value!");
}
function checkBufferSupport() {
  if (typeof Buffer === "undefined") {
    throw new TypeError("[unstorage] Buffer is not supported!");
  }
}
function serializeRaw(value) {
  if (typeof value === "string") {
    return value;
  }
  checkBufferSupport();
  const base64 = Buffer.from(value).toString("base64");
  return BASE64_PREFIX + base64;
}
function deserializeRaw(value) {
  if (typeof value !== "string") {
    return value;
  }
  if (!value.startsWith(BASE64_PREFIX)) {
    return value;
  }
  checkBufferSupport();
  return Buffer.from(value.slice(BASE64_PREFIX.length), "base64");
}
function prefixStorage(storage2, base) {
  base = normalizeBaseKey(base);
  if (!base) {
    return storage2;
  }
  const nsStorage = { ...storage2 };
  for (const property of storageKeyProperties) {
    nsStorage[property] = (key = "", ...args) => (
      // @ts-ignore
      storage2[property](base + key, ...args)
    );
  }
  nsStorage.getKeys = (key = "", ...arguments_) => storage2.getKeys(base + key, ...arguments_).then((keys) => keys.map((key2) => key2.slice(base.length)));
  return nsStorage;
}
function normalizeKey$1(key) {
  if (!key) {
    return "";
  }
  return key.split("?")[0].replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "");
}
function joinKeys(...keys) {
  return normalizeKey$1(keys.join(":"));
}
function normalizeBaseKey(base) {
  base = normalizeKey$1(base);
  return base ? base + ":" : "";
}
function defineDriver$1(factory) {
  return factory;
}
function createStorage(options = {}) {
  const context = {
    mounts: { "": options.driver || memory() },
    mountpoints: [""],
    watching: false,
    watchListeners: [],
    unwatch: {}
  };
  const getMount = (key) => {
    for (const base of context.mountpoints) {
      if (key.startsWith(base)) {
        return {
          base,
          relativeKey: key.slice(base.length),
          driver: context.mounts[base]
        };
      }
    }
    return {
      base: "",
      relativeKey: key,
      driver: context.mounts[""]
    };
  };
  const getMounts = (base, includeParent) => {
    return context.mountpoints.filter(
      (mountpoint) => mountpoint.startsWith(base) || includeParent && base.startsWith(mountpoint)
    ).map((mountpoint) => ({
      relativeBase: base.length > mountpoint.length ? base.slice(mountpoint.length) : void 0,
      mountpoint,
      driver: context.mounts[mountpoint]
    }));
  };
  const onChange = (event, key) => {
    if (!context.watching) {
      return;
    }
    key = normalizeKey$1(key);
    for (const listener of context.watchListeners) {
      listener(event, key);
    }
  };
  const startWatch = async () => {
    if (context.watching) {
      return;
    }
    context.watching = true;
    for (const mountpoint in context.mounts) {
      context.unwatch[mountpoint] = await watch4(
        context.mounts[mountpoint],
        onChange,
        mountpoint
      );
    }
  };
  const stopWatch = async () => {
    if (!context.watching) {
      return;
    }
    for (const mountpoint in context.unwatch) {
      await context.unwatch[mountpoint]();
    }
    context.unwatch = {};
    context.watching = false;
  };
  const runBatch = (items, commonOptions, cb) => {
    const batches = /* @__PURE__ */ new Map();
    const getBatch = (mount) => {
      let batch = batches.get(mount.base);
      if (!batch) {
        batch = {
          driver: mount.driver,
          base: mount.base,
          items: []
        };
        batches.set(mount.base, batch);
      }
      return batch;
    };
    for (const item of items) {
      const isStringItem = typeof item === "string";
      const key = normalizeKey$1(isStringItem ? item : item.key);
      const value = isStringItem ? void 0 : item.value;
      const options2 = isStringItem || !item.options ? commonOptions : { ...commonOptions, ...item.options };
      const mount = getMount(key);
      getBatch(mount).items.push({
        key,
        value,
        relativeKey: mount.relativeKey,
        options: options2
      });
    }
    return Promise.all([...batches.values()].map((batch) => cb(batch))).then(
      (r) => r.flat()
    );
  };
  const storage2 = {
    // Item
    hasItem(key, opts = {}) {
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      return asyncCall(driver.hasItem, relativeKey, opts);
    },
    getItem(key, opts = {}) {
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      return asyncCall(driver.getItem, relativeKey, opts).then(
        (value) => destr(value)
      );
    },
    getItems(items, commonOptions) {
      return runBatch(items, commonOptions, (batch) => {
        if (batch.driver.getItems) {
          return asyncCall(
            batch.driver.getItems,
            batch.items.map((item) => ({
              key: item.relativeKey,
              options: item.options
            })),
            commonOptions
          ).then(
            (r) => r.map((item) => ({
              key: joinKeys(batch.base, item.key),
              value: destr(item.value)
            }))
          );
        }
        return Promise.all(
          batch.items.map((item) => {
            return asyncCall(
              batch.driver.getItem,
              item.relativeKey,
              item.options
            ).then((value) => ({
              key: item.key,
              value: destr(value)
            }));
          })
        );
      });
    },
    getItemRaw(key, opts = {}) {
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (driver.getItemRaw) {
        return asyncCall(driver.getItemRaw, relativeKey, opts);
      }
      return asyncCall(driver.getItem, relativeKey, opts).then(
        (value) => deserializeRaw(value)
      );
    },
    async setItem(key, value, opts = {}) {
      if (value === void 0) {
        return storage2.removeItem(key);
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (!driver.setItem) {
        return;
      }
      await asyncCall(driver.setItem, relativeKey, stringify2(value), opts);
      if (!driver.watch) {
        onChange("update", key);
      }
    },
    async setItems(items, commonOptions) {
      await runBatch(items, commonOptions, async (batch) => {
        if (batch.driver.setItems) {
          return asyncCall(
            batch.driver.setItems,
            batch.items.map((item) => ({
              key: item.relativeKey,
              value: stringify2(item.value),
              options: item.options
            })),
            commonOptions
          );
        }
        if (!batch.driver.setItem) {
          return;
        }
        await Promise.all(
          batch.items.map((item) => {
            return asyncCall(
              batch.driver.setItem,
              item.relativeKey,
              stringify2(item.value),
              item.options
            );
          })
        );
      });
    },
    async setItemRaw(key, value, opts = {}) {
      if (value === void 0) {
        return storage2.removeItem(key, opts);
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (driver.setItemRaw) {
        await asyncCall(driver.setItemRaw, relativeKey, value, opts);
      } else if (driver.setItem) {
        await asyncCall(driver.setItem, relativeKey, serializeRaw(value), opts);
      } else {
        return;
      }
      if (!driver.watch) {
        onChange("update", key);
      }
    },
    async removeItem(key, opts = {}) {
      if (typeof opts === "boolean") {
        opts = { removeMeta: opts };
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (!driver.removeItem) {
        return;
      }
      await asyncCall(driver.removeItem, relativeKey, opts);
      if (opts.removeMeta || opts.removeMata) {
        await asyncCall(driver.removeItem, relativeKey + "$", opts);
      }
      if (!driver.watch) {
        onChange("remove", key);
      }
    },
    // Meta
    async getMeta(key, opts = {}) {
      if (typeof opts === "boolean") {
        opts = { nativeOnly: opts };
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      const meta = /* @__PURE__ */ Object.create(null);
      if (driver.getMeta) {
        Object.assign(meta, await asyncCall(driver.getMeta, relativeKey, opts));
      }
      if (!opts.nativeOnly) {
        const value = await asyncCall(
          driver.getItem,
          relativeKey + "$",
          opts
        ).then((value_) => destr(value_));
        if (value && typeof value === "object") {
          if (typeof value.atime === "string") {
            value.atime = new Date(value.atime);
          }
          if (typeof value.mtime === "string") {
            value.mtime = new Date(value.mtime);
          }
          Object.assign(meta, value);
        }
      }
      return meta;
    },
    setMeta(key, value, opts = {}) {
      return this.setItem(key + "$", value, opts);
    },
    removeMeta(key, opts = {}) {
      return this.removeItem(key + "$", opts);
    },
    // Keys
    async getKeys(base, opts = {}) {
      base = normalizeBaseKey(base);
      const mounts = getMounts(base, true);
      let maskedMounts = [];
      const allKeys = [];
      for (const mount of mounts) {
        const rawKeys = await asyncCall(
          mount.driver.getKeys,
          mount.relativeBase,
          opts
        );
        for (const key of rawKeys) {
          const fullKey = mount.mountpoint + normalizeKey$1(key);
          if (!maskedMounts.some((p) => fullKey.startsWith(p))) {
            allKeys.push(fullKey);
          }
        }
        maskedMounts = [
          mount.mountpoint,
          ...maskedMounts.filter((p) => !p.startsWith(mount.mountpoint))
        ];
      }
      return base ? allKeys.filter(
        (key) => key.startsWith(base) && key[key.length - 1] !== "$"
      ) : allKeys.filter((key) => key[key.length - 1] !== "$");
    },
    // Utils
    async clear(base, opts = {}) {
      base = normalizeBaseKey(base);
      await Promise.all(
        getMounts(base, false).map(async (m) => {
          if (m.driver.clear) {
            return asyncCall(m.driver.clear, m.relativeBase, opts);
          }
          if (m.driver.removeItem) {
            const keys = await m.driver.getKeys(m.relativeBase || "", opts);
            return Promise.all(
              keys.map((key) => m.driver.removeItem(key, opts))
            );
          }
        })
      );
    },
    async dispose() {
      await Promise.all(
        Object.values(context.mounts).map((driver) => dispose(driver))
      );
    },
    async watch(callback) {
      await startWatch();
      context.watchListeners.push(callback);
      return async () => {
        context.watchListeners = context.watchListeners.filter(
          (listener) => listener !== callback
        );
        if (context.watchListeners.length === 0) {
          await stopWatch();
        }
      };
    },
    async unwatch() {
      context.watchListeners = [];
      await stopWatch();
    },
    // Mount
    mount(base, driver) {
      base = normalizeBaseKey(base);
      if (base && context.mounts[base]) {
        throw new Error(`already mounted at ${base}`);
      }
      if (base) {
        context.mountpoints.push(base);
        context.mountpoints.sort((a, b) => b.length - a.length);
      }
      context.mounts[base] = driver;
      if (context.watching) {
        Promise.resolve(watch4(driver, onChange, base)).then((unwatcher) => {
          context.unwatch[base] = unwatcher;
        }).catch(console.error);
      }
      return storage2;
    },
    async unmount(base, _dispose = true) {
      base = normalizeBaseKey(base);
      if (!base || !context.mounts[base]) {
        return;
      }
      if (context.watching && base in context.unwatch) {
        context.unwatch[base]();
        delete context.unwatch[base];
      }
      if (_dispose) {
        await dispose(context.mounts[base]);
      }
      context.mountpoints = context.mountpoints.filter((key) => key !== base);
      delete context.mounts[base];
    },
    getMount(key = "") {
      key = normalizeKey$1(key) + ":";
      const m = getMount(key);
      return {
        driver: m.driver,
        base: m.base
      };
    },
    getMounts(base = "", opts = {}) {
      base = normalizeKey$1(base);
      const mounts = getMounts(base, opts.parents);
      return mounts.map((m) => ({
        driver: m.driver,
        base: m.mountpoint
      }));
    },
    // Aliases
    keys: (base, opts = {}) => storage2.getKeys(base, opts),
    get: (key, opts = {}) => storage2.getItem(key, opts),
    set: (key, value, opts = {}) => storage2.setItem(key, value, opts),
    has: (key, opts = {}) => storage2.hasItem(key, opts),
    del: (key, opts = {}) => storage2.removeItem(key, opts),
    remove: (key, opts = {}) => storage2.removeItem(key, opts)
  };
  return storage2;
}
function watch4(driver, onChange, base) {
  return driver.watch ? driver.watch((event, key) => onChange(event, base + key)) : () => {
  };
}
async function dispose(driver) {
  if (typeof driver.dispose === "function") {
    await asyncCall(driver.dispose);
  }
}
function defineDriver(factory) {
  return factory;
}
function createError2(driver, message2, opts) {
  const err = new Error(`[unstorage] [${driver}] ${message2}`, opts);
  return err;
}
function createRequiredError(driver, name) {
  if (Array.isArray(name)) {
    return createError2(
      driver,
      `Missing some of the required options ${name.map((n) => "`" + n + "`").join(", ")}`
    );
  }
  return createError2(driver, `Missing required option \`${name}\`.`);
}
function ignoreNotfound(err) {
  return err.code === "ENOENT" || err.code === "EISDIR" ? null : err;
}
function ignoreExists(err) {
  return err.code === "EEXIST" ? null : err;
}
async function writeFile(path, data, encoding) {
  await ensuredir(dirname(path));
  return promises.writeFile(path, data, encoding);
}
function readFile(path, encoding) {
  return promises.readFile(path, encoding).catch(ignoreNotfound);
}
function unlink(path) {
  return promises.unlink(path).catch(ignoreNotfound);
}
function readdir(dir) {
  return promises.readdir(dir, { withFileTypes: true }).catch(ignoreNotfound).then((r) => r || []);
}
async function ensuredir(dir) {
  if (existsSync(dir)) {
    return;
  }
  await ensuredir(dirname(dir)).catch(ignoreExists);
  await promises.mkdir(dir).catch(ignoreExists);
}
async function readdirRecursive(dir, ignore) {
  if (ignore && ignore(dir)) {
    return [];
  }
  const entries = await readdir(dir);
  const files = [];
  await Promise.all(
    entries.map(async (entry2) => {
      const entryPath = resolve$1(dir, entry2.name);
      if (entry2.isDirectory()) {
        const dirFiles = await readdirRecursive(entryPath, ignore);
        files.push(...dirFiles.map((f) => entry2.name + "/" + f));
      } else {
        if (!(ignore && ignore(entry2.name))) {
          files.push(entry2.name);
        }
      }
    })
  );
  return files;
}
async function rmRecursive(dir) {
  const entries = await readdir(dir);
  await Promise.all(
    entries.map((entry2) => {
      const entryPath = resolve$1(dir, entry2.name);
      if (entry2.isDirectory()) {
        return rmRecursive(entryPath).then(() => promises.rmdir(entryPath));
      } else {
        return promises.unlink(entryPath);
      }
    })
  );
}
function useStorage(base = "") {
  return base ? prefixStorage(storage, base) : storage;
}
function defaultCacheOptions() {
  return {
    name: "_",
    base: "/cache",
    swr: true,
    maxAge: 1
  };
}
function defineCachedFunction(fn, opts = {}) {
  opts = { ...defaultCacheOptions(), ...opts };
  const pending = {};
  const group = opts.group || "nitro/functions";
  const name = opts.name || fn.name || "_";
  const integrity = opts.integrity || hash([fn, opts]);
  const validate2 = opts.validate || ((entry2) => entry2.value !== void 0);
  async function get2(key, resolver, shouldInvalidateCache, event) {
    const cacheKey = [opts.base, group, name, key + ".json"].filter(Boolean).join(":").replace(/:\/$/, ":index");
    let entry2 = await useStorage().getItem(cacheKey).catch((error2) => {
      console.error(`[nitro] [cache] Cache read error.`, error2);
      useNitroApp().captureError(error2, { event, tags: ["cache"] });
    }) || {};
    if (typeof entry2 !== "object") {
      entry2 = {};
      const error2 = new Error("Malformed data read from cache.");
      console.error("[nitro] [cache]", error2);
      useNitroApp().captureError(error2, { event, tags: ["cache"] });
    }
    const ttl = (opts.maxAge ?? 0) * 1e3;
    if (ttl) {
      entry2.expires = Date.now() + ttl;
    }
    const expired = shouldInvalidateCache || entry2.integrity !== integrity || ttl && Date.now() - (entry2.mtime || 0) > ttl || validate2(entry2) === false;
    const _resolve = async () => {
      const isPending = pending[key];
      if (!isPending) {
        if (entry2.value !== void 0 && (opts.staleMaxAge || 0) >= 0 && opts.swr === false) {
          entry2.value = void 0;
          entry2.integrity = void 0;
          entry2.mtime = void 0;
          entry2.expires = void 0;
        }
        pending[key] = Promise.resolve(resolver());
      }
      try {
        entry2.value = await pending[key];
      } catch (error2) {
        if (!isPending) {
          delete pending[key];
        }
        throw error2;
      }
      if (!isPending) {
        entry2.mtime = Date.now();
        entry2.integrity = integrity;
        delete pending[key];
        if (validate2(entry2) !== false) {
          let setOpts;
          if (opts.maxAge && !opts.swr) {
            setOpts = { ttl: opts.maxAge };
          }
          const promise = useStorage().setItem(cacheKey, entry2, setOpts).catch((error2) => {
            console.error(`[nitro] [cache] Cache write error.`, error2);
            useNitroApp().captureError(error2, { event, tags: ["cache"] });
          });
          if (event?.waitUntil) {
            event.waitUntil(promise);
          }
        }
      }
    };
    const _resolvePromise = expired ? _resolve() : Promise.resolve();
    if (entry2.value === void 0) {
      await _resolvePromise;
    } else if (expired && event && event.waitUntil) {
      event.waitUntil(_resolvePromise);
    }
    if (opts.swr && validate2(entry2) !== false) {
      _resolvePromise.catch((error2) => {
        console.error(`[nitro] [cache] SWR handler error.`, error2);
        useNitroApp().captureError(error2, { event, tags: ["cache"] });
      });
      return entry2;
    }
    return _resolvePromise.then(() => entry2);
  }
  return async (...args) => {
    const shouldBypassCache = await opts.shouldBypassCache?.(...args);
    if (shouldBypassCache) {
      return fn(...args);
    }
    const key = await (opts.getKey || getKey)(...args);
    const shouldInvalidateCache = await opts.shouldInvalidateCache?.(...args);
    const entry2 = await get2(
      key,
      () => fn(...args),
      shouldInvalidateCache,
      args[0] && isEvent(args[0]) ? args[0] : void 0
    );
    let value = entry2.value;
    if (opts.transform) {
      value = await opts.transform(entry2, ...args) || value;
    }
    return value;
  };
}
function cachedFunction(fn, opts = {}) {
  return defineCachedFunction(fn, opts);
}
function getKey(...args) {
  return args.length > 0 ? hash(args, {}) : "";
}
function escapeKey(key) {
  return String(key).replace(/\W/g, "");
}
function defineCachedEventHandler(handler2, opts = defaultCacheOptions()) {
  const variableHeaderNames = (opts.varies || []).filter(Boolean).map((h3) => h3.toLowerCase()).sort();
  const _opts = {
    ...opts,
    getKey: async (event) => {
      const customKey = await opts.getKey?.(event);
      if (customKey) {
        return escapeKey(customKey);
      }
      const _path = event.node.req.originalUrl || event.node.req.url || event.path;
      let _pathname;
      try {
        _pathname = escapeKey(decodeURI(parseURL(_path).pathname)).slice(0, 16) || "index";
      } catch {
        _pathname = "-";
      }
      const _hashedPath = `${_pathname}.${hash(_path)}`;
      const _headers = variableHeaderNames.map((header) => [header, event.node.req.headers[header]]).map(([name, value]) => `${escapeKey(name)}.${hash(value)}`);
      return [_hashedPath, ..._headers].join(":");
    },
    validate: (entry2) => {
      if (!entry2.value) {
        return false;
      }
      if (entry2.value.code >= 400) {
        return false;
      }
      if (entry2.value.body === void 0) {
        return false;
      }
      if (entry2.value.headers.etag === "undefined" || entry2.value.headers["last-modified"] === "undefined") {
        return false;
      }
      return true;
    },
    group: opts.group || "nitro/handlers",
    integrity: opts.integrity || hash([handler2, opts])
  };
  const _cachedHandler = cachedFunction(
    async (incomingEvent) => {
      const variableHeaders = {};
      for (const header of variableHeaderNames) {
        const value = incomingEvent.node.req.headers[header];
        if (value !== void 0) {
          variableHeaders[header] = value;
        }
      }
      const reqProxy = cloneWithProxy(incomingEvent.node.req, {
        headers: variableHeaders
      });
      const resHeaders = {};
      let _resSendBody;
      const resProxy = cloneWithProxy(incomingEvent.node.res, {
        statusCode: 200,
        writableEnded: false,
        writableFinished: false,
        headersSent: false,
        closed: false,
        getHeader(name) {
          return resHeaders[name];
        },
        setHeader(name, value) {
          resHeaders[name] = value;
          return this;
        },
        getHeaderNames() {
          return Object.keys(resHeaders);
        },
        hasHeader(name) {
          return name in resHeaders;
        },
        removeHeader(name) {
          delete resHeaders[name];
        },
        getHeaders() {
          return resHeaders;
        },
        end(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2();
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return this;
        },
        write(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2(void 0);
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return true;
        },
        writeHead(statusCode, headers2) {
          this.statusCode = statusCode;
          if (headers2) {
            if (Array.isArray(headers2) || typeof headers2 === "string") {
              throw new TypeError("Raw headers  is not supported.");
            }
            for (const header in headers2) {
              const value = headers2[header];
              if (value !== void 0) {
                this.setHeader(
                  header,
                  value
                );
              }
            }
          }
          return this;
        }
      });
      const event = createEvent(reqProxy, resProxy);
      event.fetch = (url, fetchOptions) => fetchWithEvent(event, url, fetchOptions, {
        fetch: useNitroApp().localFetch
      });
      event.$fetch = (url, fetchOptions) => fetchWithEvent(event, url, fetchOptions, {
        fetch: globalThis.$fetch
      });
      event.context = incomingEvent.context;
      event.context.cache = {
        options: _opts
      };
      const body = await handler2(event) || _resSendBody;
      const headers = event.node.res.getHeaders();
      headers.etag = String(
        headers.Etag || headers.etag || `W/"${hash(body)}"`
      );
      headers["last-modified"] = String(
        headers["Last-Modified"] || headers["last-modified"] || (/* @__PURE__ */ new Date()).toUTCString()
      );
      const cacheControl = [];
      if (opts.swr) {
        if (opts.maxAge) {
          cacheControl.push(`s-maxage=${opts.maxAge}`);
        }
        if (opts.staleMaxAge) {
          cacheControl.push(`stale-while-revalidate=${opts.staleMaxAge}`);
        } else {
          cacheControl.push("stale-while-revalidate");
        }
      } else if (opts.maxAge) {
        cacheControl.push(`max-age=${opts.maxAge}`);
      }
      if (cacheControl.length > 0) {
        headers["cache-control"] = cacheControl.join(", ");
      }
      const cacheEntry = {
        code: event.node.res.statusCode,
        headers,
        body
      };
      return cacheEntry;
    },
    _opts
  );
  return defineEventHandler(async (event) => {
    if (opts.headersOnly) {
      if (handleCacheHeaders(event, { maxAge: opts.maxAge })) {
        return;
      }
      return handler2(event);
    }
    const response = await _cachedHandler(
      event
    );
    if (event.node.res.headersSent || event.node.res.writableEnded) {
      return response.body;
    }
    if (handleCacheHeaders(event, {
      modifiedTime: new Date(response.headers["last-modified"]),
      etag: response.headers.etag,
      maxAge: opts.maxAge
    })) {
      return;
    }
    event.node.res.statusCode = response.code;
    for (const name in response.headers) {
      const value = response.headers[name];
      if (name === "set-cookie") {
        event.node.res.appendHeader(
          name,
          splitCookiesString(value)
        );
      } else {
        if (value !== void 0) {
          event.node.res.setHeader(name, value);
        }
      }
    }
    return response.body;
  });
}
function cloneWithProxy(obj, overrides) {
  return new Proxy(obj, {
    get(target, property, receiver) {
      if (property in overrides) {
        return overrides[property];
      }
      return Reflect.get(target, property, receiver);
    },
    set(target, property, value, receiver) {
      if (property in overrides) {
        overrides[property] = value;
        return true;
      }
      return Reflect.set(target, property, value, receiver);
    }
  });
}
function defineRenderHandler(render) {
  const runtimeConfig = useRuntimeConfig2();
  return eventHandler(async (event) => {
    const nitroApp3 = useNitroApp();
    const ctx = { event, render, response: void 0 };
    await nitroApp3.hooks.callHook("render:before", ctx);
    if (!ctx.response) {
      if (event.path === `${runtimeConfig.app.baseURL}favicon.ico`) {
        setResponseHeader(event, "Content-Type", "image/x-icon");
        return send(
          event,
          "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
        );
      }
      ctx.response = await ctx.render(event);
      if (!ctx.response) {
        const _currentStatus = getResponseStatus(event);
        setResponseStatus(event, _currentStatus === 200 ? 500 : _currentStatus);
        return send(
          event,
          "No response returned from render handler: " + event.path
        );
      }
    }
    await nitroApp3.hooks.callHook("render:response", ctx.response, ctx);
    if (ctx.response.headers) {
      setResponseHeaders(event, ctx.response.headers);
    }
    if (ctx.response.statusCode || ctx.response.statusMessage) {
      setResponseStatus(
        event,
        ctx.response.statusCode,
        ctx.response.statusMessage
      );
    }
    return ctx.response.body;
  });
}
function createRouteRulesHandler(ctx) {
  return eventHandler((event) => {
    const routeRules = getRouteRules2(event);
    if (routeRules.headers) {
      setHeaders(event, routeRules.headers);
    }
    if (routeRules.redirect) {
      let target = routeRules.redirect.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.redirect._redirectStripBase;
        if (strpBase) {
          targetPath = withoutBase(targetPath, strpBase);
        }
        target = joinURL(target.slice(0, -3), targetPath);
      } else if (event.path.includes("?")) {
        const query = getQuery$1(event.path);
        target = withQuery(target, query);
      }
      return sendRedirect(event, target, routeRules.redirect.statusCode);
    }
    if (routeRules.proxy) {
      let target = routeRules.proxy.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.proxy._proxyStripBase;
        if (strpBase) {
          targetPath = withoutBase(targetPath, strpBase);
        }
        target = joinURL(target.slice(0, -3), targetPath);
      } else if (event.path.includes("?")) {
        const query = getQuery$1(event.path);
        target = withQuery(target, query);
      }
      return proxyRequest(event, target, {
        fetch: ctx.localFetch,
        ...routeRules.proxy
      });
    }
  });
}
function getRouteRules2(event) {
  event.context._nitro = event.context._nitro || {};
  if (!event.context._nitro.routeRules) {
    event.context._nitro.routeRules = getRouteRulesForPath(
      withoutBase(event.path.split("?")[0], useRuntimeConfig2().app.baseURL)
    );
  }
  return event.context._nitro.routeRules;
}
function getRouteRulesForPath(path) {
  return defu({}, ..._routeRulesMatcher.matchAll(path).reverse());
}
function createContext2(opts = {}) {
  let currentInstance;
  let isSingleton = false;
  const checkConflict = (instance6) => {
    if (currentInstance && currentInstance !== instance6) {
      throw new Error("Context conflict");
    }
  };
  let als;
  if (opts.asyncContext) {
    const _AsyncLocalStorage = opts.AsyncLocalStorage || globalThis.AsyncLocalStorage;
    if (_AsyncLocalStorage) {
      als = new _AsyncLocalStorage();
    } else {
      console.warn("[unctx] `AsyncLocalStorage` is not provided.");
    }
  }
  const _getCurrentInstance = () => {
    if (als && currentInstance === void 0) {
      const instance6 = als.getStore();
      if (instance6 !== void 0) {
        return instance6;
      }
    }
    return currentInstance;
  };
  return {
    use: () => {
      const _instance = _getCurrentInstance();
      if (_instance === void 0) {
        throw new Error("Context is not available");
      }
      return _instance;
    },
    tryUse: () => {
      return _getCurrentInstance();
    },
    set: (instance6, replace) => {
      if (!replace) {
        checkConflict(instance6);
      }
      currentInstance = instance6;
      isSingleton = true;
    },
    unset: () => {
      currentInstance = void 0;
      isSingleton = false;
    },
    call: (instance6, callback) => {
      checkConflict(instance6);
      currentInstance = instance6;
      try {
        return als ? als.run(instance6, callback) : callback();
      } finally {
        if (!isSingleton) {
          currentInstance = void 0;
        }
      }
    },
    async callAsync(instance6, callback) {
      currentInstance = instance6;
      const onRestore = () => {
        currentInstance = instance6;
      };
      const onLeave = () => currentInstance === instance6 ? onRestore : void 0;
      asyncHandlers2.add(onLeave);
      try {
        const r = als ? als.run(instance6, callback) : callback();
        if (!isSingleton) {
          currentInstance = void 0;
        }
        return await r;
      } finally {
        asyncHandlers2.delete(onLeave);
      }
    }
  };
}
function createNamespace2(defaultOpts = {}) {
  const contexts = {};
  return {
    get(key, opts = {}) {
      if (!contexts[key]) {
        contexts[key] = createContext2({ ...defaultOpts, ...opts });
      }
      contexts[key];
      return contexts[key];
    }
  };
}
function baseURL() {
  return useRuntimeConfig2().app.baseURL;
}
function buildAssetsDir() {
  return useRuntimeConfig2().app.buildAssetsDir;
}
function buildAssetsURL(...path) {
  return joinRelativeURL(publicAssetsURL(), buildAssetsDir(), ...path);
}
function publicAssetsURL(...path) {
  const app = useRuntimeConfig2().app;
  const publicBase = app.cdnURL || app.baseURL;
  return path.length ? joinRelativeURL(publicBase, ...path) : publicBase;
}
function normalizeSiteConfig(config3) {
  if (typeof config3.indexable !== "undefined")
    config3.indexable = String(config3.indexable) !== "false";
  if (typeof config3.trailingSlash !== "undefined" && !config3.trailingSlash)
    config3.trailingSlash = String(config3.trailingSlash) !== "false";
  if (config3.url && !hasProtocol(config3.url, { acceptRelative: true, strict: false }))
    config3.url = withHttps(config3.url);
  const keys = Object.keys(config3).sort((a, b) => a.localeCompare(b));
  const newConfig = {};
  for (const k of keys)
    newConfig[k] = config3[k];
  return newConfig;
}
function createSiteConfigStack(options) {
  const debug = options?.debug || false;
  const stack = [];
  function push(input) {
    if (!input || typeof input !== "object" || Object.keys(input).length === 0)
      return;
    if (!input._context && debug) {
      let lastFunctionName = new Error("tmp").stack?.split("\n")[2].split(" ")[5];
      if (lastFunctionName?.includes("/"))
        lastFunctionName = "anonymous";
      input._context = lastFunctionName;
    }
    const entry2 = {};
    for (const k in input) {
      const val = input[k];
      if (typeof val !== "undefined" && val !== "")
        entry2[k] = val;
    }
    if (Object.keys(entry2).filter((k) => !k.startsWith("_")).length > 0)
      stack.push(entry2);
  }
  function get2(options2) {
    const siteConfig = {};
    if (options2?.debug)
      siteConfig._context = {};
    for (const o in stack.sort((a, b) => (a._priority || 0) - (b._priority || 0))) {
      for (const k in stack[o]) {
        const key = k;
        const val = options2?.resolveRefs ? toValue2(stack[o][k]) : stack[o][k];
        if (!k.startsWith("_") && typeof val !== "undefined") {
          siteConfig[k] = val;
          if (options2?.debug)
            siteConfig._context[key] = stack[o]._context?.[key] || stack[o]._context || "anonymous";
        }
      }
    }
    return options2?.skipNormalize ? siteConfig : normalizeSiteConfig(siteConfig);
  }
  return {
    stack,
    push,
    get: get2
  };
}
function envSiteConfig(env) {
  return Object.fromEntries(Object.entries(env).filter(([k]) => k.startsWith("NUXT_SITE_") || k.startsWith("NUXT_PUBLIC_SITE_")).map(([k, v]) => [
    k.replace(/^NUXT_(PUBLIC_)?SITE_/, "").split("_").map((s2, i2) => i2 === 0 ? s2.toLowerCase() : s2[0].toUpperCase() + s2.slice(1).toLowerCase()).join(""),
    v
  ]));
}
function useNitroOrigin(e) {
  const cert = process2.env.NITRO_SSL_CERT;
  const key = process2.env.NITRO_SSL_KEY;
  let host = process2.env.NITRO_HOST || process2.env.HOST || false;
  let port = false;
  let protocol = cert && key || true ? "https" : "http";
  {
    host = getRequestHost(e, { xForwardedHost: true }) || host;
    protocol = getRequestProtocol(e, { xForwardedProto: true }) || protocol;
  }
  if (typeof host === "string" && host.includes(":")) {
    port = host.split(":").pop();
    host = host.split(":")[0];
  }
  port = port ? `:${port}` : "";
  return withTrailingSlash(`${protocol}://${host}${port}`);
}
function useSiteConfig(e, _options) {
  e.context.siteConfig = e.context.siteConfig || createSiteConfigStack();
  const options = defu(_options, useRuntimeConfig2(e)["nuxt-site-config"], { debug: false });
  return e.context.siteConfig.get(options);
}
function resolveSitePath(pathOrUrl, options) {
  let path = pathOrUrl;
  if (hasProtocol(pathOrUrl, { strict: false, acceptRelative: true })) {
    const parsed = parseURL(pathOrUrl);
    path = parsed.pathname;
  }
  const base = withLeadingSlash(options.base || "/");
  if (base !== "/" && path.startsWith(base)) {
    path = path.slice(base.length);
  }
  let origin = withoutTrailingSlash(options.absolute ? options.siteUrl : "");
  if (base !== "/" && origin.endsWith(base)) {
    origin = origin.slice(0, origin.indexOf(base));
  }
  const baseWithOrigin = options.withBase ? withBase(base, origin || "/") : origin;
  const resolvedUrl = withBase(path, baseWithOrigin);
  return path === "/" && !options.withBase ? withTrailingSlash(resolvedUrl) : fixSlashes(options.trailingSlash, resolvedUrl);
}
function isPathFile(path) {
  const lastSegment = path.split("/").pop();
  return !!(lastSegment || path).match(/\.[0-9a-z]+$/i)?.[0];
}
function fixSlashes(trailingSlash, pathOrUrl) {
  const $url = parseURL(pathOrUrl);
  if (isPathFile($url.pathname))
    return pathOrUrl;
  const fixedPath = trailingSlash ? withTrailingSlash($url.pathname) : withoutTrailingSlash($url.pathname);
  return `${$url.protocol ? `${$url.protocol}//` : ""}${$url.host || ""}${fixedPath}${$url.search || ""}${$url.hash || ""}`;
}
function createSitePathResolver(e, options = {}) {
  const siteConfig = useSiteConfig(e);
  const nitroOrigin = useNitroOrigin(e);
  const nuxtBase = useRuntimeConfig2(e).app.baseURL || "/";
  return (path) => {
    return resolveSitePath(path, {
      ...options,
      siteUrl: options.canonical !== false || false ? siteConfig.url : nitroOrigin,
      trailingSlash: siteConfig.trailingSlash,
      base: nuxtBase
    });
  };
}
function devalue(value) {
  const counts = /* @__PURE__ */ new Map();
  let logNum = 0;
  function log(message2) {
    if (logNum < 100) {
      console.warn(message2);
      logNum += 1;
    }
  }
  function walk(thing) {
    if (typeof thing === "function") {
      log(`Cannot stringify a function ${thing.name}`);
      return;
    }
    if (counts.has(thing)) {
      counts.set(thing, counts.get(thing) + 1);
      return;
    }
    counts.set(thing, 1);
    if (!isPrimitive(thing)) {
      const type = getType(thing);
      switch (type) {
        case "Number":
        case "String":
        case "Boolean":
        case "Date":
        case "RegExp":
          return;
        case "Array":
          thing.forEach(walk);
          break;
        case "Set":
        case "Map":
          Array.from(thing).forEach(walk);
          break;
        default:
          const proto = Object.getPrototypeOf(thing);
          if (proto !== Object.prototype && proto !== null && Object.getOwnPropertyNames(proto).sort().join("\0") !== objectProtoOwnPropertyNames) {
            if (typeof thing.toJSON !== "function") {
              log(`Cannot stringify arbitrary non-POJOs ${thing.constructor.name}`);
            }
          } else if (Object.getOwnPropertySymbols(thing).length > 0) {
            log(`Cannot stringify POJOs with symbolic keys ${Object.getOwnPropertySymbols(thing).map((symbol) => symbol.toString())}`);
          } else {
            Object.keys(thing).forEach((key) => walk(thing[key]));
          }
      }
    }
  }
  walk(value);
  const names = /* @__PURE__ */ new Map();
  Array.from(counts).filter((entry2) => entry2[1] > 1).sort((a, b) => b[1] - a[1]).forEach((entry2, i2) => {
    names.set(entry2[0], getName(i2));
  });
  function stringify3(thing) {
    if (names.has(thing)) {
      return names.get(thing);
    }
    if (isPrimitive(thing)) {
      return stringifyPrimitive(thing);
    }
    const type = getType(thing);
    switch (type) {
      case "Number":
      case "String":
      case "Boolean":
        return `Object(${stringify3(thing.valueOf())})`;
      case "RegExp":
        return thing.toString();
      case "Date":
        return `new Date(${thing.getTime()})`;
      case "Array":
        const members = thing.map((v, i2) => i2 in thing ? stringify3(v) : "");
        const tail = thing.length === 0 || thing.length - 1 in thing ? "" : ",";
        return `[${members.join(",")}${tail}]`;
      case "Set":
      case "Map":
        return `new ${type}([${Array.from(thing).map(stringify3).join(",")}])`;
      default:
        if (thing.toJSON) {
          let json = thing.toJSON();
          if (getType(json) === "String") {
            try {
              json = JSON.parse(json);
            } catch (e) {
            }
          }
          return stringify3(json);
        }
        if (Object.getPrototypeOf(thing) === null) {
          if (Object.keys(thing).length === 0) {
            return "Object.create(null)";
          }
          return `Object.create(null,{${Object.keys(thing).map((key) => `${safeKey(key)}:{writable:true,enumerable:true,value:${stringify3(thing[key])}}`).join(",")}})`;
        }
        return `{${Object.keys(thing).map((key) => `${safeKey(key)}:${stringify3(thing[key])}`).join(",")}}`;
    }
  }
  const str = stringify3(value);
  if (names.size) {
    const params = [];
    const statements = [];
    const values = [];
    names.forEach((name, thing) => {
      params.push(name);
      if (isPrimitive(thing)) {
        values.push(stringifyPrimitive(thing));
        return;
      }
      const type = getType(thing);
      switch (type) {
        case "Number":
        case "String":
        case "Boolean":
          values.push(`Object(${stringify3(thing.valueOf())})`);
          break;
        case "RegExp":
          values.push(thing.toString());
          break;
        case "Date":
          values.push(`new Date(${thing.getTime()})`);
          break;
        case "Array":
          values.push(`Array(${thing.length})`);
          thing.forEach((v, i2) => {
            statements.push(`${name}[${i2}]=${stringify3(v)}`);
          });
          break;
        case "Set":
          values.push("new Set");
          statements.push(`${name}.${Array.from(thing).map((v) => `add(${stringify3(v)})`).join(".")}`);
          break;
        case "Map":
          values.push("new Map");
          statements.push(`${name}.${Array.from(thing).map(([k, v]) => `set(${stringify3(k)}, ${stringify3(v)})`).join(".")}`);
          break;
        default:
          values.push(Object.getPrototypeOf(thing) === null ? "Object.create(null)" : "{}");
          Object.keys(thing).forEach((key) => {
            statements.push(`${name}${safeProp(key)}=${stringify3(thing[key])}`);
          });
      }
    });
    statements.push(`return ${str}`);
    return `(function(${params.join(",")}){${statements.join(";")}}(${values.join(",")}))`;
  } else {
    return str;
  }
}
function getName(num) {
  let name = "";
  do {
    name = chars[num % chars.length] + name;
    num = ~~(num / chars.length) - 1;
  } while (num >= 0);
  return reserved.test(name) ? `${name}0` : name;
}
function isPrimitive(thing) {
  return Object(thing) !== thing;
}
function stringifyPrimitive(thing) {
  if (typeof thing === "string") {
    return stringifyString(thing);
  }
  if (thing === void 0) {
    return "void 0";
  }
  if (thing === 0 && 1 / thing < 0) {
    return "-0";
  }
  const str = String(thing);
  if (typeof thing === "number") {
    return str.replace(/^(-)?0\./, "$1.");
  }
  return str;
}
function getType(thing) {
  return Object.prototype.toString.call(thing).slice(8, -1);
}
function escapeUnsafeChar(c) {
  return escaped[c] || c;
}
function escapeUnsafeChars(str) {
  return str.replace(unsafeChars, escapeUnsafeChar);
}
function safeKey(key) {
  return /^[_$a-zA-Z][_$a-zA-Z0-9]*$/.test(key) ? key : escapeUnsafeChars(JSON.stringify(key));
}
function safeProp(key) {
  return /^[_$a-zA-Z][_$a-zA-Z0-9]*$/.test(key) ? `.${key}` : `[${escapeUnsafeChars(JSON.stringify(key))}]`;
}
function stringifyString(str) {
  let result = '"';
  for (let i2 = 0; i2 < str.length; i2 += 1) {
    const char = str.charAt(i2);
    const code = char.charCodeAt(0);
    if (char === '"') {
      result += '\\"';
    } else if (char in escaped) {
      result += escaped[char];
    } else if (code >= 55296 && code <= 57343) {
      const next = str.charCodeAt(i2 + 1);
      if (code <= 56319 && (next >= 56320 && next <= 57343)) {
        result += char + str[++i2];
      } else {
        result += `\\u${code.toString(16).toUpperCase()}`;
      }
    } else {
      result += char;
    }
  }
  result += '"';
  return result;
}
function createConsola(options = {}) {
  return createConsola$1({
    reporters: [basicReporter],
    ...options
  });
}
function mergeOnKey(arr, key) {
  const res = {};
  arr.forEach((item) => {
    const k = item[key];
    res[k] = merger(item, res[k] || {});
  });
  return Object.values(res);
}
function splitForLocales(path, locales) {
  const prefix = withLeadingSlash(path).split("/")[1];
  if (locales.includes(prefix))
    return [prefix, path.replace(`/${prefix}`, "")];
  return [null, path];
}
function normalizeRuntimeFilters(input) {
  return (input || []).map((rule) => {
    if (rule instanceof RegExp || typeof rule === "string")
      return rule;
    const match = rule.regex.match(StringifiedRegExpPattern);
    if (match)
      return new RegExp(match[1], match[2]);
    return false;
  }).filter(Boolean);
}
function createPathFilter(options = {}) {
  const urlFilter = createFilter(options);
  return (loc) => {
    let path = loc;
    try {
      path = parseURL(loc).pathname;
    } catch {
      return false;
    }
    return urlFilter(path);
  };
}
function createFilter(options = {}) {
  const include = options.include || [];
  const exclude = options.exclude || [];
  if (include.length === 0 && exclude.length === 0)
    return () => true;
  return function(path) {
    for (const v of [{ rules: exclude, result: false }, { rules: include, result: true }]) {
      const regexRules = v.rules.filter((r) => r instanceof RegExp);
      if (regexRules.some((r) => r.test(path)))
        return v.result;
      const stringRules = v.rules.filter((r) => typeof r === "string");
      if (stringRules.length > 0) {
        const routes = {};
        for (const r of stringRules) {
          if (r === path)
            return v.result;
          routes[r] = true;
        }
        const routeRulesMatcher = toRouteMatcher(createRouter$1({ routes, strictTrailingSlash: false }));
        if (routeRulesMatcher.matchAll(path).length > 0)
          return Boolean(v.result);
      }
    }
    return include.length === 0;
  };
}
function useSimpleSitemapRuntimeConfig(e) {
  const clone = JSON.parse(JSON.stringify(useRuntimeConfig2(e).sitemap));
  for (const k in clone.sitemaps) {
    const sitemap = clone.sitemaps[k];
    sitemap.include = normalizeRuntimeFilters(sitemap.include);
    sitemap.exclude = normalizeRuntimeFilters(sitemap.exclude);
    clone.sitemaps[k] = sitemap;
  }
  return Object.freeze(clone);
}
function withoutQuery(path) {
  return path.split("?")[0];
}
function createNitroRouteRuleMatcher() {
  const { nitro, app } = useRuntimeConfig2();
  const _routeRulesMatcher2 = toRouteMatcher(
    createRouter$1({
      routes: Object.fromEntries(
        Object.entries(nitro?.routeRules || {}).map(([path, rules]) => [path === "/" ? path : withoutTrailingSlash(path), rules])
      )
    })
  );
  return (pathOrUrl) => {
    const path = pathOrUrl[0] === "/" ? pathOrUrl : parseURL(pathOrUrl, app.baseURL).pathname;
    const pathWithoutQuery = withoutQuery(path);
    return defu({}, ..._routeRulesMatcher2.matchAll(
      // radix3 does not support trailing slashes
      withoutBase(pathWithoutQuery === "/" ? pathWithoutQuery : withoutTrailingSlash(pathWithoutQuery), app.baseURL)
    ).reverse());
  };
}
function resolve(s2, resolvers) {
  if (typeof s2 === "undefined" || !resolvers)
    return s2;
  s2 = typeof s2 === "string" ? s2 : s2.toString();
  if (hasProtocol(s2, { acceptRelative: true, strict: false }))
    return resolvers.fixSlashes(s2);
  return resolvers.canonicalUrlResolver(s2);
}
function removeTrailingSlash(s2) {
  return s2.replace(/\/(\?|#|$)/, "$1");
}
function preNormalizeEntry(_e, resolvers) {
  const e = typeof _e === "string" ? { loc: _e } : { ..._e };
  if (e.url && !e.loc) {
    e.loc = e.url;
    delete e.url;
  }
  if (typeof e.loc !== "string") {
    e.loc = "";
  }
  e.loc = removeTrailingSlash(e.loc);
  e._abs = hasProtocol(e.loc, { acceptRelative: false, strict: false });
  try {
    e._path = e._abs ? parseURL(e.loc) : parsePath(e.loc);
  } catch (e2) {
    e2._path = null;
  }
  if (e._path) {
    const query = parseQuery(e._path.search);
    const qs = stringifyQuery(query);
    e._relativeLoc = `${encodePath(e._path?.pathname)}${qs.length ? `?${qs}` : ""}`;
    if (e._path.host) {
      e.loc = stringifyParsedURL(e._path);
    } else {
      e.loc = e._relativeLoc;
    }
  } else {
    e.loc = encodeURI(e.loc);
  }
  if (e.loc === "")
    e.loc = `/`;
  e.loc = resolve(e.loc, resolvers);
  e._key = `${e._sitemap || ""}${withoutTrailingSlash(e.loc)}`;
  return e;
}
function normaliseEntry(_e, defaults2, resolvers) {
  const e = defu(_e, defaults2);
  if (e.lastmod) {
    const date = normaliseDate(e.lastmod);
    if (date)
      e.lastmod = date;
    else
      delete e.lastmod;
  }
  if (!e.lastmod)
    delete e.lastmod;
  e.loc = resolve(e.loc, resolvers);
  if (e.alternatives) {
    e.alternatives = mergeOnKey(e.alternatives.map((e2) => {
      const a = { ...e2 };
      if (typeof a.href === "string")
        a.href = resolve(a.href, resolvers);
      else if (typeof a.href === "object" && a.href)
        a.href = resolve(a.href.href, resolvers);
      return a;
    }), "hreflang");
  }
  if (e.images) {
    e.images = mergeOnKey(e.images.map((i2) => {
      i2 = { ...i2 };
      i2.loc = resolve(i2.loc, resolvers);
      return i2;
    }), "loc");
  }
  if (e.videos) {
    e.videos = e.videos.map((v) => {
      v = { ...v };
      if (v.content_loc)
        v.content_loc = resolve(v.content_loc, resolvers);
      return v;
    });
  }
  return e;
}
function isValidW3CDate(d) {
  return IS_VALID_W3C_DATE.some((r) => r.test(d));
}
function normaliseDate(d) {
  if (typeof d === "string") {
    if (d.includes("T")) {
      const t = d.split("T")[1];
      if (!t.includes("+") && !t.includes("-") && !t.includes("Z")) {
        d += "Z";
      }
    }
    if (!isValidW3CDate(d))
      return false;
    d = new Date(d);
    d.setMilliseconds(0);
    if (Number.isNaN(d.getTime()))
      return false;
  }
  const z = (n) => `0${n}`.slice(-2);
  const date = `${d.getUTCFullYear()}-${z(d.getUTCMonth() + 1)}-${z(d.getUTCDate())}`;
  if (d.getUTCHours() > 0 || d.getUTCMinutes() > 0 || d.getUTCSeconds() > 0) {
    return `${date}T${z(d.getUTCHours())}:${z(d.getUTCMinutes())}:${z(d.getUTCSeconds())}Z`;
  }
  return date;
}
async function fetchDataSource(input, event) {
  const context = typeof input.context === "string" ? { name: input.context } : input.context || { name: "fetch" };
  context.tips = context.tips || [];
  const url = typeof input.fetch === "string" ? input.fetch : input.fetch[0];
  const options = typeof input.fetch === "string" ? {} : input.fetch[1];
  const start = Date.now();
  const timeout = options.timeout || 5e3;
  const timeoutController = new AbortController();
  const abortRequestTimeout = setTimeout(() => timeoutController.abort(), timeout);
  let isHtmlResponse = false;
  try {
    const fetchContainer = url.startsWith("/") && event ? event : globalThis;
    const urls = await fetchContainer.$fetch(url, {
      ...options,
      responseType: "json",
      signal: timeoutController.signal,
      headers: defu(options?.headers, {
        Accept: "application/json"
      }, event ? { Host: getRequestHost(event, { xForwardedHost: true }) } : {}),
      // @ts-expect-error untyped
      onResponse({ response }) {
        if (typeof response._data === "string" && response._data.startsWith("<!DOCTYPE html>"))
          isHtmlResponse = true;
      }
    });
    const timeTakenMs = Date.now() - start;
    if (isHtmlResponse) {
      context.tips.push("This is usually because the URL isn't correct or is throwing an error. Please check the URL");
      return {
        ...input,
        context,
        urls: [],
        timeTakenMs,
        error: "Received HTML response instead of JSON"
      };
    }
    return {
      ...input,
      context,
      timeTakenMs,
      urls
    };
  } catch (_err) {
    const error2 = _err;
    if (error2.message.includes("This operation was aborted"))
      context.tips.push("The request has taken too long. Make sure app sources respond within 5 seconds or adjust the timeout fetch option.");
    else
      context.tips.push(`Response returned a status of ${error2.response?.status || "unknown"}.`);
    console.error("[@nuxtjs/sitemap] Failed to fetch source.", { url, error: error2 });
    return {
      ...input,
      context,
      urls: [],
      error: error2.message
    };
  } finally {
    if (abortRequestTimeout) {
      clearTimeout(abortRequestTimeout);
    }
  }
}
function globalSitemapSources() {
  return Promise.resolve().then(() => (init_global_sources(), global_sources_exports)).then((m) => m.sources);
}
function childSitemapSources(definition) {
  return definition?._hasSourceChunk ? Promise.resolve().then(() => (init_child_sources(), child_sources_exports)).then((m) => m.sources[definition.sitemapName] || []) : Promise.resolve([]);
}
async function resolveSitemapSources(sources3, event) {
  return (await Promise.all(
    sources3.map((source) => {
      if (typeof source === "object" && "urls" in source) {
        return {
          timeTakenMs: 0,
          ...source,
          urls: source.urls
        };
      }
      if (source.fetch)
        return fetchDataSource(source, event);
      return {
        ...source,
        error: "Invalid source"
      };
    })
  )).flat();
}
function sortSitemapUrls(urls) {
  return urls.sort(
    (a, b) => {
      const aLoc = typeof a === "string" ? a : a.loc;
      const bLoc = typeof b === "string" ? b : b.loc;
      return aLoc.localeCompare(bLoc, void 0, { numeric: true });
    }
  ).sort((a, b) => {
    const aLoc = (typeof a === "string" ? a : a.loc) || "";
    const bLoc = (typeof b === "string" ? b : b.loc) || "";
    const aSegments = aLoc.split("/").length;
    const bSegments = bLoc.split("/").length;
    if (aSegments > bSegments)
      return 1;
    if (aSegments < bSegments)
      return -1;
    return 0;
  });
}
function resolveKey(k) {
  switch (k) {
    case "images":
      return "image";
    case "videos":
      return "video";
    case "news":
      return "news";
    default:
      return k;
  }
}
function handleObject(key, obj) {
  return [
    `        <${key}:${key}>`,
    ...Object.entries(obj).map(([sk, sv]) => {
      if (key === "video" && Array.isArray(sv)) {
        return sv.map((v) => {
          if (typeof v === "string") {
            return [
              `            `,
              `<${key}:${sk}>`,
              escapeValueForXml(v),
              `</${key}:${sk}>`
            ].join("");
          }
          const attributes = Object.entries(v).filter(([ssk]) => ssk !== sk).map(([ssk, ssv]) => `${ssk}="${escapeValueForXml(ssv)}"`).join(" ");
          return [
            `            <${key}:${sk} ${attributes}>`,
            // value is the same sk
            v[sk],
            `</${key}:${sk}>`
          ].join("");
        }).join("\n");
      }
      if (typeof sv === "object") {
        if (key === "video") {
          const attributes = Object.entries(sv).filter(([ssk]) => ssk !== sk).map(([ssk, ssv]) => `${ssk}="${escapeValueForXml(ssv)}"`).join(" ");
          return [
            `            <${key}:${sk} ${attributes}>`,
            // value is the same sk
            sv[sk],
            `</${key}:${sk}>`
          ].join("");
        }
        return [
          `            <${key}:${sk}>`,
          ...Object.entries(sv).map(([ssk, ssv]) => `                <${key}:${ssk}>${escapeValueForXml(ssv)}</${key}:${ssk}>`),
          `            </${key}:${sk}>`
        ].join("\n");
      }
      return `            <${key}:${sk}>${escapeValueForXml(sv)}</${key}:${sk}>`;
    }),
    `        </${key}:${key}>`
  ].join("\n");
}
function handleArray(key, arr) {
  if (arr.length === 0)
    return false;
  key = resolveKey(key);
  if (key === "alternatives") {
    return arr.map((obj) => [
      `        <xhtml:link rel="alternate" ${Object.entries(obj).map(([sk, sv]) => `${sk}="${escapeValueForXml(sv)}"`).join(" ")} />`
    ].join("\n")).join("\n");
  }
  return arr.map((obj) => handleObject(key, obj)).join("\n");
}
function handleEntry(k, e) {
  return Array.isArray(e[k]) ? handleArray(k, e[k]) : typeof e[k] === "object" ? handleObject(k, e[k]) : `        <${k}>${escapeValueForXml(e[k])}</${k}>`;
}
function wrapSitemapXml(input, resolvers, options) {
  const xsl = options.xsl ? resolvers.relativeBaseUrlResolver(options.xsl) : false;
  const credits = options.credits;
  input.unshift(`<?xml version="1.0" encoding="UTF-8"?>${xsl ? `<?xml-stylesheet type="text/xsl" href="${xsl}"?>` : ""}`);
  if (credits)
    input.push(`<!-- XML Sitemap generated by @nuxtjs/sitemap v${options.version} at ${(/* @__PURE__ */ new Date()).toISOString()} -->`);
  if (options.minify)
    return input.join("").replace(/(?<!<[^>]*)\s(?![^<]*>)/g, "");
  return input.join("\n");
}
function escapeValueForXml(value) {
  if (value === true || value === false)
    return value ? "yes" : "no";
  return String(value).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}
function resolveSitemapEntries(sitemap, sources3, runtimeConfig, resolvers) {
  const {
    autoI18n,
    isI18nMapped
  } = runtimeConfig;
  const filterPath = createPathFilter({
    include: sitemap.include,
    exclude: sitemap.exclude
  });
  const _urls = sources3.flatMap((e) => e.urls).map((_e) => {
    const e = preNormalizeEntry(_e, resolvers);
    if (!e.loc || !filterPath(e.loc))
      return false;
    return e;
  }).filter(Boolean);
  let validI18nUrlsForTransform = [];
  const withoutPrefixPaths = {};
  if (autoI18n && autoI18n.strategy !== "no_prefix") {
    const localeCodes = autoI18n.locales.map((l2) => l2.code);
    validI18nUrlsForTransform = _urls.map((_e, i2) => {
      if (_e._abs)
        return false;
      const split = splitForLocales(_e._relativeLoc, localeCodes);
      let localeCode = split[0];
      const pathWithoutPrefix = split[1];
      if (!localeCode)
        localeCode = autoI18n.defaultLocale;
      const e = _e;
      e._pathWithoutPrefix = pathWithoutPrefix;
      const locale = autoI18n.locales.find((l2) => l2.code === localeCode);
      if (!locale)
        return false;
      e._locale = locale;
      e._index = i2;
      e._key = `${e._sitemap || ""}${e._path?.pathname || "/"}${e._path.search}`;
      withoutPrefixPaths[pathWithoutPrefix] = withoutPrefixPaths[pathWithoutPrefix] || [];
      if (!withoutPrefixPaths[pathWithoutPrefix].some((e2) => e2._locale.code === locale.code))
        withoutPrefixPaths[pathWithoutPrefix].push(e);
      return e;
    }).filter(Boolean);
    for (const e of validI18nUrlsForTransform) {
      if (!e._i18nTransform && !e.alternatives?.length) {
        const alternatives = withoutPrefixPaths[e._pathWithoutPrefix].map((u) => {
          const entries = [];
          if (u._locale.code === autoI18n.defaultLocale) {
            entries.push({
              href: u.loc,
              hreflang: "x-default"
            });
          }
          entries.push({
            href: u.loc,
            hreflang: u._locale._hreflang || autoI18n.defaultLocale
          });
          return entries;
        }).flat().filter(Boolean);
        if (alternatives.length)
          e.alternatives = alternatives;
      } else if (e._i18nTransform) {
        delete e._i18nTransform;
        if (autoI18n.strategy === "no_prefix")
          ;
        if (autoI18n.differentDomains) {
          e.alternatives = [
            {
              // apply default locale domain
              ...autoI18n.locales.find((l2) => [l2.code, l2.language].includes(autoI18n.defaultLocale)),
              code: "x-default"
            },
            ...autoI18n.locales.filter((l2) => !!l2.domain)
          ].map((locale) => {
            return {
              hreflang: locale._hreflang,
              href: joinURL(withHttps(locale.domain), e._pathWithoutPrefix)
            };
          });
        } else {
          for (const l2 of autoI18n.locales) {
            let loc = joinURL(`/${l2.code}`, e._pathWithoutPrefix);
            if (autoI18n.differentDomains || ["prefix_and_default", "prefix_except_default"].includes(autoI18n.strategy) && l2.code === autoI18n.defaultLocale)
              loc = e._pathWithoutPrefix;
            const _sitemap = isI18nMapped ? l2._sitemap : void 0;
            const newEntry = preNormalizeEntry({
              _sitemap,
              ...e,
              _index: void 0,
              _key: `${_sitemap || ""}${loc || "/"}${e._path.search}`,
              _locale: l2,
              loc,
              alternatives: [{ code: "x-default", _hreflang: "x-default" }, ...autoI18n.locales].map((locale) => {
                const code = locale.code === "x-default" ? autoI18n.defaultLocale : locale.code;
                const isDefault = locale.code === "x-default" || locale.code === autoI18n.defaultLocale;
                let href = "";
                if (autoI18n.strategy === "prefix") {
                  href = joinURL("/", code, e._pathWithoutPrefix);
                } else if (["prefix_and_default", "prefix_except_default"].includes(autoI18n.strategy)) {
                  if (isDefault) {
                    href = e._pathWithoutPrefix;
                  } else {
                    href = joinURL("/", code, e._pathWithoutPrefix);
                  }
                }
                if (!filterPath(href))
                  return false;
                return {
                  hreflang: locale._hreflang,
                  href
                };
              }).filter(Boolean)
            }, resolvers);
            if (e._locale.code === newEntry._locale.code) {
              _urls[e._index] = newEntry;
              e._index = void 0;
            } else {
              _urls.push(newEntry);
            }
          }
        }
      }
      if (isI18nMapped) {
        e._sitemap = e._sitemap || e._locale._sitemap;
        e._key = `${e._sitemap || ""}${e.loc || "/"}${e._path.search}`;
      }
      if (e._index)
        _urls[e._index] = e;
    }
  }
  return _urls;
}
async function buildSitemapUrls(sitemap, resolvers, runtimeConfig) {
  const {
    sitemaps,
    // enhancing
    autoI18n,
    isI18nMapped,
    isMultiSitemap,
    // sorting
    sortEntries,
    // chunking
    defaultSitemapsChunkSize
  } = runtimeConfig;
  const isChunking = typeof sitemaps.chunks !== "undefined" && !Number.isNaN(Number(sitemap.sitemapName));
  function maybeSort(urls) {
    return sortEntries ? sortSitemapUrls(urls) : urls;
  }
  function maybeSlice(urls) {
    if (isChunking && defaultSitemapsChunkSize) {
      const chunk = Number(sitemap.sitemapName);
      return urls.slice(chunk * defaultSitemapsChunkSize, (chunk + 1) * defaultSitemapsChunkSize);
    }
    return urls;
  }
  if (autoI18n?.differentDomains) {
    const domain = autoI18n.locales.find((e) => [e.language, e.code].includes(sitemap.sitemapName))?.domain;
    if (domain) {
      const _tester = resolvers.canonicalUrlResolver;
      resolvers.canonicalUrlResolver = (path) => resolveSitePath(path, {
        absolute: true,
        withBase: false,
        siteUrl: withHttps(domain),
        trailingSlash: _tester("/test/").endsWith("/"),
        base: "/"
      });
    }
  }
  const sources3 = sitemap.includeAppSources ? await globalSitemapSources() : [];
  sources3.push(...await childSitemapSources(sitemap));
  const resolvedSources = await resolveSitemapSources(sources3, resolvers.event);
  const enhancedUrls = resolveSitemapEntries(sitemap, resolvedSources, { autoI18n, isI18nMapped }, resolvers);
  const filteredUrls = enhancedUrls.filter((e) => {
    if (isMultiSitemap && e._sitemap && sitemap.sitemapName)
      return e._sitemap === sitemap.sitemapName;
    return true;
  });
  const sortedUrls = maybeSort(filteredUrls);
  return maybeSlice(sortedUrls);
}
function urlsToXml(urls, resolvers, { version: version3, xsl, credits, minify }) {
  const urlset = urls.map((e) => {
    const keys = Object.keys(e).filter((k) => !k.startsWith("_"));
    return [
      "    <url>",
      keys.map((k) => handleEntry(k, e)).filter(Boolean).join("\n"),
      "    </url>"
    ].join("\n");
  });
  return wrapSitemapXml([
    '<urlset xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:video="http://www.google.com/schemas/sitemap-video/1.1" xmlns:xhtml="http://www.w3.org/1999/xhtml" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1" xmlns:news="http://www.google.com/schemas/sitemap-news/0.9" xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd http://www.google.com/schemas/sitemap-image/1.1 http://www.google.com/schemas/sitemap-image/1.1/sitemap-image.xsd" xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">',
    urlset.join("\n"),
    "</urlset>"
  ], resolvers, { version: version3, xsl, credits, minify });
}
function useNitroUrlResolvers(e) {
  const canonicalQuery = getQuery(e).canonical;
  const isShowingCanonical = typeof canonicalQuery !== "undefined" && canonicalQuery !== "false";
  const siteConfig = useSiteConfig(e);
  return {
    event: e,
    fixSlashes: (path) => fixSlashes(siteConfig.trailingSlash, path),
    // we need these as they depend on the nitro event
    canonicalUrlResolver: createSitePathResolver(e, {
      canonical: isShowingCanonical || true,
      absolute: true,
      withBase: true
    }),
    relativeBaseUrlResolver: createSitePathResolver(e, { absolute: false, withBase: true })
  };
}
async function createSitemap(event, definition, runtimeConfig) {
  const { sitemapName } = definition;
  const nitro = useNitroApp();
  const resolvers = useNitroUrlResolvers(event);
  let sitemapUrls = await buildSitemapUrls(definition, resolvers, runtimeConfig);
  const routeRuleMatcher = createNitroRouteRuleMatcher();
  const { autoI18n } = runtimeConfig;
  sitemapUrls = sitemapUrls.map((u) => {
    const path = u._path?.pathname || u.loc;
    let routeRules = routeRuleMatcher(path);
    if (autoI18n?.locales && autoI18n?.strategy !== "no_prefix") {
      const match = splitForLocales(path, autoI18n.locales.map((l2) => l2.code));
      const pathWithoutPrefix = match[1];
      if (pathWithoutPrefix && pathWithoutPrefix !== path)
        routeRules = defu(routeRules, routeRuleMatcher(pathWithoutPrefix));
    }
    if (routeRules.sitemap === false)
      return false;
    if (typeof routeRules.index !== "undefined" && !routeRules.index || typeof routeRules.robots !== "undefined" && !routeRules.robots) {
      return false;
    }
    const hasRobotsDisabled = Object.entries(routeRules.headers || {}).some(([name, value]) => name.toLowerCase() === "x-robots-tag" && value.toLowerCase().includes("noindex"));
    if (routeRules.redirect || hasRobotsDisabled)
      return false;
    return routeRules.sitemap ? defu(u, routeRules.sitemap) : u;
  }).filter(Boolean);
  const resolvedCtx = {
    urls: sitemapUrls,
    sitemapName
  };
  await nitro.hooks.callHook("sitemap:resolved", resolvedCtx);
  const maybeSort = (urls2) => runtimeConfig.sortEntries ? sortSitemapUrls(urls2) : urls2;
  const normalizedPreDedupe = resolvedCtx.urls.map((e) => normaliseEntry(e, definition.defaults, resolvers));
  const urls = maybeSort(mergeOnKey(normalizedPreDedupe, "_key").map((e) => normaliseEntry(e, definition.defaults, resolvers)));
  const sitemap = urlsToXml(urls, resolvers, runtimeConfig);
  const ctx = { sitemap, sitemapName };
  await nitro.hooks.callHook("sitemap:output", ctx);
  setHeader(event, "Content-Type", "text/xml; charset=UTF-8");
  if (runtimeConfig.cacheMaxAgeSeconds)
    setHeader(event, "Cache-Control", `public, max-age=${runtimeConfig.cacheMaxAgeSeconds}, must-revalidate`);
  else
    setHeader(event, "Cache-Control", `no-cache, no-store`);
  event.context._isSitemap = true;
  return ctx.sitemap;
}
function createNitroApp() {
  const config3 = useRuntimeConfig2();
  const hooks = createHooks();
  const captureError = (error2, context = {}) => {
    const promise = hooks.callHookParallel("error", error2, context).catch((error_) => {
      console.error("Error while capturing another error", error_);
    });
    if (context.event && isEvent(context.event)) {
      const errors = context.event.context.nitro?.errors;
      if (errors) {
        errors.push({ error: error2, context });
      }
      if (context.event.waitUntil) {
        context.event.waitUntil(promise);
      }
    }
  };
  const h3App = createApp2({
    debug: destr(false),
    onError: (error2, event) => {
      captureError(error2, { event, tags: ["request"] });
      return errorHandler(error2, event);
    },
    onRequest: async (event) => {
      await nitroApp.hooks.callHook("request", event).catch((error2) => {
        captureError(error2, { event, tags: ["request"] });
      });
    },
    onBeforeResponse: async (event, response) => {
      await nitroApp.hooks.callHook("beforeResponse", event, response).catch((error2) => {
        captureError(error2, { event, tags: ["request", "response"] });
      });
    },
    onAfterResponse: async (event, response) => {
      await nitroApp.hooks.callHook("afterResponse", event, response).catch((error2) => {
        captureError(error2, { event, tags: ["request", "response"] });
      });
    }
  });
  const router = createRouter2({
    preemptive: true
  });
  const localCall = createCall(toNodeListener(h3App));
  const _localFetch = createFetch(localCall, globalThis.fetch);
  const localFetch = (input, init) => _localFetch(input, init).then(
    (response) => normalizeFetchResponse(response)
  );
  const $fetch2 = createFetch$1({
    fetch: localFetch,
    Headers: Headers$1,
    defaults: { baseURL: config3.app.baseURL }
  });
  globalThis.$fetch = $fetch2;
  h3App.use(createRouteRulesHandler({ localFetch }));
  h3App.use(
    eventHandler((event) => {
      event.context.nitro = event.context.nitro || { errors: [] };
      const envContext = event.node.req?.__unenv__;
      if (envContext) {
        Object.assign(event.context, envContext);
      }
      event.fetch = (req, init) => fetchWithEvent(event, req, init, { fetch: localFetch });
      event.$fetch = (req, init) => fetchWithEvent(event, req, init, {
        fetch: $fetch2
      });
      event.waitUntil = (promise) => {
        if (!event.context.nitro._waitUntilPromises) {
          event.context.nitro._waitUntilPromises = [];
        }
        event.context.nitro._waitUntilPromises.push(promise);
        if (envContext?.waitUntil) {
          envContext.waitUntil(promise);
        }
      };
      event.captureError = (error2, context) => {
        captureError(error2, { event, ...context });
      };
    })
  );
  for (const h3 of handlers) {
    let handler2 = h3.lazy ? lazyEventHandler(h3.handler) : h3.handler;
    if (h3.middleware || !h3.route) {
      const middlewareBase = (config3.app.baseURL + (h3.route || "/")).replace(
        /\/+/g,
        "/"
      );
      h3App.use(middlewareBase, handler2);
    } else {
      const routeRules = getRouteRulesForPath(
        h3.route.replace(/:\w+|\*\*/g, "_")
      );
      if (routeRules.cache) {
        handler2 = cachedEventHandler(handler2, {
          group: "nitro/routes",
          ...routeRules.cache
        });
      }
      router.use(h3.route, handler2, h3.method);
    }
  }
  h3App.use(config3.app.baseURL, router.handler);
  const app = {
    hooks,
    h3App,
    router,
    localCall,
    localFetch,
    captureError
  };
  return app;
}
function runNitroPlugins(nitroApp22) {
  for (const plugin2 of plugins2) {
    try {
      plugin2(nitroApp22);
    } catch (error2) {
      nitroApp22.captureError(error2, { tags: ["plugin"] });
      throw error2;
    }
  }
}
function useNitroApp() {
  return nitroApp;
}
var suspectProtoRx, suspectConstructorRx, JsonSigRx, HASH_RE, AMPERSAND_RE, SLASH_RE, EQUAL_RE, IM_RE, PLUS_RE, ENC_CARET_RE, ENC_BACKTICK_RE, ENC_PIPE_RE, ENC_SPACE_RE, ENC_ENC_SLASH_RE, PROTOCOL_STRICT_REGEX, PROTOCOL_REGEX, PROTOCOL_RELATIVE_REGEX, PROTOCOL_SCRIPT_RE, TRAILING_SLASH_RE, JOIN_LEADING_SLASH_RE, protocolRelative, fieldContentRegExp, defaults, defaultPrototypesKeys, nativeFunc, nativeFuncLength, __defProp$1, __defNormalProp$1, __publicField$1, WordArray, Hex, Base64, Latin1, Utf8, BufferedBlockAlgorithm, Hasher, __defProp$3, __defNormalProp$3, __publicField$3, H, K, W, SHA256, NODE_TYPES, defu, defuFn, defaultMaxListeners, EventEmitter$1, EventEmitter2, _Readable, Readable, _Writable, Writable, __Duplex, _Duplex, Duplex, Socket, IncomingMessage, ServerResponse, __defProp$2, __defNormalProp$2, __publicField$2, H3Error, getHeader, RawBodySymbol, PayloadMethods$1, MIMES, DISALLOWED_STATUS_CHARS, defer, setHeaders, setHeader, PayloadMethods, ignoredHeaders, __defProp2, __defNormalProp, __publicField, H3Event, eventHandler, lazyEventHandler, RouterMethods, defaultTask, _createTask, createTask, Hookable, s, i, l, FetchError, payloadMethods, textTypes, JSON_RE, retryStatusCodes, nullBodyResponses$1, fetch, Headers$1, AbortController$1, ofetch, $fetch, nullBodyResponses, errorHandler, inlineAppConfig, appConfig, NUMBER_CHAR_RE, STR_SPLITTERS, envExpandRx, _inlineRuntimeConfig, envOptions, _sharedRuntimeConfig, _sharedAppConfig, BASE64_PREFIX, storageKeyProperties, DRIVER_NAME$1, memory, _assets, normalizeKey, assets, PATH_TRAVERSE_RE, DRIVER_NAME, unstorage_47drivers_47fs_45lite, storage, cachedEventHandler, config, _routeRulesMatcher, _globalThis2, globalKey2, defaultNamespace2, getContext, asyncHandlersKey2, asyncHandlers2, chars, unsafeChars, reserved, escaped, objectProtoOwnPropertyNames, _Q2EFbo9rNa, plugins2, _9GHP3o, basicReporter, consola, merger, StringifiedRegExpPattern, _M504rJ, IS_VALID_W3C_DATE, _55hRT5, _lazy_6ydn5w, handlers, nitroApp;
var init_nitro = __esm({
  ".netlify/functions-internal/server/chunks/_/nitro.mjs"() {
    "use strict";
    globalThis._importMeta_ = globalThis._importMeta_ || { url: "file:///_entry.js", env: process2.env };
    suspectProtoRx = /"(?:_|\\u0{2}5[Ff]){2}(?:p|\\u0{2}70)(?:r|\\u0{2}72)(?:o|\\u0{2}6[Ff])(?:t|\\u0{2}74)(?:o|\\u0{2}6[Ff])(?:_|\\u0{2}5[Ff]){2}"\s*:/;
    suspectConstructorRx = /"(?:c|\\u0063)(?:o|\\u006[Ff])(?:n|\\u006[Ee])(?:s|\\u0073)(?:t|\\u0074)(?:r|\\u0072)(?:u|\\u0075)(?:c|\\u0063)(?:t|\\u0074)(?:o|\\u006[Ff])(?:r|\\u0072)"\s*:/;
    JsonSigRx = /^\s*["[{]|^\s*-?\d{1,16}(\.\d{1,17})?([Ee][+-]?\d+)?\s*$/;
    HASH_RE = /#/g;
    AMPERSAND_RE = /&/g;
    SLASH_RE = /\//g;
    EQUAL_RE = /=/g;
    IM_RE = /\?/g;
    PLUS_RE = /\+/g;
    ENC_CARET_RE = /%5e/gi;
    ENC_BACKTICK_RE = /%60/gi;
    ENC_PIPE_RE = /%7c/gi;
    ENC_SPACE_RE = /%20/gi;
    ENC_ENC_SLASH_RE = /%252f/gi;
    PROTOCOL_STRICT_REGEX = /^[\s\w\0+.-]{2,}:([/\\]{1,2})/;
    PROTOCOL_REGEX = /^[\s\w\0+.-]{2,}:([/\\]{2})?/;
    PROTOCOL_RELATIVE_REGEX = /^([/\\]\s*){2,}[^/\\]/;
    PROTOCOL_SCRIPT_RE = /^[\s\0]*(blob|data|javascript|vbscript):$/i;
    TRAILING_SLASH_RE = /\/$|\/\?|\/#/;
    JOIN_LEADING_SLASH_RE = /^\.?\//;
    protocolRelative = Symbol.for("ufo:protocolRelative");
    fieldContentRegExp = /^[\u0009\u0020-\u007E\u0080-\u00FF]+$/;
    defaults = Object.freeze({
      ignoreUnknown: false,
      respectType: false,
      respectFunctionNames: false,
      respectFunctionProperties: false,
      unorderedObjects: true,
      unorderedArrays: false,
      unorderedSets: false,
      excludeKeys: void 0,
      excludeValues: void 0,
      replacer: void 0
    });
    defaultPrototypesKeys = Object.freeze([
      "prototype",
      "__proto__",
      "constructor"
    ]);
    nativeFunc = "[native code] }";
    nativeFuncLength = nativeFunc.length;
    __defProp$1 = Object.defineProperty;
    __defNormalProp$1 = (obj, key, value) => key in obj ? __defProp$1(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
    __publicField$1 = (obj, key, value) => {
      __defNormalProp$1(obj, typeof key !== "symbol" ? key + "" : key, value);
      return value;
    };
    WordArray = class _WordArray {
      constructor(words, sigBytes) {
        __publicField$1(this, "words");
        __publicField$1(this, "sigBytes");
        words = this.words = words || [];
        this.sigBytes = sigBytes === void 0 ? words.length * 4 : sigBytes;
      }
      toString(encoder) {
        return (encoder || Hex).stringify(this);
      }
      concat(wordArray) {
        this.clamp();
        if (this.sigBytes % 4) {
          for (let i2 = 0; i2 < wordArray.sigBytes; i2++) {
            const thatByte = wordArray.words[i2 >>> 2] >>> 24 - i2 % 4 * 8 & 255;
            this.words[this.sigBytes + i2 >>> 2] |= thatByte << 24 - (this.sigBytes + i2) % 4 * 8;
          }
        } else {
          for (let j = 0; j < wordArray.sigBytes; j += 4) {
            this.words[this.sigBytes + j >>> 2] = wordArray.words[j >>> 2];
          }
        }
        this.sigBytes += wordArray.sigBytes;
        return this;
      }
      clamp() {
        this.words[this.sigBytes >>> 2] &= 4294967295 << 32 - this.sigBytes % 4 * 8;
        this.words.length = Math.ceil(this.sigBytes / 4);
      }
      clone() {
        return new _WordArray([...this.words]);
      }
    };
    Hex = {
      stringify(wordArray) {
        const hexChars = [];
        for (let i2 = 0; i2 < wordArray.sigBytes; i2++) {
          const bite = wordArray.words[i2 >>> 2] >>> 24 - i2 % 4 * 8 & 255;
          hexChars.push((bite >>> 4).toString(16), (bite & 15).toString(16));
        }
        return hexChars.join("");
      }
    };
    Base64 = {
      stringify(wordArray) {
        const keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        const base64Chars = [];
        for (let i2 = 0; i2 < wordArray.sigBytes; i2 += 3) {
          const byte1 = wordArray.words[i2 >>> 2] >>> 24 - i2 % 4 * 8 & 255;
          const byte2 = wordArray.words[i2 + 1 >>> 2] >>> 24 - (i2 + 1) % 4 * 8 & 255;
          const byte3 = wordArray.words[i2 + 2 >>> 2] >>> 24 - (i2 + 2) % 4 * 8 & 255;
          const triplet = byte1 << 16 | byte2 << 8 | byte3;
          for (let j = 0; j < 4 && i2 * 8 + j * 6 < wordArray.sigBytes * 8; j++) {
            base64Chars.push(keyStr.charAt(triplet >>> 6 * (3 - j) & 63));
          }
        }
        return base64Chars.join("");
      }
    };
    Latin1 = {
      parse(latin1Str) {
        const latin1StrLength = latin1Str.length;
        const words = [];
        for (let i2 = 0; i2 < latin1StrLength; i2++) {
          words[i2 >>> 2] |= (latin1Str.charCodeAt(i2) & 255) << 24 - i2 % 4 * 8;
        }
        return new WordArray(words, latin1StrLength);
      }
    };
    Utf8 = {
      parse(utf8Str) {
        return Latin1.parse(unescape(encodeURIComponent(utf8Str)));
      }
    };
    BufferedBlockAlgorithm = class {
      constructor() {
        __publicField$1(this, "_data", new WordArray());
        __publicField$1(this, "_nDataBytes", 0);
        __publicField$1(this, "_minBufferSize", 0);
        __publicField$1(this, "blockSize", 512 / 32);
      }
      reset() {
        this._data = new WordArray();
        this._nDataBytes = 0;
      }
      _append(data) {
        if (typeof data === "string") {
          data = Utf8.parse(data);
        }
        this._data.concat(data);
        this._nDataBytes += data.sigBytes;
      }
      _doProcessBlock(_dataWords, _offset) {
      }
      _process(doFlush) {
        let processedWords;
        let nBlocksReady = this._data.sigBytes / (this.blockSize * 4);
        if (doFlush) {
          nBlocksReady = Math.ceil(nBlocksReady);
        } else {
          nBlocksReady = Math.max((nBlocksReady | 0) - this._minBufferSize, 0);
        }
        const nWordsReady = nBlocksReady * this.blockSize;
        const nBytesReady = Math.min(nWordsReady * 4, this._data.sigBytes);
        if (nWordsReady) {
          for (let offset = 0; offset < nWordsReady; offset += this.blockSize) {
            this._doProcessBlock(this._data.words, offset);
          }
          processedWords = this._data.words.splice(0, nWordsReady);
          this._data.sigBytes -= nBytesReady;
        }
        return new WordArray(processedWords, nBytesReady);
      }
    };
    Hasher = class extends BufferedBlockAlgorithm {
      update(messageUpdate) {
        this._append(messageUpdate);
        this._process();
        return this;
      }
      finalize(messageUpdate) {
        if (messageUpdate) {
          this._append(messageUpdate);
        }
      }
    };
    __defProp$3 = Object.defineProperty;
    __defNormalProp$3 = (obj, key, value) => key in obj ? __defProp$3(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
    __publicField$3 = (obj, key, value) => {
      __defNormalProp$3(obj, key + "", value);
      return value;
    };
    H = [
      1779033703,
      -1150833019,
      1013904242,
      -1521486534,
      1359893119,
      -1694144372,
      528734635,
      1541459225
    ];
    K = [
      1116352408,
      1899447441,
      -1245643825,
      -373957723,
      961987163,
      1508970993,
      -1841331548,
      -1424204075,
      -670586216,
      310598401,
      607225278,
      1426881987,
      1925078388,
      -2132889090,
      -1680079193,
      -1046744716,
      -459576895,
      -272742522,
      264347078,
      604807628,
      770255983,
      1249150122,
      1555081692,
      1996064986,
      -1740746414,
      -1473132947,
      -1341970488,
      -1084653625,
      -958395405,
      -710438585,
      113926993,
      338241895,
      666307205,
      773529912,
      1294757372,
      1396182291,
      1695183700,
      1986661051,
      -2117940946,
      -1838011259,
      -1564481375,
      -1474664885,
      -1035236496,
      -949202525,
      -778901479,
      -694614492,
      -200395387,
      275423344,
      430227734,
      506948616,
      659060556,
      883997877,
      958139571,
      1322822218,
      1537002063,
      1747873779,
      1955562222,
      2024104815,
      -2067236844,
      -1933114872,
      -1866530822,
      -1538233109,
      -1090935817,
      -965641998
    ];
    W = [];
    SHA256 = class extends Hasher {
      constructor() {
        super(...arguments);
        __publicField$3(this, "_hash", new WordArray([...H]));
      }
      /**
       * Resets the internal state of the hash object to initial values.
       */
      reset() {
        super.reset();
        this._hash = new WordArray([...H]);
      }
      _doProcessBlock(M, offset) {
        const H2 = this._hash.words;
        let a = H2[0];
        let b = H2[1];
        let c = H2[2];
        let d = H2[3];
        let e = H2[4];
        let f = H2[5];
        let g = H2[6];
        let h3 = H2[7];
        for (let i2 = 0; i2 < 64; i2++) {
          if (i2 < 16) {
            W[i2] = M[offset + i2] | 0;
          } else {
            const gamma0x = W[i2 - 15];
            const gamma0 = (gamma0x << 25 | gamma0x >>> 7) ^ (gamma0x << 14 | gamma0x >>> 18) ^ gamma0x >>> 3;
            const gamma1x = W[i2 - 2];
            const gamma1 = (gamma1x << 15 | gamma1x >>> 17) ^ (gamma1x << 13 | gamma1x >>> 19) ^ gamma1x >>> 10;
            W[i2] = gamma0 + W[i2 - 7] + gamma1 + W[i2 - 16];
          }
          const ch = e & f ^ ~e & g;
          const maj = a & b ^ a & c ^ b & c;
          const sigma0 = (a << 30 | a >>> 2) ^ (a << 19 | a >>> 13) ^ (a << 10 | a >>> 22);
          const sigma1 = (e << 26 | e >>> 6) ^ (e << 21 | e >>> 11) ^ (e << 7 | e >>> 25);
          const t1 = h3 + sigma1 + ch + K[i2] + W[i2];
          const t2 = sigma0 + maj;
          h3 = g;
          g = f;
          f = e;
          e = d + t1 | 0;
          d = c;
          c = b;
          b = a;
          a = t1 + t2 | 0;
        }
        H2[0] = H2[0] + a | 0;
        H2[1] = H2[1] + b | 0;
        H2[2] = H2[2] + c | 0;
        H2[3] = H2[3] + d | 0;
        H2[4] = H2[4] + e | 0;
        H2[5] = H2[5] + f | 0;
        H2[6] = H2[6] + g | 0;
        H2[7] = H2[7] + h3 | 0;
      }
      /**
       * Finishes the hash calculation and returns the hash as a WordArray.
       *
       * @param {string} messageUpdate - Additional message content to include in the hash.
       * @returns {WordArray} The finalised hash as a WordArray.
       */
      finalize(messageUpdate) {
        super.finalize(messageUpdate);
        const nBitsTotal = this._nDataBytes * 8;
        const nBitsLeft = this._data.sigBytes * 8;
        this._data.words[nBitsLeft >>> 5] |= 128 << 24 - nBitsLeft % 32;
        this._data.words[(nBitsLeft + 64 >>> 9 << 4) + 14] = Math.floor(
          nBitsTotal / 4294967296
        );
        this._data.words[(nBitsLeft + 64 >>> 9 << 4) + 15] = nBitsTotal;
        this._data.sigBytes = this._data.words.length * 4;
        this._process();
        return this._hash;
      }
    };
    NODE_TYPES = {
      NORMAL: 0,
      WILDCARD: 1,
      PLACEHOLDER: 2
    };
    defu = createDefu();
    defuFn = createDefu((object, key, currentValue) => {
      if (object[key] !== void 0 && typeof currentValue === "function") {
        object[key] = currentValue(object[key]);
        return true;
      }
    });
    defaultMaxListeners = 10;
    EventEmitter$1 = class EventEmitter {
      __unenv__ = true;
      _events = /* @__PURE__ */ Object.create(null);
      _maxListeners;
      static get defaultMaxListeners() {
        return defaultMaxListeners;
      }
      static set defaultMaxListeners(arg) {
        if (typeof arg !== "number" || arg < 0 || Number.isNaN(arg)) {
          throw new RangeError(
            'The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received ' + arg + "."
          );
        }
        defaultMaxListeners = arg;
      }
      setMaxListeners(n) {
        if (typeof n !== "number" || n < 0 || Number.isNaN(n)) {
          throw new RangeError(
            'The value of "n" is out of range. It must be a non-negative number. Received ' + n + "."
          );
        }
        this._maxListeners = n;
        return this;
      }
      getMaxListeners() {
        return _getMaxListeners(this);
      }
      emit(type, ...args) {
        if (!this._events[type] || this._events[type].length === 0) {
          return false;
        }
        if (type === "error") {
          let er;
          if (args.length > 0) {
            er = args[0];
          }
          if (er instanceof Error) {
            throw er;
          }
          const err = new Error(
            "Unhandled error." + (er ? " (" + er.message + ")" : "")
          );
          err.context = er;
          throw err;
        }
        for (const _listener of this._events[type]) {
          (_listener.listener || _listener).apply(this, args);
        }
        return true;
      }
      addListener(type, listener) {
        return _addListener(this, type, listener, false);
      }
      on(type, listener) {
        return _addListener(this, type, listener, false);
      }
      prependListener(type, listener) {
        return _addListener(this, type, listener, true);
      }
      once(type, listener) {
        return this.on(type, _wrapOnce(this, type, listener));
      }
      prependOnceListener(type, listener) {
        return this.prependListener(type, _wrapOnce(this, type, listener));
      }
      removeListener(type, listener) {
        return _removeListener(this, type, listener);
      }
      off(type, listener) {
        return this.removeListener(type, listener);
      }
      removeAllListeners(type) {
        return _removeAllListeners(this, type);
      }
      listeners(type) {
        return _listeners(this, type, true);
      }
      rawListeners(type) {
        return _listeners(this, type, false);
      }
      listenerCount(type) {
        return this.rawListeners(type).length;
      }
      eventNames() {
        return Object.keys(this._events);
      }
    };
    EventEmitter2 = globalThis.EventEmitter || EventEmitter$1;
    _Readable = class __Readable extends EventEmitter2 {
      __unenv__ = true;
      readableEncoding = null;
      readableEnded = true;
      readableFlowing = false;
      readableHighWaterMark = 0;
      readableLength = 0;
      readableObjectMode = false;
      readableAborted = false;
      readableDidRead = false;
      closed = false;
      errored = null;
      readable = false;
      destroyed = false;
      static from(_iterable, options) {
        return new __Readable(options);
      }
      constructor(_opts) {
        super();
      }
      _read(_size) {
      }
      read(_size) {
      }
      setEncoding(_encoding) {
        return this;
      }
      pause() {
        return this;
      }
      resume() {
        return this;
      }
      isPaused() {
        return true;
      }
      unpipe(_destination) {
        return this;
      }
      unshift(_chunk, _encoding) {
      }
      wrap(_oldStream) {
        return this;
      }
      push(_chunk, _encoding) {
        return false;
      }
      _destroy(_error, _callback) {
        this.removeAllListeners();
      }
      destroy(error2) {
        this.destroyed = true;
        this._destroy(error2);
        return this;
      }
      pipe(_destenition, _options) {
        return {};
      }
      compose(stream, options) {
        throw new Error("[unenv] Method not implemented.");
      }
      [Symbol.asyncDispose]() {
        this.destroy();
        return Promise.resolve();
      }
      // eslint-disable-next-line require-yield
      async *[Symbol.asyncIterator]() {
        throw createNotImplementedError("Readable.asyncIterator");
      }
      iterator(options) {
        throw createNotImplementedError("Readable.iterator");
      }
      map(fn, options) {
        throw createNotImplementedError("Readable.map");
      }
      filter(fn, options) {
        throw createNotImplementedError("Readable.filter");
      }
      forEach(fn, options) {
        throw createNotImplementedError("Readable.forEach");
      }
      reduce(fn, initialValue, options) {
        throw createNotImplementedError("Readable.reduce");
      }
      find(fn, options) {
        throw createNotImplementedError("Readable.find");
      }
      findIndex(fn, options) {
        throw createNotImplementedError("Readable.findIndex");
      }
      some(fn, options) {
        throw createNotImplementedError("Readable.some");
      }
      toArray(options) {
        throw createNotImplementedError("Readable.toArray");
      }
      every(fn, options) {
        throw createNotImplementedError("Readable.every");
      }
      flatMap(fn, options) {
        throw createNotImplementedError("Readable.flatMap");
      }
      drop(limit, options) {
        throw createNotImplementedError("Readable.drop");
      }
      take(limit, options) {
        throw createNotImplementedError("Readable.take");
      }
      asIndexedPairs(options) {
        throw createNotImplementedError("Readable.asIndexedPairs");
      }
    };
    Readable = globalThis.Readable || _Readable;
    _Writable = class extends EventEmitter2 {
      __unenv__ = true;
      writable = true;
      writableEnded = false;
      writableFinished = false;
      writableHighWaterMark = 0;
      writableLength = 0;
      writableObjectMode = false;
      writableCorked = 0;
      closed = false;
      errored = null;
      writableNeedDrain = false;
      destroyed = false;
      _data;
      _encoding = "utf-8";
      constructor(_opts) {
        super();
      }
      pipe(_destenition, _options) {
        return {};
      }
      _write(chunk, encoding, callback) {
        if (this.writableEnded) {
          if (callback) {
            callback();
          }
          return;
        }
        if (this._data === void 0) {
          this._data = chunk;
        } else {
          const a = typeof this._data === "string" ? Buffer.from(this._data, this._encoding || encoding || "utf8") : this._data;
          const b = typeof chunk === "string" ? Buffer.from(chunk, encoding || this._encoding || "utf8") : chunk;
          this._data = Buffer.concat([a, b]);
        }
        this._encoding = encoding;
        if (callback) {
          callback();
        }
      }
      _writev(_chunks, _callback) {
      }
      _destroy(_error, _callback) {
      }
      _final(_callback) {
      }
      write(chunk, arg2, arg3) {
        const encoding = typeof arg2 === "string" ? this._encoding : "utf-8";
        const cb = typeof arg2 === "function" ? arg2 : typeof arg3 === "function" ? arg3 : void 0;
        this._write(chunk, encoding, cb);
        return true;
      }
      setDefaultEncoding(_encoding) {
        return this;
      }
      end(arg1, arg2, arg3) {
        const callback = typeof arg1 === "function" ? arg1 : typeof arg2 === "function" ? arg2 : typeof arg3 === "function" ? arg3 : void 0;
        if (this.writableEnded) {
          if (callback) {
            callback();
          }
          return this;
        }
        const data = arg1 === callback ? void 0 : arg1;
        if (data) {
          const encoding = arg2 === callback ? void 0 : arg2;
          this.write(data, encoding, callback);
        }
        this.writableEnded = true;
        this.writableFinished = true;
        this.emit("close");
        this.emit("finish");
        return this;
      }
      cork() {
      }
      uncork() {
      }
      destroy(_error) {
        this.destroyed = true;
        delete this._data;
        this.removeAllListeners();
        return this;
      }
      compose(stream, options) {
        throw new Error("[h3] Method not implemented.");
      }
    };
    Writable = globalThis.Writable || _Writable;
    __Duplex = class {
      allowHalfOpen = true;
      _destroy;
      constructor(readable = new Readable(), writable = new Writable()) {
        Object.assign(this, readable);
        Object.assign(this, writable);
        this._destroy = mergeFns(readable._destroy, writable._destroy);
      }
    };
    _Duplex = /* @__PURE__ */ getDuplex();
    Duplex = globalThis.Duplex || _Duplex;
    Socket = class extends Duplex {
      __unenv__ = true;
      bufferSize = 0;
      bytesRead = 0;
      bytesWritten = 0;
      connecting = false;
      destroyed = false;
      pending = false;
      localAddress = "";
      localPort = 0;
      remoteAddress = "";
      remoteFamily = "";
      remotePort = 0;
      autoSelectFamilyAttemptedAddresses = [];
      readyState = "readOnly";
      constructor(_options) {
        super();
      }
      write(_buffer, _arg1, _arg2) {
        return false;
      }
      connect(_arg1, _arg2, _arg3) {
        return this;
      }
      end(_arg1, _arg2, _arg3) {
        return this;
      }
      setEncoding(_encoding) {
        return this;
      }
      pause() {
        return this;
      }
      resume() {
        return this;
      }
      setTimeout(_timeout, _callback) {
        return this;
      }
      setNoDelay(_noDelay) {
        return this;
      }
      setKeepAlive(_enable, _initialDelay) {
        return this;
      }
      address() {
        return {};
      }
      unref() {
        return this;
      }
      ref() {
        return this;
      }
      destroySoon() {
        this.destroy();
      }
      resetAndDestroy() {
        const err = new Error("ERR_SOCKET_CLOSED");
        err.code = "ERR_SOCKET_CLOSED";
        this.destroy(err);
        return this;
      }
    };
    IncomingMessage = class extends Readable {
      __unenv__ = {};
      aborted = false;
      httpVersion = "1.1";
      httpVersionMajor = 1;
      httpVersionMinor = 1;
      complete = true;
      connection;
      socket;
      headers = {};
      trailers = {};
      method = "GET";
      url = "/";
      statusCode = 200;
      statusMessage = "";
      closed = false;
      errored = null;
      readable = false;
      constructor(socket) {
        super();
        this.socket = this.connection = socket || new Socket();
      }
      get rawHeaders() {
        return rawHeaders(this.headers);
      }
      get rawTrailers() {
        return [];
      }
      setTimeout(_msecs, _callback) {
        return this;
      }
      get headersDistinct() {
        return _distinct(this.headers);
      }
      get trailersDistinct() {
        return _distinct(this.trailers);
      }
    };
    ServerResponse = class extends Writable {
      __unenv__ = true;
      statusCode = 200;
      statusMessage = "";
      upgrading = false;
      chunkedEncoding = false;
      shouldKeepAlive = false;
      useChunkedEncodingByDefault = false;
      sendDate = false;
      finished = false;
      headersSent = false;
      strictContentLength = false;
      connection = null;
      socket = null;
      req;
      _headers = {};
      constructor(req) {
        super();
        this.req = req;
      }
      assignSocket(socket) {
        socket._httpMessage = this;
        this.socket = socket;
        this.connection = socket;
        this.emit("socket", socket);
        this._flush();
      }
      _flush() {
        this.flushHeaders();
      }
      detachSocket(_socket) {
      }
      writeContinue(_callback) {
      }
      writeHead(statusCode, arg1, arg2) {
        if (statusCode) {
          this.statusCode = statusCode;
        }
        if (typeof arg1 === "string") {
          this.statusMessage = arg1;
          arg1 = void 0;
        }
        const headers = arg2 || arg1;
        if (headers) {
          if (Array.isArray(headers))
            ;
          else {
            for (const key in headers) {
              this.setHeader(key, headers[key]);
            }
          }
        }
        this.headersSent = true;
        return this;
      }
      writeProcessing() {
      }
      setTimeout(_msecs, _callback) {
        return this;
      }
      appendHeader(name, value) {
        name = name.toLowerCase();
        const current = this._headers[name];
        const all = [
          ...Array.isArray(current) ? current : [current],
          ...Array.isArray(value) ? value : [value]
        ].filter(Boolean);
        this._headers[name] = all.length > 1 ? all : all[0];
        return this;
      }
      setHeader(name, value) {
        this._headers[name.toLowerCase()] = value;
        return this;
      }
      getHeader(name) {
        return this._headers[name.toLowerCase()];
      }
      getHeaders() {
        return this._headers;
      }
      getHeaderNames() {
        return Object.keys(this._headers);
      }
      hasHeader(name) {
        return name.toLowerCase() in this._headers;
      }
      removeHeader(name) {
        delete this._headers[name.toLowerCase()];
      }
      addTrailers(_headers) {
      }
      flushHeaders() {
      }
      writeEarlyHints(_headers, cb) {
        if (typeof cb === "function") {
          cb();
        }
      }
    };
    __defProp$2 = Object.defineProperty;
    __defNormalProp$2 = (obj, key, value) => key in obj ? __defProp$2(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
    __publicField$2 = (obj, key, value) => {
      __defNormalProp$2(obj, typeof key !== "symbol" ? key + "" : key, value);
      return value;
    };
    H3Error = class extends Error {
      constructor(message2, opts = {}) {
        super(message2, opts);
        __publicField$2(this, "statusCode", 500);
        __publicField$2(this, "fatal", false);
        __publicField$2(this, "unhandled", false);
        __publicField$2(this, "statusMessage");
        __publicField$2(this, "data");
        __publicField$2(this, "cause");
        if (opts.cause && !this.cause) {
          this.cause = opts.cause;
        }
      }
      toJSON() {
        const obj = {
          message: this.message,
          statusCode: sanitizeStatusCode(this.statusCode, 500)
        };
        if (this.statusMessage) {
          obj.statusMessage = sanitizeStatusMessage(this.statusMessage);
        }
        if (this.data !== void 0) {
          obj.data = this.data;
        }
        return obj;
      }
    };
    __publicField$2(H3Error, "__h3_error__", true);
    getHeader = getRequestHeader;
    RawBodySymbol = Symbol.for("h3RawBody");
    PayloadMethods$1 = ["PATCH", "POST", "PUT", "DELETE"];
    MIMES = {
      html: "text/html",
      json: "application/json"
    };
    DISALLOWED_STATUS_CHARS = /[^\u0009\u0020-\u007E]/g;
    defer = typeof setImmediate === "undefined" ? (fn) => fn() : setImmediate;
    setHeaders = setResponseHeaders;
    setHeader = setResponseHeader;
    PayloadMethods = /* @__PURE__ */ new Set(["PATCH", "POST", "PUT", "DELETE"]);
    ignoredHeaders = /* @__PURE__ */ new Set([
      "transfer-encoding",
      "connection",
      "keep-alive",
      "upgrade",
      "expect",
      "host",
      "accept"
    ]);
    __defProp2 = Object.defineProperty;
    __defNormalProp = (obj, key, value) => key in obj ? __defProp2(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
    __publicField = (obj, key, value) => {
      __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
      return value;
    };
    H3Event = class {
      constructor(req, res) {
        __publicField(this, "__is_event__", true);
        __publicField(this, "node");
        __publicField(this, "web");
        __publicField(this, "context", {});
        __publicField(this, "_method");
        __publicField(this, "_path");
        __publicField(this, "_headers");
        __publicField(this, "_requestBody");
        __publicField(this, "_handled", false);
        __publicField(this, "_onBeforeResponseCalled");
        __publicField(this, "_onAfterResponseCalled");
        this.node = { req, res };
      }
      // --- Request ---
      get method() {
        if (!this._method) {
          this._method = (this.node.req.method || "GET").toUpperCase();
        }
        return this._method;
      }
      get path() {
        return this._path || this.node.req.url || "/";
      }
      get headers() {
        if (!this._headers) {
          this._headers = _normalizeNodeHeaders(this.node.req.headers);
        }
        return this._headers;
      }
      // --- Respoonse ---
      get handled() {
        return this._handled || this.node.res.writableEnded || this.node.res.headersSent;
      }
      respondWith(response) {
        return Promise.resolve(response).then(
          (_response) => sendWebResponse(this, _response)
        );
      }
      // --- Utils ---
      toString() {
        return `[${this.method}] ${this.path}`;
      }
      toJSON() {
        return this.toString();
      }
      // --- Deprecated ---
      /** @deprecated Please use `event.node.req` instead. */
      get req() {
        return this.node.req;
      }
      /** @deprecated Please use `event.node.res` instead. */
      get res() {
        return this.node.res;
      }
    };
    eventHandler = defineEventHandler;
    lazyEventHandler = defineLazyEventHandler;
    RouterMethods = [
      "connect",
      "delete",
      "get",
      "head",
      "options",
      "post",
      "put",
      "trace",
      "patch"
    ];
    defaultTask = { run: (function_) => function_() };
    _createTask = () => defaultTask;
    createTask = typeof console.createTask !== "undefined" ? console.createTask : _createTask;
    Hookable = class {
      constructor() {
        this._hooks = {};
        this._before = void 0;
        this._after = void 0;
        this._deprecatedMessages = void 0;
        this._deprecatedHooks = {};
        this.hook = this.hook.bind(this);
        this.callHook = this.callHook.bind(this);
        this.callHookWith = this.callHookWith.bind(this);
      }
      hook(name, function_, options = {}) {
        if (!name || typeof function_ !== "function") {
          return () => {
          };
        }
        const originalName = name;
        let dep;
        while (this._deprecatedHooks[name]) {
          dep = this._deprecatedHooks[name];
          name = dep.to;
        }
        if (dep && !options.allowDeprecated) {
          let message2 = dep.message;
          if (!message2) {
            message2 = `${originalName} hook has been deprecated` + (dep.to ? `, please use ${dep.to}` : "");
          }
          if (!this._deprecatedMessages) {
            this._deprecatedMessages = /* @__PURE__ */ new Set();
          }
          if (!this._deprecatedMessages.has(message2)) {
            console.warn(message2);
            this._deprecatedMessages.add(message2);
          }
        }
        if (!function_.name) {
          try {
            Object.defineProperty(function_, "name", {
              get: () => "_" + name.replace(/\W+/g, "_") + "_hook_cb",
              configurable: true
            });
          } catch {
          }
        }
        this._hooks[name] = this._hooks[name] || [];
        this._hooks[name].push(function_);
        return () => {
          if (function_) {
            this.removeHook(name, function_);
            function_ = void 0;
          }
        };
      }
      hookOnce(name, function_) {
        let _unreg;
        let _function = (...arguments_) => {
          if (typeof _unreg === "function") {
            _unreg();
          }
          _unreg = void 0;
          _function = void 0;
          return function_(...arguments_);
        };
        _unreg = this.hook(name, _function);
        return _unreg;
      }
      removeHook(name, function_) {
        if (this._hooks[name]) {
          const index3 = this._hooks[name].indexOf(function_);
          if (index3 !== -1) {
            this._hooks[name].splice(index3, 1);
          }
          if (this._hooks[name].length === 0) {
            delete this._hooks[name];
          }
        }
      }
      deprecateHook(name, deprecated) {
        this._deprecatedHooks[name] = typeof deprecated === "string" ? { to: deprecated } : deprecated;
        const _hooks = this._hooks[name] || [];
        delete this._hooks[name];
        for (const hook of _hooks) {
          this.hook(name, hook);
        }
      }
      deprecateHooks(deprecatedHooks) {
        Object.assign(this._deprecatedHooks, deprecatedHooks);
        for (const name in deprecatedHooks) {
          this.deprecateHook(name, deprecatedHooks[name]);
        }
      }
      addHooks(configHooks) {
        const hooks = flatHooks(configHooks);
        const removeFns = Object.keys(hooks).map(
          (key) => this.hook(key, hooks[key])
        );
        return () => {
          for (const unreg of removeFns.splice(0, removeFns.length)) {
            unreg();
          }
        };
      }
      removeHooks(configHooks) {
        const hooks = flatHooks(configHooks);
        for (const key in hooks) {
          this.removeHook(key, hooks[key]);
        }
      }
      removeAllHooks() {
        for (const key in this._hooks) {
          delete this._hooks[key];
        }
      }
      callHook(name, ...arguments_) {
        arguments_.unshift(name);
        return this.callHookWith(serialTaskCaller, name, ...arguments_);
      }
      callHookParallel(name, ...arguments_) {
        arguments_.unshift(name);
        return this.callHookWith(parallelTaskCaller, name, ...arguments_);
      }
      callHookWith(caller, name, ...arguments_) {
        const event = this._before || this._after ? { name, args: arguments_, context: {} } : void 0;
        if (this._before) {
          callEachWith(this._before, event);
        }
        const result = caller(
          name in this._hooks ? [...this._hooks[name]] : [],
          arguments_
        );
        if (result instanceof Promise) {
          return result.finally(() => {
            if (this._after && event) {
              callEachWith(this._after, event);
            }
          });
        }
        if (this._after && event) {
          callEachWith(this._after, event);
        }
        return result;
      }
      beforeEach(function_) {
        this._before = this._before || [];
        this._before.push(function_);
        return () => {
          if (this._before !== void 0) {
            const index3 = this._before.indexOf(function_);
            if (index3 !== -1) {
              this._before.splice(index3, 1);
            }
          }
        };
      }
      afterEach(function_) {
        this._after = this._after || [];
        this._after.push(function_);
        return () => {
          if (this._after !== void 0) {
            const index3 = this._after.indexOf(function_);
            if (index3 !== -1) {
              this._after.splice(index3, 1);
            }
          }
        };
      }
    };
    s = globalThis.Headers;
    i = globalThis.AbortController;
    l = globalThis.fetch || (() => {
      throw new Error("[node-fetch-native] Failed to fetch: `globalThis.fetch` is not available!");
    });
    FetchError = class extends Error {
      constructor(message2, opts) {
        super(message2, opts);
        this.name = "FetchError";
        if (opts?.cause && !this.cause) {
          this.cause = opts.cause;
        }
      }
    };
    payloadMethods = new Set(
      Object.freeze(["PATCH", "POST", "PUT", "DELETE"])
    );
    textTypes = /* @__PURE__ */ new Set([
      "image/svg",
      "application/xml",
      "application/xhtml",
      "application/html"
    ]);
    JSON_RE = /^application\/(?:[\w!#$%&*.^`~-]*\+)?json(;.+)?$/i;
    retryStatusCodes = /* @__PURE__ */ new Set([
      408,
      // Request Timeout
      409,
      // Conflict
      425,
      // Too Early (Experimental)
      429,
      // Too Many Requests
      500,
      // Internal Server Error
      502,
      // Bad Gateway
      503,
      // Service Unavailable
      504
      // Gateway Timeout
    ]);
    nullBodyResponses$1 = /* @__PURE__ */ new Set([101, 204, 205, 304]);
    fetch = globalThis.fetch ? (...args) => globalThis.fetch(...args) : createNodeFetch();
    Headers$1 = globalThis.Headers || s;
    AbortController$1 = globalThis.AbortController || i;
    ofetch = createFetch$1({ fetch, Headers: Headers$1, AbortController: AbortController$1 });
    $fetch = ofetch;
    nullBodyResponses = /* @__PURE__ */ new Set([101, 204, 205, 304]);
    errorHandler = async function errorhandler(error2, event) {
      const { stack, statusCode, statusMessage, message: message2 } = normalizeError(error2);
      const errorObject = {
        url: event.path,
        statusCode,
        statusMessage,
        message: message2,
        stack: "",
        // TODO: check and validate error.data for serialisation into query
        data: error2.data
      };
      if (error2.unhandled || error2.fatal) {
        const tags = [
          "[nuxt]",
          "[request error]",
          error2.unhandled && "[unhandled]",
          error2.fatal && "[fatal]",
          Number(errorObject.statusCode) !== 200 && `[${errorObject.statusCode}]`
        ].filter(Boolean).join(" ");
        console.error(tags, (error2.message || error2.toString() || "internal server error") + "\n" + stack.map((l2) => "  " + l2.text).join("  \n"));
      }
      if (event.handled) {
        return;
      }
      setResponseStatus(event, errorObject.statusCode !== 200 && errorObject.statusCode || 500, errorObject.statusMessage);
      if (isJsonRequest(event)) {
        setResponseHeader(event, "Content-Type", "application/json");
        return send(event, JSON.stringify(errorObject));
      }
      const reqHeaders = getRequestHeaders(event);
      const isRenderingError = event.path.startsWith("/__nuxt_error") || !!reqHeaders["x-nuxt-error"];
      const res = isRenderingError ? null : await useNitroApp().localFetch(
        withQuery(joinURL(useRuntimeConfig2(event).app.baseURL, "/__nuxt_error"), errorObject),
        {
          headers: { ...reqHeaders, "x-nuxt-error": "true" },
          redirect: "manual"
        }
      ).catch(() => null);
      if (!res) {
        const { template: template3 } = await Promise.resolve().then(() => (init_error_500(), error_500_exports));
        if (event.handled) {
          return;
        }
        setResponseHeader(event, "Content-Type", "text/html;charset=UTF-8");
        return send(event, template3(errorObject));
      }
      const html = await res.text();
      if (event.handled) {
        return;
      }
      for (const [header, value] of res.headers.entries()) {
        setResponseHeader(event, header, value);
      }
      setResponseStatus(event, res.status && res.status !== 200 ? res.status : void 0, res.statusText);
      return send(event, html);
    };
    inlineAppConfig = {
      "nuxt": {}
    };
    appConfig = defuFn(inlineAppConfig);
    NUMBER_CHAR_RE = /\d/;
    STR_SPLITTERS = ["-", "_", "/", "."];
    envExpandRx = /{{(.*?)}}/g;
    _inlineRuntimeConfig = {
      "app": {
        "baseURL": "/",
        "buildId": "d371dd60-c5b4-47b2-a19e-b8f7c42c4ae5",
        "buildAssetsDir": "/_nuxt/",
        "cdnURL": ""
      },
      "nitro": {
        "envPrefix": "NUXT_",
        "routeRules": {
          "/__nuxt_error": {
            "cache": false
          },
          "/sitemap.xsl": {
            "headers": {
              "Content-Type": "application/xslt+xml"
            }
          },
          "/sitemap.xml": {
            "swr": 600,
            "cache": {
              "swr": true,
              "maxAge": 600,
              "varies": [
                "X-Forwarded-Host",
                "X-Forwarded-Proto",
                "Host"
              ]
            }
          },
          "/_nuxt/builds/meta/**": {
            "headers": {
              "cache-control": "public, max-age=31536000, immutable"
            }
          },
          "/_nuxt/builds/**": {
            "headers": {
              "cache-control": "public, max-age=1, immutable"
            }
          },
          "/_nuxt/**": {
            "headers": {
              "cache-control": "public, max-age=31536000, immutable"
            }
          }
        }
      },
      "public": {
        "appBaseUrl": "http://localhost:3000",
        "appSiteUrl": "http://localhost:3000",
        "serverBaseUrl": "http://localhost:3000",
        "serverApiUrl": "http://localhost:8000/api",
        "apiVersion": "v1"
      },
      "sitemap": {
        "isI18nMapped": false,
        "sitemapName": "sitemap.xml",
        "isMultiSitemap": false,
        "excludeAppSources": [],
        "cacheMaxAgeSeconds": 600,
        "autoLastmod": false,
        "defaultSitemapsChunkSize": 1e3,
        "minify": false,
        "sortEntries": true,
        "debug": false,
        "discoverImages": true,
        "discoverVideos": true,
        "sitemapsPathPrefix": "/__sitemap__/",
        "isNuxtContentDocumentDriven": false,
        "xsl": "/__sitemap__/style.xsl",
        "xslTips": true,
        "xslColumns": [
          {
            "label": "URL",
            "width": "50%"
          },
          {
            "label": "Images",
            "width": "25%",
            "select": "count(image:image)"
          },
          {
            "label": "Last Updated",
            "width": "25%",
            "select": "concat(substring(sitemap:lastmod,0,11),concat(' ', substring(sitemap:lastmod,12,5)),concat(' ', substring(sitemap:lastmod,20,6)))"
          }
        ],
        "credits": true,
        "version": "6.1.5",
        "sitemaps": {
          "sitemap.xml": {
            "sitemapName": "sitemap.xml",
            "route": "sitemap.xml",
            "defaults": {},
            "include": [],
            "exclude": [
              "/admin/**",
              "/_nuxt/**",
              "/_**"
            ],
            "includeAppSources": true
          }
        }
      },
      "nuxt-site-config": {
        "stack": [
          {
            "_context": "system",
            "_priority": -15,
            "name": "ite-site",
            "env": "production"
          },
          {
            "_context": "package.json",
            "_priority": -10,
            "name": "ite",
            "description": "ite"
          },
          {
            "_context": "vendorEnv",
            "_priority": -5,
            "url": "https://prismatic-heliotrope-ddff86.netlify.app",
            "name": "prismatic-heliotrope-ddff86"
          },
          {
            "_context": "buildEnv",
            "_priority": -1,
            "url": "nuxt-ite-build.netlify.app"
          }
        ],
        "version": "2.2.21",
        "debug": false
      }
    };
    envOptions = {
      prefix: "NITRO_",
      altPrefix: _inlineRuntimeConfig.nitro.envPrefix ?? process2.env.NITRO_ENV_PREFIX ?? "_",
      envExpansion: _inlineRuntimeConfig.nitro.envExpansion ?? process2.env.NITRO_ENV_EXPANSION ?? false
    };
    _sharedRuntimeConfig = _deepFreeze(
      applyEnv(klona(_inlineRuntimeConfig), envOptions)
    );
    _sharedAppConfig = _deepFreeze(klona(appConfig));
    new Proxy(/* @__PURE__ */ Object.create(null), {
      get: (_, prop) => {
        console.warn(
          "Please use `useRuntimeConfig()` instead of accessing config directly."
        );
        const runtimeConfig = useRuntimeConfig2();
        if (prop in runtimeConfig) {
          return runtimeConfig[prop];
        }
        return void 0;
      }
    });
    BASE64_PREFIX = "base64:";
    storageKeyProperties = [
      "hasItem",
      "getItem",
      "getItemRaw",
      "setItem",
      "setItemRaw",
      "removeItem",
      "getMeta",
      "setMeta",
      "removeMeta",
      "getKeys",
      "clear",
      "mount",
      "unmount"
    ];
    DRIVER_NAME$1 = "memory";
    memory = defineDriver$1(() => {
      const data = /* @__PURE__ */ new Map();
      return {
        name: DRIVER_NAME$1,
        getInstance: () => data,
        hasItem(key) {
          return data.has(key);
        },
        getItem(key) {
          return data.get(key) ?? null;
        },
        getItemRaw(key) {
          return data.get(key) ?? null;
        },
        setItem(key, value) {
          data.set(key, value);
        },
        setItemRaw(key, value) {
          data.set(key, value);
        },
        removeItem(key) {
          data.delete(key);
        },
        getKeys() {
          return [...data.keys()];
        },
        clear() {
          data.clear();
        },
        dispose() {
          data.clear();
        }
      };
    });
    _assets = {};
    normalizeKey = function normalizeKey2(key) {
      if (!key) {
        return "";
      }
      return key.split("?")[0].replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "");
    };
    assets = {
      getKeys() {
        return Promise.resolve(Object.keys(_assets));
      },
      hasItem(id) {
        id = normalizeKey(id);
        return Promise.resolve(id in _assets);
      },
      getItem(id) {
        id = normalizeKey(id);
        return Promise.resolve(_assets[id] ? _assets[id].import() : null);
      },
      getMeta(id) {
        id = normalizeKey(id);
        return Promise.resolve(_assets[id] ? _assets[id].meta : {});
      }
    };
    PATH_TRAVERSE_RE = /\.\.:|\.\.$/;
    DRIVER_NAME = "fs-lite";
    unstorage_47drivers_47fs_45lite = defineDriver((opts = {}) => {
      if (!opts.base) {
        throw createRequiredError(DRIVER_NAME, "base");
      }
      opts.base = resolve$1(opts.base);
      const r = (key) => {
        if (PATH_TRAVERSE_RE.test(key)) {
          throw createError2(
            DRIVER_NAME,
            `Invalid key: ${JSON.stringify(key)}. It should not contain .. segments`
          );
        }
        const resolved = join(opts.base, key.replace(/:/g, "/"));
        return resolved;
      };
      return {
        name: DRIVER_NAME,
        options: opts,
        hasItem(key) {
          return existsSync(r(key));
        },
        getItem(key) {
          return readFile(r(key), "utf8");
        },
        getItemRaw(key) {
          return readFile(r(key));
        },
        async getMeta(key) {
          const { atime, mtime, size, birthtime, ctime } = await promises.stat(r(key)).catch(() => ({}));
          return { atime, mtime, size, birthtime, ctime };
        },
        setItem(key, value) {
          if (opts.readOnly) {
            return;
          }
          return writeFile(r(key), value, "utf8");
        },
        setItemRaw(key, value) {
          if (opts.readOnly) {
            return;
          }
          return writeFile(r(key), value);
        },
        removeItem(key) {
          if (opts.readOnly) {
            return;
          }
          return unlink(r(key));
        },
        getKeys() {
          return readdirRecursive(r("."), opts.ignore);
        },
        async clear() {
          if (opts.readOnly || opts.noClear) {
            return;
          }
          await rmRecursive(r("."));
        }
      };
    });
    storage = createStorage({});
    storage.mount("/assets", assets);
    storage.mount("data", unstorage_47drivers_47fs_45lite({ "driver": "fsLite", "base": "D:\\Beniten\\admin\\api\\ite-site\\.data\\kv" }));
    cachedEventHandler = defineCachedEventHandler;
    config = useRuntimeConfig2();
    _routeRulesMatcher = toRouteMatcher(
      createRouter$1({ routes: config.nitro.routeRules })
    );
    _globalThis2 = typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof global !== "undefined" ? global : {};
    globalKey2 = "__unctx__";
    defaultNamespace2 = _globalThis2[globalKey2] || (_globalThis2[globalKey2] = createNamespace2());
    getContext = (key, opts = {}) => defaultNamespace2.get(key, opts);
    asyncHandlersKey2 = "__unctx_async_handlers__";
    asyncHandlers2 = _globalThis2[asyncHandlersKey2] || (_globalThis2[asyncHandlersKey2] = /* @__PURE__ */ new Set());
    chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_$";
    unsafeChars = /[<>\b\f\n\r\t\0\u2028\u2029]/g;
    reserved = /^(?:do|if|in|for|int|let|new|try|var|byte|case|char|else|enum|goto|long|this|void|with|await|break|catch|class|const|final|float|short|super|throw|while|yield|delete|double|export|import|native|return|switch|throws|typeof|boolean|default|extends|finally|package|private|abstract|continue|debugger|function|volatile|interface|protected|transient|implements|instanceof|synchronized)$/;
    escaped = {
      "<": "\\u003C",
      ">": "\\u003E",
      "/": "\\u002F",
      "\\": "\\\\",
      "\b": "\\b",
      "\f": "\\f",
      "\n": "\\n",
      "\r": "\\r",
      "	": "\\t",
      "\0": "\\0",
      "\u2028": "\\u2028",
      "\u2029": "\\u2029"
    };
    objectProtoOwnPropertyNames = Object.getOwnPropertyNames(Object.prototype).sort().join("\0");
    _Q2EFbo9rNa = defineNitroPlugin(async (nitroApp3) => {
      nitroApp3.hooks.hook("render:html", async (ctx, { event }) => {
        const routeOptions = getRouteRules2(event);
        const isIsland = process2.env.NUXT_COMPONENT_ISLANDS && event.path.startsWith("/__nuxt_island");
        event.path;
        const noSSR = event.context.nuxt?.noSSR || routeOptions.ssr === false && !isIsland || false;
        if (noSSR) {
          const siteConfig = Object.fromEntries(
            Object.entries(useSiteConfig(event)).map(([k, v]) => [k, toValue2(v)])
          );
          ctx.body.push(`<script>window.__NUXT_SITE_CONFIG__=${devalue(siteConfig)}</script>`);
        }
      });
    });
    plugins2 = [
      _Q2EFbo9rNa
    ];
    _9GHP3o = defineEventHandler(async (e) => {
      if (e.context.siteConfig)
        return;
      const runtimeConfig = useRuntimeConfig2(e);
      const config3 = runtimeConfig["nuxt-site-config"];
      const nitroApp3 = useNitroApp();
      const siteConfig = createSiteConfigStack({
        debug: config3.debug
      });
      const appConfig2 = useAppConfig(e);
      const nitroOrigin = useNitroOrigin(e);
      e.context.siteConfigNitroOrigin = nitroOrigin;
      {
        siteConfig.push({
          _context: "nitro:init",
          _priority: -4,
          url: nitroOrigin
        });
      }
      siteConfig.push({
        _context: "runtimeEnv",
        _priority: 0,
        ...runtimeConfig.site || {},
        ...runtimeConfig.public.site || {},
        // @ts-expect-error untyped
        ...envSiteConfig(globalThis._importMeta_.env)
        // just in-case, shouldn't be needed
      });
      const buildStack = config3.stack || [];
      buildStack.forEach((c) => siteConfig.push(c));
      if (appConfig2.site) {
        siteConfig.push({
          _priority: -2,
          _context: "app:config",
          ...appConfig2.site
        });
      }
      if (e.context._nitro.routeRules.site) {
        siteConfig.push({
          _context: "route-rules",
          ...e.context._nitro.routeRules.site
        });
      }
      const ctx = { siteConfig, event: e };
      await nitroApp3.hooks.callHook("site-config:init", ctx);
      e.context.siteConfig = ctx.siteConfig;
    });
    basicReporter = {
      log(logObj) {
        (console[logObj.type] || console.log)(...logObj.args);
      }
    };
    consola = createConsola();
    consola.consola = consola;
    createConsola({
      defaults: {
        tag: "@nuxt/sitemap"
      }
    });
    merger = createDefu((obj, key, value) => {
      if (Array.isArray(obj[key]) && Array.isArray(value))
        obj[key] = Array.from(/* @__PURE__ */ new Set([...obj[key], ...value]));
      return obj[key];
    });
    StringifiedRegExpPattern = /\/(.*?)\/([gimsuy]*)$/;
    _M504rJ = defineEventHandler(async (e) => {
      const fixPath = createSitePathResolver(e, { absolute: false, withBase: true });
      const { sitemapName: fallbackSitemapName, cacheMaxAgeSeconds, version: version3, xslColumns, xslTips } = useSimpleSitemapRuntimeConfig();
      setHeader(e, "Content-Type", "application/xslt+xml");
      if (cacheMaxAgeSeconds)
        setHeader(e, "Cache-Control", `public, max-age=${cacheMaxAgeSeconds}, must-revalidate`);
      else
        setHeader(e, "Cache-Control", `no-cache, no-store`);
      const { name: siteName, url: siteUrl } = useSiteConfig(e);
      const referrer = getHeader(e, "Referer") || "/";
      const referrerPath = parseURL(referrer).pathname;
      const isNotIndexButHasIndex = referrerPath !== "/sitemap.xml" && referrerPath !== "/sitemap_index.xml" && referrerPath.endsWith(".xml");
      const sitemapName = parseURL(referrer).pathname.split("/").pop()?.split("-sitemap")[0] || fallbackSitemapName;
      const title = `${siteName}${sitemapName !== "sitemap.xml" ? ` - ${sitemapName === "sitemap_index.xml" ? "index" : sitemapName}` : ""}`.replace(/&/g, "&amp;");
      const canonicalQuery = getQuery$1(referrer).canonical;
      const isShowingCanonical = typeof canonicalQuery !== "undefined" && canonicalQuery !== "false";
      const conditionalTips = [
        'You are looking at a <a href="https://developer.mozilla.org/en-US/docs/Web/XSLT/Transforming_XML_with_XSLT/An_Overview" style="color: #398465" target="_blank">XML stylesheet</a>. Read the <a href="https://nuxtseo.com/sitemap/guides/customising-ui" style="color: #398465" target="_blank">docs</a> to learn how to customize it. View the page source to see the raw XML.',
        `URLs missing? Check Nuxt Devtools Sitemap tab (or the <a href="${withQuery("/__sitemap__/debug.json", { sitemap: sitemapName })}" style="color: #398465" target="_blank">debug endpoint</a>).`
      ];
      if (!isShowingCanonical) {
        const canonicalPreviewUrl = withQuery(referrer, { canonical: "" });
        conditionalTips.push(`Your canonical site URL is <strong>${siteUrl}</strong>.`);
        conditionalTips.push(`You can preview your canonical sitemap by visiting <a href="${canonicalPreviewUrl}" style="color: #398465; white-space: nowrap;">${fixPath(canonicalPreviewUrl)}?canonical</a>`);
      } else {
        conditionalTips.push(`You are viewing the canonical sitemap. You can switch to using the request origin: <a href="${fixPath(referrer)}" style="color: #398465; white-space: nowrap ">${fixPath(referrer)}</a>`);
      }
      let columns = [...xslColumns];
      if (!columns.length) {
        columns = [
          { label: "URL", width: "50%" },
          { label: "Images", width: "25%", select: "count(image:image)" },
          { label: "Last Updated", width: "25%", select: "concat(substring(sitemap:lastmod,0,11),concat(' ', substring(sitemap:lastmod,12,5)),concat(' ', substring(sitemap:lastmod,20,6)))" }
        ];
      }
      return `<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="2.0"
                xmlns:html="http://www.w3.org/TR/REC-html40"
                xmlns:image="http://www.google.com/schemas/sitemap-image/1.1"
                xmlns:sitemap="http://www.sitemaps.org/schemas/sitemap/0.9"
                xmlns:xhtml="http://www.w3.org/1999/xhtml"
                xmlns:news="http://www.google.com/schemas/sitemap-news/0.9"
                xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
  <xsl:output method="html" version="1.0" encoding="UTF-8" indent="yes"/>
  <xsl:template match="/">
    <html xmlns="http://www.w3.org/1999/xhtml">
      <head>
        <title>XML Sitemap</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <style type="text/css">
          body {
            font-family: Inter, Helvetica, Arial, sans-serif;
            font-size: 14px;
            color: #333;
          }

          table {
            border: none;
            border-collapse: collapse;
          }

          .bg-yellow-200 {
            background-color: #fef9c3;
          }

          .p-5 {
            padding: 1.25rem;
          }

          .rounded {
            border-radius: 4px;
            }

          .shadow {
            box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
          }

          #sitemap tr:nth-child(odd) td {
            background-color: #f8f8f8 !important;
          }

          #sitemap tbody tr:hover td {
            background-color: #fff;
          }

          #sitemap tbody tr:hover td, #sitemap tbody tr:hover td a {
            color: #000;
          }

          .expl a {
            color: #398465
            font-weight: 600;
          }

          .expl a:visited {
            color: #398465
          }

          a {
            color: #000;
            text-decoration: none;
          }

          a:visited {
            color: #777;
          }

          a:hover {
            text-decoration: underline;
          }

          td {
            font-size: 12px;
          }

          .text-2xl {
            font-size: 2rem;
            font-weight: 600;
            line-height: 1.25;
          }

          th {
            text-align: left;
            padding-right: 30px;
            font-size: 12px;
          }

          thead th {
            border-bottom: 1px solid #000;
          }
          .fixed { position: fixed; }
          .right-2 { right: 2rem; }
          .top-2 { top: 2rem; }
          .w-30 { width: 30rem; }
          p { margin: 0; }
          li { padding-bottom: 0.5rem; line-height: 1.5; }
          h1 { margin: 0; }
          .mb-5 { margin-bottom: 1.25rem; }
          .mb-3 { margin-bottom: 0.75rem; }
        </style>
      </head>
      <body>
        <div style="grid-template-columns: 1fr 1fr; display: grid; margin: 3rem;">
            <div>
             <div id="content">
          <h1 class="text-2xl mb-3">XML Sitemap</h1>
          <h2>${title}</h2>
          ${isNotIndexButHasIndex ? `<p style="font-size: 12px; margin-bottom: 1rem;"><a href="${fixPath("/sitemap_index.xml")}">${fixPath("/sitemap_index.xml")}</a></p>` : ""}
          <xsl:if test="count(sitemap:sitemapindex/sitemap:sitemap) &gt; 0">
            <p class="expl" style="margin-bottom: 1rem;">
              This XML Sitemap Index file contains
              <xsl:value-of select="count(sitemap:sitemapindex/sitemap:sitemap)"/> sitemaps.
            </p>
            <table id="sitemap" cellpadding="3">
              <thead>
                <tr>
                  <th width="75%">Sitemap</th>
                  <th width="25%">Last Modified</th>
                </tr>
              </thead>
              <tbody>
                <xsl:for-each select="sitemap:sitemapindex/sitemap:sitemap">
                  <xsl:variable name="sitemapURL">
                    <xsl:value-of select="sitemap:loc"/>
                  </xsl:variable>
                  <tr>
                    <td>
                      <a href="{$sitemapURL}">
                        <xsl:value-of select="sitemap:loc"/>
                      </a>
                    </td>
                    <td>
                      <xsl:value-of
                        select="concat(substring(sitemap:lastmod,0,11),concat(' ', substring(sitemap:lastmod,12,5)),concat(' ', substring(sitemap:lastmod,20,6)))"/>
                    </td>
                  </tr>
                </xsl:for-each>
              </tbody>
            </table>
          </xsl:if>
          <xsl:if test="count(sitemap:sitemapindex/sitemap:sitemap) &lt; 1">
            <p class="expl" style="margin-bottom: 1rem;">
              This XML Sitemap contains
              <xsl:value-of select="count(sitemap:urlset/sitemap:url)"/> URLs.
            </p>
            <table id="sitemap" cellpadding="3">
              <thead>
                <tr>
                  ${columns.map((c) => `<th width="${c.width}">${c.label}</th>`).join("\n")}
                </tr>
              </thead>
              <tbody>
                <xsl:variable name="lower" select="'abcdefghijklmnopqrstuvwxyz'"/>
                <xsl:variable name="upper" select="'ABCDEFGHIJKLMNOPQRSTUVWXYZ'"/>
                <xsl:for-each select="sitemap:urlset/sitemap:url">
                  <tr>
                    <td>
                      <xsl:variable name="itemURL">
                        <xsl:value-of select="sitemap:loc"/>
                      </xsl:variable>
                      <a href="{$itemURL}">
                        <xsl:value-of select="sitemap:loc"/>
                      </a>
                    </td>
                    ${columns.filter((c) => c.label !== "URL").map((c) => `<td>
<xsl:value-of select="${c.select}"/>
</td>`).join("\n")}
                  </tr>
                </xsl:for-each>
              </tbody>
            </table>
          </xsl:if>
        </div>
        </div>
                    ${""}
        </div>
      </body>
    </html>
  </xsl:template>
</xsl:stylesheet>
`;
    });
    IS_VALID_W3C_DATE = [
      /(\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d:[0-5]\d\.\d+([+-][0-2]\d:[0-5]\d|Z))|(\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d:[0-5]\d([+-][0-2]\d:[0-5]\d|Z))|(\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d([+-][0-2]\d:[0-5]\d|Z))/,
      /^\d{4}-[01]\d-[0-3]\d$/,
      /^\d{4}-[01]\d$/,
      /^\d{4}$/
    ];
    _55hRT5 = defineEventHandler(async (e) => {
      const runtimeConfig = useSimpleSitemapRuntimeConfig();
      const { sitemaps } = runtimeConfig;
      if ("index" in sitemaps) {
        return sendRedirect(e, withBase("/sitemap_index.xml", useRuntimeConfig2().app.baseURL), 301);
      }
      return createSitemap(e, Object.values(sitemaps)[0], runtimeConfig);
    });
    _lazy_6ydn5w = () => Promise.resolve().then(() => (init_renderer(), renderer_exports));
    handlers = [
      { route: "/__nuxt_error", handler: _lazy_6ydn5w, lazy: true, middleware: false, method: void 0 },
      { route: "", handler: _9GHP3o, lazy: false, middleware: true, method: void 0 },
      { route: "/__sitemap__/style.xsl", handler: _M504rJ, lazy: false, middleware: false, method: void 0 },
      { route: "/sitemap.xml", handler: _55hRT5, lazy: false, middleware: false, method: void 0 },
      { route: "/**", handler: _lazy_6ydn5w, lazy: true, middleware: false, method: void 0 }
    ];
    nitroApp = createNitroApp();
    runNitroPlugins(nitroApp);
  }
});

// .netlify/functions-internal/server/main.mjs
init_nitro();
import process3 from "node:process";
import "vue";
import "consola/core";
globalThis._importMeta_ = { url: import.meta.url, env: process3.env };
var nitroApp2 = useNitroApp();
var handler = async (req) => {
  const url = new URL(req.url);
  const relativeUrl = `${url.pathname}${url.search}`;
  const r = await nitroApp2.localCall({
    url: relativeUrl,
    headers: req.headers,
    method: req.method,
    body: req.body
  });
  const headers = normalizeResponseHeaders({
    ...getCacheHeaders(url.pathname),
    ...r.headers
  });
  return new Response(r.body, {
    status: r.status,
    headers
  });
};
var ONE_YEAR_IN_SECONDS = 365 * 24 * 60 * 60;
function normalizeResponseHeaders(headers) {
  const outgoingHeaders = new Headers();
  for (const [name, header] of Object.entries(headers)) {
    if (name === "set-cookie") {
      for (const cookie of normalizeCookieHeader(header)) {
        outgoingHeaders.append("set-cookie", cookie);
      }
    } else if (header !== void 0) {
      outgoingHeaders.set(name, joinHeaders(header));
    }
  }
  return outgoingHeaders;
}
function getCacheHeaders(url) {
  const { isr } = getRouteRulesForPath(url);
  if (isr) {
    const maxAge = typeof isr === "number" ? isr : ONE_YEAR_IN_SECONDS;
    const revalidateDirective = typeof isr === "number" ? `stale-while-revalidate=${ONE_YEAR_IN_SECONDS}` : "must-revalidate";
    return {
      "Cache-Control": "public, max-age=0, must-revalidate",
      "Netlify-CDN-Cache-Control": `public, max-age=${maxAge}, ${revalidateDirective}, durable`
    };
  }
  return {};
}

// .netlify/functions-internal/server/server.mjs
var config2 = {
  name: "server handler",
  generator: "nuxt@3.14.159",
  path: "/*",
  excludedPath: ["/.netlify/*", "/_nuxt/builds/meta/*", "/_nuxt/builds/*", "/_nuxt/*"],
  preferStatic: true
};
export {
  config2 as config,
  handler as default
};
/*! Element Plus Icons Vue v2.3.1 */
/*!
 * pinia v2.2.6
 * (c) 2024 Eduardo San Martin Morote
 * @license MIT
 */
/*! #__NO_SIDE_EFFECTS__ */
/**
  * vee-validate v4.14.7
  * (c) 2024 Abdelrahman Awad
  * @license MIT
  */
